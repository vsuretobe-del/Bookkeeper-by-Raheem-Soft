import os
import re

def process_file(filepath):
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()

    orig = content

    # Increase widths by 40% (rounded) to ensure they never cut off
    def repl_width(m):
        key = m.group(1)
        val = int(m.group(2))
        new_val = int(val * 1.4)
        return f'{key}{new_val}'

    # The dictionary definition is like: widths = { ... }
    in_widths = False
    lines = content.split('\n')
    for i in range(len(lines)):
        if 'widths = {' in lines[i]:
            in_widths = True
        elif in_widths and '}' in lines[i]:
            in_widths = False
            
        if in_widths or ('widths = {' in lines[i]):
            lines[i] = re.sub(r'(\".*?\"\s*:\s*)(\d+)', repl_width, lines[i])
            lines[i] = re.sub(r'(\'.*?\'\s*:\s*)(\d+)', repl_width, lines[i])

    content = '\n'.join(lines)

    # Now change self.tree.column(c, width=..., anchor=...)
    def repl_col(m):
        c_var = m.group(1)
        w_var = m.group(2)
        a_var = m.group(3)
        return f'self.tree.column({c_var}, width={w_var}, minwidth={w_var}, anchor={a_var}, stretch=False)'
        
    content = re.sub(r'self\.tree\.column\(([^,]+),\s*width=([^,]+),\s*anchor=([^\)]+)\)', repl_col, content)
    
    # Add disable_resize binding if not present
    if 'def disable_resize' not in content and 'self.tree.heading' in content:
        bind_code = '''
        def disable_resize(event):
            if self.tree.identify_region(event.x, event.y) == "separator":
                return "break"
        self.tree.bind('<Button-1>', disable_resize)
        self.tree.bind('<B1-Motion>', disable_resize)
'''
        if 'style = ttk.Style()' in content:
            content = content.replace('style = ttk.Style()', bind_code.lstrip() + '        style = ttk.Style()')

    if content != orig:
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f'Patched {filepath}')

for f in os.listdir('.'):
    if f.startswith('report_') and f.endswith('.py') and f != 'report_sales_register.py':
        process_file(f)
