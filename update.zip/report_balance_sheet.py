import tkinter as tk
from tkinter import ttk, messagebox
import db
import datetime

BG_DARK = "#2B579A"
WHITE = "#FFFFFF"
GRAY = "#E0E0E0"
DARK_GRAY = "#666666"

FONT = ("Segoe UI", 10)
FONT_BOLD = ("Segoe UI", 10, "bold")
TITLE_FONT = ("Segoe UI", 14, "bold")
CELL_FONT = ("Segoe UI", 9)

class ReportBalanceSheet(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent, bg=WHITE)
        self.app_ref = parent
        self.title("Balance Sheet")
        self.state("zoomed")
        self.geometry("1024x768")
        
        try:
            self.end_d = self.app_ref.reporting_to_dp.get_date().strftime("%Y-%m-%d")
        except:
            today = datetime.date.today()
            self.end_d = today.strftime("%Y-%m-%d")
            
        self.build_ui()
        self.load_data()
        
    def not_implemented(self, event=None):
        messagebox.showinfo("Coming Soon", "This feature is not implemented yet.")

    def build_ui(self):
        # Toolbar
        tb = tk.Frame(self, bg=WHITE)
        tb.pack(fill="x", padx=10, pady=5)
        
        btn_exit = tk.Button(tb, text="✖ Ctrl+Q: Exit", bg="black", fg="white", font=("Tahoma", 8, "bold"), padx=4, pady=2, relief="flat", cursor="hand2", command=self.destroy)
        btn_exit.pack(side="left", padx=2)
        
        btn_print = tk.Button(tb, text="🖨 Alt+P: Print", bg="white", fg="black", font=("Tahoma", 8), padx=4, pady=2, relief="flat", cursor="hand2", command=self.not_implemented)
        btn_print.pack(side="left", padx=2)
        
        btn_word = tk.Button(tb, text="📄 Ctrl+W: Open In MS Word", bg="#DCDCDC", fg="black", font=("Tahoma", 8), padx=4, pady=2, relief="flat", cursor="hand2", command=self.not_implemented)
        btn_word.pack(side="left", padx=2)
        
        btn_excel = tk.Button(tb, text="📊 Ctrl+E: Open In MS Excel", bg="#DCDCDC", fg="black", font=("Tahoma", 8), padx=4, pady=2, relief="flat", cursor="hand2", command=self.not_implemented)
        btn_excel.pack(side="left", padx=2)
        
        btn_pdf = tk.Button(tb, text="📄 Ctrl+V: Open In PDF", bg="white", fg="black", font=("Tahoma", 8), padx=4, pady=2, relief="flat", cursor="hand2", command=self.not_implemented)
        btn_pdf.pack(side="left", padx=2)
        
        btn_browser = tk.Button(tb, text="🌐 Ctrl+H: Open In Browser", bg="black", fg="white", font=("Tahoma", 8, "bold"), padx=4, pady=2, relief="flat", cursor="hand2", command=self.not_implemented)
        btn_browser.pack(side="left", padx=2)
        
        # Additional Toolbar (Alt+F1)
        tb2 = tk.Frame(self, bg="#F0F0F0")
        tb2.pack(fill="x")
        btn_f1 = tk.Button(tb2, text="Alt+F1: View Detailed/Condensed Report", bg="#F0F0F0", fg="black", font=("Tahoma", 8), relief="flat", cursor="hand2", command=self.not_implemented)
        btn_f1.pack(side="left", padx=10, pady=2)
        
        tk.Frame(self, bg="#bbb", height=1).pack(fill="x")
        
        # Header
        self.header_f = tk.Frame(self, bg=WHITE)
        self.header_f.pack(fill="x", padx=20, pady=(20, 10))
        
        lbl_co = tk.Label(self.header_f, text="ALHUMDULILLAH", font=FONT_BOLD, bg=WHITE, fg=BG_DARK)
        lbl_co.pack(anchor="w")
        
        lbl_report = tk.Label(self.header_f, text=f"BALANCE SHEET As On {self.end_d}", font=TITLE_FONT, bg=WHITE, fg="black")
        lbl_report.pack(anchor="w")
        
        # Treeview container
        self.tree_f = tk.Frame(self, bg=WHITE)
        self.tree_f.pack(fill="both", expand=True, padx=20, pady=10)
        
    def format_money(self, val, show_currency=False):
        if val is None or val == 0:
            return "0"
        prefix = "Rs" if show_currency else ""
        if val < 0:
            return f"-{prefix}{abs(val):,.0f}"
        return f"{prefix}{val:,.0f}"

    def build_treeview(self):
        for widget in self.tree_f.winfo_children():
            widget.destroy()
            
        cols = ["DESC", "E1", "E2", "AMOUNT"]
                
        self.tree = ttk.Treeview(self.tree_f, columns=cols, show="headings", height=25, selectmode="none")
        
        self.tree.heading("DESC", text="")
        self.tree.column("DESC", width=400, minwidth=400, anchor="w", stretch=False)
        
        self.tree.heading("E1", text="")
        self.tree.column("E1", width=100, minwidth=100, anchor="c", stretch=False)
        
        self.tree.heading("E2", text="")
        self.tree.column("E2", width=100, minwidth=100, anchor="c", stretch=False)
        
        self.tree.heading("AMOUNT", text="")
        self.tree.column("AMOUNT", width=150, minwidth=150, anchor="e", stretch=False)
            
        def disable_resize(event):
            if self.tree.identify_region(event.x, event.y) == "separator":
                return "break"
        self.tree.bind('<Button-1>', disable_resize)
        self.tree.bind('<B1-Motion>', disable_resize)
        style = ttk.Style()
        style.configure("Treeview", font=CELL_FONT, rowheight=30)
        # We don't want standard headings to show because we will render "LIABILITIES" and "ASSETS" as rows.
        # But Treeview requires headings to be shown unless we set show="tree" but we want column separation.
        # So we just set empty text for headings, and style them thin if possible.
        
        self.tree.tag_configure("row", font=CELL_FONT)
        self.tree.tag_configure("bold_row", font=FONT_BOLD)
        self.tree.tag_configure("header_row", font=FONT_BOLD, background="#f0f0f0")
        self.tree.tag_configure("grand", font=FONT_BOLD, background="#f0f0f0")
        
        ysb = ttk.Scrollbar(self.tree_f, orient="vertical", command=self.tree.yview)
        xsb = ttk.Scrollbar(self.tree_f, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscroll=ysb.set, xscroll=xsb.set)
        
        ysb.pack(side="right", fill="y")
        xsb.pack(side="bottom", fill="x")
        self.tree.pack(fill="both", expand=True)

    def load_data(self):
        self.build_treeview()
        try:
            data = db.get_detailed_balance_sheet(self.end_d)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to fetch data:\n{e}")
            return
            
        # 1. LIABILITIES Section
        self.tree.insert("", "end", values=["LIABILITIES", "", "", "AMOUNT"], tags=("header_row",))
        
        for item in data['liabilities']:
            val_str = self.format_money(item['val'])
            if item['name'] == 'Profit & Loss A/c':
                self.tree.insert("", "end", values=[item['name'], "", "", val_str], tags=("bold_row",))
                self.tree.insert("", "end", values=["   Opening Balance", "0", "", ""], tags=("row",))
                self.tree.insert("", "end", values=["   Selected Period", val_str, "", ""], tags=("row",))
            else:
                self.tree.insert("", "end", values=[item['name'], "", "", val_str], tags=("row",))
                
        tot = self.format_money(data['total'], True)
        self.tree.insert("", "end", values=["LIABILITIES(TOTAL)", "", "", tot], tags=("grand",))
        
        # 2. ASSETS Section
        self.tree.insert("", "end", values=["ASSETS", "", "", "AMOUNT"], tags=("header_row",))
        
        for item in data['assets']:
            val_str = self.format_money(item['val'])
            self.tree.insert("", "end", values=[item['name'], "", "", val_str], tags=("row",))
            
        self.tree.insert("", "end", values=["ASSETS(TOTAL)", "", "", tot], tags=("grand",))

if __name__ == "__main__":
    root = tk.Tk()
    root.withdraw()
    app = ReportBalanceSheet(root)
    root.mainloop()
