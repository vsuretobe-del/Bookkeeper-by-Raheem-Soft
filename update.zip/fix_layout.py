import sys
with open('bookkeeper.py', 'r', encoding='utf-8') as f:
    lines = f.readlines()
    
# Find the start and end of the right column block
start_idx = -1
end_idx = -1
for i, l in enumerate(lines):
    if 'fields[\'tax_regn\'] = create_combo(rx+100' in l:
        start_idx = i - 1
    if 'fields[\'defaultdiscountpercent\'].insert(0,' in l:
        end_idx = i + 3
        break

if start_idx != -1 and end_idx != -1:
    new_block = [
        '        create_lbl(rx-70, 190, "Default Tax Account", width=20)\n',
        '        fields[\'tax_regn\'] = create_combo(rx+90, 190, 25, ["VAT 0%", "VAT 5%", "VAT 15%"])\n\n',
        '        create_lbl(rx-70, 220, "Additional Cess", width=20)\n',
        '        fields[\'additional_cess\'] = create_entry(rx+90, 220, 25)\n',
        '        fields[\'additional_cess\'].insert(0, "0")\n\n',
        '        tk.Label(main_frame, text="Exclusive Tax", bg="#ffffff", fg="#000", font=FONT).place(x=rx+90, y=260)\n',
        '        tk.Label(main_frame, text="Inclusive Tax", bg="#ffffff", fg="#000", font=FONT).place(x=rx+210, y=260)\n\n',
        '        create_lbl(rx-80, 290, "Default Purchase Price", width=20)\n',
        '        fields[\'defaultpurchaseprice\'] = create_entry(rx+90, 290, 12)\n',
        '        fields[\'defaultpurchaseprice\'].insert(0, "0")\n',
        '        inc_pur = create_entry(rx+210, 290, 12)\n',
        '        inc_pur.insert(0, "0")\n\n',
        '        create_lbl(rx-80, 320, "Default Sale Price", width=20)\n',
        '        fields[\'defaultsellingprice\'] = create_entry(rx+90, 320, 12)\n',
        '        fields[\'defaultsellingprice\'].insert(0, "0")\n',
        '        inc_sal = create_entry(rx+210, 320, 12)\n',
        '        inc_sal.insert(0, "0")\n\n',
        '        create_lbl(rx-80, 350, "Default Discount %", width=20)\n',
        '        fields[\'defaultdiscountpercent\'] = create_entry(rx+90, 350, 12)\n',
        '        fields[\'defaultdiscountpercent\'].insert(0, "0")\n',
        '        inc_dis = create_entry(rx+210, 350, 12)\n',
        '        inc_dis.insert(0, "0")\n'
    ]
    lines[start_idx:end_idx] = new_block
    with open('bookkeeper.py', 'w', encoding='utf-8') as f:
        f.writelines(lines)
    print('Fixed layout!')
else:
    print('Could not find indices.', start_idx, end_idx)
