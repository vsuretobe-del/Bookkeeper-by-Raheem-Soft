with open('bookkeeper.py', 'r', encoding='utf-8') as f:
    content = f.read()

content = content.replace("command=self._new_invoice_form).pack(side=\"left\", padx=2)", "command=self._open_create_voucher).pack(side=\"left\", padx=2)")

with open('bookkeeper.py', 'w', encoding='utf-8') as f:
    f.write(content)
print("Mapped New Invoice to _open_create_voucher")
