with open('bookkeeper.py', 'r', encoding='utf-8') as f:
    lines = f.readlines()

new_lines = []
for line in lines:
    if "ref_box" in line: continue
    new_lines.append(line)

with open('bookkeeper.py', 'w', encoding='utf-8') as f:
    f.writelines(new_lines)
print("Removed all ref_box lines")
