import tkinter as tk
from tkinter import ttk, messagebox
import db
from datetime import datetime
from autocomplete import AutocompleteCombobox

BG_BLUE = "#2b579a"
BG_WHITE = "#ffffff"
FONT = ("Segoe UI", 10)
FONT_BOLD = ("Segoe UI", 10, "bold")

class OutstandingReportView:
    def __init__(self, master, app_ref, is_receivable=False):
        self.master = tk.Toplevel(master)
        self.app_ref = app_ref
        self.is_receivable = is_receivable
        self.title_text = "OUTSTANDING RECEIVABLE" if is_receivable else "OUTSTANDING PAYABLE"
        
        self.master.title("Outstanding Receivable" if is_receivable else "Outstanding Payable")
        self.master.geometry("1100x700")
        self.master.configure(bg=BG_WHITE)
        self.master.grab_set()
        
        self._build_ui()
        self.load_combos()
        
    def _build_ui(self):
        # 1. Top Toolbar
        top_bar = tk.Frame(self.master, bg=BG_WHITE)
        top_bar.pack(fill="x", side="top")
        
        buttons = [
            ("✖ Ctrl+Q: Exit", self.master.destroy),
            ("🖨️ Alt+P: Print", self.not_implemented),
            ("📝 Ctrl+W: Open In MS Word", self.not_implemented),
            ("📊 Ctrl+E: Open In MS Excel", self.not_implemented),
            ("📄 Ctrl+V: Open In PDF", self.not_implemented),
            ("🌐 Ctrl+H: Open In Browser", self.not_implemented)
        ]
        for text, cmd in buttons:
            btn = tk.Button(top_bar, text=text, font=("Segoe UI", 9), relief="flat", bg=BG_WHITE, cursor="hand2", command=cmd)
            btn.pack(side="left", padx=2, pady=2)
            
        tk.Frame(self.master, bg="#cccccc", height=1).pack(fill="x")
        
        # 2. Main Content
        content_fr = tk.Frame(self.master, bg=BG_WHITE)
        content_fr.pack(fill="both", expand=True)
        
        # Left Panel
        left_fr = tk.Frame(content_fr, bg=BG_BLUE, width=280)
        left_fr.pack(side="left", fill="y")
        left_fr.pack_propagate(False)
        
        # Right Panel
        self.right_fr = tk.Frame(content_fr, bg=BG_WHITE)
        self.right_fr.pack(side="left", fill="both", expand=True)
        
        # --- Left Panel Content ---
        self.filter_mode = tk.StringVar(value="group")
        
        rb_group = tk.Radiobutton(left_fr, text="Account Group", variable=self.filter_mode, value="group", 
                                  bg=BG_BLUE, fg="white", font=FONT, selectcolor=BG_BLUE, activebackground=BG_BLUE, activeforeground="white", command=self.on_mode_change)
        rb_group.pack(anchor="w", padx=10, pady=(10, 2))
        
        self.cb_group = AutocompleteCombobox(left_fr, font=FONT, state="readonly")
        self.cb_group.pack(fill="x", padx=20, pady=2)
        
        rb_name = tk.Radiobutton(left_fr, text="F9: Account Name:", variable=self.filter_mode, value="name", 
                                  bg=BG_BLUE, fg="white", font=FONT, selectcolor=BG_BLUE, activebackground=BG_BLUE, activeforeground="white", command=self.on_mode_change)
        rb_name.pack(anchor="w", padx=10, pady=(10, 2))
        
        self.cb_name = AutocompleteCombobox(left_fr, font=FONT, state="readonly")
        self.cb_name.pack(fill="x", padx=20, pady=2)
        
        self.chk_narration = tk.BooleanVar()
        chk = tk.Checkbutton(left_fr, text="Display Narration", variable=self.chk_narration, bg=BG_BLUE, fg="white", font=FONT, 
                             selectcolor=BG_BLUE, activebackground=BG_BLUE, activeforeground="white")
        chk.pack(anchor="w", padx=15, pady=15)
        
        btn_display = tk.Button(left_fr, text="Display", bg="#2b579a", fg="white", font=FONT, relief="raised", bd=2, command=self.display_report)
        btn_display.pack(fill="x", padx=20, pady=20)
        
        # --- Right Panel Content ---
        self.report_header = tk.Frame(self.right_fr, bg=BG_WHITE)
        self.report_header.pack(fill="x", pady=10, padx=10)
        
        self.lbl_company = tk.Label(self.report_header, text=db.get_company_name().upper() if db.get_company_name() else "ALHUMDULILLAH", 
                                    font=("Segoe UI", 14, "bold"), bg=BG_WHITE, fg="#2b579a")
        self.lbl_company.pack(anchor="w")
        
        self.lbl_title = tk.Label(self.report_header, text=self.title_text, font=("Segoe UI", 12, "bold"), bg=BG_WHITE, fg="black")
        self.lbl_title.pack(anchor="w")
        
        self.lbl_dates = tk.Label(self.report_header, text="", font=("Segoe UI", 12, "bold"), bg=BG_WHITE, fg="black")
        self.lbl_dates.pack(anchor="w")
        
        # Treeview
        tree_fr = tk.Frame(self.right_fr, bg=BG_WHITE)
        tree_fr.pack(fill="both", expand=True, padx=10, pady=10)
        
        columns = ("date", "vch_no", "po_no", "party_name", "phone", "inv_amt", "out_amt", "due_date", "overdue")
        self.tree = ttk.Treeview(tree_fr, columns=columns, show="headings", selectmode="none")
        
        self.tree.heading("date", text="DATE")
        self.tree.heading("vch_no", text="VCH NO.")
        self.tree.heading("po_no", text="PURCHASE ORDER NO" if self.is_receivable else "SUPPLIER INVOICE NO")
        self.tree.heading("party_name", text="PARTY'S NAME")
        self.tree.heading("phone", text="PHONE NO")
        self.tree.heading("inv_amt", text="INVOICE AMOUNT")
        self.tree.heading("out_amt", text="OUTSTANDING AMOUNT")
        self.tree.heading("due_date", text="DUE DATE")
        self.tree.heading("overdue", text="OVERDUE BY DAYS")
        
        self.tree.column("date", width=100, minwidth=100, anchor="center", stretch=False)
        self.tree.column("vch_no", width=100, minwidth=100, anchor="w", stretch=False)
        self.tree.column("po_no", width=120, minwidth=120, anchor="center", stretch=False)
        self.tree.column("party_name", width=200, minwidth=200, anchor="w", stretch=False)
        self.tree.column("phone", width=120, minwidth=120, anchor="w", stretch=False)
        self.tree.column("inv_amt", width=120, minwidth=120, anchor="e", stretch=False)
        self.tree.column("out_amt", width=150, minwidth=150, anchor="e", stretch=False)
        self.tree.column("due_date", width=100, minwidth=100, anchor="center", stretch=False)
        self.tree.column("overdue", width=120, minwidth=120, anchor="center", stretch=False)
        
        scrollbar_y = ttk.Scrollbar(tree_fr, orient="vertical", command=self.tree.yview)
        scrollbar_x = ttk.Scrollbar(tree_fr, orient="horizontal", command=self.tree.xview)
        
        self.tree.configure(yscrollcommand=scrollbar_y.set, xscrollcommand=scrollbar_x.set)
        
        scrollbar_y.pack(side="right", fill="y")
        scrollbar_x.pack(side="bottom", fill="x")
        self.tree.pack(side="left", fill="both", expand=True)
        
        self.tree.tag_configure("even", background="#f9f9f9")
        self.tree.tag_configure("odd", background="#ffffff")
        self.tree.tag_configure("bold", font=("Segoe UI", 10, "bold"), background="#f0f0f0")
        
        self.on_mode_change()
        
    def load_combos(self):
        conn = db.get_conn()
        base_group = "Sundry Debtors" if self.is_receivable else "Sundry Creditors"
        
        self.cb_group['values'] = ["ALL", base_group]
        self.cb_group.current(0)
        
        names = conn.execute("SELECT aname FROM account_detail WHERE account_group=?", (base_group)).fetchall()
        self.cb_name['values'] = ["ALL"] + [n['aname'] for n in names]
        self.cb_name.current(0)
        conn.close()
        
    def on_mode_change(self):
        if self.filter_mode.get() == "group":
            self.cb_group.config(state="readonly")
            self.cb_name.config(state="disabled")
        else:
            self.cb_group.config(state="disabled")
            self.cb_name.config(state="readonly")
            
    def display_report(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
            
        mode = self.filter_mode.get()
        is_group = (mode == "group")
        name_or_group = self.cb_group.get() if is_group else self.cb_name.get()
        
        # Fetch dates from BookKeeper app
        start_date = "2020-01-01"
        end_date = datetime.today().strftime("%Y-%m-%d")
        
        if hasattr(self.app_ref, 'reporting_from') and hasattr(self.app_ref, 'reporting_to'):
            if hasattr(self.app_ref.reporting_from, 'get_date') and self.app_ref.reporting_from.get_date():
                start_date = self.app_ref.reporting_from.get_date().strftime("%Y-%m-%d")
            if hasattr(self.app_ref.reporting_to, 'get_date') and self.app_ref.reporting_to.get_date():
                end_date = self.app_ref.reporting_to.get_date().strftime("%Y-%m-%d")
                
        self.lbl_dates.config(text=f"{start_date} to {end_date}")
        
        data = db.get_outstanding_data(self.is_receivable, name_or_group, is_group, start_date, end_date)
        
        total_inv = 0
        total_out = 0
        
        for i, row in enumerate(data):
            tag = "even" if i % 2 == 0 else "odd"
            
            d_date = row['date']
            vch_no = row['vch_no']
            po_no = "" # Can implement later if POs exist
            p_name = row['party_name']
            phone = row['phone']
            inv_amt = row['invoice_amount']
            out_amt = row['outstanding_amount']
            due_date = row['due_date']
            overdue = row['overdue_days']
            
            total_inv += inv_amt
            total_out += out_amt
            
            f_inv = f"{inv_amt:,.0f}" if inv_amt > 0 else ""
            f_out = f"{out_amt:,.0f}" if out_amt > 0 else ""
            
            self.tree.insert("", "end", values=(d_date, vch_no, po_no, p_name, phone, f_inv, f_out, due_date, overdue), tags=(tag))
            
        # Optional dummy filter row, but sticking to actual data:
        self.tree.insert("", "end", values=("TOTAL", "", "", "", "", f"RS{total_inv:,.0f}", f"RS{total_out:,.0f}", "", ""), tags=("bold"))

    def not_implemented(self):
        messagebox.showinfo("Coming Soon", "This feature is currently under development.")
