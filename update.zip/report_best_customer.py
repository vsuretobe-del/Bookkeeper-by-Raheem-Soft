import tkinter as tk
from tkinter import ttk, messagebox
import db
import datetime

BG_DARK = "#2B579A"
WHITE = "#FFFFFF"
GRAY = "#E0E0E0"
DARK_GRAY = "#666666"

FONT = ("Segoe UI", 10)
FONT_BOLD = ("Segoe UI", 10, "bold")
TITLE_FONT = ("Segoe UI", 14, "bold")
CELL_FONT = ("Segoe UI", 9)

class ReportBestCustomer(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent, bg=WHITE)
        self.app_ref = parent
        self.title("Best Customer")
        self.state("zoomed")
        self.geometry("1024x768")
        
        # Try to get dates from the main app
        try:
            self.start_d = self.app_ref.reporting_from_dp.get_date().strftime("%Y-%m-%d")
            self.end_d = self.app_ref.reporting_to_dp.get_date().strftime("%Y-%m-%d")
        except:
            today = datetime.date.today()
            self.start_d = datetime.date(today.year if today.month >= 4 else today.year - 1, 4, 1).strftime("%Y-%m-%d")
            self.end_d = today.strftime("%Y-%m-%d")
            
        self.build_ui()
        self.load_data()
        
    def not_implemented(self, event=None):
        messagebox.showinfo("Coming Soon", "This feature is not implemented yet.")

    def build_ui(self):
        # Toolbar
        tb = tk.Frame(self, bg=WHITE)
        tb.pack(fill="x", padx=10, pady=5)
        
        btn_exit = tk.Button(tb, text="✖ Ctrl+Q: Exit", bg="black", fg="white", font=("Tahoma", 8, "bold"), padx=4, pady=2, relief="flat", cursor="hand2", command=self.destroy)
        btn_exit.pack(side="left", padx=2)
        
        btn_print = tk.Button(tb, text="🖨 Alt+P: Print", bg="white", fg="black", font=("Tahoma", 8), padx=4, pady=2, relief="flat", cursor="hand2", command=self.not_implemented)
        btn_print.pack(side="left", padx=2)
        
        btn_word = tk.Button(tb, text="📄 Ctrl+W: Open In MS Word", bg="#DCDCDC", fg="black", font=("Tahoma", 8), padx=4, pady=2, relief="flat", cursor="hand2", command=self.not_implemented)
        btn_word.pack(side="left", padx=2)
        
        btn_excel = tk.Button(tb, text="📊 Ctrl+E: Open In MS Excel", bg="#DCDCDC", fg="black", font=("Tahoma", 8), padx=4, pady=2, relief="flat", cursor="hand2", command=self.not_implemented)
        btn_excel.pack(side="left", padx=2)
        
        btn_pdf = tk.Button(tb, text="📄 Ctrl+V: Open In PDF", bg="white", fg="black", font=("Tahoma", 8), padx=4, pady=2, relief="flat", cursor="hand2", command=self.not_implemented)
        btn_pdf.pack(side="left", padx=2)
        
        btn_browser = tk.Button(tb, text="🌐 Ctrl+H: Open In Browser", bg="black", fg="white", font=("Tahoma", 8, "bold"), padx=4, pady=2, relief="flat", cursor="hand2", command=self.not_implemented)
        btn_browser.pack(side="left", padx=2)
        
        tk.Frame(self, bg="#bbb", height=1).pack(fill="x")
        
        # Header
        self.header_f = tk.Frame(self, bg=WHITE)
        self.header_f.pack(fill="x", padx=20, pady=(20, 10))
        
        lbl_co = tk.Label(self.header_f, text="ALHUMDULILLAH", font=FONT_BOLD, bg=WHITE, fg=BG_DARK)
        lbl_co.pack(anchor="w")
        
        lbl_report = tk.Label(self.header_f, text="Best Customers", font=TITLE_FONT, bg=WHITE, fg="black")
        lbl_report.pack(anchor="w")
        
        lbl_date_range = tk.Label(self.header_f, text=f"From {self.start_d} To {self.end_d}", font=FONT_BOLD, bg=WHITE, fg="black")
        lbl_date_range.pack(anchor="w")
        
        # Custom Treeview equivalent (Since we need 2 rows in the header)
        self.tree_f = tk.Frame(self, bg=WHITE)
        self.tree_f.pack(fill="both", expand=True, padx=20, pady=10)
        
    def format_money(self, val):
        if val is None or val == 0:
            return "0"
        if val < 0:
            return f"-{abs(val):,.0f}"
        return f"{val:,.0f}"
        
    def format_total(self, val):
        if val is None or val == 0:
            return "RS0"
        if val < 0:
            return f"-RS{abs(val):,.0f}"
        return f"RS{val:,.0f}"

    def build_treeview(self):
        for widget in self.tree_f.winfo_children():
            widget.destroy()
            
        cols = ["CUSTOMER", "B/F", "SALES_INC", "SALES_EXC", "TAX", "C/F"]
                
        self.tree = ttk.Treeview(self.tree_f, columns=cols, show="headings", height=20, selectmode="none")
        
        # Since standard Tkinter Treeview doesn't support multi-line headers,
        # we will set the headings to approximate the screenshot.
        self.tree.heading("CUSTOMER", text="CUSTOMER")
        self.tree.column("CUSTOMER", width=250, minwidth=250, anchor="w", stretch=False)
        
        self.tree.heading("B/F", text="B/F")
        self.tree.column("B/F", width=100, minwidth=100, anchor="e", stretch=False)
        
        self.tree.heading("SALES_INC", text="SALES\n(INCLUDING OTHER CHARGE & TAX)")
        self.tree.column("SALES_INC", width=250, minwidth=250, anchor="e", stretch=False)
        
        self.tree.heading("SALES_EXC", text="SALES\n(EXCLUDING OTHER CHARGE & TAX)")
        self.tree.column("SALES_EXC", width=250, minwidth=250, anchor="e", stretch=False)
        
        self.tree.heading("TAX", text="TAX")
        self.tree.column("TAX", width=100, minwidth=100, anchor="e", stretch=False)
        
        self.tree.heading("C/F", text="C/F")
        self.tree.column("C/F", width=100, minwidth=100, anchor="e", stretch=False)
            
        def disable_resize(event):
            if self.tree.identify_region(event.x, event.y) == "separator":
                return "break"
        self.tree.bind('<Button-1>', disable_resize)
        self.tree.bind('<B1-Motion>', disable_resize)
        style = ttk.Style()
        style.configure("Treeview", font=CELL_FONT, rowheight=35)
        # Note: Tkinter Treeview Heading text doesn't easily support newlines in all OS. 
        # But we pass it and hope it renders reasonably.
        style.configure("Treeview.Heading", font=FONT_BOLD)
        
        self.tree.tag_configure("row", font=CELL_FONT)
        self.tree.tag_configure("bold_row", font=FONT_BOLD)
        self.tree.tag_configure("grand", font=FONT_BOLD, background="#f0f0f0")
        
        ysb = ttk.Scrollbar(self.tree_f, orient="vertical", command=self.tree.yview)
        xsb = ttk.Scrollbar(self.tree_f, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscroll=ysb.set, xscroll=xsb.set)
        
        ysb.pack(side="right", fill="y")
        xsb.pack(side="bottom", fill="x")
        self.tree.pack(fill="both", expand=True)

    def load_data(self):
        self.build_treeview()
        try:
            data = db.get_best_customers_data(self.start_d, self.end_d)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to fetch data:\n{e}")
            return
            
        tot_bf = 0
        tot_inc = 0
        tot_exc = 0
        tot_tax = 0
        tot_cf = 0
        
        for row in data:
            name = row['name']
            bf = row['bf']
            inc = row['sales_inc']
            exc = row['sales_exc']
            tax = row['tax']
            cf = row['cf']
            
            tot_bf += bf
            tot_inc += inc
            tot_exc += exc
            tot_tax += tax
            tot_cf += cf
            
            vals = [
                name,
                self.format_money(bf),
                self.format_money(inc),
                self.format_money(exc),
                self.format_money(tax),
                self.format_money(cf)
            ]
            self.tree.insert("", "end", values=vals, tags=("bold_row",))
            
        # Grand Total
        grand_vals = [
            "TOTAL",
            self.format_total(tot_bf),
            self.format_total(tot_inc),
            self.format_total(tot_exc),
            self.format_total(tot_tax),
            self.format_total(tot_cf)
        ]
        self.tree.insert("", "end", values=grand_vals, tags=("grand",))

if __name__ == "__main__":
    root = tk.Tk()
    root.withdraw()
    app = ReportBestCustomer(root)
    root.mainloop()
