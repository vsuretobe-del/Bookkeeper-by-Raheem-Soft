with open('invoice_preview.py', 'r', encoding='utf-8') as f:
    content = f.read()

content = content.replace("item['name']", "item.get('name', item.get('item_name', ''))")
content = content.replace("item['unit']", "item.get('unit', '')")

with open('invoice_preview.py', 'w', encoding='utf-8') as f:
    f.write(content)
print("invoice_preview.py patched")
