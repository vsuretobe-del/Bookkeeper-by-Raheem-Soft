import re

with open('bookkeeper.py', 'r', encoding='utf-8') as f:
    content = f.read()

# Fix _account_form
broken_str = '''        if existing:
            for k, w in fields.items():
                if k in existing and existing[k] is not None:
                    if hasattr(w, 'set'):
                        w.set(existing[k])
                    elif hasattr(w, 'insert'):
                        w.delete(0, "end")
                        w.insert(0, str(existing[k]))
                    elif hasattr(w, 'delete'):
                        w.delete("1.0", "end")
                        w.insert("1.0", str(existing[k]))
            calc_inc()

        def save(e=None):
            data = {}
            for k, var in fields.items():
                data[k] = var.get() if hasattr(var, 'get') else var.get("1.0", "end-1c").strip()
                
            name = data.get('item', '').strip()
            if not name:
                messagebox.showerror("Error", "Item Name is required!", parent=win)
                fields['item'].focus_set()
                return

            try:
            except ValueError:'''

fixed_str = '''        if existing:
            for k, w in fields.items():
                if k in existing and existing[k] is not None:
                    if hasattr(w, 'set'):
                        w.set(existing[k])
                    elif hasattr(w, 'insert'):
                        w.delete(0, "end")
                        w.insert(0, str(existing[k]))
                    elif hasattr(w, 'delete'):
                        w.delete("1.0", "end")
                        w.insert("1.0", str(existing[k]))

        def save(e=None):
            data = {}
            for k, var in fields.items():
                data[k] = var.get() if hasattr(var, 'get') else var.get("1.0", "end-1c").strip()
                
            name = data.get('aname', '').strip()
            if not name:
                messagebox.showerror("Error", "Account Name is required!", parent=win)
                fields['aname'].focus_set()
                return
                
            try:
                if data.get("op_bal"): data["op_bal"] = float(data["op_bal"])
            except ValueError:'''

if broken_str in content:
    content = content.replace(broken_str, fixed_str)
    with open('bookkeeper.py', 'w', encoding='utf-8') as f:
        f.write(content)
    print("Fixed _account_form")
else:
    print("Broken string not found")

