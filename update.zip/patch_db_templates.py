import re

with open('db.py', 'r', encoding='utf-8') as f:
    text = f.read()

# 1. Update create_invoice
old_create = '''def create_invoice(invoice_no, inv_type, account_id, date, line_items, notes='', status=None, terms='', linked_po_id=None, paid_amount=0.0):
    conn = get_conn()
    total = sum(item['total'] for item in line_items)
    
    account_name = account_id

    if inv_type in ('sale', 'estimate', 'credit_note'):
        debit, credit = account_name, None
    else:
        debit, credit = None, account_name

    v_id = conn.execute(
        "INSERT INTO vouchers (vch_no, v_type, date, amount, narration, paid_amount, status, terms, linked_po_id, debit, credit) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
        (invoice_no, inv_type, date, total, notes, paid_amount, status, terms, linked_po_id, debit, credit)
    ).lastrowid'''

new_create = '''def create_invoice(invoice_no, inv_type, account_id, date, line_items, notes='', status=None, terms='', linked_po_id=None, paid_amount=0.0, is_template=0):
    conn = get_conn()
    total = sum(item['total'] for item in line_items)
    
    account_name = account_id

    if inv_type in ('sale', 'estimate', 'credit_note'):
        debit, credit = account_name, None
    else:
        debit, credit = None, account_name

    v_id = conn.execute(
        "INSERT INTO vouchers (vch_no, v_type, date, amount, narration, paid_amount, status, terms, linked_po_id, debit, credit, is_template) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
        (invoice_no, inv_type, date, total, notes, paid_amount, status, terms, linked_po_id, debit, credit, is_template)
    ).lastrowid'''

text = text.replace(old_create, new_create)

# 2. Update get_all_invoices to exclude is_template=1
old_get = '''    if inv_type and inv_type != "all":
        rows = conn.execute("""
            SELECT v.v_id as id, v.vch_no as invoice_no, v.v_type as type, v.date, v.amount as total,
                   v.paid_amount as paid, (v.amount - COALESCE(v.paid_amount,0)) as due,
                   v.narration as notes, v.status as status, v.linked_po_id, v.debit, v.credit,
                   COALESCE((SELECT debit FROM vouchers_all va WHERE va.v_id = v.v_id LIMIT 1), v.debit, v.credit) as account_id,
                   COALESCE((SELECT debit FROM vouchers_all va WHERE va.v_id = v.v_id LIMIT 1), v.debit, v.credit) as account_name,
                   COALESCE((SELECT credit FROM vouchers_all va WHERE va.v_id = v.v_id LIMIT 1), v.credit, v.debit) as credit_name
            FROM vouchers v
            WHERE v.v_type=? ORDER BY v.date DESC
        """, (inv_type,)).fetchall()
    else:
        rows = conn.execute("""
            SELECT v.v_id as id, v.vch_no as invoice_no, v.v_type as type, v.date, v.amount as total,
                   v.paid_amount as paid, (v.amount - COALESCE(v.paid_amount,0)) as due,
                   v.narration as notes, v.status as status, v.linked_po_id, v.debit, v.credit,
                   COALESCE((SELECT debit FROM vouchers_all va WHERE va.v_id = v.v_id LIMIT 1), v.debit, v.credit) as account_id,
                   COALESCE((SELECT debit FROM vouchers_all va WHERE va.v_id = v.v_id LIMIT 1), v.debit, v.credit) as account_name,
                   COALESCE((SELECT credit FROM vouchers_all va WHERE va.v_id = v.v_id LIMIT 1), v.credit, v.debit) as credit_name
            FROM vouchers v
            ORDER BY v.date DESC
        """).fetchall()'''

new_get = '''    if inv_type and inv_type != "all":
        rows = conn.execute("""
            SELECT v.v_id as id, v.vch_no as invoice_no, v.v_type as type, v.date, v.amount as total,
                   v.paid_amount as paid, (v.amount - COALESCE(v.paid_amount,0)) as due,
                   v.narration as notes, v.status as status, v.linked_po_id, v.debit, v.credit,
                   COALESCE((SELECT debit FROM vouchers_all va WHERE va.v_id = v.v_id LIMIT 1), v.debit, v.credit) as account_id,
                   COALESCE((SELECT debit FROM vouchers_all va WHERE va.v_id = v.v_id LIMIT 1), v.debit, v.credit) as account_name,
                   COALESCE((SELECT credit FROM vouchers_all va WHERE va.v_id = v.v_id LIMIT 1), v.credit, v.debit) as credit_name
            FROM vouchers v
            WHERE v.v_type=? AND COALESCE(v.is_template, 0) = 0 ORDER BY v.date DESC
        """, (inv_type,)).fetchall()
    else:
        rows = conn.execute("""
            SELECT v.v_id as id, v.vch_no as invoice_no, v.v_type as type, v.date, v.amount as total,
                   v.paid_amount as paid, (v.amount - COALESCE(v.paid_amount,0)) as due,
                   v.narration as notes, v.status as status, v.linked_po_id, v.debit, v.credit,
                   COALESCE((SELECT debit FROM vouchers_all va WHERE va.v_id = v.v_id LIMIT 1), v.debit, v.credit) as account_id,
                   COALESCE((SELECT debit FROM vouchers_all va WHERE va.v_id = v.v_id LIMIT 1), v.debit, v.credit) as account_name,
                   COALESCE((SELECT credit FROM vouchers_all va WHERE va.v_id = v.v_id LIMIT 1), v.credit, v.debit) as credit_name
            FROM vouchers v
            WHERE COALESCE(v.is_template, 0) = 0
            ORDER BY v.date DESC
        """).fetchall()'''
text = text.replace(old_get, new_get)

# 3. Add get_estimate_templates function
templates_func = '''
def get_estimate_templates():
    conn = get_conn()
    conn.row_factory = __import__('sqlite3').Row
    rows = conn.execute("""
        SELECT v.v_id as id, v.vch_no as invoice_no, v.v_type as type, v.date, v.amount as total,
               v.narration as notes, v.debit, v.credit,
               COALESCE((SELECT debit FROM vouchers_all va WHERE va.v_id = v.v_id LIMIT 1), v.debit, v.credit) as account_id
        FROM vouchers v
        WHERE v.v_type='estimate' AND v.is_template=1
        ORDER BY v.date DESC
    """).fetchall()
    conn.close()
    return [dict(r) for r in rows]
'''
text += templates_func

with open('db.py', 'w', encoding='utf-8') as f:
    f.write(text)
print("db.py patched successfully")
