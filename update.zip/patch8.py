with open('bookkeeper.py', 'r', encoding='utf-8') as f:
    content = f.read()

# Fix ?? buttons
content = content.replace(
    'tk.Button(main_frame, text="??", bg="#ffffff", relief="flat", command=choose_image, font=(FONT[0], 16)).place(x=rx+80, y=40)',
    'tk.Button(main_frame, text="Browse", bg="#ffffff", relief="solid", bd=1, command=choose_image, font=(FONT[0], 10)).place(x=rx+70, y=40, width=60, height=25)'
)

content = content.replace(
    'tk.Button(main_frame, text="???", bg="#ffffff", relief="flat", command=lambda: [image_path_var.set(""), img_lbl.config(image="")], font=(FONT[0], 16)).place(x=rx+80, y=80)',
    'tk.Button(main_frame, text="Clear", bg="#ffffff", relief="solid", bd=1, command=lambda: [image_path_var.set(""), img_lbl.config(image="")], font=(FONT[0], 10)).place(x=rx+70, y=80, width=60, height=25)'
)

# Fix save method
old_save_start = '''            data['detail1'] = image_path_var.get()

            if not data.get('item'):
                messagebox.showerror("Error", "Item Name is required!", parent=win)
                fields['item'].focus_set()
                return'''

new_save_start = '''            data['detail1'] = image_path_var.get()
            
            data.pop('date_created', None)
            data.pop('tax_regn', None)

            if not data.get('item'):
                messagebox.showerror("Error", "Item Name is required!", parent=win)
                fields['item'].focus_set()
                return'''

content = content.replace(old_save_start, new_save_start)

with open('bookkeeper.py', 'w', encoding='utf-8') as f:
    f.write(content)
print("Fixed icons and save method")
