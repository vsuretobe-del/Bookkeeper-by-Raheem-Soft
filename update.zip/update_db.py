with open('db.py', 'r', encoding='utf-8') as f:
    content = f.read()

target = '''    type_map = {
        'customer': 'Sundry Debtors',
        'supplier': 'Sundry Creditors',
        'cash': 'Cash-in-hand',
        'bank': 'Bank A/Cs'
    }'''

replacement = '''    type_map = {
        'customer': 'Sundry Debtors',
        'supplier': 'Sundry Creditors',
        'cash': 'Cash-in-hand',
        'bank': 'Bank A/Cs',
        'sales': 'Sales Accounts',
        'purchase': 'Purchase Accounts'
    }'''

content = content.replace(target, replacement)
with open('db.py', 'w', encoding='utf-8') as f:
    f.write(content)

print("db.py updated")
