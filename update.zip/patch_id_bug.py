import re

with open('db.py', 'r', encoding='utf-8') as f:
    db_content = f.read()

db_content = re.sub(
    r'def delete_unit\(unit_id\):.*?conn\.execute\("DELETE FROM units_measure WHERE id=\?", \(unit_id,\)\)',
    r'def delete_unit(unit_name):\n    conn = get_conn()\n    conn.execute("DELETE FROM units_measure WHERE units_name=?", (unit_name,))',
    db_content, flags=re.DOTALL
)

db_content = re.sub(
    r'def update_unit\(unit_id, data\):.*?query = f"UPDATE units_measure SET \{set_clause\} WHERE id=\?".*?conn\.execute\(query, tuple\(data\.values\(\)\) \+ \(unit_id,\)\)',
    r'def update_unit(old_name, data):\n    conn = get_conn()\n    set_clause = ", ".join(f"{k}=?" for k in data.keys())\n    query = f"UPDATE units_measure SET {set_clause} WHERE units_name=?"\n    conn.execute(query, tuple(data.values()) + (old_name,))',
    db_content, flags=re.DOTALL
)

with open('db.py', 'w', encoding='utf-8') as f:
    f.write(db_content)


with open('bookkeeper.py', 'r', encoding='utf-8') as f:
    bk_content = f.read()

bk_content = bk_content.replace('db.update_unit(existing["id"], data)', 'db.update_unit(existing["units_name"], data)')

old_load_units = '''        def load_units(*args):
            q = search_var.get().lower()
            for item in tree.get_children():
                tree.delete(item)
            for u in db.get_all_units():
                if q in u['units_name'].lower() or q in u['symbol'].lower():
                    tree.insert("", "end", iid=str(u["id"]), values=(u["units_name"], u["symbol"]))'''

new_load_units = '''        def load_units(*args):
            q = search_var.get().lower()
            for item in tree.get_children():
                tree.delete(item)
            for u in db.get_all_units():
                u_name = str(u.get('units_name', ''))
                symb = str(u.get('symbol', ''))
                if q in u_name.lower() or q in symb.lower():
                    tree.insert("", "end", iid=u_name, values=(u_name, symb))'''

bk_content = bk_content.replace(old_load_units, new_load_units)

old_edit_unit = '''    def _edit_selected_unit(self, tree):
        sel = tree.selection()
        if not sel: return
        unit_id = sel[0]
        u = next((u for u in db.get_all_units() if str(u["id"]) == unit_id), None)
        if u:
            self._unit_form(existing=u)'''

new_edit_unit = '''    def _edit_selected_unit(self, tree):
        sel = tree.selection()
        if not sel: return
        unit_name = sel[0]
        u = next((u for u in db.get_all_units() if u["units_name"] == unit_name), None)
        if u:
            self._unit_form(existing=u)'''

bk_content = bk_content.replace(old_edit_unit, new_edit_unit)

with open('bookkeeper.py', 'w', encoding='utf-8') as f:
    f.write(bk_content)

print("Fixed unit id bugs")
