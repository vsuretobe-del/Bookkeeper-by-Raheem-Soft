import re

with open('db.py', 'r', encoding='utf-8') as f:
    content = f.read()

old_get_items = '''def get_all_items():
    conn = get_conn()
    rows = conn.execute("""
        SELECT item as id, item as name, sku as code, units_name as unit, 
               defaultpurchaseprice as purchase_price, defaultsellingprice as sale_price, 
               COALESCE((SELECT cl_bal FROM stock WHERE stock_name=item_measure.item LIMIT 1), 0.0) as stock, 
               reorder_qty as low_stock_alert 
        FROM item_measure ORDER BY item
    """).fetchall()
    conn.close()
    return [dict(r) for r in rows]'''

new_get_items = '''def get_all_items():
    conn = get_conn()
    rows = conn.execute("""
        SELECT *, item as id, item as name, sku as code, units_name as unit, 
               defaultpurchaseprice as purchase_price, defaultsellingprice as sale_price, 
               COALESCE((SELECT cl_bal FROM stock WHERE stock_name=item_measure.item LIMIT 1), 0.0) as stock, 
               reorder_qty as low_stock_alert 
        FROM item_measure ORDER BY item
    """).fetchall()
    conn.close()
    return [dict(r) for r in rows]'''

content = content.replace(old_get_items, new_get_items)

old_add_item = '''def add_item(name, code, unit, purchase_price, sale_price, stock, low_stock_alert):
    conn = get_conn()
    conn.execute("""INSERT INTO item_measure (item, sku, units_name, defaultpurchaseprice, defaultsellingprice, reorder_qty)
                    VALUES (?,?,?,?,?,?)""",
                 (name, code, unit, purchase_price, sale_price, low_stock_alert))
    conn.execute("INSERT INTO stock (stock_name, cl_bal) VALUES (?,?)", (name, stock))
    conn.commit()
    conn.close()

def update_item(item_id, name, code, unit, purchase_price, sale_price, stock, low_stock_alert):
    conn = get_conn()
    conn.execute("""UPDATE item_measure SET item=?, sku=?, units_name=?, defaultpurchaseprice=?, defaultsellingprice=?, reorder_qty=? 
                    WHERE item=?""",
                 (name, code, unit, purchase_price, sale_price, low_stock_alert, item_id))
    conn.execute("UPDATE stock SET stock_name=?, cl_bal=? WHERE stock_name=?", (name, stock, item_id))
    conn.commit()
    conn.close()'''

new_add_item = '''def add_item(data):
    conn = get_conn()
    stock_qty = data.pop('stock', 0)
    
    cols = ", ".join(data.keys())
    placeholders = ", ".join("?" * len(data))
    query = f"INSERT INTO item_measure ({cols}) VALUES ({placeholders})"
    
    conn.execute(query, tuple(data.values()))
    if 'item' in data:
        conn.execute("INSERT INTO stock (stock_name, cl_bal) VALUES (?,?)", (data['item'], stock_qty))
    conn.commit()
    conn.close()

def update_item(item_id, data):
    conn = get_conn()
    stock_qty = data.pop('stock', 0)
    
    set_clause = ", ".join(f"{k}=?" for k in data.keys())
    values = tuple(data.values()) + (item_id,)
    
    conn.execute(f"UPDATE item_measure SET {set_clause} WHERE item=?", values)
    
    if 'item' in data:
        new_name = data['item']
        conn.execute("UPDATE stock SET stock_name=?, cl_bal=? WHERE stock_name=?", (new_name, stock_qty, item_id))
        
        if new_name != item_id:
            conn.execute("UPDATE sales SET item_name=? WHERE item_name=?", (new_name, item_id))
            conn.execute("UPDATE purchases SET item_name=? WHERE item_name=?", (new_name, item_id))
            
    conn.commit()
    conn.close()'''

content = content.replace(old_add_item, new_add_item)

with open('db.py', 'w', encoding='utf-8') as f:
    f.write(content)
print("Updated db.py")
