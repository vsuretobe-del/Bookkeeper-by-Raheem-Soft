import tkinter as tk
from tkinter import ttk, messagebox
import db
from autocomplete import AutocompleteCombobox

FONT = ("Segoe UI", 10)
FONT_BOLD = ("Segoe UI", 10, "bold")
FONT_TITLE = ("Segoe UI", 12, "bold")
FONT_NOTICE = ("Segoe UI", 9, "italic", "bold")
BG_HEADER = "#d6ded9"
WHITE = "#ffffff"

def format_amt(val):
    try:
        f = float(val or 0)
        return f"{f:,.2f}" if not f.is_integer() else f"{f:,.0f}"
    except (ValueError, TypeError):
        return str(val or "")

class InventoryItemsWindow(tk.Toplevel):
    def __init__(self, master):
        super().__init__(master)
        self.master_app = master
        self.title("Inventory Items")
        self.geometry("1100x680")
        try:
            self.state("zoomed")
        except tk.TclError:
            pass
        self.configure(bg=WHITE)
        self.transient(master)
        self.grab_set()

        self.all_items = []
        self.filtered_items = []

        self._build_ui()
        self._bind_shortcuts()
        self.load_data()

    def _build_ui(self):
        # ── 1. Top Navigation Bar (matching screenshot) ──────────────────────
        nav_frame = tk.Frame(self, bg=WHITE, height=36)
        nav_frame.pack(fill="x", side="top")

        # Left grip handle ⋮
        tk.Label(nav_frame, text="⋮", font=("Segoe UI", 12, "bold"), fg="#888888", bg=WHITE).pack(side="left", padx=(8, 2))

        # [✕] Ctrl+Q: Exit
        exit_frame = tk.Frame(nav_frame, bg=WHITE, cursor="hand2")
        exit_frame.pack(side="left", padx=(2, 4), pady=4)
        lbl_x = tk.Label(exit_frame, text="✕", font=("Segoe UI", 9, "bold"), fg=WHITE, bg="#000000", width=2)
        lbl_x.pack(side="left")
        lbl_x.bind("<Button-1>", lambda e: self.destroy())
        btn_exit = tk.Button(exit_frame, text="Ctrl+Q: Exit", font=("Segoe UI", 9), bg=WHITE, activebackground="#e8e8e8",
                             relief="flat", bd=0, command=self.destroy, cursor="hand2")
        btn_exit.pack(side="left", padx=(2, 0))

        # Divider
        tk.Frame(nav_frame, bg="#cccccc", width=1, height=18).pack(side="left", padx=4, pady=8)

        # 🛒 F2: New Inventory Item
        btn_new = tk.Button(nav_frame, text="🛒 F2: New Inventory Item", font=("Segoe UI", 9), bg=WHITE,
                            activebackground="#e8e8e8", relief="flat", bd=0, cursor="hand2",
                            command=self.new_item)
        btn_new.pack(side="left", padx=4, pady=4)

        # Divider
        tk.Frame(nav_frame, bg="#cccccc", width=1, height=18).pack(side="left", padx=4, pady=8)

        # Filter Combobox (Active Items / Inactive Items / ALL)
        self.status_var = tk.StringVar(value="Active Items")
        self.cb_status = AutocompleteCombobox(nav_frame, textvariable=self.status_var,
                                      values=["Active Items", "Inactive Items", "ALL"],
                                      state="readonly", width=15, font=("Segoe UI", 9))
        self.cb_status.pack(side="left", padx=4, pady=6)
        self.cb_status.bind("<<ComboboxSelected>>", lambda e: self.apply_filters())

        # 🔄 Reload/Refresh
        btn_refresh = tk.Button(nav_frame, text="🔄 Reload/Refresh", font=("Segoe UI", 9), bg=WHITE,
                                activebackground="#e8e8e8", relief="flat", bd=0, cursor="hand2",
                                command=self.load_data)
        btn_refresh.pack(side="left", padx=6, pady=4)

        # ── 2. Header & Search Frame (matching screenshot) ───────────────────
        header_frame = tk.Frame(self, bg=BG_HEADER, padx=16, pady=6)
        header_frame.pack(fill="x")

        # Centered Title: Inventory Items
        lbl_title = tk.Label(header_frame, text="Inventory Items", font=FONT_TITLE, bg=BG_HEADER, fg="#000000")
        lbl_title.pack(anchor="center", pady=(2, 4))

        # Search Row
        search_row = tk.Frame(header_frame, bg=BG_HEADER)
        search_row.pack(fill="x", pady=2)

        lbl_search = tk.Label(search_row, text="F3: Search:", font=("Segoe UI", 11), bg=BG_HEADER, fg="#000000")
        lbl_search.pack(side="left", padx=(0, 6))

        self.search_var = tk.StringVar()
        self.search_entry = tk.Entry(search_row, textvariable=self.search_var, font=FONT,
                                     bg=WHITE, relief="solid", bd=1)
        self.search_entry.pack(side="left", fill="x", expand=True, padx=(0, 10))
        self.search_entry.bind("<KeyRelease>", lambda e: self.apply_filters())

        # Notice Row: Press ENTER to edit and DELETE to delete
        lbl_notice = tk.Label(header_frame, text="Press ENTER to edit and DELETE to delete",
                              font=FONT_NOTICE, fg="#800000", bg=BG_HEADER)
        lbl_notice.pack(anchor="w", pady=(4, 2))

        # ── 3. Table Frame with Treeview ─────────────────────────────────────
        table_frame = tk.Frame(self, bg=WHITE)
        table_frame.pack(fill="both", expand=True, padx=6, pady=6)

        cols = ("id", "name", "sku", "barcode", "unit", "cost", "price", "stock", "reorder", "status")
        headers = {
            "id": "ID",
            "name": "Item Name",
            "sku": "Code / SKU / HSN",
            "barcode": "Barcode",
            "unit": "Unit",
            "cost": "Initial Cost",
            "price": "Sale Price",
            "stock": "Quantity On Hand",
            "reorder": "Min Order Qty",
            "status": "Status"
        }
        widths = {
            "id": 50,
            "name": 260,
            "sku": 120,
            "barcode": 110,
            "unit": 80,
            "cost": 100,
            "price": 100,
            "stock": 120,
            "reorder": 100,
            "status": 80
        }
        alignments = {
            "id": "center",
            "name": "w",
            "sku": "w",
            "barcode": "w",
            "unit": "center",
            "cost": "e",
            "price": "e",
            "stock": "e",
            "reorder": "e",
            "status": "center"
        }

        # Style Treeview
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("Treeview.Heading", font=("Segoe UI", 9, "bold"), background="#f0f0f0", foreground="#000000")
        style.configure("Treeview", font=FONT, rowheight=30)
        style.map("Treeview", background=[("selected", "#d0e2f5")], foreground=[("selected", "#111827")])

        self.tree = ttk.Treeview(table_frame, columns=cols, show="headings", selectmode="browse")

        for c in cols:
            self.tree.heading(c, text=headers[c], command=lambda col=c: self._sort_column(col, False))
            self.tree.column(c, width=widths[c], anchor=alignments[c], stretch=(c == "name"))

        vsb = ttk.Scrollbar(table_frame, orient="vertical", command=self.tree.yview)
        hsb = ttk.Scrollbar(table_frame, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)

        vsb.pack(side="right", fill="y")
        hsb.pack(side="bottom", fill="x")
        self.tree.pack(fill="both", expand=True)

        # Context Menu
        self.menu = tk.Menu(self, tearoff=0)
        self.menu.add_command(label="✏ Edit Item (Enter)", command=self.edit_selected_item)
        self.menu.add_command(label="🗑 Delete Item (Delete)", command=self.delete_selected_item)
        self.menu.add_separator()
        self.menu.add_command(label="➕ New Item (F2)", command=self.new_item)
        self.menu.add_command(label="🔄 Refresh (Ctrl+R)", command=self.load_data)

        self.tree.bind("<Button-3>", self._show_context_menu)

    def _show_context_menu(self, event):
        item = self.tree.identify_row(event.y)
        if item:
            self.tree.selection_set(item)
            self.menu.post(event.x_root, event.y_root)

    def _bind_shortcuts(self):
        self.bind("<Control-q>", lambda e: self.destroy())
        self.bind("<Control-Q>", lambda e: self.destroy())
        self.bind("<Escape>", lambda e: self.destroy())
        self.bind("<F2>", lambda e: self.new_item())
        self.bind("<F3>", lambda e: self._focus_search())
        self.bind("<Control-r>", lambda e: self.load_data())
        self.bind("<Control-R>", lambda e: self.load_data())
        self.bind("<F5>", lambda e: self.load_data())

        self.tree.bind("<Double-1>", lambda e: self.edit_selected_item())
        self.tree.bind("<Return>", lambda e: self.edit_selected_item())
        self.tree.bind("<KP_Enter>", lambda e: self.edit_selected_item())
        self.tree.bind("<Delete>", lambda e: self.delete_selected_item())

    def _focus_search(self):
        self.search_entry.focus_set()
        self.search_entry.select_range(0, 'end')

    def load_data(self):
        try:
            items = db.get_all_items()
            self.all_items = [dict(r) for r in items]
        except Exception as e:
            print("Error loading items:", e)
            self.all_items = []
        self.apply_filters()

    def apply_filters(self):
        status_filter = self.status_var.get()
        query = self.search_var.get().strip().lower()

        self.filtered_items = []
        for r in self.all_items:
            # Status check
            st = r.get("status")
            is_active = (st is None or st == 1 or str(st).lower() in ["active", "1"])
            
            if status_filter == "Active Items" and not is_active:
                continue
            elif status_filter == "Inactive Items" and is_active:
                continue

            # Query search
            if query:
                name = str(r.get("name") or r.get("item") or "").lower()
                sku = str(r.get("sku") or r.get("code") or "").lower()
                barcode = str(r.get("barcode") or "").lower()
                unit = str(r.get("unit") or r.get("units_name") or "").lower()
                desc = str(r.get("item_desc") or "").lower()
                remarks = str(r.get("remarks") or "").lower()

                if not (query in name or query in sku or query in barcode or query in unit or query in desc or query in remarks):
                    continue

            self.filtered_items.append(r)

        self._render_tree()

    def _render_tree(self):
        for item in self.tree.get_children():
            self.tree.delete(item)

        for r in self.filtered_items:
            item_id = r.get("id") or r.get("item") or ""
            name = r.get("name") or r.get("item") or ""
            sku = r.get("sku") or r.get("code") or ""
            barcode = r.get("barcode") or ""
            unit = db.get_unit_symbol(r.get("unit") or r.get("units_name") or "")
            cost = format_amt(r.get("rate1") if r.get("rate1") is not None else r.get("purchase_price"))
            price = format_amt(r.get("defaultsellingprice") if r.get("defaultsellingprice") is not None else r.get("sale_price"))
            stock = format_amt(r.get("stock"))
            reorder = format_amt(r.get("reorder_qty"))
            
            st = r.get("status")
            is_active = (st is None or st == 1 or str(st).lower() in ["active", "1"])
            status_text = "Active" if is_active else "Inactive"

            self.tree.insert("", "end", iid=str(item_id), values=(
                item_id, name, sku, barcode, unit, cost, price, stock, reorder, status_text
            ))

    def _sort_column(self, col, reverse):
        l = [(self.tree.set(k, col), k) for k in self.tree.get_children('')]
        try:
            l.sort(key=lambda t: float(t[0].replace(",", "")), reverse=reverse)
        except ValueError:
            l.sort(reverse=reverse)

        for index, (val, k) in enumerate(l):
            self.tree.move(k, '', index)

        self.tree.heading(col, command=lambda: self._sort_column(col, not reverse))

    def new_item(self):
        if hasattr(self.master_app, "_item_form"):
            self.master_app._item_form(callback=self.load_data)

    def edit_selected_item(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showwarning("Select Item", "Please select an item to edit.", parent=self)
            return
        item_id = sel[0]
        item = next((r for r in self.all_items if str(r.get("id") or r.get("item")) == str(item_id) or str(r.get("item")) == str(item_id)), None)
        if item and hasattr(self.master_app, "_item_form"):
            self.master_app._item_form(existing=item, callback=self.load_data)

    def delete_selected_item(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showwarning("Select Item", "Please select an item to delete.", parent=self)
            return
        item_id = sel[0]
        item = next((r for r in self.all_items if str(r.get("id") or r.get("item")) == str(item_id) or str(r.get("item")) == str(item_id)), None)
        item_name = item.get("name") or item.get("item") if item else item_id
        
        if messagebox.askyesno("Confirm Delete", f"Are you sure you want to delete item '{item_name}'?", parent=self):
            try:
                db.delete_item(item_id)
                self.load_data()
            except Exception as e:
                messagebox.showerror("Error", str(e), parent=self)
