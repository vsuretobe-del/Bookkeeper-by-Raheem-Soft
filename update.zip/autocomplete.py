import tkinter as tk

class AutocompleteCombobox(tk.Entry):
    def __init__(self, master, values=None, **kwargs):
        self.allow_create = kwargs.pop('allow_create', False)
        self.create_callback = kwargs.pop('create_callback', None)
        
        # We need to extract arguments that Entry doesn't support but Combobox does
        if 'style' in kwargs:
            kwargs.pop('style')
            
        # Combobox uses 'state', Entry uses 'state' too but values like 'readonly' vs 'normal'/'disabled'
        self._combobox_state = kwargs.get('state', 'normal')
        if self._combobox_state == 'readonly':
            # We want it to be editable for searching, but behave like readonly if needed.
            # Actually, if it's autocomplete, they MUST type in it to search, so we force normal state
            # unless it's explicitly disabled.
            kwargs['state'] = 'normal'
            
        self.textvariable = kwargs.get('textvariable')
        if not self.textvariable:
            self.textvariable = tk.StringVar()
            kwargs['textvariable'] = self.textvariable
            
        super().__init__(master, **kwargs)
        self.values = values or []
        self.listbox = None
        self.popup = None
        self.hide_timer = None
        
        # Override the cget/configure to handle 'values'
        self.bind('<KeyRelease>', self.handle_keyrelease)
        self.bind('<FocusOut>', self.handle_focusout)
        self.bind('<FocusIn>', self.handle_focusin)
        self.bind('<Down>', self.handle_down)
        self.bind('<Up>', self.handle_up)
        self.bind('<Return>', self.handle_return)
        self.bind('<Button-1>', self.handle_click)
        
    def __setitem__(self, key, value):
        if key == 'values':
            self.values = value
        elif key == 'state':
            self._combobox_state = value
            if value == 'disabled':
                super().__setitem__('state', 'disabled')
            else:
                super().__setitem__('state', 'normal')
        elif key == 'style':
            pass
        else:
            super().__setitem__(key, value)

    def __getitem__(self, key):
        if key == 'values':
            return self.values
        elif key == 'state':
            return self._combobox_state
        return super().__getitem__(key)

    def configure(self, **kw):
        if 'values' in kw:
            self.values = kw.pop('values')
        if 'state' in kw:
            self._combobox_state = kw['state']
            if kw['state'] == 'disabled':
                kw['state'] = 'disabled'
            else:
                kw['state'] = 'normal'
        if 'style' in kw:
            kw.pop('style')
        if kw:
            super().configure(**kw)
            
    def config(self, **kw):
        self.configure(**kw)
        
    def set(self, value):
        self.textvariable.set(value)
        
    def get(self):
        return self.textvariable.get()
        
    def handle_click(self, event):
        if self.cget('state') == 'disabled':
            return
        if not self.popup:
            self.show_popup(self.values)
            
    def handle_focusin(self, event):
        # We can optionally show popup on focus in, but click is usually better
        pass
        
    def handle_keyrelease(self, event):
        if self.cget('state') == 'disabled':
            return
        if event.keysym in ('Up', 'Down', 'Return', 'Escape', 'Tab'):
            return
            
        text = self.textvariable.get().lower()
        if text == '':
            matches = self.values
        else:
            # Sort matches: items starting with text first, then items containing text
            starts_with = [v for v in self.values if str(v).lower().startswith(text)]
            contains = [v for v in self.values if text in str(v).lower() and not str(v).lower().startswith(text)]
            matches = starts_with + contains
            
            if self.allow_create:
                exact_match = any(str(v).lower() == text for v in self.values)
                if not exact_match:
                    matches.append(f"+ Create '{self.textvariable.get()}'")
            
        self.show_popup(matches)
        
    def show_popup(self, matches):
        if not matches:
            self.hide_popup()
            return
            
        if not self.popup:
            self.popup = tk.Toplevel(self)
            self.popup.wm_overrideredirect(True)
            self.popup.attributes("-topmost", True)
            
            x = self.winfo_rootx()
            y = self.winfo_rooty() + self.winfo_height()
            w = self.winfo_width()
            self.popup.geometry(f"{w}x150+{x}+{y}")
            
            # Add a frame with border for aesthetics
            frame = tk.Frame(self.popup, bg="#d1d5db", bd=1, relief="solid")
            frame.pack(fill='both', expand=True)
            
            # Scrollbar
            scrollbar = tk.Scrollbar(frame, orient="vertical")
            scrollbar.pack(side="right", fill="y")
            
            self.listbox = tk.Listbox(frame, font=self.cget('font'), bg='white', 
                                      selectbackground='#2563eb', selectforeground='white', 
                                      relief='flat', bd=0, highlightthickness=0,
                                      yscrollcommand=scrollbar.set)
            self.listbox.pack(side="left", fill='both', expand=True)
            scrollbar.config(command=self.listbox.yview)
            
            self.listbox.bind('<ButtonRelease-1>', self.select_item)
            self.listbox.bind('<Motion>', self.hover_item)
            
        self.listbox.delete(0, tk.END)
        for m in matches:
            self.listbox.insert(tk.END, str(m))
            
    def hover_item(self, event):
        if not self.listbox: return
        index = self.listbox.nearest(event.y)
        if index >= 0:
            self.listbox.selection_clear(0, tk.END)
            self.listbox.selection_set(index)
            self.listbox.activate(index)
            
    def hide_popup(self):
        if self.popup:
            self.popup.destroy()
            self.popup = None
            self.listbox = None
            
    def handle_focusout(self, event):
        # Allow time for click to register on listbox before closing popup
        if self.hide_timer:
            self.after_cancel(self.hide_timer)
        self.hide_timer = self.after(150, self.hide_popup)
        
    def handle_down(self, event):
        if self.cget('state') == 'disabled': return
        if self.popup and self.listbox:
            if not self.listbox.curselection():
                self.listbox.selection_set(0)
            else:
                idx = self.listbox.curselection()[0]
                if idx < self.listbox.size() - 1:
                    self.listbox.selection_clear(0, tk.END)
                    self.listbox.selection_set(idx + 1)
            self.listbox.see(self.listbox.curselection()[0])
            return "break"
        else:
            self.show_popup(self.values)
            
    def handle_up(self, event):
        if self.cget('state') == 'disabled': return
        if self.popup and self.listbox:
            if self.listbox.curselection():
                idx = self.listbox.curselection()[0]
                if idx > 0:
                    self.listbox.selection_clear(0, tk.END)
                    self.listbox.selection_set(idx - 1)
                    self.listbox.see(idx - 1)
            return "break"
            
    def handle_return(self, event):
        if self.cget('state') == 'disabled': return
        if self.popup and self.listbox and self.listbox.curselection():
            self.select_item()
        else:
            self.hide_popup()
            # Let the event propagate
            
    def select_item(self, event=None):
        if not self.listbox: return
        selection = self.listbox.curselection()
        if selection:
            value = self.listbox.get(selection[0])
            
            if self.allow_create and value.startswith("+ Create '") and value.endswith("'"):
                # Extract the typed name
                typed_name = value[10:-1]
                self.hide_popup()
                if self.create_callback:
                    self.create_callback(typed_name)
                return
                
            self.textvariable.set(value)
            self.icursor(tk.END)
            # Generate the virtual event for bound callbacks
            self.event_generate("<<ComboboxSelected>>")
        self.hide_popup()
        self.focus_set()
