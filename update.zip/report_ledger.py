import tkinter as tk
from tkinter import ttk, messagebox
import db
from custom_calendar import DateEntry
from datetime import datetime
from autocomplete import AutocompleteCombobox

BG_BLUE = "#2b579a"
BG_WHITE = "#ffffff"
BG_YELLOW = "#ffff00"
FONT = ("Segoe UI", 10)
FONT_BOLD = ("Segoe UI", 10, "bold")
FONT_TITLE = ("Segoe UI", 12, "bold")

class LedgerReportView(tk.Frame):
    def __init__(self, master, app_ref):
        super().__init__(master, bg=BG_WHITE)
        self.app_ref = app_ref
        self.pack(fill="both", expand=True)
        self._build_ui()
        self.load_combos()
        
    def _build_ui(self):
        # 1. Top Toolbar
        top_bar = tk.Frame(self, bg=BG_WHITE)
        top_bar.pack(fill="x", side="top")
        
        # Add buttons
        buttons = [
            ("✖ Ctrl+Q: Exit", self.app_ref.show_dashboard if hasattr(self.app_ref, 'show_dashboard') else self.master.destroy),
            ("🖨️ Alt+P: Print", self.not_implemented),
            ("📝 Ctrl+W: Open In MS Word", self.not_implemented),
            ("📊 Ctrl+E: Open In MS Excel", self.not_implemented),
            ("📄 Ctrl+V: Open In PDF", self.not_implemented),
            ("🌐 Ctrl+H: Open In Browser", self.not_implemented),
            ("📧 Send Email", self.not_implemented)
        ]
        for text, cmd in buttons:
            btn = tk.Button(top_bar, text=text, font=("Segoe UI", 9), relief="flat", bg=BG_WHITE, cursor="hand2", command=cmd)
            btn.pack(side="left", padx=2, pady=2)
            
        tk.Frame(self, bg="#cccccc", height=1).pack(fill="x") # Separator
        
        # 2. Main Content Area
        content_fr = tk.Frame(self, bg=BG_WHITE)
        content_fr.pack(fill="both", expand=True)
        
        # Left Panel (Filters)
        left_fr = tk.Frame(content_fr, bg=BG_BLUE, width=300)
        left_fr.pack(side="left", fill="y")
        left_fr.pack_propagate(False)
        
        # Right Panel (Report)
        self.right_fr = tk.Frame(content_fr, bg=BG_WHITE)
        self.right_fr.pack(side="left", fill="both", expand=True)
        
        # --- Build Left Panel ---
        self.filter_mode = tk.StringVar(value="group")
        
        # Radio 1: Account Group/Type
        rb_group = tk.Radiobutton(left_fr, text="Account Group/Type:", variable=self.filter_mode, value="group", 
                                  bg=BG_BLUE, fg="white", font=FONT, selectcolor=BG_BLUE, activebackground=BG_BLUE, activeforeground="white",
                                  command=self.on_mode_change)
        rb_group.pack(anchor="w", padx=10, pady=(10, 2))
        
        self.cb_group = AutocompleteCombobox(left_fr, font=FONT, state="readonly")
        self.cb_group.pack(fill="x", padx=20, pady=2)
        
        # Radio 2: Account Name
        rb_name = tk.Radiobutton(left_fr, text="Account Name", variable=self.filter_mode, value="name", 
                                  bg=BG_BLUE, fg="white", font=FONT, selectcolor=BG_BLUE, activebackground=BG_BLUE, activeforeground="white",
                                  command=self.on_mode_change)
        rb_name.pack(anchor="w", padx=10, pady=(10, 2))
        
        self.cb_name = AutocompleteCombobox(left_fr, font=FONT, state="readonly")
        self.cb_name.pack(fill="x", padx=20, pady=2)
        
        # Start Date
        tk.Label(left_fr, text="Start Date:", bg=BG_BLUE, fg="white", font=FONT).pack(anchor="w", padx=10, pady=(10, 2))
        self.start_date = DateEntry(left_fr, date_pattern="Month DD, YYYY")
        self.start_date.pack(fill="x", padx=20)
        
        # End Date
        tk.Label(left_fr, text="End date:", bg=BG_BLUE, fg="white", font=FONT).pack(anchor="w", padx=10, pady=(10, 2))
        self.end_date = DateEntry(left_fr, date_pattern="Month DD, YYYY")
        self.end_date.pack(fill="x", padx=20)
        
        # Voucher Type
        tk.Label(left_fr, text="Voucher Type:", bg=BG_BLUE, fg="white", font=FONT).pack(anchor="w", padx=10, pady=(10, 2))
        self.cb_voucher = AutocompleteCombobox(left_fr, font=FONT, state="readonly")
        self.cb_voucher['values'] = ["ALL", "Journal", "Expense", "Income", "Receipt From Customer", "Payment To Supplier", 
                                     "Purchase", "Sales", "Contra", "Purchases Return", "Sales Return", "Manufacturing", 
                                     "Stock Journal", "Stock Adjustment"]
        self.cb_voucher.set(self.cb_voucher['values'][0])
        self.cb_voucher.pack(fill="x", padx=20, pady=2)
        
        # Style for highlighting active combobox
        def on_focus_in(e): e.widget.config(background=BG_YELLOW)
        def on_focus_out(e): e.widget.config(background=BG_WHITE)
        # Note: AutocompleteCombobox styling background dynamically is tricky without themes. We will let it be default.
        
        # Checkboxes
        self.chk_vars = {}
        chk_options = [
            ("Display Company Details, Logo\nand Signature", True),
            ("Display Customer Details", True),
            ("Display Count Of Transactions", False),
            ("Display Amount For All Accounts", False),
            ("Display Outstanding Transactions\nin Red", False),
            ("Display Item Details", False),
            ("Display Narration", False),
            ("Display Bill Details", False),
            ("Display Post Dated Vouchers", False)
        ]
        
        for text, default in chk_options:
            var = tk.BooleanVar(value=default)
            self.chk_vars[text] = var
            chk = tk.Checkbutton(left_fr, text=text, variable=var, bg=BG_BLUE, fg="white", font=("Segoe UI", 9), 
                                 selectcolor=BG_BLUE, activebackground=BG_BLUE, activeforeground="white", justify="left")
            chk.pack(anchor="w", padx=10, pady=2)
            
        # Display Button
        btn_display = tk.Button(left_fr, text="Display", bg="#2b579a", fg="white", font=FONT, relief="raised", bd=2, command=self.display_report)
        btn_display.pack(fill="x", padx=20, pady=20)
        
        # --- Build Right Panel (Report Structure) ---
        self._build_report_area()
        self.on_mode_change() # Init state
        
    def _build_report_area(self):
        # We use a canvas for scrolling if needed, but treeview handles its own scroll.
        # Let's put a header frame, then a treeview, then a footer frame.
        self.report_header = tk.Frame(self.right_fr, bg=BG_WHITE)
        self.report_header.pack(fill="x", pady=20)
        
        self.lbl_company = tk.Label(self.report_header, text=db.get_company_name().upper() if db.get_company_name() else "ALHUMDULILLAH", 
                                    font=("Segoe UI", 16, "bold"), bg=BG_WHITE, fg="black")
        self.lbl_company.pack()
        
        self.lbl_email = tk.Label(self.report_header, text="✉ blinkbytebazaar@gmail.com", font=FONT, bg=BG_WHITE, fg="black")
        self.lbl_email.pack()
        
        self.lbl_acc_name = tk.Label(self.report_header, text="", font=("Segoe UI", 12, "bold"), bg=BG_WHITE, fg="black")
        self.lbl_acc_name.pack(pady=(10, 0))
        
        self.lbl_acc_group = tk.Label(self.report_header, text="", font=FONT, bg=BG_WHITE, fg="black")
        self.lbl_acc_group.pack()
        
        self.lbl_date_range = tk.Label(self.report_header, text="", font=FONT, bg=BG_WHITE, fg="black")
        self.lbl_date_range.pack()
        
        # Treeview
        tree_fr = tk.Frame(self.right_fr, bg=BG_WHITE)
        tree_fr.pack(fill="both", expand=True, padx=20, pady=10)
        
        columns = ("date", "particulars", "vch_no", "ref_no", "vch_type", "debit", "credit", "running_balance")
        self.tree = ttk.Treeview(tree_fr, columns=columns, show="headings", selectmode="none")
        
        self.tree.heading("date", text="DATE")
        self.tree.heading("particulars", text="PARTICULARS")
        self.tree.heading("vch_no", text="VCH NO")
        self.tree.heading("ref_no", text="REF NO")
        self.tree.heading("vch_type", text="VCH TYPE")
        self.tree.heading("debit", text="DEBIT")
        self.tree.heading("credit", text="CREDIT")
        self.tree.heading("running_balance", text="RUNNING BALANCE")
        
        self.tree.column("date", width=100, minwidth=100, anchor="center", stretch=False)
        self.tree.column("particulars", width=200, minwidth=200, anchor="w", stretch=False)
        self.tree.column("vch_no", width=80, minwidth=80, anchor="center", stretch=False)
        self.tree.column("ref_no", width=80, minwidth=80, anchor="center", stretch=False)
        self.tree.column("vch_type", width=120, minwidth=120, anchor="center", stretch=False)
        self.tree.column("debit", width=100, minwidth=100, anchor="e", stretch=False)
        self.tree.column("credit", width=100, minwidth=100, anchor="e", stretch=False)
        self.tree.column("running_balance", width=150, minwidth=150, anchor="e", stretch=False)
        
        scrollbar = ttk.Scrollbar(tree_fr, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)
        
        self.tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        # Apply striped row tags and bold tags
        self.tree.tag_configure("even", background="#f9f9f9")
        self.tree.tag_configure("odd", background="#ffffff")
        self.tree.tag_configure("bold", font=("Segoe UI", 10, "bold"), background="#f0f0f0")
        
        # Footer
        self.report_footer = tk.Frame(self.right_fr, bg=BG_WHITE)
        self.report_footer.pack(fill="x", padx=20, pady=20)
        tk.Label(self.report_footer, text="Authorized Signatory", font=FONT, bg=BG_WHITE, fg="black").pack(side="right")
        
    def load_combos(self):
        conn = db.get_conn()
        groups = conn.execute("SELECT DISTINCT account_group FROM account_detail").fetchall()
        self.cb_group['values'] = [g['account_group'] for g in groups]
        if self.cb_group['values']: self.cb_group.set(self.cb_group['values'][0])
        
        names = conn.execute("SELECT aname FROM account_detail").fetchall()
        self.cb_name['values'] = [n['aname'] for n in names]
        if self.cb_name['values']: self.cb_name.set(self.cb_name['values'][0])
        conn.close()
        
    def on_mode_change(self):
        if self.filter_mode.get() == "group":
            self.cb_group.config(state="readonly")
            self.cb_name.config(state="disabled")
        else:
            self.cb_group.config(state="disabled")
            self.cb_name.config(state="readonly")
            
    def display_report(self):
        # Clear tree
        for item in self.tree.get_children():
            self.tree.delete(item)
            
        mode = self.filter_mode.get()
        is_group = (mode == "group")
        name_or_group = self.cb_group.get() if is_group else self.cb_name.get()
        
        s_date = self.start_date.get_date()
        e_date = self.end_date.get_date()
        v_type = self.cb_voucher.get()
        
        # Update Headers
        self.lbl_acc_name.config(text=f"{name_or_group.upper()} A/C" if not is_group else f"{name_or_group.upper()} GROUP")
        self.lbl_acc_group.config(text="" if is_group else db.get_account_balance(name_or_group)) # To show group if name selected
        if not is_group:
            conn = db.get_conn()
            res = conn.execute("SELECT account_group FROM account_detail WHERE aname=?", (name_or_group)).fetchone()
            conn.close()
            if res: self.lbl_acc_group.config(text=res['account_group'])
            
        self.lbl_date_range.config(text=f"{s_date.strftime('%Y-%m-%d')} to {e_date.strftime('%Y-%m-%d')}")
        
        # Fetch Data
        op_bal, rows = db.get_ledger_advanced(is_group, name_or_group, s_date.strftime("%Y-%m-%d"), e_date.strftime("%Y-%m-%d"), v_type)
        
        # Insert Opening Balance
        self.tree.insert("", "end", values=("", "", "", "", "Opening Balance:", f"Rs{op_bal:,.0f}" if op_bal >= 0 else "", f"Rs{abs(op_bal):,.0f}" if op_bal < 0 else "", ""), tags=("bold"))
        
        running_bal = op_bal
        total_debit = 0
        total_credit = 0
        
        for i, row in enumerate(rows):
            dt = row['date']
            part = row['particulars']
            vch_no = row['vch_no']
            ref_no = row['ref_no'] if row['ref_no'] else ""
            vch_type = row['v_type'].capitalize() if row['v_type'] else ""
            deb = row['debit']
            cre = row['credit']
            
            total_debit += deb
            total_credit += cre
            running_bal += (deb - cre)
            
            d_str = f"{deb:,.0f}" if deb > 0 else ""
            c_str = f"{cre:,.0f}" if cre > 0 else ""
            rb_str = f"{running_bal:,.0f}"
            
            tag = "even" if i % 2 == 0 else "odd"
            self.tree.insert("", "end", values=(dt, part, vch_no, ref_no, vch_type, d_str, c_str, rb_str), tags=(tag))
            
        # Summary Rows
        self.tree.insert("", "end", values=("", "", "", "", "Current Total", f"Rs{total_debit:,.0f}", f"Rs{total_credit:,.0f}", ""), tags=("bold"))
        closing = op_bal + total_debit - total_credit
        self.tree.insert("", "end", values=("", "", "", "", "Closing Balance:", f"-Rs{abs(closing):,.0f}" if closing < 0 else f"Rs{closing:,.0f}", "", ""), tags=("bold"))
        
    def not_implemented(self):
        messagebox.showinfo("Coming Soon", "This feature is currently under development.")
