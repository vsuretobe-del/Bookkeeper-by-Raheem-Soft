[Setup]
AppName=Book Keeper
AppVersion=1.0
DefaultDirName={pf}\Book Keeper
DefaultGroupName=Book Keeper
UninstallDisplayIcon={app}\bookkeeper.exe
Compression=lzma2
SolidCompression=yes
OutputDir=Output
OutputBaseFilename=BookKeeper_Setup

[Files]
Source: "dist\bookkeeper.exe"; DestDir: "{app}"; Flags: ignoreversion
; If you have other assets, uncomment and modify the next line:
; Source: "assets\*"; DestDir: "{app}\assets"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\Book Keeper"; Filename: "{app}\bookkeeper.exe"
Name: "{commondesktop}\Book Keeper"; Filename: "{app}\bookkeeper.exe"

[Run]
Filename: "{app}\bookkeeper.exe"; Description: "Launch Book Keeper"; Flags: nowait postinstall skipifsilent
