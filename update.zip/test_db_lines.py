import db
conn = db.get_conn()
conn.row_factory = __import__('sqlite3').Row

v_exp = conn.execute("SELECT * FROM vouchers WHERE v_type='expense' LIMIT 1").fetchone()
if v_exp:
    lines = conn.execute("SELECT * FROM vouchers_all WHERE v_id=?", (v_exp['v_id'],)).fetchall()
    print('Expense lines DB:', len(lines))
    print('First expense line amount:', lines[0]['amount'] if lines else 'None')

v_sale = conn.execute("SELECT * FROM vouchers WHERE v_type='sale' LIMIT 1").fetchone()
if v_sale:
    items = db.get_invoice_items(v_sale['v_id'])
    print('Sale items DB:', len(items))
    print('First sale item price:', items[0]['price'] if items else 'None')
    print('First sale item qty:', items[0]['qty'] if items else 'None')
