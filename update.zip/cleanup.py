with open('bookkeeper.py', 'r', encoding='utf-8') as f:
    lines = f.readlines()

new_lines = []
skip = False
for line in lines:
    if "round_var = tk.StringVar(value=\"0\")" in line and "    def recalc_total():" not in ''.join(lines):
        pass # Wait, just delete by line numbers or exact match in the duplicate section

    if "#  Grand total vars " in line:
        skip = True
    
    if skip and "def recalc_total():" in line:
        skip = False
    
    if not skip:
        new_lines.append(line)

with open('bookkeeper.py', 'w', encoding='utf-8') as f:
    f.writelines(new_lines)
print("Removed duplicate totals block")
