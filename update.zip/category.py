import tkinter as tk
from tkinter import ttk, messagebox
import db
from autocomplete import AutocompleteCombobox

FONT = ("Segoe UI", 10)
FONT_BOLD = ("Segoe UI", 10, "bold")
FONT_TITLE = ("Segoe UI", 12, "bold")
BG = "#f0f0f0"
BG_WHITE = "#ffffff"

class CategorySubcategoryWindow(tk.Toplevel):
    def __init__(self, master, app=None):
        super().__init__(master)
        self.app = app

        self.title("Item Category Subcategory")
        self.geometry("820x520")
        self.configure(bg=BG)
        self.grab_set()
        self.transient(master)

        self._build_ui()
        self._load_categories()
        
        self.bind("<Control-q>", lambda e: self.destroy())
        self.bind("<Control-Q>", lambda e: self.destroy())

    def _build_ui(self):
        # 1. Top Toolbar Frame
        tb = tk.Frame(self, bg=BG_WHITE, relief="groove", bd=1)
        tb.pack(fill="x", side="top")

        btn_exit = tk.Button(tb, text="❎ Ctrl+Q: Exit", font=FONT_BOLD, bg=BG_WHITE, relief="flat", bd=0, cursor="hand2", command=self.destroy)
        btn_exit.pack(side="left", padx=8, pady=4)

        # 2. Main Content Frame
        content = tk.Frame(self, bg=BG)
        content.pack(fill="both", expand=True, padx=40, pady=20)

        # Row 1: Item Category
        r1 = tk.Frame(content, bg=BG)
        r1.pack(fill="x", pady=6)
        tk.Label(r1, text="Item Category", font=FONT, bg=BG, width=20, anchor="e").pack(side="left", padx=10)
        self.v_cat = tk.StringVar()
        self.cb_cat = AutocompleteCombobox(r1, textvariable=self.v_cat, font=FONT, width=32, state="readonly")
        self.cb_cat.pack(side="left", padx=5)
        self.cb_cat.bind("<<ComboboxSelected>>", self._on_cat_selected)
        
        btn_del_cat = tk.Button(r1, text="Delete this Category", font=FONT, bg="#e0e0e0", relief="solid", bd=1, width=25, command=self._delete_category)
        btn_del_cat.pack(side="left", padx=15)

        # Row 2: Item Subcategory
        r2 = tk.Frame(content, bg=BG)
        r2.pack(fill="x", pady=6)
        tk.Label(r2, text="Item Subcategory", font=FONT, bg=BG, width=20, anchor="e").pack(side="left", padx=10)
        self.v_sub = tk.StringVar()
        self.cb_sub = AutocompleteCombobox(r2, textvariable=self.v_sub, font=FONT, width=32, state="readonly")
        self.cb_sub.pack(side="left", padx=5)
        
        btn_del_sub = tk.Button(r2, text="Delete this Subcategory", font=FONT, bg="#e0e0e0", relief="solid", bd=1, width=25, command=self._delete_subcategory)
        btn_del_sub.pack(side="left", padx=15)

        # 3. Subcategory Management Tabs Notebook
        self.nb_sub = ttk.Notebook(content)
        self.nb_sub.pack(fill="x", pady=(15, 10))

        # Sub Tab 1: Add Subcategory
        tab_add_sub = tk.Frame(self.nb_sub, bg=BG_WHITE, relief="solid", bd=1)
        self.nb_sub.add(tab_add_sub, text="Add Subcategory")
        
        fr_as = tk.Frame(tab_add_sub, bg=BG_WHITE, pady=15)
        fr_as.pack(fill="x")
        tk.Label(fr_as, text="Subcategory Name to be", font=FONT, bg=BG_WHITE, width=25, anchor="e").pack(side="left", padx=10)
        self.v_add_sub_name = tk.StringVar()
        tk.Entry(fr_as, textvariable=self.v_add_sub_name, font=FONT, width=32, relief="solid", bd=1).pack(side="left", padx=5)
        tk.Button(fr_as, text="Add Subcategory", font=FONT, bg="#e0e0e0", relief="solid", bd=1, width=25, command=self._add_subcategory).pack(side="left", padx=15)

        # Sub Tab 2: Update Subcategory
        tab_upd_sub = tk.Frame(self.nb_sub, bg=BG_WHITE, relief="solid", bd=1)
        self.nb_sub.add(tab_upd_sub, text="Update Subcategory")

        fr_us = tk.Frame(tab_upd_sub, bg=BG_WHITE, pady=15)
        fr_us.pack(fill="x")
        tk.Label(fr_us, text="New name", font=FONT, bg=BG_WHITE, width=25, anchor="e").pack(side="left", padx=10)
        self.v_upd_sub_name = tk.StringVar()
        tk.Entry(fr_us, textvariable=self.v_upd_sub_name, font=FONT, width=32, relief="solid", bd=1).pack(side="left", padx=5)
        tk.Button(fr_us, text="Update Subcategory", font=FONT, bg="#e0e0e0", relief="solid", bd=1, width=25, command=self._update_subcategory).pack(side="left", padx=15)

        # 4. Category Management Tabs Notebook
        self.nb_cat = ttk.Notebook(content)
        self.nb_cat.pack(fill="x", pady=(10, 10))

        # Cat Tab 1: Add Category
        tab_add_cat = tk.Frame(self.nb_cat, bg=BG_WHITE, relief="solid", bd=1)
        self.nb_cat.add(tab_add_cat, text="Add Category")

        fr_ac = tk.Frame(tab_add_cat, bg=BG_WHITE, pady=15)
        fr_ac.pack(fill="x")
        tk.Label(fr_ac, text="Category Name to be added", font=FONT, bg=BG_WHITE, width=25, anchor="e").pack(side="left", padx=10)
        self.v_add_cat_name = tk.StringVar()
        tk.Entry(fr_ac, textvariable=self.v_add_cat_name, font=FONT, width=32, relief="solid", bd=1).pack(side="left", padx=5)
        tk.Button(fr_ac, text="Add Category", font=FONT, bg="#e0e0e0", relief="solid", bd=1, width=25, command=self._add_category).pack(side="left", padx=15)

        # Cat Tab 2: Update Category
        tab_upd_cat = tk.Frame(self.nb_cat, bg=BG_WHITE, relief="solid", bd=1)
        self.nb_cat.add(tab_upd_cat, text="Update Category")

        fr_uc = tk.Frame(tab_upd_cat, bg=BG_WHITE, pady=15)
        fr_uc.pack(fill="x")
        tk.Label(fr_uc, text="New name", font=FONT, bg=BG_WHITE, width=25, anchor="e").pack(side="left", padx=10)
        self.v_upd_cat_name = tk.StringVar()
        tk.Entry(fr_uc, textvariable=self.v_upd_cat_name, font=FONT, width=32, relief="solid", bd=1).pack(side="left", padx=5)
        tk.Button(fr_uc, text="Update Category", font=FONT, bg="#e0e0e0", relief="solid", bd=1, width=25, command=self._update_category).pack(side="left", padx=15)

        # 5. Footer Link
        lbl_foot = tk.Label(self, text="Video: Inventory Management", font=("Segoe UI", 9, "underline"), fg="blue", bg=BG, cursor="hand2")
        lbl_foot.pack(side="bottom", pady=10)

    def _load_categories(self, select_name=None):
        self.categories = db.get_all_categories()
        cat_names = [c["name"] for c in self.categories]
        self.cb_cat["values"] = cat_names

        if cat_names:
            if select_name and select_name in cat_names:
                self.cb_cat.set(select_name)
            else:
                self.cb_cat.current(0)
            self._on_cat_selected()
        else:
            self.v_cat.set("")
            self.cb_sub["values"] = []
            self.v_sub.set("")

    def _on_cat_selected(self, event=None):
        cat_name = self.v_cat.get()
        cat_data = next((c for c in self.categories if c["name"] == cat_name), None)
        if cat_data:
            self.subcategories = db.get_subcategories_by_category(cat_data["id"])
            sub_names = [s["name"] for s in self.subcategories]
            self.cb_sub["values"] = sub_names
            if sub_names:
                self.cb_sub.current(0)
            else:
                self.v_sub.set("")
        else:
            self.cb_sub["values"] = []
            self.v_sub.set("")

    def _add_category(self):
        name = self.v_add_cat_name.get().strip()
        if not name:
            messagebox.showerror("Error", "Category name cannot be empty.", parent=self)
            return
        db.add_category(name)
        self.v_add_cat_name.set("")
        messagebox.showinfo("Success", f"Category '{name}' added successfully!", parent=self)
        self._load_categories(select_name=name)

    def _update_category(self):
        cat_name = self.v_cat.get()
        cat_data = next((c for c in self.categories if c["name"] == cat_name), None)
        if not cat_data:
            messagebox.showerror("Error", "No category selected to update.", parent=self)
            return

        new_name = self.v_upd_cat_name.get().strip()
        if not new_name:
            messagebox.showerror("Error", "New category name cannot be empty.", parent=self)
            return

        db.update_category(cat_data["id"], new_name)
        self.v_upd_cat_name.set("")
        messagebox.showinfo("Success", "Category updated successfully!", parent=self)
        self._load_categories(select_name=new_name)

    def _delete_category(self):
        cat_name = self.v_cat.get()
        cat_data = next((c for c in self.categories if c["name"] == cat_name), None)
        if not cat_data:
            return

        if cat_name == "default":
            messagebox.showwarning("Warning", "Cannot delete the default category.", parent=self)
            return

        if messagebox.askyesno("Confirm Delete", f"Are you sure you want to delete category '{cat_name}' and all its subcategories?", parent=self):
            db.delete_category(cat_data["id"])
            messagebox.showinfo("Deleted", "Category deleted successfully!", parent=self)
            self._load_categories()

    def _add_subcategory(self):
        cat_name = self.v_cat.get()
        cat_data = next((c for c in self.categories if c["name"] == cat_name), None)
        if not cat_data:
            messagebox.showerror("Error", "Please select a category first.", parent=self)
            return

        name = self.v_add_sub_name.get().strip()
        if not name:
            messagebox.showerror("Error", "Subcategory name cannot be empty.", parent=self)
            return

        db.add_subcategory(name, cat_data["id"])
        self.v_add_sub_name.set("")
        messagebox.showinfo("Success", f"Subcategory '{name}' added successfully under '{cat_name}'!", parent=self)
        self._on_cat_selected()
        self.cb_sub.set(name)

    def _update_subcategory(self):
        sub_name = self.v_sub.get()
        sub_data = next((s for s in self.subcategories if s["name"] == sub_name), None)
        if not sub_data:
            messagebox.showerror("Error", "No subcategory selected to update.", parent=self)
            return

        new_name = self.v_upd_sub_name.get().strip()
        if not new_name:
            messagebox.showerror("Error", "New subcategory name cannot be empty.", parent=self)
            return

        db.update_subcategory(sub_data["id"], new_name)
        self.v_upd_sub_name.set("")
        messagebox.showinfo("Success", "Subcategory updated successfully!", parent=self)
        self._on_cat_selected()
        self.cb_sub.set(new_name)

    def _delete_subcategory(self):
        sub_name = self.v_sub.get()
        sub_data = next((s for s in self.subcategories if s["name"] == sub_name), None)
        if not sub_data:
            return

        if sub_name == "default":
            messagebox.showwarning("Warning", "Cannot delete the default subcategory.", parent=self)
            return

        if messagebox.askyesno("Confirm Delete", f"Are you sure you want to delete subcategory '{sub_name}'?", parent=self):
            db.delete_subcategory(sub_data["id"])
            messagebox.showinfo("Deleted", "Subcategory deleted successfully!", parent=self)
            self._on_cat_selected()
