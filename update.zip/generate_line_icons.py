"""
generate_line_icons.py
Generates modern minimalist Line Icons (Feather / Material Symbols style)
with consistent 24x24 dimensions, soft dark grey color (#4A4A4A),
and transparent backgrounds using Pillow with 8x supersampling for ultra-crisp antialiasing.
"""

import os
import math
from PIL import Image, ImageDraw

COLOR_STROKE = (74, 74, 74, 255)  # #4A4A4A (Soft dark grey)
SIZE_HIGH = 192
SIZE_TARGET = 24
STROKE_WIDTH = 12  # Scales to 1.5px at 24x24


def create_canvas():
    return Image.new("RGBA", (SIZE_HIGH, SIZE_HIGH), (0, 0, 0, 0))


def save_icon(img, filepath):
    resized = img.resize((SIZE_TARGET, SIZE_TARGET), Image.Resampling.LANCZOS)
    resized.save(filepath, "PNG")


def gen_dashboard():
    img = create_canvas()
    d = ImageDraw.Draw(img)
    # 4 rounded tiles
    r = 10
    d.rounded_rectangle([28, 28, 86, 86], radius=r, outline=COLOR_STROKE, width=STROKE_WIDTH)
    d.rounded_rectangle([106, 28, 164, 86], radius=r, outline=COLOR_STROKE, width=STROKE_WIDTH)
    d.rounded_rectangle([28, 106, 86, 164], radius=r, outline=COLOR_STROKE, width=STROKE_WIDTH)
    d.rounded_rectangle([106, 106, 164, 164], radius=r, outline=COLOR_STROKE, width=STROKE_WIDTH)
    return img


def gen_customer():
    img = create_canvas()
    d = ImageDraw.Draw(img)
    # Head circle
    d.ellipse([66, 26, 126, 86], outline=COLOR_STROKE, width=STROKE_WIDTH)
    # Body arc
    d.arc([30, 100, 162, 220], start=190, end=350, fill=COLOR_STROKE, width=STROKE_WIDTH)
    # Shoulders base line connect
    d.line([(31, 158), (44, 168)], fill=COLOR_STROKE, width=STROKE_WIDTH)
    d.line([(161, 158), (148, 168)], fill=COLOR_STROKE, width=STROKE_WIDTH)
    d.line([(44, 168), (148, 168)], fill=COLOR_STROKE, width=STROKE_WIDTH)
    return img


def gen_supplier():
    img = create_canvas()
    d = ImageDraw.Draw(img)
    # Truck cargo box
    d.rounded_rectangle([24, 48, 116, 138], radius=6, outline=COLOR_STROKE, width=STROKE_WIDTH)
    # Cabin
    d.line([(116, 80), (146, 80), (168, 104), (168, 138), (116, 138)], fill=COLOR_STROKE, width=STROKE_WIDTH)
    # Cabin window
    d.line([(126, 88), (142, 88), (154, 104), (126, 104), (126, 88)], fill=COLOR_STROKE, width=8)
    # Front & Rear Wheels
    d.ellipse([46, 130, 78, 162], outline=COLOR_STROKE, width=STROKE_WIDTH)
    d.ellipse([128, 130, 160, 162], outline=COLOR_STROKE, width=STROKE_WIDTH)
    return img


def gen_accounts():
    img = create_canvas()
    d = ImageDraw.Draw(img)
    # Bank / Landmark structure
    # Roof pediment
    d.polygon([(96, 32), (24, 70), (168, 70)], outline=COLOR_STROKE, fill=(0, 0, 0, 0))
    d.line([(96, 32), (24, 70), (168, 70), (96, 32)], fill=COLOR_STROKE, width=STROKE_WIDTH)
    # Columns
    d.line([(48, 70), (48, 134)], fill=COLOR_STROKE, width=STROKE_WIDTH)
    d.line([(80, 70), (80, 134)], fill=COLOR_STROKE, width=STROKE_WIDTH)
    d.line([(112, 70), (112, 134)], fill=COLOR_STROKE, width=STROKE_WIDTH)
    d.line([(144, 70), (144, 134)], fill=COLOR_STROKE, width=STROKE_WIDTH)
    # Base
    d.rounded_rectangle([20, 134, 172, 156], radius=4, outline=COLOR_STROKE, width=STROKE_WIDTH)
    return img


def gen_inventory():
    img = create_canvas()
    d = ImageDraw.Draw(img)
    # Isometric Box / Package
    p_top = (96, 30)
    p_left = (32, 66)
    p_right = (160, 66)
    p_mid = (96, 102)
    p_bot_l = (32, 138)
    p_bot_r = (160, 138)
    p_bot = (96, 174)

    # Top rhombus
    d.line([p_top, p_right, p_mid, p_left, p_top], fill=COLOR_STROKE, width=STROKE_WIDTH)
    # Left & right & center verticals
    d.line([p_left, p_bot_l], fill=COLOR_STROKE, width=STROKE_WIDTH)
    d.line([p_right, p_bot_r], fill=COLOR_STROKE, width=STROKE_WIDTH)
    d.line([p_mid, p_bot], fill=COLOR_STROKE, width=STROKE_WIDTH)
    # Bottom lines
    d.line([p_bot_l, p_bot, p_bot_r], fill=COLOR_STROKE, width=STROKE_WIDTH)
    # Flap line
    d.line([(96, 30), (96, 66)], fill=COLOR_STROKE, width=STROKE_WIDTH)
    return img


def gen_unit():
    img = create_canvas()
    d = ImageDraw.Draw(img)
    # Ruler / Measure
    d.rounded_rectangle([28, 70, 164, 122], radius=8, outline=COLOR_STROKE, width=STROKE_WIDTH)
    # Ticks
    d.line([(56, 70), (56, 92)], fill=COLOR_STROKE, width=STROKE_WIDTH)
    d.line([(82, 70), (82, 102)], fill=COLOR_STROKE, width=STROKE_WIDTH)
    d.line([(108, 70), (108, 92)], fill=COLOR_STROKE, width=STROKE_WIDTH)
    d.line([(134, 70), (134, 102)], fill=COLOR_STROKE, width=STROKE_WIDTH)
    return img


def gen_service():
    img = create_canvas()
    d = ImageDraw.Draw(img)
    # Service Gear / Cog outline
    cx, cy, r_out, r_in = 96, 96, 64, 44
    teeth = 6
    points = []
    for i in range(teeth * 2):
        angle = i * (math.pi / teeth)
        r = r_out if i % 2 == 0 else r_in
        # Two sub-points for trapezoidal teeth
        a1 = angle - 0.15
        a2 = angle + 0.15
        points.append((cx + r * math.cos(a1), cy + r * math.sin(a1)))
        points.append((cx + r * math.cos(a2), cy + r * math.sin(a2)))
    points.append(points[0])
    d.line(points, fill=COLOR_STROKE, width=STROKE_WIDTH)
    # Center hole
    d.ellipse([74, 74, 118, 118], outline=COLOR_STROKE, width=STROKE_WIDTH)
    return img


def gen_balance():
    img = create_canvas()
    d = ImageDraw.Draw(img)
    # Weighing Scales
    # Pillar & base
    d.line([(96, 32), (96, 160)], fill=COLOR_STROKE, width=STROKE_WIDTH)
    d.line([(60, 160), (132, 160)], fill=COLOR_STROKE, width=STROKE_WIDTH)
    # Beam
    d.line([(40, 58), (152, 58)], fill=COLOR_STROKE, width=STROKE_WIDTH)
    # Left pan strings & plate
    d.line([(40, 58), (22, 112)], fill=COLOR_STROKE, width=STROKE_WIDTH - 3)
    d.line([(40, 58), (58, 112)], fill=COLOR_STROKE, width=STROKE_WIDTH - 3)
    d.arc([18, 104, 62, 122], start=0, end=180, fill=COLOR_STROKE, width=STROKE_WIDTH)
    d.line([(18, 113), (62, 113)], fill=COLOR_STROKE, width=STROKE_WIDTH)
    # Right pan strings & plate
    d.line([(152, 58), (134, 112)], fill=COLOR_STROKE, width=STROKE_WIDTH - 3)
    d.line([(152, 58), (170, 112)], fill=COLOR_STROKE, width=STROKE_WIDTH - 3)
    d.arc([130, 104, 174, 122], start=0, end=180, fill=COLOR_STROKE, width=STROKE_WIDTH)
    d.line([(130, 113), (174, 113)], fill=COLOR_STROKE, width=STROKE_WIDTH)
    return img


def gen_profit():
    img = create_canvas()
    d = ImageDraw.Draw(img)
    # Trending Up line graph
    # Axes
    d.line([(28, 36), (28, 164), (164, 164)], fill=COLOR_STROKE, width=STROKE_WIDTH)
    # Trend line
    pts = [(38, 134), (74, 100), (110, 118), (154, 52)]
    d.line(pts, fill=COLOR_STROKE, width=STROKE_WIDTH)
    # Arrow head
    d.line([(126, 52), (154, 52), (154, 80)], fill=COLOR_STROKE, width=STROKE_WIDTH)
    return img


def gen_ledger():
    img = create_canvas()
    d = ImageDraw.Draw(img)
    # Book / Journal
    d.line([(96, 160), (32, 144), (32, 44), (96, 60), (160, 44), (160, 144), (96, 160)], fill=COLOR_STROKE, width=STROKE_WIDTH)
    d.line([(96, 60), (96, 160)], fill=COLOR_STROKE, width=STROKE_WIDTH)
    # Lines on left page
    d.line([(48, 76), (82, 84)], fill=COLOR_STROKE, width=STROKE_WIDTH - 4)
    d.line([(48, 100), (82, 108)], fill=COLOR_STROKE, width=STROKE_WIDTH - 4)
    # Lines on right page
    d.line([(110, 84), (144, 76)], fill=COLOR_STROKE, width=STROKE_WIDTH - 4)
    d.line([(110, 108), (144, 100)], fill=COLOR_STROKE, width=STROKE_WIDTH - 4)
    return img


def gen_daybook():
    img = create_canvas()
    d = ImageDraw.Draw(img)
    # Calendar page
    d.rounded_rectangle([32, 44, 160, 164], radius=10, outline=COLOR_STROKE, width=STROKE_WIDTH)
    # Header bar
    d.line([(32, 80), (160, 80)], fill=COLOR_STROKE, width=STROKE_WIDTH)
    # Binder rings
    d.line([(60, 26), (60, 54)], fill=COLOR_STROKE, width=STROKE_WIDTH)
    d.line([(132, 26), (132, 54)], fill=COLOR_STROKE, width=STROKE_WIDTH)
    # Grid dots / checklist
    for y in [104, 134]:
        for x in [58, 96, 134]:
            d.ellipse([x - 5, y - 5, x + 5, y + 5], fill=COLOR_STROKE)
    return img


def gen_sales():
    img = create_canvas()
    d = ImageDraw.Draw(img)
    # Shopping Cart
    d.line([(24, 40), (46, 40), (62, 120), (144, 120), (158, 62), (48, 62)], fill=COLOR_STROKE, width=STROKE_WIDTH)
    # Wheels
    d.ellipse([64, 136, 88, 160], outline=COLOR_STROKE, width=STROKE_WIDTH)
    d.ellipse([126, 136, 150, 160], outline=COLOR_STROKE, width=STROKE_WIDTH)
    return img


def gen_invdet():
    img = create_canvas()
    d = ImageDraw.Draw(img)
    # Box with Magnifier
    # Small Box at top-left
    d.rounded_rectangle([28, 36, 116, 120], radius=8, outline=COLOR_STROKE, width=STROKE_WIDTH)
    d.line([(28, 66), (116, 66)], fill=COLOR_STROKE, width=STROKE_WIDTH - 4)
    # Magnifier at bottom right
    d.ellipse([92, 92, 148, 148], outline=COLOR_STROKE, width=STROKE_WIDTH)
    d.line([(134, 134), (166, 166)], fill=COLOR_STROKE, width=STROKE_WIDTH + 2)
    return img


def gen_invsum():
    img = create_canvas()
    d = ImageDraw.Draw(img)
    # Bar Chart Summary
    d.line([(24, 164), (168, 164)], fill=COLOR_STROKE, width=STROKE_WIDTH)
    # 3 Outline Bars
    d.rounded_rectangle([36, 108, 68, 164], radius=4, outline=COLOR_STROKE, width=STROKE_WIDTH)
    d.rounded_rectangle([80, 72, 112, 164], radius=4, outline=COLOR_STROKE, width=STROKE_WIDTH)
    d.rounded_rectangle([124, 38, 156, 164], radius=4, outline=COLOR_STROKE, width=STROKE_WIDTH)
    return img


def gen_tax():
    img = create_canvas()
    d = ImageDraw.Draw(img)
    # Percent inside rounded badge
    d.rounded_rectangle([28, 28, 164, 164], radius=16, outline=COLOR_STROKE, width=STROKE_WIDTH)
    # Diagonal % line
    d.line([(130, 62), (62, 130)], fill=COLOR_STROKE, width=STROKE_WIDTH)
    # Circles
    d.ellipse([64, 60, 88, 84], outline=COLOR_STROKE, width=STROKE_WIDTH - 2)
    d.ellipse([104, 108, 128, 132], outline=COLOR_STROKE, width=STROKE_WIDTH - 2)
    return img


def gen_allrep():
    img = create_canvas()
    d = ImageDraw.Draw(img)
    # Cascading documents
    # Back document
    d.rounded_rectangle([60, 26, 164, 132], radius=6, outline=COLOR_STROKE, width=STROKE_WIDTH)
    # Front document
    d.rounded_rectangle([28, 56, 132, 166], radius=6, outline=COLOR_STROKE, width=STROKE_WIDTH)
    # Lines on front doc
    d.line([(48, 88), (112, 88)], fill=COLOR_STROKE, width=STROKE_WIDTH - 4)
    d.line([(48, 112), (112, 112)], fill=COLOR_STROKE, width=STROKE_WIDTH - 4)
    d.line([(48, 136), (88, 136)], fill=COLOR_STROKE, width=STROKE_WIDTH - 4)
    return img


def generate_all_icons(output_dir):
    os.makedirs(output_dir, exist_ok=True)
    generators = {
        "dashboard.png": gen_dashboard,
        "customer.png": gen_customer,
        "supplier.png": gen_supplier,
        "accounts.png": gen_accounts,
        "inventory.png": gen_inventory,
        "unit.png": gen_unit,
        "service.png": gen_service,
        "balance.png": gen_balance,
        "profit.png": gen_profit,
        "ledger.png": gen_ledger,
        "daybook.png": gen_daybook,
        "sales.png": gen_sales,
        "invdet.png": gen_invdet,
        "invsum.png": gen_invsum,
        "tax.png": gen_tax,
        "allrep.png": gen_allrep,
    }

    for fname, fn in generators.items():
        img = fn()
        out_path = os.path.join(output_dir, fname)
        save_icon(img, out_path)
        print(f"Generated line icon: {fname}")


if __name__ == "__main__":
    base_dir = os.path.dirname(os.path.abspath(__file__))
    icons_dir = os.path.join(base_dir, "icons")
    generate_all_icons(icons_dir)
    print("All modern line icons generated successfully!")
