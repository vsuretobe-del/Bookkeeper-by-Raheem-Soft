import re

with open('bookkeeper.py', 'r', encoding='utf-8') as f:
    text = f.read()

update_logic = '''
def check_for_updates(root):
    import urllib.request
    import threading
    from tkinter import messagebox
    import subprocess
    import sys
    import os

    # Replace with the actual URL to the raw version.txt in the GitHub repo
    VERSION_URL = "https://raw.githubusercontent.com/YOUR_GITHUB_USERNAME/YOUR_REPO_NAME/main/version.txt"
    
    def run_check():
        try:
            if "YOUR_GITHUB_USERNAME" in VERSION_URL:
                return # Not configured yet
                
            # Read local version
            local_version = "1.0.0"
            if os.path.exists("version.txt"):
                with open("version.txt", "r") as vf:
                    local_version = vf.read().strip()
            
            # Fetch remote version
            req = urllib.request.Request(VERSION_URL, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=5) as response:
                remote_version = response.read().decode('utf-8').strip()
                
            # Simple string comparison for versions (assuming format X.Y.Z)
            def parse_version(v):
                return [int(x) for x in v.split('.') if x.isdigit()]
                
            if parse_version(remote_version) > parse_version(local_version):
                root.after(0, prompt_update, remote_version)
        except Exception as e:
            pass # Fail silently if no internet or error

    def prompt_update(new_ver):
        if messagebox.askyesno("Update Available", f"A new version ({new_ver}) is available. Would you like to update now?"):
            try:
                subprocess.Popen([sys.executable, "updater.py"], creationflags=subprocess.CREATE_NEW_CONSOLE)
            except:
                os.startfile("updater.py")
            root.destroy()
            sys.exit(0)

    threading.Thread(target=run_check, daemon=True).start()

'''

# Inject before BookKeeperClone class or after imports
old_import = "class BookKeeperClone(tk.Tk):"
new_import = update_logic + "class BookKeeperClone(tk.Tk):"
text = text.replace(old_import, new_import)

# Call check_for_updates at the end of __init__
old_init_end = '''        # Try loading recently used company
        recent_path = "recent_companies.json"
        if os.path.exists(recent_path):
            try:
                with open(recent_path, "r") as f:
                    data = json.load(f)
                    recent_comps = data.get("recent", [])
                    if recent_comps:
                        last_c = recent_comps[0]
                        if os.path.exists(last_c["path"]):
                            self.db_path = last_c["path"]
                            self.company_name = last_c["name"]
                            self.update_title()
            except Exception:
                pass'''
new_init_end = old_init_end + '''
        
        # Check for updates in background
        check_for_updates(self)'''
        
text = text.replace(old_init_end, new_init_end)

with open('bookkeeper.py', 'w', encoding='utf-8') as f:
    f.write(text)
print("bookkeeper.py patched successfully for Auto-Updates")
