with open('db.py', 'r', encoding='utf-8') as f:
    content = f.read()

new_func = '''def get_all_units():
    conn = get_conn()
    rows = conn.execute("SELECT * FROM units_measure ORDER BY units_name").fetchall()
    conn.close()
    return [dict(r) for r in rows]

def add_unit(data):
    conn = get_conn()
    cols = ", ".join(data.keys())
    placeholders = ", ".join("?" * len(data))
    query = f"INSERT INTO units_measure ({cols}) VALUES ({placeholders})"
    conn.execute(query, tuple(data.values()))
    conn.commit()
    conn.close()
'''

# append it at the end of db.py
with open('db.py', 'w', encoding='utf-8') as f:
    f.write(content + "\n" + new_func)

print("Added db methods")
