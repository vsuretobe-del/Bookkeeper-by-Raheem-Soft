import db
conn = db.get_conn()
conn.row_factory = __import__('sqlite3').Row

v_sale = conn.execute("SELECT * FROM vouchers WHERE v_type='sale' LIMIT 1").fetchone()
if v_sale:
    items = db.get_invoice_items(v_sale['v_id'])
    print('Sale items DB:', len(items))
    if items:
        print('First sale item price:', repr(items[0]['price']))
        print('First sale item qty:', repr(items[0]['qty']))
        print('First sale item tax_pct:', repr(items[0]['tax_pct']))
