with open('authentic_schema.sql', 'r', encoding='utf-16le') as f:
    lines = f.readlines()
for i, line in enumerate(lines):
    if "CREATE TABLE" in line and "item_measure" in line.lower():
        print("".join(lines[i:i+30]))
        break
