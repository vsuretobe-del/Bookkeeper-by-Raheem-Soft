import tkinter as tk
from tkinter import ttk, messagebox
import db

WHITE = "#ffffff"
BG = "#f2f2f2"
BLUE_DARK = "#005a9e"
FONT = ("Segoe UI", 10)
FONT_BOLD = ("Segoe UI", 10, "bold")
RED = "darkred"

class UserManagementWindow(tk.Toplevel):
    def __init__(self, master):
        super().__init__(master)
        self.title("User Management")
        self.geometry("980x720")
        self.configure(bg=WHITE)
        self.transient(master)
        self.grab_set()

        # Pre-check: Company Level Password must be enabled
        enable_pwd = db.get_setting("company_enable_pwd", "0")
        pwd = db.get_setting("company_password", "").strip()
        if str(enable_pwd) != "1" or not pwd:
            messagebox.showwarning(
                "operation failed",
                "You need to first setup company password.\nGo to Settings > Company Settings & enable Company Level Password.\n\nERRCODE: [v7.3.9][BKW10301289]",
                parent=self
            )
            self.destroy()
            return

        self.users = []
        self.editing_user_id = None
        self.is_editing = False

        self.setup_ui()
        self.load_users()
        self.bind_events()

    def setup_ui(self):
        # ── Top Frame ────────────────────────────────────────────────────────
        top_fr = tk.Frame(self, bg=WHITE)
        top_fr.pack(fill="x", padx=15, pady=(10, 5))

        inst1 = tk.Label(
            top_fr,
            text="Press ENTER to move forward SHIFT+ENTER to move back.\nPress SPACE to check/uncheck checkboxes.",
            bg=WHITE,
            fg=RED,
            font=("Segoe UI", 10, "bold italic"),
            justify="left"
        )
        inst1.pack(side="left", anchor="nw")

        fr_right_inst = tk.Frame(top_fr, bg=WHITE)
        fr_right_inst.pack(side="right", anchor="ne")
        
        lbl_red_part = tk.Label(
            fr_right_inst,
            text="Press ENTER to edit & DELETE to delete user.",
            bg=WHITE,
            fg=RED,
            font=("Segoe UI", 10, "bold italic")
        )
        lbl_red_part.pack(anchor="w")
        
        inst2_rest = tk.Label(
            fr_right_inst,
            text="This block displays summary of all users, you can edit\nusername and password here. If you need to change\npermissions, press Enter to edit it in left block and then\nclick 'Save Changes' or 'Add User'",
            bg=WHITE,
            fg="black",
            font=("Segoe UI", 9),
            justify="left"
        )
        inst2_rest.pack(anchor="w")

        # ── Main Content ─────────────────────────────────────────────────────
        main_fr = tk.Frame(self, bg=WHITE)
        main_fr.pack(fill="both", expand=True, padx=15, pady=5)

        left_fr = tk.Frame(main_fr, bg=WHITE)
        left_fr.pack(side="left", fill="both", expand=True, padx=(0, 10))

        right_fr = tk.Frame(main_fr, bg=WHITE)
        right_fr.pack(side="right", fill="both", expand=False, padx=(10, 0))

        # --- Left Form Header / Status ---
        self.lbl_mode_status = tk.Label(
            left_fr,
            text="Add New User",
            bg=WHITE,
            fg=BLUE_DARK,
            font=("Segoe UI", 11, "bold")
        )
        self.lbl_mode_status.pack(anchor="w", pady=(0, 5))

        # --- Left Form Inputs ---
        form_fr = tk.Frame(left_fr, bg=WHITE)
        form_fr.pack(fill="x", pady=2)
        
        tk.Label(form_fr, text="Username *", bg=WHITE, font=FONT_BOLD).grid(row=0, column=0, sticky="e", padx=5, pady=3)
        tk.Label(form_fr, text="Password *", bg=WHITE, font=FONT_BOLD).grid(row=1, column=0, sticky="e", padx=5, pady=3)
        tk.Label(form_fr, text="Initials", bg=WHITE, font=FONT).grid(row=2, column=0, sticky="e", padx=5, pady=3)

        self.uname_var = tk.StringVar()
        self.pass_var = tk.StringVar()
        self.init_var = tk.StringVar()

        self.uname_e = tk.Entry(form_fr, textvariable=self.uname_var, font=FONT, width=32, relief="solid", bd=1)
        self.uname_e.grid(row=0, column=1, padx=5, pady=3, sticky="w")
        
        pass_sub_fr = tk.Frame(form_fr, bg=WHITE)
        pass_sub_fr.grid(row=1, column=1, padx=5, pady=3, sticky="w")
        self.pass_e = tk.Entry(pass_sub_fr, textvariable=self.pass_var, font=FONT, width=26, relief="solid", bd=1, show="*")
        self.pass_e.pack(side="left")
        
        self.show_pwd_var = tk.BooleanVar(value=False)
        def toggle_pwd():
            if self.show_pwd_var.get():
                self.pass_e.config(show="")
            else:
                self.pass_e.config(show="*")
        btn_eye = tk.Checkbutton(pass_sub_fr, text="Show", variable=self.show_pwd_var, command=toggle_pwd, bg=WHITE, font=("Segoe UI", 8))
        btn_eye.pack(side="left", padx=5)

        self.init_e = tk.Entry(form_fr, textvariable=self.init_var, font=FONT, width=32, relief="solid", bd=1)
        self.init_e.grid(row=2, column=1, padx=5, pady=3, sticky="w")

        tk.Label(
            form_fr,
            text="(Initials will be added to voucher numbers created by this user. Ex:\nRM-INV1, where RM are initials of user)",
            bg=WHITE,
            fg="#555555",
            font=("Segoe UI", 8, "italic"),
            justify="left"
        ).grid(row=3, column=1, sticky="w", padx=5, pady=(0, 5))

        # Permissions Quick Controls
        quick_perm_fr = tk.Frame(left_fr, bg=WHITE)
        quick_perm_fr.pack(fill="x", pady=(5, 2))
        
        tk.Label(quick_perm_fr, text="Permissions:", bg=WHITE, font=FONT_BOLD).pack(side="left")
        
        def select_all_perms():
            for v in self.perm_vars.values():
                v.set(1)
                
        def deselect_all_perms():
            for v in self.perm_vars.values():
                v.set(0)
                
        btn_sel_all = tk.Button(quick_perm_fr, text="Select All", font=("Segoe UI", 8), command=select_all_perms, bg="#eef2f7", relief="groove", cursor="hand2")
        btn_sel_all.pack(side="left", padx=(10, 4))
        
        btn_desel_all = tk.Button(quick_perm_fr, text="Deselect All", font=("Segoe UI", 8), command=deselect_all_perms, bg="#eef2f7", relief="groove", cursor="hand2")
        btn_desel_all.pack(side="left", padx=4)

        # Permissions Grid
        perm_fr = tk.Frame(left_fr, bg=WHITE)
        perm_fr.pack(fill="x", pady=5)

        self.perm_vars = {}
        self.perm_widgets = []
        
        def create_perm_group(parent, title, row, col, checks):
            lf = tk.LabelFrame(parent, text=title, bg=WHITE, font=FONT_BOLD)
            lf.grid(row=row, column=col, padx=4, pady=4, sticky="nsew")
            for i, (text, key) in enumerate(checks):
                var = tk.IntVar(value=0)
                self.perm_vars[key] = var
                cb = tk.Checkbutton(lf, text=text, variable=var, bg=WHITE, font=FONT, cursor="hand2")
                cb.grid(row=i//2, column=i%2, sticky="w", padx=4, pady=2)
                cb.bind("<FocusIn>", lambda e, k=key: self.show_desc(k))
                cb.bind("<Enter>", lambda e, k=key: self.show_desc(k))
                self.perm_widgets.append(cb)

        create_perm_group(perm_fr, "ACCOUNTS", 0, 0, [("Create", "acc_create"), ("View", "acc_view")])
        create_perm_group(perm_fr, "Sales", 0, 1, [("Create", "sales_create"), ("View", "sales_view")])
        create_perm_group(perm_fr, "Purchase", 0, 2, [("Create", "purchase_create"), ("View", "purchase_view")])

        create_perm_group(perm_fr, "INVENTORY", 1, 0, [("Create", "inv_create"), ("View", "inv_view")])
        create_perm_group(perm_fr, "Banking", 1, 1, [("Create", "banking_create"), ("View", "banking_view")])
        create_perm_group(perm_fr, "Expense/Income", 1, 2, [("Create", "exp_inc_create"), ("View", "exp_inc_view")])

        create_perm_group(perm_fr, "Journal", 2, 0, [("Create", "journal_create"), ("View All", "journal_view_all")])
        create_perm_group(perm_fr, "Reports", 2, 1, [("View", "reports_view")])
        create_perm_group(perm_fr, "Modify Vouchers", 2, 2, [("Delete", "mod_delete"), ("Edit", "mod_edit")])

        # Other Permissions spans all cols
        lf_other = tk.LabelFrame(perm_fr, text="Other Permissions", bg=WHITE, font=FONT_BOLD)
        lf_other.grid(row=3, column=0, columnspan=3, padx=4, pady=4, sticky="nsew")
        
        var1 = tk.IntVar(); self.perm_vars["other_backdated"] = var1
        cb1 = tk.Checkbutton(lf_other, text="Allow Backdated Vouchers", variable=var1, bg=WHITE, font=FONT, cursor="hand2")
        cb1.grid(row=0, column=0, sticky="w", padx=4, pady=2); self.perm_widgets.append(cb1)
        cb1.bind("<FocusIn>", lambda e: self.show_desc("other_backdated"))
        cb1.bind("<Enter>", lambda e: self.show_desc("other_backdated"))

        var2 = tk.IntVar(); self.perm_vars["other_edit_vch_no"] = var2
        cb2 = tk.Checkbutton(lf_other, text="Allow Editing Voucher No.", variable=var2, bg=WHITE, font=FONT, cursor="hand2")
        cb2.grid(row=1, column=0, sticky="w", padx=4, pady=2); self.perm_widgets.append(cb2)
        cb2.bind("<FocusIn>", lambda e: self.show_desc("other_edit_vch_no"))
        cb2.bind("<Enter>", lambda e: self.show_desc("other_edit_vch_no"))

        var3 = tk.IntVar(); self.perm_vars["other_mod_rate"] = var3
        cb3 = tk.Checkbutton(lf_other, text="Allow Modification Of Rate", variable=var3, bg=WHITE, font=FONT, cursor="hand2")
        cb3.grid(row=0, column=1, sticky="w", padx=20, pady=2); self.perm_widgets.append(cb3)
        cb3.bind("<FocusIn>", lambda e: self.show_desc("other_mod_rate"))
        cb3.bind("<Enter>", lambda e: self.show_desc("other_mod_rate"))

        # Description Label
        self.desc_lbl = tk.Label(
            left_fr,
            text="",
            bg=WHITE,
            fg=RED,
            font=("Segoe UI", 9, "bold italic"),
            justify="left",
            wraplength=480,
            height=3
        )
        self.desc_lbl.pack(anchor="w", padx=5, pady=(2, 5))

        # Form Action Buttons Row
        action_btn_fr = tk.Frame(left_fr, bg=WHITE)
        action_btn_fr.pack(fill="x", pady=5)
        
        self.btn_cancel = tk.Button(
            action_btn_fr,
            text="Cancel / New User",
            font=FONT,
            bg="#f0f0f0",
            relief="solid",
            bd=1,
            command=self.clear_form,
            cursor="hand2"
        )
        self.btn_cancel.pack(side="left", padx=5)

        self.btn_save = tk.Button(
            action_btn_fr,
            text="Add User",
            font=FONT_BOLD,
            bg="#0078d7",
            fg="white",
            relief="solid",
            bd=1,
            padx=15,
            pady=4,
            command=self.save_user,
            cursor="hand2"
        )
        self.btn_save.pack(side="right", padx=5)

        # --- Right Summary Block ---
        sum_hdr_fr = tk.Frame(right_fr, bg=WHITE)
        sum_hdr_fr.pack(fill="x", pady=(0, 5))
        
        tk.Label(sum_hdr_fr, text="Summary", bg=WHITE, font=FONT_BOLD).pack(side="left")
        
        self.lbl_user_count = tk.Label(sum_hdr_fr, text="(0 Users)", bg=WHITE, fg="#666666", font=("Segoe UI", 9))
        self.lbl_user_count.pack(side="left", padx=5)

        table_fr = tk.Frame(right_fr, bg=WHITE)
        table_fr.pack(fill="both", expand=True)

        style = ttk.Style()
        style.configure("UM.Treeview", font=FONT, rowheight=26)
        style.configure("UM.Treeview.Heading", font=FONT_BOLD)
        
        self.tv = ttk.Treeview(
            table_fr,
            columns=("Username", "Password", "Initials"),
            show="headings",
            style="UM.Treeview",
            height=16
        )
        self.tv.heading("Username", text="Username", anchor="w")
        self.tv.heading("Password", text="Password", anchor="w")
        self.tv.heading("Initials", text="Initials", anchor="w")
        
        self.tv.column("Username", width=140)
        self.tv.column("Password", width=110)
        self.tv.column("Initials", width=90)
        
        tv_scroll = ttk.Scrollbar(table_fr, orient="vertical", command=self.tv.yview)
        self.tv.configure(yscrollcommand=tv_scroll.set)
        
        tv_scroll.pack(side="right", fill="y")
        self.tv.pack(side="left", fill="both", expand=True)

        # Summary Action Buttons below table
        sum_btn_fr = tk.Frame(right_fr, bg=WHITE)
        sum_btn_fr.pack(fill="x", pady=6)
        
        btn_edit_sel = tk.Button(
            sum_btn_fr,
            text="✎ Edit Selected",
            font=FONT,
            bg="#f0f0f0",
            relief="solid",
            bd=1,
            command=self.edit_user,
            cursor="hand2"
        )
        btn_edit_sel.pack(side="left", padx=(0, 5))
        
        btn_del_sel = tk.Button(
            sum_btn_fr,
            text="🗑 Delete Selected",
            font=FONT,
            bg="#f0f0f0",
            relief="solid",
            bd=1,
            command=self.delete_user,
            cursor="hand2"
        )
        btn_del_sel.pack(side="left", padx=5)

        # Context Menu for right click
        self.context_menu = tk.Menu(self, tearoff=0, font=FONT)
        self.context_menu.add_command(label="Edit User", command=self.edit_user)
        self.context_menu.add_command(label="Delete User", command=self.delete_user)

        # ── Bottom Bar ───────────────────────────────────────────────────────
        bot_fr = tk.Frame(self, bg=BG)
        bot_fr.pack(fill="x", side="bottom")
        
        tk.Button(bot_fr, text="Ctrl+Q: Exit", font=FONT, command=self.destroy, bg="#e0e0e0", relief="groove", padx=10, pady=3).pack(side="left", padx=10, pady=6)
        
        lbl_vid = tk.Label(
            bot_fr,
            text="Video: How to Create Users ?",
            bg=BG,
            fg="blue",
            font=("Segoe UI", 9, "underline"),
            cursor="hand2"
        )
        lbl_vid.pack(side="left", expand=True, pady=6)
        lbl_vid.bind("<Button-1>", lambda e: messagebox.showinfo(
            "User Management Help",
            "To manage users:\n1. Fill in Username, Password, and optional Initials.\n2. Select desired permissions for the user.\n3. Click 'Add User' (or F12:Save).\n4. Click any existing user in the Summary list to edit their details and permissions, then click 'Save Changes'.\n5. Select a user and press Delete (or click 'Delete Selected') to remove a user.",
            parent=self
        ))
        
        tk.Button(bot_fr, text="F12:Save", font=FONT_BOLD, bg="#0078d7", fg="white", command=self.save_user, relief="raised", padx=15, pady=3).pack(side="right", padx=10, pady=6)

    def bind_events(self):
        self.bind("<Control-q>", lambda e: self.destroy())
        self.bind("<Control-Q>", lambda e: self.destroy())
        self.bind("<F12>", lambda e: self.save_user())
        
        self.tv.bind("<Return>", self.edit_user)
        self.tv.bind("<Double-1>", self.edit_user)
        self.tv.bind("<<TreeviewSelect>>", self.on_tree_select)
        self.tv.bind("<Delete>", self.delete_user)
        self.tv.bind("<Button-3>", self.show_context_menu)

        # Enter/Shift-Enter traversal for form
        fields = [self.uname_e, self.pass_e, self.init_e] + self.perm_widgets + [self.btn_save]
        
        for i, w in enumerate(fields):
            nxt = fields[(i+1) % len(fields)]
            prv = fields[(i-1) % len(fields)]
            w.bind("<Return>", lambda e, n=nxt: (n.focus_set(), "break")[1])
            w.bind("<Shift-Return>", lambda e, p=prv: (p.focus_set(), "break")[1])
            if isinstance(w, tk.Checkbutton):
                w.bind("<space>", lambda e, cb=w: (cb.invoke(), "break")[1])

        self.uname_e.bind("<FocusIn>", lambda e: self.uname_e.config(bg="#ffffcc"))
        self.uname_e.bind("<FocusOut>", lambda e: self.uname_e.config(bg=WHITE))
        self.pass_e.bind("<FocusIn>", lambda e: self.pass_e.config(bg="#ffffcc"))
        self.pass_e.bind("<FocusOut>", lambda e: self.pass_e.config(bg=WHITE))
        self.init_e.bind("<FocusIn>", lambda e: self.init_e.config(bg="#ffffcc"))
        self.init_e.bind("<FocusOut>", lambda e: self.init_e.config(bg=WHITE))

    def show_context_menu(self, event):
        row_id = self.tv.identify_row(event.y)
        if row_id:
            self.tv.selection_set(row_id)
            self.context_menu.post(event.x_root, event.y_root)

    def load_users(self):
        for item in self.tv.get_children():
            self.tv.delete(item)
        self.users = db.get_all_users()
        self.lbl_user_count.config(text=f"({len(self.users)} Users)")
        for u in self.users:
            self.tv.insert("", "end", iid=str(u["id"]), values=(u["username"], u["password"], u.get("initials", "") or ""))

    def on_tree_select(self, event=None):
        sel = self.tv.selection()
        if not sel:
            return
        user_id_str = sel[0]
        user = next((u for u in self.users if str(u["id"]) == user_id_str), None)
        if not user:
            # Try by username from values
            vals = self.tv.item(user_id_str, "values")
            if vals:
                user = next((u for u in self.users if u["username"] == vals[0]), None)
        if user:
            self.load_user_into_form(user)

    def load_user_into_form(self, user):
        self.editing_user_id = user["id"]
        self.is_editing = user["username"]
        self.uname_var.set(user["username"])
        self.pass_var.set(user["password"])
        self.init_var.set(user.get("initials", "") or "")
        
        for k, v in self.perm_vars.items():
            if k in user:
                try:
                    v.set(int(user[k]) if user[k] is not None else 0)
                except:
                    v.set(1 if user[k] else 0)
            else:
                v.set(0)
                
        self.lbl_mode_status.config(text=f"Editing User: '{user['username']}'", fg="#d9534f")
        self.btn_save.config(text="Save Changes", bg="#28a745")

    def edit_user(self, event=None):
        sel = self.tv.selection()
        if not sel:
            return
        self.on_tree_select()
        self.uname_e.focus_set()

    def delete_user(self, event=None):
        sel = self.tv.selection()
        if not sel:
            messagebox.showinfo("Select User", "Please select a user from the summary table to delete.", parent=self)
            return
        user_id_str = sel[0]
        vals = self.tv.item(user_id_str, "values")
        uname = vals[0] if vals else "User"
        
        if messagebox.askyesno("Confirm Deletion", f"Are you sure you want to delete user '{uname}'?", parent=self):
            db.delete_user(int(user_id_str) if user_id_str.isdigit() else uname)
            self.clear_form()
            self.load_users()
            messagebox.showinfo("Deleted", f"User '{uname}' deleted successfully.", parent=self)

    def clear_form(self):
        self.editing_user_id = None
        self.is_editing = False
        self.uname_var.set("")
        self.pass_var.set("")
        self.init_var.set("")
        for v in self.perm_vars.values():
            v.set(0)
        self.lbl_mode_status.config(text="Add New User", fg=BLUE_DARK)
        self.btn_save.config(text="Add User", bg="#0078d7")
        self.desc_lbl.config(text="")
        if self.tv.selection():
            self.tv.selection_remove(self.tv.selection())
        self.uname_e.focus_set()

    def save_user(self):
        uname = self.uname_var.get().strip()
        pwd = self.pass_var.get().strip()
        if not uname:
            messagebox.showerror("Validation Error", "Username is required.", parent=self)
            self.uname_e.focus_set()
            return
        if not pwd:
            messagebox.showerror("Validation Error", "Password is required.", parent=self)
            self.pass_e.focus_set()
            return

        data = {
            "username": uname,
            "password": pwd,
            "initials": self.init_var.get().strip(),
        }
        for k, v in self.perm_vars.items():
            data[k] = v.get()

        if self.editing_user_id:
            # Check if another user has the same username
            conflict = any(u["username"].lower() == uname.lower() and u["id"] != self.editing_user_id for u in self.users)
            if conflict:
                messagebox.showerror("Duplicate Username", f"Another user with username '{uname}' already exists.", parent=self)
                self.uname_e.focus_set()
                return

            success = db.update_user(self.editing_user_id, data)
            if success is not False:
                messagebox.showinfo("Success", f"Changes saved successfully for user '{uname}'.", parent=self)
            else:
                messagebox.showerror("Error", "Failed to update user.", parent=self)
                return
        else:
            # Check if username exists
            conflict = any(u["username"].lower() == uname.lower() for u in self.users)
            if conflict:
                messagebox.showerror("Duplicate Username", f"User '{uname}' already exists. Please choose a different username or select the user to edit.", parent=self)
                self.uname_e.focus_set()
                return

            success = db.add_user(data)
            if success:
                messagebox.showinfo("Success", f"User '{uname}' created successfully.", parent=self)
            else:
                messagebox.showerror("Error", "Failed to create user.", parent=self)
                return

        self.clear_form()
        self.load_users()

    def show_desc(self, key):
        descs = {
            "acc_create": "User can create new accounts.",
            "acc_view": "User can view list of accounts of all account types like:\nCustomer/Supplier/Cash/Bank/Expense etc.\n\nUser can also view Account Group Balance, Aged\nPayable/Receivable, Outstanding Payable/Receivable,\nBest Customers and Customer Supplier List report.",
            "inv_create": "User can create new inventory items.",
            "inv_view": "User can view inventory items and stock levels.",
            "journal_create": "User can create journal entries.",
            "journal_view_all": "User can view all journal entries.",
            "sales_create": "User can create sales invoices, estimates, credit notes and receipts.",
            "sales_view": "User can view sales reports and transactions.",
            "purchase_create": "User can create purchase invoices, purchase orders, debit notes and payments.",
            "purchase_view": "User can view purchase reports and transactions.",
            "banking_create": "User can create banking vouchers (Contra, Bank Payments/Receipts).",
            "banking_view": "User can view banking reports and statements.",
            "exp_inc_create": "User can create expenses and incomes.",
            "exp_inc_view": "User can view expenses and incomes.",
            "reports_view": "User can view reports like Balance Sheet, Profit & Loss, Trial Balance, etc.",
            "mod_delete": "User can delete existing vouchers.",
            "mod_edit": "User can edit existing vouchers.",
            "other_backdated": "User can create or edit backdated vouchers.",
            "other_edit_vch_no": "User can manually edit voucher numbers.",
            "other_mod_rate": "User can modify item unit rates in invoices.",
        }
        self.desc_lbl.config(text=descs.get(key, ""))
