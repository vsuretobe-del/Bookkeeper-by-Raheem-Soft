import re

with open('bookkeeper.py', 'r', encoding='utf-8') as f:
    text = f.read()

# 1. Add cash_adv_var, bank_adv_var, bank_acc_var
text = re.sub(
    r'adv_var\s*=\s*tk\.StringVar\(value="[^"]*"\)\s*\n\s*pmt_acc_var\s*=\s*tk\.StringVar\(value="[^"]*"\)',
    'cash_adv_var = tk.StringVar(value="0")\n        bank_adv_var = tk.StringVar(value="0")\n        bank_acc_var = tk.StringVar(value="")',
    text
)

# Fix edit loading where adv_var.set is used
text = text.replace('adv_var.set(str(abs(bal)))', 'cash_adv_var.set(str(abs(bal)))')
text = text.replace('adv_var.set("0")', 'cash_adv_var.set("0")')

# Fix trace_add
text = text.replace('adv_var.trace_add("write", lambda *args: recalc_total())', 'cash_adv_var.trace_add("write", lambda *args: recalc_total())\n        bank_adv_var.trace_add("write", lambda *args: recalc_total())')

# Fix recalc_total missed adv_var
text = text.replace('adv = float(adv_var.get() or 0)', 'adv = float(cash_adv_var.get() or 0) + float(bank_adv_var.get() or 0)')

# Fix save_voucher missed adv_var
text = text.replace('adv = sf(adv_var.get())', 'cash_adv = sf(cash_adv_var.get())\n                bank_adv = sf(bank_adv_var.get())\n                adv = cash_adv + bank_adv')

with open('bookkeeper.py', 'w', encoding='utf-8') as f:
    f.write(text)
print("Second patch applied!")
