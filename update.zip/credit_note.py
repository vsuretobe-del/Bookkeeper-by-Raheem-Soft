import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import datetime
import os
import db
from autocomplete import AutocompleteCombobox

FONT = ("Segoe UI", 10)
FONT_BOLD = ("Segoe UI", 10, "bold")
FONT_TITLE = ("Segoe UI", 12, "bold")
BG = "#f0f0f0"
BG_WHITE = "#ffffff"
YELLOW_BG = "#ffff00"

class SelectVouchersWindow(tk.Toplevel):
    def __init__(self, master, customer_name, callback):
        super().__init__(master)
        self.title("Select Vouchers")
        self.geometry("900x600")
        self.configure(bg=BG_WHITE)
        self.grab_set()
        self.transient(master)

        self.customer_name = customer_name
        self.callback = callback

        # Table
        columns = ("accounts", "description", "total", "outstanding", "to_pay", "select")
        
        style = ttk.Style()
        style.configure("SelectVouchers.Treeview", font=FONT, rowheight=45)
        style.configure("SelectVouchers.Treeview.Heading", font=FONT_BOLD)

        self.tree = ttk.Treeview(self, columns=columns, show="headings", height=11, style="SelectVouchers.Treeview")
        self.tree.heading("accounts", text="ACCOUNTS", anchor="w")
        self.tree.heading("description", text="Description", anchor="w")
        self.tree.heading("total", text="Total Amount", anchor="e")
        self.tree.heading("outstanding", text="Outstanding Amount", anchor="e")
        self.tree.heading("to_pay", text="Amount To Pay", anchor="e")
        self.tree.heading("select", text="Select", anchor="center")

        self.tree.column("accounts", width=160, anchor="w")
        self.tree.column("description", width=340, anchor="w")
        self.tree.column("total", width=100, anchor="e")
        self.tree.column("outstanding", width=130, anchor="e")
        self.tree.column("to_pay", width=100, anchor="e")
        self.tree.column("select", width=70, anchor="center")

        self.tree.tag_configure("selected", background="#ffff00")

        self.tree.pack(fill="both", expand=True, padx=10, pady=10)
        self.tree.bind("<Button-1>", self.on_click)
        self.tree.bind("<Double-1>", self.on_click)

        # Bottom section
        bot = tk.Frame(self, bg=BG_WHITE)
        bot.pack(fill="x", side="bottom", padx=15, pady=10)

        # Exit
        tk.Button(bot, text="Ctrl+Q: Exit", font=FONT_BOLD, bg="#e0e0e0", relief="solid", bd=1, width=12, pady=4,
                  command=self.destroy).pack(side="left")
        # OK
        tk.Button(bot, text="F12: OK", font=FONT_BOLD, bg="#e0e0e0", relief="solid", bd=1, width=12, pady=4,
                  command=self.on_ok).pack(side="right")

        # Fields
        f_fields = tk.Frame(bot, bg=BG_WHITE)
        f_fields.pack(side="top", pady=5)

        tk.Label(f_fields, text="F9: Advance Payment", font=FONT, bg=BG_WHITE).grid(row=0, column=0, sticky="e", pady=2)
        self.v_adv = tk.StringVar(value="0")
        adv_entry = tk.Entry(f_fields, textvariable=self.v_adv, font=FONT, justify="right", width=18, relief="solid", bd=1)
        adv_entry.grid(row=0, column=1, padx=5, pady=2)
        adv_entry.bind('<KeyRelease>', lambda e: self._update_total())

        tk.Label(f_fields, text="Against Opening Balance", font=FONT, bg=BG_WHITE).grid(row=1, column=0, sticky="e", pady=2)
        self.v_open = tk.StringVar(value="0")
        tk.Entry(f_fields, textvariable=self.v_open, font=FONT, justify="right", width=18, relief="solid", bd=1).grid(row=1, column=1, padx=5, pady=2)

        tk.Label(f_fields, text="Total Amount", font=FONT_BOLD, bg=BG_WHITE).grid(row=2, column=0, sticky="e", pady=2)
        self.v_tot = tk.StringVar(value="0")
        tk.Entry(f_fields, textvariable=self.v_tot, font=FONT_BOLD, justify="right", width=18, relief="solid", bd=1, state="readonly").grid(row=2, column=1, padx=5, pady=2)

        self._load_data()

        self.bind("<Control-q>", lambda e: self.destroy())
        self.bind("<Control-Q>", lambda e: self.destroy())
        self.bind("<F9>", lambda e: adv_entry.focus_set())
        self.bind("<F12>", lambda e: self.on_ok())

    def _load_data(self):
        conn = db.get_conn()
        if self.customer_name:
            rows = conn.execute("SELECT * FROM vouchers WHERE (debit=? OR credit=?) ORDER BY date DESC", (self.customer_name, self.customer_name)).fetchall()
        else:
            rows = conn.execute("SELECT * FROM vouchers ORDER BY date DESC").fetchall()
        conn.close()

        for r in rows:
            out = r["amount"] - (r["paid_amount"] if r["paid_amount"] else 0)
            v_type_title = "Journal" if r["v_type"] == "journal" else "Sales" if r["v_type"] == "sale" else r["v_type"].capitalize()
            desc = f"{v_type_title}\nVoucher No:{r['vch_no']}\nVoucher Date: {r['date']}\nVoucher Due Date: {r['date']}"
            accs = f"{self.customer_name or r.get('debit') or ''}\nCash"

            tot_str = f"{r['amount']:,.0f}" if r['amount'].is_integer() else f"{r['amount']:,.2f}"
            out_str = f"{out:,.0f}" if out.is_integer() else f"{out:,.2f}"

            self.tree.insert("", "end", values=(accs, desc, tot_str, out_str, "0", "☐"), tags=())

    def on_click(self, event):
        item = self.tree.identify('item', event.x, event.y)
        if not item: return

        column = self.tree.identify_column(event.x)
        vals = list(self.tree.item(item, "values"))

        if column == "#6" or event.type == "2":
            if vals[5] in ("☐", "False", ""):
                vals[5] = "☑"
                vals[4] = vals[3]
                self.tree.item(item, values=vals, tags=("selected"))
            else:
                vals[5] = "☐"
                vals[4] = "0"
                self.tree.item(item, values=vals, tags=())
            self._update_total()

    def _update_total(self):
        tot = 0.0
        for item in self.tree.get_children():
            v = self.tree.item(item, "values")
            if v[5] == "☑":
                try:
                    tot += float(str(v[4]).replace(',', ''))
                except ValueError:
                    pass
        try:
            adv = float(self.v_adv.get() or 0)
        except ValueError:
            adv = 0.0
        tot_val = tot + adv
        self.v_tot.set(f"{tot_val:,.0f}" if tot_val.is_integer() else f"{tot_val:,.2f}")

    def on_ok(self):
        selected_vchs = []
        tot_amt = 0.0
        for item in self.tree.get_children():
            v = self.tree.item(item, "values")
            if v[5] == "☑":
                try:
                    vch_no = v[1].split('Voucher No:')[1].split('\n')[0].strip()
                    amt = float(str(v[4]).replace(',', ''))
                    selected_vchs.append(vch_no)
                    tot_amt += amt
                except Exception:
                    pass
        self.callback(tot_amt, selected_vchs)
        self.destroy()


class CreditNoteWindow(tk.Toplevel):
    def __init__(self, master, app=None, edit_inv=None, is_duplicate=False):
        super().__init__(master)
        self.app = app
        self.edit_inv = edit_inv
        self.is_duplicate = is_duplicate

        self.title("Create Voucher" if not edit_inv or is_duplicate else "Edit Voucher")
        self.geometry("1280x750")
        try:
            self.state('zoomed')
        except Exception:
            pass

        self.configure(bg=BG)
        self.grab_set()
        self.transient(master)

        self.line_items = []
        self.ref_file_path = ""
        self.active_entry = None

        self._build_ui()
        self._bind_shortcuts()

        if self.edit_inv:
            self._load_edit_data()

    def _build_ui(self):
        # 1. Top Shortcut Bar
        tb = tk.Frame(self, bg=BG_WHITE, relief="groove", bd=1)
        tb.pack(fill="x", side="top")

        left_shortcuts = [
            ("Alt+A: New Account", lambda: self.app._account_form("account") if self.app else None),
            ("Alt+C: New Customer", lambda: self.app._account_form("customer") if self.app else None),
            ("Alt+S: New Supplier", lambda: self.app._account_form("supplier") if self.app else None),
            ("Alt+T: New Tax Account", lambda: self.app._account_form("tax") if self.app else None),
            ("Alt+I: New Inventory Item", lambda: self.app._item_form() if self.app else None),
            ("Alt+E: New Service", lambda: self.app._item_form() if self.app else None),
        ]
        for txt, cmd in left_shortcuts:
            btn = tk.Button(tb, text=txt, font=FONT_BOLD, bg=BG_WHITE, relief="flat", bd=0, cursor="hand2", command=cmd)
            btn.pack(side="left", padx=6, pady=4)

        tk.Button(tb, text="Ctrl+M: Item Mode", font=FONT_BOLD, bg=BG_WHITE, relief="flat", bd=0, cursor="hand2").pack(side="right", padx=10)
        tk.Button(tb, text="🔍 Ctrl+F: Search", font=FONT_BOLD, bg=BG_WHITE, relief="flat", bd=0, cursor="hand2",
                  command=lambda: self.app.show_invoices("credit_note") if self.app else None).pack(side="right", padx=5)

        tk.Frame(self, bg="#cccccc", height=1).pack(fill="x")

        # 2. Main Content Frame
        content = tk.Frame(self, bg=BG)
        content.pack(fill="both", expand=True, padx=15, pady=8)

        # Instruction Notice
        lbl_inst = tk.Label(content, text="Press ENTER to move forward", font=("Segoe UI", 11, "bold italic"), fg="#990000", bg=BG)
        lbl_inst.pack(anchor="center", pady=(0, 5))

        # Header Section
        hdr_fr = tk.Frame(content, bg=BG)
        hdr_fr.pack(fill="x", pady=(0, 5))

        # Row 1: Credit Note No
        r1 = tk.Frame(hdr_fr, bg=BG)
        r1.pack(fill="x", pady=2)
        tk.Label(r1, text="Credit Note No", font=FONT_BOLD, bg=BG, width=15, anchor="w").pack(side="left")
        self.v_cn_no = tk.StringVar(value=db.get_next_credit_note_no())
        e_cn = tk.Entry(r1, textvariable=self.v_cn_no, font=FONT_BOLD, bg=YELLOW_BG, width=30, relief="solid", bd=1)
        e_cn.pack(side="left")

        # Row 2: Voucher Date
        r2 = tk.Frame(hdr_fr, bg=BG)
        r2.pack(fill="x", pady=2)
        tk.Label(r2, text="Voucher Date", font=FONT, bg=BG, width=15, anchor="w").pack(side="left")
        today_str = datetime.date.today().strftime("%B %d, %Y")
        self.v_date = tk.StringVar(value=today_str)
        e_date = tk.Entry(r2, textvariable=self.v_date, font=FONT, width=25, relief="solid", bd=1)
        e_date.pack(side="left")
        btn_cal = tk.Button(r2, text="📅", font=("Segoe UI", 9), relief="solid", bd=1, command=self._pick_date, cursor="hand2")
        btn_cal.pack(side="left", padx=2)

        # Row 3: Debit Account (Sales Return)
        r3 = tk.Frame(hdr_fr, bg=BG)
        r3.pack(fill="x", pady=2)
        tk.Label(r3, text="Debit Account", font=FONT, bg=BG, width=15, anchor="w").pack(side="left")
        self.v_debit_acc = tk.StringVar(value="Sales Return")
        all_acc_names = [a["name"] for a in db.get_all_accounts()]
        if "Sales Return" not in all_acc_names:
            all_acc_names.insert(0, "Sales Return")
        cb_deb = AutocompleteCombobox(r3, textvariable=self.v_debit_acc, values=all_acc_names, font=FONT, width=28)
        cb_deb.pack(side="left")
        self.lbl_deb_bal = tk.Label(r3, text="balance 0", font=FONT, bg=BG, fg="#555555")
        self.lbl_deb_bal.pack(side="left", padx=10)
        cb_deb.bind("<<ComboboxSelected>>", self._update_deb_bal)

        # Row 4: Customer/Cash
        r4 = tk.Frame(hdr_fr, bg=BG)
        r4.pack(fill="x", pady=2)
        tk.Label(r4, text="Customer/Cash", font=FONT, bg=BG, width=15, anchor="w").pack(side="left")
        cust_accs = [a["name"] for a in db.get_all_accounts()]
        self.v_cust_acc = tk.StringVar()
        cb_cust = AutocompleteCombobox(r4, textvariable=self.v_cust_acc, values=cust_accs, font=FONT, width=28)
        cb_cust.pack(side="left")
        self.lbl_cust_bal = tk.Label(r4, text="balance 0", font=FONT, bg=BG, fg="#555555")
        self.lbl_cust_bal.pack(side="left", padx=10)
        cb_cust.bind("<<ComboboxSelected>>", self._update_cust_bal)

        # 3. Item Selection Header Bar
        item_hdr = tk.Frame(content, bg=BG)
        item_hdr.pack(fill="x", pady=(5, 2))

        tk.Label(item_hdr, text="Press ENTER key to add item.", font=("Segoe UI", 11, "bold italic"), fg="#990000", bg=BG).pack(anchor="w")

        r_item_sel = tk.Frame(item_hdr, bg=BG)
        r_item_sel.pack(fill="x", pady=2)

        # Left Item Entry
        tk.Label(r_item_sel, text="F9: Item", font=FONT_BOLD, bg=BG).pack(side="left", padx=(0, 5))
        self.all_items = db.get_all_items()
        item_names = [i.get("item") or i.get("name") or i.get("id", "") for i in self.all_items if (i.get("item") or i.get("name"))]
        self.v_sel_item = tk.StringVar()
        self.cb_item = AutocompleteCombobox(r_item_sel, textvariable=self.v_sel_item, values=item_names, font=FONT, width=35)
        self.cb_item.pack(side="left")
        self.cb_item.bind("<Return>", lambda e: self._add_item_row())

        self.lbl_units_left = tk.Label(r_item_sel, text="Units Left: 0", font=FONT, bg=BG, fg="#333333")
        self.lbl_units_left.pack(side="left", padx=10)
        btn_photo = tk.Label(r_item_sel, text="View Photo", font=("Segoe UI", 9, "underline"), fg="blue", bg=BG, cursor="hand2")
        btn_photo.pack(side="left")

        # Right Service Entry & Instruction
        lbl_right_inst = tk.Label(r_item_sel, text="DELETE: To Delete Row, Shift+UP/Down: To Rearrange Items",
                                  font=("Segoe UI", 9, "bold underline"), fg="#990000", bg=BG)
        lbl_right_inst.pack(side="right")

        tk.Label(r_item_sel, text="F10: Service", font=FONT_BOLD, bg=BG).pack(side="right", padx=(0, 5))
        self.v_sel_service = tk.StringVar()
        self.cb_service = AutocompleteCombobox(r_item_sel, textvariable=self.v_sel_service, values=item_names, font=FONT, width=20)
        self.cb_service.pack(side="right", padx=5)

        # 4. Line Items Grid / Table
        grid_frame = tk.Frame(content, bg=BG_WHITE, relief="solid", bd=1)
        grid_frame.pack(fill="both", expand=True, pady=5)

        columns = ("Item", "QTY", "Units", "Rate", "Per", "Discount(%)", "Tax", "Value", "Description")
        self.tree = ttk.Treeview(grid_frame, columns=columns, show="headings", height=8)
        
        widths = [220, 70, 70, 90, 70, 100, 70, 110, 220]
        for col, w in zip(columns, widths):
            self.tree.heading(col, text=col, anchor="w" if col in ("Item", "Description") else "e")
            self.tree.column(col, width=w, anchor="w" if col in ("Item", "Description") else "e")

        sb = ttk.Scrollbar(grid_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=sb.set)

        self.tree.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")

        self.tree.bind("<Button-1>", self._on_cell_click)
        self.tree.bind("<Double-1>", self._on_cell_click)
        self.tree.bind("<Delete>", self._on_row_delete)

        # 5. Set off against invoice section
        setoff_fr = tk.Frame(content, bg=BG)
        setoff_fr.pack(fill="x", pady=4)

        btn_setoff = tk.Button(setoff_fr, text="Set off against invoice", font=FONT_BOLD, bg="#e0e0e0", relief="solid", bd=1, padx=12, pady=2, command=self._set_off_invoice)
        btn_setoff.pack(side="left")

        self.lbl_setoff_vchs = tk.Label(setoff_fr, text="", font=FONT_BOLD, fg="black", bg=BG)
        self.lbl_setoff_vchs.pack(side="left", padx=10)

        tk.Label(setoff_fr, text="Amount", font=FONT_BOLD, bg=BG).pack(side="right", padx=(0, 5))
        self.v_setoff_amt = tk.StringVar(value="0")
        e_setoff = tk.Entry(setoff_fr, textvariable=self.v_setoff_amt, font=FONT_BOLD, width=20, justify="right", relief="solid", bd=1)
        e_setoff.pack(side="right", padx=5)

        # 6. Bottom Options & Save Section
        bot = tk.Frame(content, bg=BG)
        bot.pack(fill="x", pady=(5, 0))

        # Bottom Left
        bot_left = tk.Frame(bot, bg=BG)
        bot_left.pack(side="left", fill="both", expand=True)

        self.v_other_charges_check = tk.BooleanVar(value=False)
        chk_oc = tk.Checkbutton(bot_left, text="Other Charges", variable=self.v_other_charges_check, font=FONT, bg=BG)
        chk_oc.pack(anchor="w")

        nar_fr = tk.Frame(bot_left, bg=BG)
        nar_fr.pack(fill="x", pady=2)

        nar_lbl_fr = tk.Frame(nar_fr, bg=BG)
        nar_lbl_fr.pack(side="left", anchor="n", padx=(0, 10))
        tk.Label(nar_lbl_fr, text="Narration", font=FONT_BOLD, bg=BG).pack(anchor="w")
        tk.Label(nar_lbl_fr, text="Ctrl+Enter for next line", font=("Segoe UI", 9, "italic"), fg="#555555", bg=BG).pack(anchor="w")

        self.txt_narration = tk.Text(nar_fr, width=45, height=3, font=FONT, relief="solid", bd=1)
        self.txt_narration.pack(side="left", padx=(0, 10))

        btn_exit = tk.Button(nar_fr, text="Ctrl+Q: Exit", font=FONT_BOLD, bg="#e0e0e0", relief="solid", bd=1,
                             padx=15, pady=6, command=self.destroy)
        btn_exit.pack(side="left", anchor="s")

        # Bottom Right
        bot_right = tk.Frame(bot, bg=BG)
        bot_right.pack(side="right", anchor="se")

        r_tot_opts = tk.Frame(bot_right, bg=BG)
        r_tot_opts.pack(anchor="e", pady=2)

        tk.Label(r_tot_opts, text="Round Off", font=FONT, bg=BG).pack(side="left", padx=5)
        self.v_round_off = tk.StringVar(value="0")
        e_ro = tk.Entry(r_tot_opts, textvariable=self.v_round_off, font=FONT, width=10, justify="right", relief="solid", bd=1)
        e_ro.pack(side="left", padx=5)

        tk.Label(r_tot_opts, text="Total Amount", font=FONT_BOLD, bg=BG).pack(side="left", padx=(15, 5))
        self.v_grand_tot = tk.StringVar(value="0")
        e_gt = tk.Entry(r_tot_opts, textvariable=self.v_grand_tot, font=FONT_BOLD, width=20, justify="right", state="readonly", relief="solid", bd=1)
        e_gt.pack(side="left")

        dt_frame = tk.LabelFrame(bot_right, text="Discount & Tax", font=FONT, bg=BG, padx=5, pady=2)
        dt_frame.pack(side="left", anchor="n", padx=(0, 10))

        self.v_disc_tax_mode = tk.StringVar(value="per_item")
        tk.Radiobutton(dt_frame, text="On Total", variable=self.v_disc_tax_mode, value="total", font=FONT, bg=BG).pack(anchor="w")
        tk.Radiobutton(dt_frame, text="Per Item", variable=self.v_disc_tax_mode, value="per_item", font=FONT, bg=BG).pack(anchor="w")

        # Reference Document Frame
        ref_frame = tk.LabelFrame(bot_right, text="Reference Document", font=FONT, bg=BG, padx=5, pady=2)
        ref_frame.pack(side="left", anchor="n")

        self.v_ref_doc = tk.StringVar()
        e_ref = tk.Entry(ref_frame, textvariable=self.v_ref_doc, font=FONT, width=30, relief="solid", bd=1)
        e_ref.pack(fill="x", pady=(0, 2))

        btn_ref_fr = tk.Frame(ref_frame, bg=BG)
        btn_ref_fr.pack(fill="x")

        tk.Button(btn_ref_fr, text="Browse", font=FONT, bg="#e0e0e0", relief="solid", bd=1, width=8, command=self._browse_ref).pack(side="left", padx=2)
        tk.Button(btn_ref_fr, text="View", font=FONT, bg="#e0e0e0", relief="solid", bd=1, width=8, command=self._view_ref).pack(side="left", padx=2)
        tk.Button(btn_ref_fr, text="Delete", font=FONT, bg="#e0e0e0", relief="solid", bd=1, width=8, command=self._delete_ref).pack(side="left", padx=2)

        # Save Button
        save_fr = tk.Frame(bot_right, bg=BG)
        save_fr.pack(anchor="e", pady=(5, 0))

        btn_save = tk.Button(save_fr, text="F12:Save", font=FONT_BOLD, bg="#e0e0e0", relief="solid", bd=1, padx=20, pady=6,
                             command=self.save)
        btn_save.pack(side="right")

    def _bind_shortcuts(self):
        self.bind("<Control-q>", lambda e: self.destroy())
        self.bind("<Control-Q>", lambda e: self.destroy())
        self.bind("<F12>", lambda e: self.save())
        self.bind("<F9>", lambda e: self.cb_item.focus_set())
        self.bind("<F10>", lambda e: self.cb_service.focus_set())
        self.bind("<Control-f>", lambda e: self.app.show_invoices("credit_note") if self.app else None)
        self.bind("<Control-F>", lambda e: self.app.show_invoices("credit_note") if self.app else None)
        self.bind("<Alt-a>", lambda e: self.app._account_form("account") if self.app else None)
        self.bind("<Alt-A>", lambda e: self.app._account_form("account") if self.app else None)
        self.bind("<Alt-c>", lambda e: self.app._account_form("customer") if self.app else None)
        self.bind("<Alt-C>", lambda e: self.app._account_form("customer") if self.app else None)
        self.bind("<Alt-s>", lambda e: self.app._account_form("supplier") if self.app else None)
        self.bind("<Alt-S>", lambda e: self.app._account_form("supplier") if self.app else None)
        self.bind("<Alt-t>", lambda e: self.app._account_form("tax") if self.app else None)
        self.bind("<Alt-T>", lambda e: self.app._account_form("tax") if self.app else None)
        self.bind("<Alt-i>", lambda e: self.app._item_form() if self.app else None)
        self.bind("<Alt-I>", lambda e: self.app._item_form() if self.app else None)
        self.bind("<Alt-e>", lambda e: self.app._item_form() if self.app else None)
        self.bind("<Alt-E>", lambda e: self.app._item_form() if self.app else None)

    def _pick_date(self):
        top = tk.Toplevel(self)
        top.title("Select Date")
        top.geometry("280x250")
        top.grab_set()
        top.transient(self)

        try:
            from tkcalendar import Calendar
            cal = Calendar(top, selectmode='day', date_pattern='yyyy-mm-dd')
            cal.pack(padx=10, pady=10, fill="both", expand=True)

            def on_select():
                sel_d = cal.selection_get()
                self.v_date.set(sel_d.strftime("%B %d, %Y"))
                top.destroy()

            tk.Button(top, text="Select", font=FONT_BOLD, bg="#e0e0e0", relief="solid", bd=1, command=on_select).pack(pady=(0, 10))
        except Exception:
            top.destroy()

    def _update_deb_bal(self, event=None):
        acc = self.v_debit_acc.get()
        if acc:
            bal = db.get_account_balance(acc)
            self.lbl_deb_bal.config(text=f"balance {bal:,.0f}" if bal.is_integer() else f"balance {bal:,.2f}")

    def _update_cust_bal(self, event=None):
        acc = self.v_cust_acc.get()
        if acc:
            bal = db.get_account_balance(acc)
            self.lbl_cust_bal.config(text=f"balance {bal:,.0f}" if bal.is_integer() else f"balance {bal:,.2f}")

    def _add_item_row(self):
        item_name = self.v_sel_item.get().strip()
        if not item_name:
            return

        item_data = next((i for i in self.all_items if (i.get("item") or i.get("name")) == item_name), None)
        price = float(item_data.get("sale_price") or item_data.get("defaultsellingprice") or 0.0) if item_data else 0.0
        unit = db.get_unit_symbol(item_data.get("unit") or item_data.get("units_name")) if item_data else "Nos"

        new_item = {
            'name': item_name,
            'qty': 1.0,
            'unit': unit,
            'price': price,
            'per': unit,
            'discount': 0.0,
            'tax_pct': 0.0,
            'total': price,
            'desc': ''
        }
        self.line_items.append(new_item)
        self._refresh_tree()
        self.v_sel_item.set("")

    def _refresh_tree(self):
        if self.active_entry:
            try:
                self.active_entry.destroy()
            except Exception:
                pass
            self.active_entry = None

        for row in self.tree.get_children():
            self.tree.delete(row)

        tot_sum = 0.0

        for item in self.line_items:
            val = item['qty'] * item['price'] * (1 - item['discount']/100) + item['tax_pct']
            item['total'] = val
            tot_sum += val

            q_str = f"{item['qty']:,.0f}" if item['qty'].is_integer() else f"{item['qty']:,.2f}"
            r_str = f"{item['price']:,.0f}" if item['price'].is_integer() else f"{item['price']:,.2f}"
            v_str = f"{val:,.0f}" if val.is_integer() else f"{val:,.2f}"

            self.tree.insert("", "end", values=(
                item['name'], q_str, item['unit'], r_str, item['per'],
                f"{item['discount']}%", f"{item['tax_pct']}", v_str, item['desc']
            ))

        self.v_grand_tot.set(f"{tot_sum:,.0f}" if tot_sum.is_integer() else f"{tot_sum:,.2f}")
        if not self.lbl_setoff_vchs.cget("text"):
            self.v_setoff_amt.set(f"{tot_sum:,.0f}" if tot_sum.is_integer() else f"{tot_sum:,.2f}")

    def _on_cell_click(self, event):
        if self.active_entry:
            try:
                self.active_entry.destroy()
            except Exception:
                pass
            self.active_entry = None

        region = self.tree.identify_region(event.x, event.y)
        if region != "cell":
            return

        column = self.tree.identify_column(event.x)
        item_id = self.tree.identify_row(event.y)
        if not item_id or column in ("#1", "#3", "#5"):
            return

        item_idx = self.tree.index(item_id)
        if item_idx >= len(self.line_items):
            return

        target_item = self.line_items[item_idx]
        bbox = self.tree.bbox(item_id, column)
        if not bbox:
            return

        x, y, w, h = bbox
        
        col_map = {"#2": "qty", "#4": "price", "#6": "discount", "#7": "tax_pct", "#8": "total", "#9": "desc"}
        col_key = col_map.get(column)
        if not col_key:
            return

        val = target_item[col_key]
        entry_var = tk.StringVar(value=str(int(val)) if isinstance(val, float) and val.is_integer() else str(val))
        
        entry = tk.Entry(self.tree, textvariable=entry_var, font=FONT, justify="right" if column != "#9" else "left", relief="solid", bd=1)
        entry.place(x=x, y=y, width=w, height=h)
        entry.focus_set()
        entry.select_range(0, tk.END)
        self.active_entry = entry

        def save_edit(e=None):
            if not entry.winfo_exists():
                return
            new_text = entry_var.get().strip()
            if col_key in ("qty", "price", "discount", "tax_pct", "total"):
                try:
                    target_item[col_key] = float(new_text or 0)
                except ValueError:
                    pass
            else:
                target_item[col_key] = new_text

            entry.destroy()
            self.active_entry = None
            self._refresh_tree()

        entry.bind("<Return>", save_edit)
        entry.bind("<FocusOut>", save_edit)
        entry.bind("<Escape>", lambda e: entry.destroy())

    def _on_row_delete(self, event):
        sel = self.tree.selection()
        if not sel:
            return
        idx = self.tree.index(sel[0])
        if idx < len(self.line_items):
            del self.line_items[idx]
            self._refresh_tree()

    def _set_off_invoice(self):
        cust = self.v_cust_acc.get().strip()
        
        def on_vouchers_selected(tot_amt, selected_vchs):
            if selected_vchs:
                vch_str = ", ".join(selected_vchs) + ","
                self.lbl_setoff_vchs.config(text=vch_str)
                self.v_setoff_amt.set(f"{tot_amt:,.0f}" if tot_amt.is_integer() else f"{tot_amt:,.2f}")
                self.v_grand_tot.set(f"{tot_amt:,.0f}" if tot_amt.is_integer() else f"{tot_amt:,.2f}")

        SelectVouchersWindow(self, customer_name=cust, callback=on_vouchers_selected)

    def _load_edit_data(self):
        conn = db.get_conn()
        main_row = conn.execute("SELECT * FROM vouchers WHERE v_id=?", (self.edit_inv["id"])).fetchone()
        if main_row:
            if not self.is_duplicate:
                self.v_cn_no.set(main_row["vch_no"])
            self.v_date.set(main_row["date"])
            self.v_debit_acc.set(main_row["debit"] or "Sales Return")
            self.v_cust_acc.set(main_row["credit"] or "")
            if hasattr(self, 'txt_narration'):
                self.txt_narration.insert("1.0", main_row["narration"] or "")
            if hasattr(self, 'v_ref_doc'):
                self.v_ref_doc.set(main_row["detail1"] or "")

            items = db.get_invoice_items(self.edit_inv["id"])
            self.line_items = []
            for r in items:
                self.line_items.append({
                    'name': r['item_name'],
                    'qty': float(r['qty']),
                    'unit': 'Pcs',
                    'price': float(r['price']),
                    'per': 'Pcs',
                    'discount': float(r.get('tax_pct', 0)),
                    'tax_pct': 0.0,
                    'total': float(r['total']),
                    'desc': ''
                })

            self._refresh_tree()
        conn.close()

    def _browse_ref(self):
        file_path = filedialog.askopenfilename(title="Select Reference Document", parent=self)
        if file_path:
            self.ref_file_path = file_path
            self.v_ref_doc.set(file_path)

    def _view_ref(self):
        path = self.v_ref_doc.get()
        if path and os.path.exists(path):
            try:
                os.startfile(path)
            except Exception as e:
                messagebox.showerror("Error", f"Could not open file: {e}", parent=self)
        else:
            messagebox.showwarning("Warning", "File does not exist.", parent=self)

    def _delete_ref(self):
        self.ref_file_path = ""
        self.v_ref_doc.set("")

    def save(self):
        cust_acc = self.v_cust_acc.get().strip()
        if not cust_acc and not self.lbl_setoff_vchs.cget("text"):
            messagebox.showerror("Error", "Please select Customer/Cash account or set off against invoice.", parent=self)
            return

        cn_no = self.v_cn_no.get().strip()
        date_str = self.v_date.get().strip()
        try:
            date_str = datetime.datetime.strptime(date_str, "%B %d, %Y").strftime("%Y-%m-%d")
        except Exception:
            pass

        debit_acc = self.v_debit_acc.get().strip() or "Sales Return"
        narration = self.txt_narration.get("1.0", "end").strip()
        ref_doc = self.v_ref_doc.get().strip()

        # Save to DB
        v_id = db.create_credit_note(
            credit_note_no=cn_no,
            date=date_str,
            debit_acc=debit_acc,
            customer_acc=cust_acc or "Customer A",
            line_items=self.line_items,
            narration=narration,
            ref_doc=ref_doc
        )

        messagebox.showinfo("Saved", "Credit Note / Sales Return saved successfully!", parent=self)
        self.destroy()

        if self.app:
            self.app.show_invoices("credit_note")
