import sqlite3
conn = sqlite3.connect('bookkeeper.db')
print(conn.execute("SELECT DISTINCT account_group FROM account_detail").fetchall())
