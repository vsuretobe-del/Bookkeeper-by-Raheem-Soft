import re

with open('bookkeeper.py', 'r', encoding='utf-8') as f:
    text = f.read()

# 1. Add "Load Template" button at the top if v_type == 'estimate'
old_top_bar = '''            ("inventory", " New Inventory Item", lambda: self._item_form(parent=win)),
            ("service", " New Service", None),
        ]'''
new_top_bar = '''            ("inventory", " New Inventory Item", lambda: self._item_form(parent=win)),
            ("service", " New Service", None),
        ]
        
        if v_type == "estimate":
            def open_load_template():
                import db
                templates = db.get_estimate_templates()
                if not templates:
                    messagebox.showinfo("No Templates", "No templates saved yet.", parent=win)
                    return
                
                t_win = tk.Toplevel(win)
                t_win.title("Select Template")
                t_win.geometry("500x300")
                t_win.grab_set()
                
                tk.Label(t_win, text="Select an Estimate Template to load:", font=FONT_BOLD).pack(pady=10)
                
                lb = tk.Listbox(t_win, font=FONT, width=50)
                lb.pack(fill="both", expand=True, padx=10, pady=5)
                
                for t in templates:
                    lb.insert(tk.END, f"{t['invoice_no']} - {t['notes'] or 'Template'} - Total: {t['total']}")
                    
                def on_load():
                    sel = lb.curselection()
                    if not sel: return
                    t_data = templates[sel[0]]
                    items = db.get_invoice_items(t_data['id'])
                    
                    # Clear existing grid
                    for r in line_data[:]:
                        for k, w in r.items():
                            if k.endswith('_w') and w:
                                w.destroy()
                    line_data.clear()
                    
                    # Add items
                    for it in items:
                        add_grid_row(item_name=it.get("item_name", ""),
                                     qty=str(it.get("qty", 1)),
                                     unit=it.get("unit", "Nos"),
                                     rate=str(it.get("price", 0)),
                                     disc=str(it.get("discount", 0)),
                                     tax=str(it.get("tax_pct", 0)))
                    recalc_total()
                    t_win.destroy()
                    
                tk.Button(t_win, text="Load Template", command=on_load, bg="#4CAF50", fg="white", font=FONT_BOLD).pack(pady=10)
                
            shortcuts.append(("template", " Load Template", open_load_template))'''
text = text.replace(old_top_bar, new_top_bar)

# 2. Add is_template_var initialization before save_voucher
old_save_def = '''        def save_voucher(print_receipt=False, view_after=False):'''
new_save_def = '''        is_template_var = tk.IntVar()
        def save_voucher(print_receipt=False, view_after=False):'''
text = text.replace(old_save_def, new_save_def)

# 3. Add Save as Template Checkbutton to the bottom right buttons
old_btns = '''        tk.Button(bot_right_btns, text="Ctrl+F12: Save & Receipt", font=FONT,
                  command=lambda: save_voucher(print_receipt=True),
                  bg="#e0e0e0", fg="#000", relief="solid", bd=1).pack(side="left", padx=5, ipadx=10, ipady=5)'''
new_btns = '''        if v_type == "estimate":
            tk.Checkbutton(bot_right_btns, text="Save as Template", variable=is_template_var, bg=BG, font=FONT_BOLD).pack(side="left", padx=10)

        tk.Button(bot_right_btns, text="Ctrl+F12: Save & Receipt", font=FONT,
                  command=lambda: save_voucher(print_receipt=True),
                  bg="#e0e0e0", fg="#000", relief="solid", bd=1).pack(side="left", padx=5, ipadx=10, ipady=5)'''
text = text.replace(old_btns, new_btns)

# 4. Pass is_template_var.get() to create_invoice in save_voucher
def replace_db_create_invoice(m):
    orig = m.group(0)
    return orig.replace("paid_amount=adv)", "paid_amount=adv, is_template=is_template_var.get())")

text = re.sub(r'db\.create_invoice\(inv_no.*?paid_amount=adv\)', replace_db_create_invoice, text, flags=re.DOTALL)


with open('bookkeeper.py', 'w', encoding='utf-8') as f:
    f.write(text)
print("bookkeeper.py patched successfully for Estimate Templates")
