import tkinter as tk
from tkinter import ttk, messagebox
import db
import datetime
from PIL import Image, ImageTk
import io
import base64
from autocomplete import AutocompleteCombobox

# Define Colors & Fonts (Standardized)
BLUE = "#2B548F"
WHITE = "#FFFFFF"
GRAY = "#EFEFEF"
DARK_GRAY = "#D3D3D3"
BLACK = "#000000"
RED = "#B22222"

FONT = ("Segoe UI", 10)
FONT_BOLD = ("Segoe UI", 10, "bold")
TITLE_FONT = ("Segoe UI", 14, "bold")

class InventoryItemDetailsView(tk.Toplevel):
    def __init__(self, master_app):
        super().__init__(master_app)
        self.master_app = master_app
        self.title("Inventory Item Details")
        self.state("zoomed")
        self.configure(bg=WHITE)
        self.geometry("1024x768")

        self.start_date = datetime.date(datetime.date.today().year, 1, 1).strftime("%Y-%m-%d")
        self.end_date = datetime.date.today().strftime("%Y-%m-%d")

        self.build_ui()
        self.populate_filters()
        self.load_data()

    def build_ui(self):
        # Top Toolbar
        toolbar = tk.Frame(self, bg=WHITE, relief="raised", bd=1)
        toolbar.pack(side="top", fill="x")
        
        btn_exit = tk.Button(toolbar, text="✕ Ctrl+Q: Exit", font=FONT, bg=WHITE, relief="flat", command=self.destroy)
        btn_exit.pack(side="left", padx=5, pady=2)
        
        btn_print = tk.Button(toolbar, text="🖨 Alt+P: Print", font=FONT, bg=WHITE, relief="flat")
        btn_print.pack(side="left", padx=5, pady=2)
        
        btn_stock = tk.Button(toolbar, text="ℹ Alt+S: Item Stock Level Enquiry", font=FONT, bg=WHITE, relief="flat")
        btn_stock.pack(side="left", padx=5, pady=2)

        # Main Layout
        self.paned = tk.PanedWindow(self, orient="horizontal", bg=WHITE, sashwidth=5)
        self.paned.pack(fill="both", expand=True)

        # Left Panel (Filters)
        self.left_panel = tk.Frame(self.paned, bg=BLUE, width=250)
        self.paned.add(self.left_panel, minsize=250)

        # Right Panel (Report)
        self.right_panel = tk.Frame(self.paned, bg=WHITE)
        self.paned.add(self.right_panel, stretch="always")

        self.build_left_panel()
        self.build_right_panel()

    def build_left_panel(self):
        # Filters logic
        f = tk.Frame(self.left_panel, bg=BLUE)
        f.pack(fill="both", expand=True, padx=10, pady=10)

        self.filter_mode = tk.StringVar(value="ITEM")

        # Cat / Subcat
        self.rb_cat = tk.Radiobutton(f, text="Item Category Subcategory", variable=self.filter_mode, value="CAT", bg=BLUE, fg=WHITE, selectcolor=BLUE, font=FONT_BOLD)
        self.rb_cat.pack(anchor="w", pady=(0, 5))

        self.cb_cat = AutocompleteCombobox(f, font=FONT, state="readonly", values=["ALL"])
        self.cb_cat.set("ALL")
        self.cb_cat.pack(fill="x", pady=(0, 5), padx=(15, 0))

        self.cb_subcat = AutocompleteCombobox(f, font=FONT, state="readonly", values=["ALL"])
        self.cb_subcat.set("ALL")
        self.cb_subcat.pack(fill="x", pady=(0, 15), padx=(15, 0))

        # Item Name
        self.rb_item = tk.Radiobutton(f, text="F9: Inventory Item:", variable=self.filter_mode, value="ITEM", bg=BLUE, fg=WHITE, selectcolor=BLUE, font=FONT_BOLD)
        self.rb_item.pack(anchor="w", pady=(0, 5))

        self.cb_item = AutocompleteCombobox(f, font=FONT, values=["ALL"])
        self.cb_item.set("ALL")
        self.cb_item.pack(fill="x", pady=(0, 15), padx=(15, 0))

        # Checkboxes
        self.show_profits = tk.IntVar(value=1)
        self.show_zero = tk.IntVar(value=0)
        self.show_image = tk.IntVar(value=0)

        tk.Checkbutton(f, text="Show Profits?", variable=self.show_profits, bg=BLUE, fg=WHITE, selectcolor=BLUE, font=FONT).pack(anchor="w")
        tk.Checkbutton(f, text="Show Zero Qty Item?", variable=self.show_zero, bg=BLUE, fg=WHITE, selectcolor=BLUE, font=FONT).pack(anchor="w")
        tk.Checkbutton(f, text="Show Item Image?", variable=self.show_image, bg=BLUE, fg=WHITE, selectcolor=BLUE, font=FONT).pack(anchor="w", pady=(0, 15))

        # Additional Filters
        tk.Label(f, text="Account Name", bg=BLUE, fg=WHITE, font=FONT).pack(anchor="w")
        self.cb_account = AutocompleteCombobox(f, font=FONT, values=["ALL"])
        self.cb_account.set("ALL")
        self.cb_account.pack(fill="x", pady=(0, 10))

        tk.Label(f, text="Voucher Type:", bg=BLUE, fg=WHITE, font=FONT).pack(anchor="w")
        self.cb_vtype = AutocompleteCombobox(f, font=FONT, values=["ALL", "Sales", "Purchase", "inventory_adjustment"])
        self.cb_vtype.set("ALL")
        self.cb_vtype.pack(fill="x", pady=(0, 15))

        btn_display = tk.Button(f, text="Display", bg="#1C3D6D", fg=WHITE, font=FONT_BOLD, relief="flat", command=self.load_data)
        btn_display.pack(fill="x", pady=20)

    def build_right_panel(self):
        # Header Info
        header_f = tk.Frame(self.right_panel, bg=WHITE, pady=10, padx=10)
        header_f.pack(fill="x")
        
        c_name = self.master_app.company_name if hasattr(self.master_app, 'company_name') else "Company Name"
        
        tk.Label(header_f, text=c_name, bg=WHITE, fg=BLUE, font=TITLE_FONT).pack(anchor="w")
        tk.Label(header_f, text="Inventory Items Details", bg=WHITE, fg=BLACK, font=("Segoe UI", 12, "bold")).pack(anchor="w")
        tk.Label(header_f, text=f"{self.start_date} To {self.end_date}", bg=WHITE, fg=BLACK, font=FONT).pack(anchor="w")

        # Treeview
        tree_f = tk.Frame(self.right_panel, bg=WHITE)
        tree_f.pack(fill="both", expand=True, padx=10, pady=(0,10))

        cols = ("DATE", "VCH TYPE", "PARTICULARS", "VCH NO", "RATE/UNIT", 
                "INWARDS QTY", "INWARDS VALUE", "OUTWARDS QTY", "OUTWARDS VALUE", 
                "CLOSING QTY", "COST", "GROSS PROFIT", "% PROFIT", "DESCRIPTION", "NARRATION")
        
        self.tree = ttk.Treeview(tree_f, columns=cols, show="headings", height=20, selectmode="none")
        
        # Configure Columns
        w_small = 70
        w_med = 100
        w_large = 150
        
        self.tree.heading("DATE", text="DATE")
        self.tree.column("DATE", width=90, minwidth=90, anchor="w", stretch=False)
        self.tree.heading("VCH TYPE", text="VCH TYPE")
        self.tree.column("VCH TYPE", width=90, minwidth=90, anchor="w", stretch=False)
        self.tree.heading("PARTICULARS", text="PARTICULARS")
        self.tree.column("PARTICULARS", width=120, minwidth=120, anchor="w", stretch=False)
        self.tree.heading("VCH NO", text="VCH NO.")
        self.tree.column("VCH NO", width=70, minwidth=70, anchor="w", stretch=False)
        self.tree.heading("RATE/UNIT", text="RATE/UNIT")
        self.tree.column("RATE/UNIT", width=w_small, minwidth=w_small, anchor="e", stretch=False)
        self.tree.heading("INWARDS QTY", text="INWARDS QTY")
        self.tree.column("INWARDS QTY", width=w_small, minwidth=w_small, anchor="e", stretch=False)
        self.tree.heading("INWARDS VALUE", text="INWARDS VALUE")
        self.tree.column("INWARDS VALUE", width=w_small, minwidth=w_small, anchor="e", stretch=False)
        self.tree.heading("OUTWARDS QTY", text="OUTWARDS QTY")
        self.tree.column("OUTWARDS QTY", width=w_small, minwidth=w_small, anchor="e", stretch=False)
        self.tree.heading("OUTWARDS VALUE", text="OUTWARDS VALUE")
        self.tree.column("OUTWARDS VALUE", width=w_small, minwidth=w_small, anchor="e", stretch=False)
        self.tree.heading("CLOSING QTY", text="CLOSING QTY")
        self.tree.column("CLOSING QTY", width=w_small, minwidth=w_small, anchor="e", stretch=False)
        self.tree.heading("COST", text="COST")
        self.tree.column("COST", width=w_small, minwidth=w_small, anchor="e", stretch=False)
        self.tree.heading("GROSS PROFIT", text="GROSS PROFIT (INC. DIS%)")
        self.tree.column("GROSS PROFIT", width=w_med, minwidth=w_med, anchor="e", stretch=False)
        self.tree.heading("% PROFIT", text="% PROFIT")
        self.tree.column("% PROFIT", width=w_small, minwidth=w_small, anchor="e", stretch=False)
        self.tree.heading("DESCRIPTION", text="DESCRIPTION")
        self.tree.column("DESCRIPTION", width=w_med, minwidth=w_med, anchor="w", stretch=False)
        self.tree.heading("NARRATION", text="NARRATION")
        self.tree.column("NARRATION", width=w_med, minwidth=w_med, anchor="w", stretch=False)

        # Styling
        def disable_resize(event):
            if self.tree.identify_region(event.x, event.y) == "separator":
                return "break"
        self.tree.bind('<Button-1>', disable_resize)
        self.tree.bind('<B1-Motion>', disable_resize)
        style = ttk.Style()
        style.configure("Treeview", font=FONT, rowheight=25)
        style.configure("Treeview.Heading", font=FONT_BOLD)
        
        self.tree.tag_configure("header", font=FONT_BOLD, background=WHITE, foreground=BLUE)
        self.tree.tag_configure("sub", font=FONT_BOLD, background=WHITE)
        self.tree.tag_configure("footer", font=FONT_BOLD, background=WHITE)
        self.tree.tag_configure("grand", font=FONT_BOLD, background=GRAY)
        self.tree.tag_configure("stripe1", background="#F9F9F9")
        self.tree.tag_configure("stripe2", background=WHITE)

        ysb = ttk.Scrollbar(tree_f, orient="vertical", command=self.tree.yview)
        xsb = ttk.Scrollbar(tree_f, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscroll=ysb.set, xscroll=xsb.set)

        ysb.pack(side="right", fill="y")
        xsb.pack(side="bottom", fill="x")
        self.tree.pack(fill="both", expand=True)

    def populate_filters(self):
        conn = db.get_conn()
        try:
            items = conn.execute("SELECT item FROM item_measure ORDER BY item").fetchall()
            self.cb_item['values'] = ["ALL"] + [r['item'] for r in items]
            
            # Accounts
            acc = conn.execute("SELECT name FROM account_detail ORDER BY name").fetchall()
            self.cb_account['values'] = ["ALL"] + [r['name'] for r in acc]
            
            # Categories
            cats = conn.execute("SELECT name FROM item_category ORDER BY name").fetchall()
            self.cb_cat['values'] = ["ALL"] + [r['name'] for r in cats]
        except Exception as e:
            print("Error loading filters:", e)
        finally:
            conn.close()

    def load_data(self):
        # Clear tree
        for child in self.tree.get_children():
            self.tree.delete(child)

        item_name = "ALL"
        cat = "ALL"
        subcat = "ALL"
        
        if self.filter_mode.get() == "ITEM":
            item_name = self.cb_item.get().strip()
        else:
            cat = self.cb_cat.get().strip()
            subcat = self.cb_subcat.get().strip()
            
        acc_name = self.cb_account.get().strip()
        v_type = self.cb_vtype.get().strip()
        
        try:
            results = db.get_inventory_item_details(
                category=cat, subcategory=subcat, 
                item_name=item_name, account_name=acc_name, 
                voucher_type=v_type, 
                start_date=self.start_date, end_date=self.end_date
            )
        except Exception as e:
            import traceback
            traceback.print_exc()
            messagebox.showerror("Error", f"Failed to fetch inventory details:\n{e}")
            return

        grand_in_qty = 0
        grand_in_val = 0
        grand_out_qty = 0
        grand_out_val = 0
        
        show_prof = self.show_profits.get()

        for item_data in results:
            if item_data['opening_qty'] == 0 and len(item_data['transactions']) == 0 and not self.show_zero.get():
                continue
                
            i_name = item_data['item_name']
            unit = item_data['unit']
            op_qty = item_data['opening_qty']
            op_val = item_data['opening_value']
            avg_cost = item_data['avg_cost']
            
            # Item Header
            self.tree.insert("", "end", values=(i_name, "", "", "", "", "", "", "", "", "", "", "", "", "", ""), tags=("header"))
            
            # Subheader
            sub_txt = f"Opening Inventory: {op_qty:g} {unit} X {avg_cost:,.2f} = {op_val:,.2f}"
            self.tree.insert("", "end", values=(sub_txt, "", "", "", "", "", "", "", "", "", "", "", "", "", ""), tags=("sub"))
            
            stripe = "stripe1"
            for t in item_data['transactions']:
                v_in_q = f"{t['in_qty']:g} {unit}" if t['in_qty'] else ""
                v_in_v = f"{t['in_val']:,.2f}" if t['in_val'] else ""
                v_out_q = f"{t['out_qty']:g} {unit}" if t['out_qty'] else ""
                v_out_v = f"{t['out_val']:,.2f}" if t['out_val'] else ""
                
                cl_qty = f"{t['closing_qty']:g} {unit}"
                cost_v = f"{t['cost']:,.2f}" if (show_prof and t['cost']) else ""
                gp_v = f"{t['gross_profit']:,.2f}" if (show_prof and t['cost']) else ""
                pp_v = f"{t['profit_percent']:,.0f}" if (show_prof and t['cost']) else ""
                
                self.tree.insert("", "end", values=(
                    t['date'],
                    t['v_type'],
                    t['particulars'],
                    t['vch_no'],
                    f"{t['rate']:,.2f}",
                    v_in_q, v_in_v,
                    v_out_q, v_out_v,
                    cl_qty,
                    cost_v, gp_v, pp_v,
                    t.get('description', ''),
                    t.get('narration', '').replace('\\n', ' ')
                ), tags=(stripe))
                
                stripe = "stripe2" if stripe == "stripe1" else "stripe1"
                
            # Totals
            tot = item_data['totals']
            tot_in_q = f"{tot['in_qty']:g} {unit}" if tot['in_qty'] else ""
            tot_in_v = f"{tot['in_val']:,.2f}" if tot['in_val'] else ""
            tot_out_q = f"{tot['out_qty']:g} {unit}" if tot['out_qty'] else ""
            tot_out_v = f"{tot['out_val']:,.2f}" if tot['out_val'] else ""
            
            cost_tot = f"{tot['cost']:,.2f}" if show_prof else ""
            gp_tot = f"{tot['gp']:,.2f}" if show_prof else ""
            pp_tot = ""
            if show_prof and tot['cost'] > 0:
                pp_tot = f"{(tot['gp'] / tot['cost'] * 100):.0f}"
                
            self.tree.insert("", "end", values=(
                "", "", "", "", "TOTAL",
                tot_in_q, tot_in_v,
                tot_out_q, tot_out_v,
                "", cost_tot, gp_tot, pp_tot, "", ""
            ), tags=("footer"))
            
            # Closing inventory
            cl_txt = f"Closing Inventory: {item_data['closing_qty']:g} {unit} X {avg_cost:,.2f} = {item_data['closing_value']:,.2f}"
            self.tree.insert("", "end", values=(cl_txt, "", "", "", "", "", "", "", "", "", "", "", "", "", ""), tags=("sub"))
            
            # Empty row separator
            self.tree.insert("", "end", values=("", "", "", "", "", "", "", "", "", "", "", "", "", "", ""), tags=("stripe2"))
            
            grand_in_qty += tot['in_qty']
            grand_in_val += tot['in_val']
            grand_out_qty += tot['out_qty']
            grand_out_val += tot['out_val']
            
        # Grand Totals
        self.tree.insert("", "end", values=("TOTAL INWARDS (ALL ITEMS)", "", "", "", "", f"{grand_in_qty:g}", f"{grand_in_val:,.2f}", "", "", "", "", "", "", "", ""), tags=("grand"))
        self.tree.insert("", "end", values=("TOTAL OUTWARDS (ALL ITEMS)", "", "", "", "", "", "", f"{grand_out_qty:g}", f"{grand_out_val:,.2f}", "", "", "", "", "", ""), tags=("grand"))

if __name__ == "__main__":
    root = tk.Tk()
    root.withdraw()
    app = InventoryItemDetailsView(root)
    app.mainloop()
