with open('db.py', 'r', encoding='utf-8') as f:
    lines = f.readlines()

new_content = '''def get_account_balance(account_name):
    conn = get_conn()
    row = conn.execute("SELECT cl_bal FROM account_detail WHERE aname=?", (account_name,)).fetchone()
    conn.close()
    if row:
        return row['cl_bal']
    return 0.0

def create_receipt(date, account_name, amount, payment_account_name, notes=''):
    conn = get_conn()
    import datetime
    vch_no = "REC-" + str(int(datetime.datetime.now().timestamp() * 1000))[-8:]
    v_id = conn.execute(
        "INSERT INTO vouchers (vch_no, v_type, date, amount, narration, paid_amount) VALUES (?,?,?,?,?,?)",
        (vch_no, 'receipt', date, amount, notes, 0.0)
    ).lastrowid
    
    conn.execute("INSERT INTO vouchers_all (v_id, debit, credit, amount, date) VALUES (?,?,?,?,?)",
                 (v_id, payment_account_name, account_name, amount, date))
                 
    conn.execute("UPDATE account_detail SET cl_bal=cl_bal+? WHERE aname=?", (amount, payment_account_name))
    conn.execute("UPDATE account_detail SET cl_bal=cl_bal-? WHERE aname=?", (amount, account_name))
    
    conn.commit()
    conn.close()
    return v_id

def delete_voucher(v_id):
    conn = get_conn()
    vch = conn.execute("SELECT v_type, amount, status, linked_po_id FROM vouchers WHERE v_id=?", (v_id,)).fetchone()
    if not vch:
        return
    v_type, amount, status, linked_po_id = vch
    
    if v_type == 'sale':
        items = conn.execute("SELECT item, units FROM sales WHERE v_id=?", (v_id,)).fetchall()
        for item in items:
            conn.execute("UPDATE stock SET cl_bal=cl_bal+? WHERE stock_name=?", (item['units'], item['item']))
        conn.execute("DELETE FROM sales WHERE v_id=?", (v_id,))
    elif v_type == 'purchase':
        items = conn.execute("SELECT item, units FROM purchases WHERE v_id=?", (v_id,)).fetchall()
        for item in items:
            conn.execute("UPDATE stock SET cl_bal=cl_bal-? WHERE stock_name=?", (item['units'], item['item']))
        conn.execute("DELETE FROM purchases WHERE v_id=?", (v_id,))
    elif v_type == 'purchase_order':
        conn.execute("DELETE FROM purchases WHERE v_id=?", (v_id,))
    elif v_type == 'estimate':
        conn.execute("DELETE FROM sales WHERE v_id=?", (v_id,))
        
    va = conn.execute("SELECT debit, credit FROM vouchers_all WHERE v_id=?", (v_id,)).fetchone()
    if va:
        if v_type == 'sale':
            conn.execute("UPDATE account_detail SET cl_bal=cl_bal-? WHERE aname=?", (amount, va['debit']))
        elif v_type == 'purchase':
            conn.execute("UPDATE account_detail SET cl_bal=cl_bal+? WHERE aname=?", (amount, va['credit']))
        elif v_type == 'receipt':
            conn.execute("UPDATE account_detail SET cl_bal=cl_bal-? WHERE aname=?", (amount, va['debit']))
            conn.execute("UPDATE account_detail SET cl_bal=cl_bal+? WHERE aname=?", (amount, va['credit']))
        conn.execute("DELETE FROM vouchers_all WHERE v_id=?", (v_id,))

    if linked_po_id:
        conn.execute("UPDATE vouchers SET status='OPEN' WHERE v_id=?", (linked_po_id,))
        
    conn.execute("DELETE FROM vouchers WHERE v_id=?", (v_id,))
    conn.commit()
    conn.close()

def cancel_voucher(v_id):
'''

start_idx = -1
end_idx = -1
for i, line in enumerate(lines):
    if line.startswith('def get_account_balance(account_name):'):
        start_idx = i
    if start_idx != -1 and line.strip().startswith("conn.execute(\"UPDATE vouchers SET status='CANCELLED', amount=0 WHERE v_id=?\", (v_id,))"):
        end_idx = i
        break

if start_idx != -1 and end_idx != -1:
    lines[start_idx:end_idx] = [new_content]
    with open('db.py', 'w', encoding='utf-8') as f:
        f.writelines(lines)
    print('SUCCESS')
else:
    print('FAILED to find indices', start_idx, end_idx)
