import tkinter as tk
import os
import sys
sys.path.insert(0, os.path.abspath("."))
from PIL import ImageGrab
import company_selection

class MockApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Mock App")
        self.geometry("800x600")
        self.active_company_path = None
        
    def load_company(self, path):
        print(f"Loaded: {path}")
        
    def open_company_settings(self, is_new=False, parent_win=None):
        print(f"Open company settings: is_new={is_new}")

root = MockApp()
view = company_selection.CompanySelectionView(root, root)

root.update()
root.update_idletasks()

# Grab screen of root window
x = root.winfo_rootx()
y = root.winfo_rooty()
w = root.winfo_width()
h = root.winfo_height()

print(f"Window bounds: x={x}, y={y}, w={w}, h={h}")
img = ImageGrab.grab(bbox=(x, y, x + w, y + h))
img.save(r"scratch/company_view_current.png")
print("Screenshot saved to scratch/company_view_current.png")
root.destroy()
