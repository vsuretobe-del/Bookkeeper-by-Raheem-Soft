import sys, os, traceback
sys.path.insert(0, os.path.abspath(os.path.dirname(os.path.dirname(__file__))))
import tkinter as tk
import bookkeeper
import db

def test_subuser_load_company():
    print("Testing BookKeeperApp with subuser t1...")
    app = bookkeeper.BookKeeperApp()
    app.withdraw()
    
    filepath = r"C:\Users\hk546\OneDrive\Desktop\bookkeeper.db"
    
    # Fetch t1 user
    db.set_db_path(filepath)
    conn = db.get_conn()
    conn.row_factory = db.sqlite3.Row
    c = conn.cursor()
    u_row = c.execute("SELECT * FROM users WHERE username='t1'").fetchone()
    conn.close()
    
    assert u_row is not None, "t1 user not found in DB!"
    user_dict = dict(u_row)
    print("Subuser dict:", user_dict)
    
    app.current_user = user_dict
    try:
        app.load_company(filepath)
        print("SUCCESS: load_company succeeded for subuser t1!")
    except Exception as e:
        print("ERROR in load_company for subuser:")
        traceback.print_exc()
    finally:
        app.destroy()

if __name__ == "__main__":
    test_subuser_load_company()
