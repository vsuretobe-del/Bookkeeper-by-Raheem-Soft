import os, sqlite3

dirs = [r'.', r'C:\Users\hk546\OneDrive\Desktop', r'C:\Users\hk546\Desktop', r'C:\Users\hk546\Downloads']
seen = set()
for d in dirs:
    if os.path.exists(d):
        for f in os.listdir(d):
            if f.endswith('.db'):
                full = os.path.normpath(os.path.abspath(os.path.join(d, f)))
                if full in seen: continue
                seen.add(full)
                try:
                    conn = sqlite3.connect(full)
                    conn.row_factory = sqlite3.Row
                    c = conn.cursor()
                    s = dict(c.execute("SELECT key, value FROM app_settings WHERE key LIKE 'company_%'").fetchall())
                    try:
                        u = [dict(r) for r in c.execute("SELECT id, username, password FROM users").fetchall()]
                    except Exception as eu:
                        u = f"NO_USERS_TABLE ({eu})"
                    print(f"\n{full}:")
                    print(f"   company_name={s.get('company_company_name')}, pwd_enabled={s.get('company_enable_pwd')}, admin_user={s.get('company_username')}, admin_pwd={s.get('company_password')}")
                    print(f"   users={u}")
                    conn.close()
                except Exception as e:
                    print(f"\n{full} -> ERROR: {e}")
