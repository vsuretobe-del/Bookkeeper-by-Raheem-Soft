import os
import sys
sys.path.insert(0, os.path.abspath("."))
import tkinter as tk
from PIL import ImageGrab
import bookkeeper
import db

db_file = r"C:\Users\hk546\OneDrive\Desktop\bookkeeper.db"
if os.path.exists(db_file):
    db.set_db_path(db_file)

app = bookkeeper.BookKeeperApp()
app.withdraw()

# Create Voucher window
app._open_create_voucher("sale")
app.update()
app.update_idletasks()

# Find voucher window among toplevels
voucher_win = None
for w in app.winfo_children():
    if isinstance(w, tk.Toplevel):
        voucher_win = w
        break

if not voucher_win:
    print("Voucher window not found")
    sys.exit(1)

# Grab screenshot of voucher window
voucher_win.update()
voucher_win.update_idletasks()
x = voucher_win.winfo_rootx()
y = voucher_win.winfo_rooty()
w = voucher_win.winfo_width()
h = voucher_win.winfo_height()

print(f"Voucher window geometry: {w}x{h} at ({x}, {y})")

# Test 1: Typing 'op' in search entry
item_entry = None
for widget in voucher_win.winfo_children():
    for child in widget.winfo_children():
        if isinstance(child, tk.Entry) and child.cget("width") == 34:
            item_entry = child
            break

print("Found item entry:", item_entry)
if item_entry:
    item_entry.focus_set()
    item_entry.delete(0, "end")
    item_entry.insert(0, "op")
    item_entry.event_generate("<KeyRelease>", keysym="p")
    voucher_win.update()
    voucher_win.update_idletasks()

    # Capture popup
    img = ImageGrab.grab(bbox=(x, y, x + w, y + h))
    img.save("scratch/test_voucher_autocomplete_dropdown.png")
    print("Saved autocomplete screenshot to scratch/test_voucher_autocomplete_dropdown.png")

# Test 2: Testing item creation form with pre-filled name 'jo'
app._item_form(initial_name="jo")
voucher_win.update()
voucher_win.update_idletasks()

item_win = None
for w in app.winfo_children():
    if isinstance(w, tk.Toplevel) and "Inventory Item" in w.title():
        item_win = w
        break

if item_win:
    item_win.update()
    item_win.update_idletasks()
    ix = item_win.winfo_rootx()
    iy = item_win.winfo_rooty()
    iw = item_win.winfo_width()
    ih = item_win.winfo_height()
    img_item = ImageGrab.grab(bbox=(ix, iy, ix + iw, iy + ih))
    img_item.save("scratch/test_create_inventory_item_prefilled.png")
    print("Saved create inventory item screenshot to scratch/test_create_inventory_item_prefilled.png")

app.destroy()
print("All voucher item tests completed successfully!")
