import sys, os
sys.path.insert(0, os.path.abspath(os.path.dirname(os.path.dirname(__file__))))
import db

def test_contra():
    # Clean any leftover
    conn = db.get_conn()
    conn.execute("DELETE FROM vouchers WHERE vch_no='CON_TEST_100'")
    conn.commit()
    conn.close()

    # Create contra
    vid = db.create_contra(
        invoice_no='CON_TEST_100',
        date='2025-08-31',
        to_account='Cash',
        from_account='Bank',
        amount=120.0,
        notes='Cash withdrawal from bank',
        status='OPEN',
        ref_doc='C:/docs/receipt.pdf'
    )
    print('Created test contra voucher ID:', vid)

    # Check vouchers table
    conn = db.get_conn()
    row = conn.execute("SELECT * FROM vouchers WHERE v_id=?", (vid,)).fetchone()
    assert row['v_type'] == 'contra', f"Expected contra, got {row['v_type']}"
    assert row['detail1'] == 'Cash', f"Expected detail1 Cash, got {row['detail1']}"
    assert row['detail2'] == 'C:/docs/receipt.pdf', f"Expected detail2 C:/docs/receipt.pdf, got {row['detail2']}"
    assert float(row['amount']) == 120.0, f"Expected amount 120.0, got {row['amount']}"

    # Check vouchers_all table
    va = conn.execute("SELECT * FROM vouchers_all WHERE v_id=?", (vid,)).fetchall()
    assert len(va) == 1, f"Expected 1 row, got {len(va)}"
    assert va[0]['debit'] == 'Cash', f"Expected debit Cash, got {va[0]['debit']}"
    assert va[0]['credit'] == 'Bank', f"Expected credit Bank, got {va[0]['credit']}"
    assert float(va[0]['amount']) == 120.0, f"Expected amount 120.0, got {va[0]['amount']}"
    conn.close()

    print("DB creation and fields verified!")

    # Verify edit loading
    conn = db.get_conn()
    edit_main = conn.execute("SELECT * FROM vouchers WHERE v_id=?", (vid,)).fetchone()
    edit_lines = conn.execute("SELECT * FROM vouchers_all WHERE v_id=?", (vid,)).fetchall()
    to_acc = edit_lines[0]['debit']
    from_acc = edit_lines[0]['credit']
    ref_doc = edit_main['detail2']
    assert to_acc == 'Cash'
    assert from_acc == 'Bank'
    assert ref_doc == 'C:/docs/receipt.pdf'
    conn.close()

    print("Edit load verified: To Account = Cash, From Account = Bank, Ref Doc = C:/docs/receipt.pdf")

    # Clean up
    db.delete_voucher(vid)
    print("Cleanup complete. All tests PASSED!")

if __name__ == '__main__':
    test_contra()
