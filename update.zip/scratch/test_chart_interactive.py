import os
import sys
sys.path.insert(0, os.path.abspath("."))
import tkinter as tk
from PIL import ImageGrab
import math

class InteractiveChart(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Modern Interactive Daily Cash Flow")
        self.geometry("1100x650")
        self.configure(bg="#f8fafc")

        # Outer card
        card = tk.Frame(self, bg="#ffffff", relief="solid", bd=1, highlightbackground="#e2e8f0", highlightthickness=1)
        card.pack(fill="both", expand=True, padx=20, pady=20)

        # Header
        header = tk.Frame(card, bg="#ffffff")
        header.pack(fill="x", padx=16, pady=(14, 6))

        tk.Label(header, text="Daily Cash Flow", bg="#ffffff", fg="#0f172a",
                 font=("Segoe UI", 13, "bold")).pack(anchor="center")

        # Legend
        legend = tk.Frame(header, bg="#ffffff")
        legend.pack(anchor="center", pady=(6, 2))

        # Cash legend
        c_box = tk.Frame(legend, bg="#93c5fd", relief="solid", bd=1, highlightbackground="#3b82f6", highlightthickness=1, width=24, height=12)
        c_box.pack(side="left", padx=(0, 6))
        c_box.pack_propagate(False)
        tk.Label(legend, text="Cash", bg="#ffffff", fg="#334155", font=("Segoe UI", 9, "bold")).pack(side="left", padx=(0, 20))

        # Bank legend
        b_box = tk.Frame(legend, bg="#86efac", relief="solid", bd=1, highlightbackground="#22c55e", highlightthickness=1, width=24, height=12)
        b_box.pack(side="left", padx=(0, 6))
        b_box.pack_propagate(False)
        tk.Label(legend, text="Bank", bg="#ffffff", fg="#334155", font=("Segoe UI", 9, "bold")).pack(side="left")

        # Canvas
        self._canvas = tk.Canvas(card, bg="#ffffff", height=340, highlightthickness=0)
        self._canvas.pack(fill="both", expand=True, padx=12, pady=(4, 12))

        # Hover state
        self._hover_idx = None
        self._data = []
        self._plot_meta = {}

        self._canvas.bind("<Configure>", self._draw_chart)
        self._canvas.bind("<Motion>", self._on_hover)
        self._canvas.bind("<Leave>", self._on_leave)

        # Sample test data matching real transactions
        self._data = [
            {'date': '2026-07-18', 'cash': -11.0, 'bank': 10.0, 'total': -1.0},
            {'date': '2026-07-19', 'cash': 1086.0, 'bank': 0.0, 'total': 1086.0},
            {'date': '2026-07-21', 'cash': 0.0, 'bank': 0.0, 'total': 0.0},
            {'date': '2026-07-22', 'cash': -379.0, 'bank': 0.0, 'total': -379.0},
            {'date': '2026-07-23', 'cash': 13189.0, 'bank': -12000.0, 'total': 1189.0},
            {'date': '2026-07-24', 'cash': 0.0, 'bank': 0.0, 'total': 0.0},
            {'date': '2026-07-25', 'cash': 152800.0, 'bank': -12000.0, 'total': 140800.0},
            {'date': '2026-07-31', 'cash': 0.0, 'bank': 0.0, 'total': 0.0},
            {'date': '2026-08-01', 'cash': 38000.0, 'bank': 0.0, 'total': 38000.0},
            {'date': '2026-08-03', 'cash': 24500.0, 'bank': 15000.0, 'total': 39500.0},
            {'date': '2026-08-05', 'cash': 42000.0, 'bank': 31000.0, 'total': 73000.0}
        ]

    def _calc_nice_ticks(self, min_val, max_val, max_ticks=5):
        if min_val > 0:
            min_val = 0.0
        if max_val < 0:
            max_val = 0.0
        if min_val == max_val:
            return [-1000.0, 0.0, 1000.0], -1000.0, 1000.0

        span = max_val - min_val
        raw_step = span / max_ticks
        magnitude = 10 ** math.floor(math.log10(raw_step))
        fraction = raw_step / magnitude

        if fraction <= 1.5:
            step = 1.0 * magnitude
        elif fraction <= 3.0:
            step = 2.0 * magnitude
        elif fraction <= 7.0:
            step = 5.0 * magnitude
        else:
            step = 10.0 * magnitude

        low = math.floor(min_val / step) * step
        high = math.ceil(max_val / step) * step

        ticks = []
        curr = low
        while curr <= high + (step * 0.01):
            ticks.append(curr)
            curr += step

        if 0.0 not in [round(t, 4) for t in ticks] and low < 0 and high > 0:
            ticks.append(0.0)
            ticks = sorted(set(ticks))

        return ticks, low, high

    def _draw_chart(self, event=None):
        c = self._canvas
        c.delete("all")
        c.update_idletasks()
        W = c.winfo_width()
        H = c.winfo_height()
        if W < 100 or H < 100:
            return

        padL, padR, padT, padB = 105, 30, 25, 75
        cW = W - padL - padR
        cH = H - padT - padB

        data = self._data
        if not data:
            c.create_text(W / 2, H / 2, text="No cash flow transactions found",
                          font=("Segoe UI", 11), fill="#64748b")
            return

        n = len(data)
        all_vals = [d['cash'] for d in data] + [d['bank'] for d in data]
        min_v_raw = min(all_vals)
        max_v_raw = max(all_vals)

        ticks, min_v, max_v = self._calc_nice_ticks(min_v_raw, max_v_raw, 5)
        rng = max_v - min_v if max_v != min_v else 1.0

        def px(i):
            return padL + (i / (n - 1)) * cW if n > 1 else padL + cW / 2

        def py(v):
            return padT + ((max_v - v) / rng) * cH

        self._plot_meta = {
            'W': W, 'H': H, 'padL': padL, 'padR': padR, 'padT': padT, 'padB': padB,
            'cW': cW, 'cH': cH, 'n': n, 'px': px, 'py': py, 'y_base': py(0.0),
            'bar_w': max(6, min(22, int(cW / n * 0.35)))
        }

        # 1. Gridlines & Y-axis labels
        for tick in ticks:
            y = py(tick)
            if abs(tick) < 0.001:
                # Baseline 0
                c.create_line(padL, y, padL + cW, y, fill="#94a3b8", width=1.5, tags="chart_elem")
            else:
                c.create_line(padL, y, padL + cW, y, fill="#f1f5f9", width=1, tags="chart_elem")

            # Formatted text
            txt = f"Rs {tick:,.0f}" if abs(tick) >= 1000 else f"Rs {tick:,.2f}"
            c.create_text(padL - 10, y, text=txt, anchor="e",
                          font=("Segoe UI", 8, "bold" if abs(tick) < 0.001 else "normal"),
                          fill="#334155" if abs(tick) < 0.001 else "#64748b", tags="chart_elem")

        # 2. X-Axis Date Labels & Ticks
        y_base = py(0.0)
        for i, item in enumerate(data):
            x = px(i)
            # Date label
            lbl = item['date']
            c.create_text(x, H - padB + 10, text=lbl,
                          anchor="ne", font=("Segoe UI", 8), angle=315, fill="#475569", tags="chart_elem")
            # Tick mark on baseline
            c.create_line(x, y_base - 3, x, y_base + 3, fill="#cbd5e1", tags="chart_elem")

        bar_w = self._plot_meta['bar_w']

        # 3. Draw Bars (Cash & Bank)
        for i, item in enumerate(data):
            x = px(i)
            v_cash = item['cash']
            v_bank = item['bank']

            # Cash Bar (left half)
            y_c = py(v_cash)
            if v_cash >= 0:
                c.create_rectangle(x - bar_w, y_c, x, y_base,
                                   fill="#93c5fd", outline="#3b82f6", width=1, tags=f"bar_c_{i}")
            else:
                c.create_rectangle(x - bar_w, y_base, x, y_c,
                                   fill="#fca5a5", outline="#ef4444", width=1, tags=f"bar_c_{i}")

            # Bank Bar (right half)
            y_b = py(v_bank)
            if v_bank >= 0:
                c.create_rectangle(x, y_b, x + bar_w, y_base,
                                   fill="#86efac", outline="#22c55e", width=1, tags=f"bar_b_{i}")
            else:
                c.create_rectangle(x, y_base, x + bar_w, y_b,
                                   fill="#fca5a5", outline="#ef4444", width=1, tags=f"bar_b_{i}")

        # 4. Connecting Lines
        cash_pts = []
        for i, item in enumerate(data):
            cash_pts.extend([px(i) - bar_w / 2, py(item['cash'])])
        if len(cash_pts) >= 4:
            c.create_line(cash_pts, fill="#2563eb", width=2, tags="line_c")

        bank_pts = []
        for i, item in enumerate(data):
            bank_pts.extend([px(i) + bar_w / 2, py(item['bank'])])
        if len(bank_pts) >= 4:
            c.create_line(bank_pts, fill="#16a34a", width=2, tags="line_b")

        # 5. Circular Data Points
        for i, item in enumerate(data):
            # Cash marker
            x_c = px(i) - bar_w / 2
            y_c = py(item['cash'])
            col_c = "#ef4444" if item['cash'] < 0 else "#1d4ed8"
            c.create_oval(x_c - 4, y_c - 4, x_c + 4, y_c + 4,
                          fill=col_c, outline="#ffffff", width=1.5, tags=f"pt_c_{i}")

            # Bank marker
            x_b = px(i) + bar_w / 2
            y_b = py(item['bank'])
            col_b = "#ef4444" if item['bank'] < 0 else "#15803d"
            c.create_oval(x_b - 4, y_b - 4, x_b + 4, y_b + 4,
                          fill=col_b, outline="#ffffff", width=1.5, tags=f"pt_b_{i}")

        # 6. Border lines
        c.create_line(padL, padT, padL, padT + cH, fill="#e2e8f0", tags="chart_elem")
        c.create_line(padL, padT + cH, padL + cW, padT + cH, fill="#e2e8f0", tags="chart_elem")

    def _on_hover(self, event):
        if not self._data or not self._plot_meta:
            return

        c = self._canvas
        padL = self._plot_meta['padL']
        cW = self._plot_meta['cW']
        n = self._plot_meta['n']
        px = self._plot_meta['px']
        py = self._plot_meta['py']
        H = self._plot_meta['H']
        padT = self._plot_meta['padT']
        padB = self._plot_meta['padB']

        # Check if cursor is in plot bounds
        if not (padL - 20 <= event.x <= padL + cW + 20 and padT <= event.y <= H - padB + 30):
            self._on_leave(event)
            return

        # Find closest data index
        closest_idx = 0
        min_dist = float('inf')
        for i in range(n):
            dist = abs(event.x - px(i))
            if dist < min_dist:
                min_dist = dist
                closest_idx = i

        if closest_idx != self._hover_idx or not c.find_withtag("hover_elem"):
            self._hover_idx = closest_idx
            c.delete("hover_elem")

            item = self._data[closest_idx]
            cx = px(closest_idx)

            # Draw vertical guide line
            c.create_line(cx, padT, cx, H - padB, fill="#64748b", dash=(3, 3), width=1.2, tags="hover_elem")

            # Draw Tooltip Box
            d_str = item['date']
            cash_val = item['cash']
            bank_val = item['bank']
            net_val = item['total']

            # Tooltip dimensions & location
            tw, th = 175, 88
            # Flip left if near right edge
            tx = cx + 14 if cx + tw + 20 < self._plot_meta['W'] else cx - tw - 14
            ty = max(padT + 5, min(event.y - th / 2, H - padB - th - 5))

            # Background card with shadow
            c.create_rectangle(tx + 2, ty + 2, tx + tw + 2, ty + th + 2,
                               fill="#0f172a", outline="", tags="hover_elem")
            c.create_rectangle(tx, ty, tx + tw, ty + th,
                               fill="#1e293b", outline="#475569", width=1.5, tags="hover_elem")

            # Content inside Tooltip
            c.create_text(tx + 10, ty + 12, text=f"📅 {d_str}", anchor="w",
                          font=("Segoe UI", 9, "bold"), fill="#f8fafc", tags="hover_elem")
            c.create_line(tx + 8, ty + 24, tx + tw - 8, ty + 24, fill="#334155", tags="hover_elem")

            c.create_text(tx + 10, ty + 36, text=f"● Cash: Rs {cash_val:,.2f}", anchor="w",
                          font=("Segoe UI", 8, "bold"), fill="#93c5fd", tags="hover_elem")
            c.create_text(tx + 10, ty + 52, text=f"● Bank: Rs {bank_val:,.2f}", anchor="w",
                          font=("Segoe UI", 8, "bold"), fill="#86efac", tags="hover_elem")
            c.create_text(tx + 10, ty + 68, text=f"● Net:  Rs {net_val:,.2f}", anchor="w",
                          font=("Segoe UI", 8, "bold"), fill="#fde047", tags="hover_elem")

    def _on_leave(self, event=None):
        self._hover_idx = None
        self._canvas.delete("hover_elem")


if __name__ == "__main__":
    app = InteractiveChart()
    app.update()
    app.update_idletasks()

    # Trigger hover simulation for preview
    class MockEvent:
        x = 550
        y = 150
    app._on_hover(MockEvent())
    app.update()

    x = app.winfo_rootx()
    y = app.winfo_rooty()
    w = app.winfo_width()
    h = app.winfo_height()
    img = ImageGrab.grab(bbox=(x, y, x + w, y + h))
    img.save("scratch/interactive_preview.png")
    print("Screenshot saved to scratch/interactive_preview.png")
    app.destroy()
