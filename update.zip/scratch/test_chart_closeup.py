import os
import sys
sys.path.insert(0, os.path.abspath("."))
import tkinter as tk
from PIL import ImageGrab
import bookkeeper
import db

db_file = r"C:\Users\hk546\OneDrive\Desktop\bookkeeper.db"
if not os.path.exists(db_file):
    db_file = r"C:\Users\hk546\OneDrive\Desktop\ALLAH HU AKBAR_Fixed.db"

app = bookkeeper.BookKeeperApp()
app.load_company(db_file)
app.geometry("1100x800")
app.update()
app.update_idletasks()

app._draw_chart()
app.update()
app.update_idletasks()

# Hover over index 8 / x around 600
class MockEvent:
    x = 650
    y = 150

app._on_chart_hover(MockEvent())
app.update()
app.update_idletasks()

c = app._chart_canvas
x = c.winfo_rootx()
y = c.winfo_rooty()
w = c.winfo_width()
h = c.winfo_height()

img = ImageGrab.grab(bbox=(x - 10, y - 60, x + w + 10, y + h + 10))
img.save(r"scratch/chart_card_closeup.png")
print("Close up saved to scratch/chart_card_closeup.png")
app.destroy()
