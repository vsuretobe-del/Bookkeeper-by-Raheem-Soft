import os
import sys
sys.path.insert(0, os.path.abspath("."))
import tkinter as tk
from PIL import ImageGrab
import bookkeeper
import db

db_file = r"C:\Users\hk546\OneDrive\Desktop\bookkeeper.db"
if not os.path.exists(db_file):
    db_file = r"C:\Users\hk546\OneDrive\Desktop\ALLAH HU AKBAR_Fixed.db"
if not os.path.exists(db_file):
    db_file = "company.db"

app = bookkeeper.BookKeeperApp()
app.load_company(db_file)
app.geometry("1200x850")
app.update()
app.update_idletasks()

# Draw chart
app._draw_chart()
app.update()
app.update_idletasks()

# Simulate hover
class MockEvent:
    x = 620
    y = 120

app._on_chart_hover(MockEvent())
app.update()
app.update_idletasks()

x = app.winfo_rootx()
y = app.winfo_rooty()
w = app.winfo_width()
h = app.winfo_height()

img = ImageGrab.grab(bbox=(x, y, x + w, y + h))
img.save(r"scratch/full_dashboard_new_chart.png")
print("Full dashboard screenshot saved to scratch/full_dashboard_new_chart.png")
app.destroy()
