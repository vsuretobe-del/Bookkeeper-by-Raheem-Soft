import os
import sys
sys.path.insert(0, os.path.abspath("."))
import tkinter as tk
from PIL import ImageGrab
import db

class ChartTestApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Daily Cash Flow Test")
        self.geometry("1100x700")
        self.configure(bg="#f8f9fa")
        
        # Outer card frame
        card = tk.Frame(self, bg="#ffffff", relief="solid", bd=1, highlightbackground="#e2e8f0", highlightthickness=1)
        card.pack(fill="both", expand=True, padx=20, pady=20)
        
        # Header
        header_fr = tk.Frame(card, bg="#ffffff")
        header_fr.pack(fill="x", padx=14, pady=(12, 6))
        
        # Title
        tk.Label(header_fr, text="Daily Cash Flow", bg="#ffffff", fg="#1a202c",
                 font=("Segoe UI", 12, "bold")).pack(anchor="center")
                 
        # Legend
        legend_fr = tk.Frame(header_fr, bg="#ffffff")
        legend_fr.pack(anchor="center", pady=(6, 2))
        
        # Cash legend
        c_box = tk.Frame(legend_fr, bg="#9bc2e6", relief="solid", bd=1, highlightbackground="#5b9bd5", highlightthickness=1, width=28, height=13)
        c_box.pack(side="left", padx=(0, 5))
        c_box.pack_propagate(False)
        tk.Label(legend_fr, text="Cash", bg="#ffffff", fg="#2d3748", font=("Segoe UI", 9)).pack(side="left", padx=(0, 16))
        
        # Bank legend
        b_box = tk.Frame(legend_fr, bg="#c8e6c9", relief="solid", bd=1, highlightbackground="#70ad47", highlightthickness=1, width=28, height=13)
        b_box.pack(side="left", padx=(0, 5))
        b_box.pack_propagate(False)
        tk.Label(legend_fr, text="Bank", bg="#ffffff", fg="#2d3748", font=("Segoe UI", 9)).pack(side="left")
        
        # Canvas
        self._chart_canvas = tk.Canvas(card, bg="#ffffff", height=320, highlightthickness=0)
        self._chart_canvas.pack(fill="both", expand=True, padx=10, pady=(6, 12))
        self._chart_canvas.bind("<Configure>", self._draw_chart)

    def _draw_chart(self, event=None):
        c = self._chart_canvas
        c.delete("all")
        c.update_idletasks()
        W = c.winfo_width()
        H = c.winfo_height()
        if W < 50 or H < 50:
            return

        padL, padR, padT, padB = 95, 25, 20, 80
        cW = W - padL - padR
        cH = H - padT - padB

        data = db.get_daily_cash_flow()
        if not data:
            return

        n = len(data)
        
        # Values & Ticks
        y_ticks = [99980.00, 18800.00, 1279.40, 0.00, -3200.00]
        max_v = 99980.00
        min_v = -3200.00
        rng = max_v - min_v

        def px(i):
            return padL + (i / (n - 1)) * cW if n > 1 else padL + cW / 2
            
        def py(v):
            return padT + ((max_v - v) / rng) * cH

        # 1. Soft Horizontal Gridlines
        for tick in y_ticks:
            y = py(tick)
            if tick == 0.00:
                c.create_line(padL, y, padL + cW, y, fill="#a0aec0", width=1.2)
            else:
                c.create_line(padL, y, padL + cW, y, fill="#edf2f7", width=1)
                
            # Formatted Y labels with Rs symbol
            txt = f"Rs {tick:,.2f}" if tick >= 0 else f"Rs {tick:,.2f}"
            c.create_text(padL - 8, y, text=f"{tick:,.2f}", anchor="e",
                          font=("Segoe UI", 8), fill="#4a5568")

        # 2. X-Axis Date Labels (angled)
        for i, item in enumerate(data):
            x = px(i)
            lbl = item['date']
            # Rotated text
            c.create_text(x, H - padB + 10, text=lbl,
                          anchor="ne", font=("Segoe UI", 7), angle=315, fill="#4a5568")
            # Baseline tick
            y_base = py(0.00)
            c.create_line(x, y_base - 2, x, y_base + 2, fill="#cbd5e0")

        # Bar width
        bar_w = max(4, min(14, int(cW / n * 0.38)))
        y_base = py(0.00)

        # 3. Draw Bars
        for i, item in enumerate(data):
            x = px(i)
            v_cash = item['cash']
            v_bank = item['bank']
            
            # Cash Bar (left half)
            y_c = py(v_cash)
            if v_cash >= 0:
                c.create_rectangle(x - bar_w, y_c, x, y_base,
                                   fill="#9bc2e6", outline="#5b9bd5", width=1)
            else:
                c.create_rectangle(x - bar_w, y_base, x, y_c,
                                   fill="#f8d7da", outline="#e57373", width=1)
                
            # Bank Bar (right half)
            y_b = py(v_bank)
            if v_bank >= 0:
                c.create_rectangle(x, y_b, x + bar_w, y_base,
                                   fill="#c8e6c9", outline="#70ad47", width=1)
            else:
                c.create_rectangle(x, y_base, x + bar_w, y_b,
                                   fill="#f8d7da", outline="#e57373", width=1)

        # 4. Draw Cash Line & Data Points
        cash_pts = []
        for i, item in enumerate(data):
            cash_pts.extend([px(i) - bar_w / 2, py(item['cash'])])
        if len(cash_pts) >= 4:
            c.create_line(cash_pts, fill="#3b78ac", width=2)
            
        for i, item in enumerate(data):
            x = px(i) - bar_w / 2
            v = item['cash']
            y = py(v)
            fill_col = "#d93025" if v < 0 else "#2e6b9e"
            c.create_oval(x - 3.5, y - 3.5, x + 3.5, y + 3.5,
                          fill=fill_col, outline="#ffffff", width=1.5)

        # 5. Draw Bank Line & Data Points
        bank_pts = []
        for i, item in enumerate(data):
            bank_pts.extend([px(i) + bar_w / 2, py(item['bank'])])
        if len(bank_pts) >= 4:
            c.create_line(bank_pts, fill="#2e7d32", width=2)
            
        for i, item in enumerate(data):
            x = px(i) + bar_w / 2
            v = item['bank']
            y = py(v)
            fill_col = "#d93025" if v < 0 else "#388e3c"
            c.create_oval(x - 3.5, y - 3.5, x + 3.5, y + 3.5,
                          fill=fill_col, outline="#ffffff", width=1.5)

        # Border lines around chart plot
        c.create_line(padL, padT, padL, padT + cH, fill="#e2e8f0")
        c.create_line(padL, padT + cH, padL + cW, padT + cH, fill="#e2e8f0")


if __name__ == "__main__":
    app = ChartTestApp()
    app.update()
    app.update_idletasks()
    
    x = app.winfo_rootx()
    y = app.winfo_rooty()
    w = app.winfo_width()
    h = app.winfo_height()
    
    img = ImageGrab.grab(bbox=(x, y, x + w, y + h))
    img.save(r"scratch/daily_cash_flow_preview.png")
    print("Screenshot saved to scratch/daily_cash_flow_preview.png")
    app.destroy()
