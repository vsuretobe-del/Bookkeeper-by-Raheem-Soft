import os
import sys
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')
sys.path.insert(0, os.path.abspath("."))
import tkinter as tk
from PIL import ImageGrab
import db

db_file = r"C:\Users\hk546\OneDrive\Desktop\bookkeeper.db"
if os.path.exists(db_file):
    db.set_db_path(db_file)

import bookkeeper

app = bookkeeper.BookKeeperApp()
app.withdraw()

# Open Sales Invoice
app._open_create_voucher("sale")
app.update()

toplevels = [w for w in app.winfo_children() if isinstance(w, tk.Toplevel)]
sale_win = next((w for w in toplevels if "Sales Invoice" in w.title()), None)
assert sale_win is not None, "Sales Invoice window not found"

# Find item search entry recursively
item_search_entry = None
def find_entry(w):
    global item_search_entry
    if isinstance(w, tk.Entry) and w.cget("width") == 34:
        item_search_entry = w
        return
    for c in w.winfo_children():
        find_entry(c)

find_entry(sale_win)
print(f"Found item_search_entry: {item_search_entry}")
assert item_search_entry is not None

# Add Laptop item
item_search_entry.focus_set()
item_search_entry.delete(0, "end")
item_search_entry.insert(0, "Laptop")
item_search_entry.event_generate("<KeyPress>", keysym="Return")
app.update()

# Capture clean screenshot
sale_win.deiconify()
sale_win.lift()
sale_win.focus_force()
app.update()
sale_win.update_idletasks()
import time
time.sleep(0.5)
app.update()

sx = sale_win.winfo_rootx()
sy = sale_win.winfo_rooty()
sw = sale_win.winfo_width()
sh = sale_win.winfo_height()
img = ImageGrab.grab(bbox=(sx, sy, sx + sw, sy + sh))
os.makedirs("scratch", exist_ok=True)
img.save("scratch/test_voucher_clean_layout.png")
print("Saved clean screenshot to scratch/test_voucher_clean_layout.png")

app.destroy()
print("CLEAN SCREENSHOT CAPTURED SUCCESSFULLY!")
