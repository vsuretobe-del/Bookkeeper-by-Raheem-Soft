import os, sqlite3, datetime

for path in [r'.\bookkeeper.db', r'C:\Users\hk546\OneDrive\Desktop\bookkeeper.db']:
    if os.path.exists(path):
        mtime = os.path.getmtime(path)
        dt = datetime.datetime.fromtimestamp(mtime).strftime('%Y-%m-%d %H:%M:%S')
        conn = sqlite3.connect(path)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        users = [dict(r) for r in c.execute('SELECT * FROM users').fetchall()]
        settings = dict(c.execute("SELECT key, value FROM app_settings WHERE key LIKE 'company_%'").fetchall())
        vouchers_cnt = c.execute('SELECT COUNT(*) as cnt FROM vouchers').fetchone()['cnt']
        accounts_cnt = c.execute('SELECT COUNT(*) as cnt FROM account_detail').fetchone()['cnt']
        print(f"PATH: {os.path.abspath(path)}")
        print(f"  Modified: {dt}, Size: {os.path.getsize(path)}")
        print(f"  Settings: enable_pwd={settings.get('company_enable_pwd')}, user={settings.get('company_username')}, pwd={settings.get('company_password')}")
        print(f"  Users count: {len(users)}, Vouchers: {vouchers_cnt}, Accounts: {accounts_cnt}")
        print(f"  Users: {[u['username'] for u in users]}")
        conn.close()
