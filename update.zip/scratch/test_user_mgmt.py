import sys, os
sys.path.insert(0, os.path.abspath(os.path.dirname(os.path.dirname(__file__))))
import db

def test_user_management():
    print("Testing DB User Management functions...")
    
    # 1. Clean existing test user if any
    conn = db.get_conn()
    conn.execute("DELETE FROM users WHERE username IN ('TestUser1', 'TestUser2', 'TestUserUpdated')")
    conn.commit()
    conn.close()

    # 2. Add new user
    user1_data = {
        "username": "TestUser1",
        "password": "Password123",
        "initials": "TU",
        "acc_create": 1,
        "acc_view": 1,
        "sales_create": 1,
        "sales_view": 0,
        "purchase_create": 0,
        "purchase_view": 0,
        "mod_delete": 0,
        "mod_edit": 1
    }
    success = db.add_user(user1_data)
    assert success is True, "Failed to add user1"
    print("[PASS] Added user1 successfully")

    # 3. Duplicate username should fail
    dup_success = db.add_user(user1_data)
    assert dup_success is False, "Duplicate user addition should have failed"
    print("[PASS] Duplicate username correctly rejected")

    # 4. Fetch users
    users = db.get_all_users()
    u1 = next((u for u in users if u["username"] == "TestUser1"), None)
    assert u1 is not None, "TestUser1 not found in get_all_users"
    assert u1["password"] == "Password123"
    assert u1["initials"] == "TU"
    assert u1["sales_create"] == 1
    assert u1["sales_view"] == 0
    print(f"[PASS] get_all_users returned user with id={u1['id']}, perms verified")

    # 5. Update user by ID
    updated_data = {
        "username": "TestUserUpdated",
        "password": "NewPassword456",
        "initials": "TUX",
        "acc_create": 1,
        "acc_view": 1,
        "sales_create": 1,
        "sales_view": 1,
        "purchase_create": 1,
        "purchase_view": 1,
        "mod_delete": 1,
        "mod_edit": 1
    }
    up_success = db.update_user(u1["id"], updated_data)
    assert up_success is not False, "Failed to update user"
    
    users = db.get_all_users()
    u_updated = next((u for u in users if u["id"] == u1["id"]), None)
    assert u_updated is not None
    assert u_updated["username"] == "TestUserUpdated"
    assert u_updated["password"] == "NewPassword456"
    assert u_updated["initials"] == "TUX"
    assert u_updated["sales_view"] == 1
    print("[PASS] Updated user by ID successfully")

    # 6. Delete user by ID
    db.delete_user(u1["id"])
    users_after_del = db.get_all_users()
    assert not any(u["id"] == u1["id"] for u in users_after_del)
    print("[PASS] Deleted user successfully")

    print("\nALL USER MANAGEMENT TESTS PASSED!")

if __name__ == "__main__":
    test_user_management()
