import sys, os, datetime
sys.path.insert(0, os.path.abspath(os.path.dirname(os.path.dirname(__file__))))
import company_selection

user_home = os.path.expanduser("~")
search_dirs = [
    r"C:\Users\hk546\OneDrive\Desktop",
    os.path.join(user_home, "Desktop"),
    os.path.join(user_home, "OneDrive", "Desktop"),
    os.getcwd()
]

found_files = {}
for d in search_dirs:
    if os.path.exists(d):
        try:
            for f in os.listdir(d):
                if f.endswith(".db") and not f.startswith("._") and f not in found_files:
                    path = os.path.join(d, f)
                    if os.path.isfile(path):
                        stat = os.stat(path)
                        dt = datetime.datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %I:%M %p")
                        size = f"{max(1, stat.st_size // 1024)}KB"
                        found_files[f] = (path, dt, size, stat.st_mtime)
        except Exception:
            pass

for f, (path, dt, size, _) in sorted(found_files.items()):
    print(f"File: {f} -> Path: {path}")
