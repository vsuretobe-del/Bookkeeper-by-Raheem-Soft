import sqlite3, os

for path in [r'C:\Users\hk546\OneDrive\Desktop\bookkeeper.db', r'.\bookkeeper.db']:
    print(f"Testing DB: {path}")
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    
    # Check admin settings
    s_rows = c.execute("SELECT key, value FROM app_settings WHERE key LIKE 'company_%'").fetchall()
    settings = {r['key']: r['value'] for r in s_rows}
    correct_user = settings.get('company_username', '')
    correct_pass = settings.get('company_password', '')
    
    test_cases = [
        # (entered_user, entered_pass, should_succeed, expected_type)
        ("admin", "786", True, "admin"),
        ("Admin", "786", True, "admin"),
        ("", "786", True, "admin"),
        ("Muhammad Ali", "78688", True, "user"),
        ("muhammad ali", "78688", True, "user"),
        ("Test1", "786", True, "user"),
        ("test1", "786", True, "user"),
        ("t1", "786", True, "user"),
        ("T1", "786", True, "user"),
        ("t2", "786", True, "user"),
        ("wronguser", "786", False, "none"),
        ("t1", "wrongpass", False, "none"),
    ]
    
    for u, p, expected_ok, exp_type in test_cases:
        admin_match = False
        if p.strip() == str(correct_pass).strip():
            if not u.strip() or u.strip().lower() == str(correct_user).strip().lower() or u.strip().lower() == "admin":
                admin_match = True
        
        user_match = None
        if not admin_match:
            u_row = c.execute(
                "SELECT * FROM users WHERE LOWER(TRIM(username))=LOWER(TRIM(?)) AND TRIM(password)=TRIM(?)",
                (u.strip(), p.strip())
            ).fetchone()
            if u_row:
                user_match = dict(u_row)
                
        actual_ok = admin_match or (user_match is not None)
        assert actual_ok == expected_ok, f"Failed for ({u!r}, {p!r}): expected {expected_ok}, got {actual_ok}"
        print(f"  [PASS] Login ({u!r}, {p!r}) -> ok={actual_ok} (admin={admin_match})")
    
    conn.close()

print("\nALL LOGIN TESTS PASSED SUCCESSFULLY!")
