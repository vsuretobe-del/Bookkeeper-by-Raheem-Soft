import os
import sys
sys.path.insert(0, os.path.abspath("."))
import tkinter as tk
import tkinter.messagebox
from tkinter import messagebox
from PIL import ImageGrab
import db
db_file = r"C:\Users\hk546\OneDrive\Desktop\bookkeeper.db"
if os.path.exists(db_file):
    db.set_db_path(db_file)

import bookkeeper

# Monkey patch askyesno so it doesn't block GUI test
def mock_askyesno(title, message, parent=None):
    print(f"Mocked askyesno invoked: Title='{title}', Message='{message}'")
    return True

tkinter.messagebox.askyesno = mock_askyesno
messagebox.askyesno = mock_askyesno
bookkeeper.messagebox.askyesno = mock_askyesno

app = bookkeeper.BookKeeperApp()
app.withdraw()

# Ensure at least 1 item exists in active DB
if not db.get_all_items():
    db.add_item({"item": "Laptop", "units_name": "Nos", "defaultpurchaseprice": 50000.0, "defaultsellingprice": 60000.0, "stock": 10.0})

# 1. Open Sales Invoice
app._open_create_voucher("sale")
app.update()

toplevels = [w for w in app.winfo_children() if isinstance(w, tk.Toplevel)]
sale_win = next((w for w in toplevels if "Sales Invoice" in w.title()), None)
assert sale_win is not None, "Sales Invoice window not found"

# 2. Check Terms & Conditions vs Narration
terms_labels = []
narration_labels = []
def scan_labels(widget):
    for child in widget.winfo_children():
        if isinstance(child, tk.Label):
            txt = str(child.cget("text"))
            if "Terms & Conditions" in txt:
                terms_labels.append(txt)
            if "Narration" in txt:
                narration_labels.append(txt)
        scan_labels(child)

scan_labels(sale_win)
print(f"Terms labels found: {len(terms_labels)}")
print(f"Narration labels found: {len(narration_labels)} ({narration_labels})")
assert len(terms_labels) == 0, "Terms & Conditions should be removed!"
assert len(narration_labels) > 0, "Narration label should be present!"

# 3. Find Item Search Entry & Calendar labels
item_search_entry = None
cal_labels = []
def find_widgets(widget):
    global item_search_entry
    for child in widget.winfo_children():
        if isinstance(child, tk.Entry) and child.cget("width") == 34:
            item_search_entry = child
        if isinstance(child, tk.Label) and "📅" in str(child.cget("text")):
            cal_labels.append(child)
        find_widgets(child)

find_widgets(sale_win)
print(f"Found item_search_entry: {item_search_entry}")
print(f"Found calendar icons: {len(cal_labels)}")

# 4. Check Calendar positioning
for i, cal in enumerate(cal_labels):
    cal.update_idletasks()
    print(f"Cal {i} root pos: x={cal.winfo_rootx()}, y={cal.winfo_rooty()}")

# 5. Type and add an item
test_item = "Laptop"
print(f"Testing with item: '{test_item}'")

item_search_entry.focus_set()
item_search_entry.delete(0, "end")
item_search_entry.insert(0, test_item)
item_search_entry.event_generate("<KeyRelease>", keysym="p")
app.update()

item_search_entry.event_generate("<KeyPress>", keysym="Return")
app.update()

# 6. Check Grid Scrollbar visibility with 1 item
grid_vsb = None
def find_vsb(widget):
    global grid_vsb
    for child in widget.winfo_children():
        if isinstance(child, tk.ttk.Scrollbar):
            grid_vsb = child
        find_vsb(child)

find_vsb(sale_win)
print(f"Grid VSB widget: {grid_vsb}")
if grid_vsb:
    print(f"Grid VSB is mapped with 1 item?: {grid_vsb.winfo_ismapped()}")
    assert not grid_vsb.winfo_ismapped(), "Scrollbar should be hidden with only 1 item!"

# 7. Check Enter key navigation across row fields
cur = sale_win.focus_get()
print(f"1. Focus after item add (should be QTY): {cur}")

cur.event_generate("<KeyPress>", keysym="Return")
app.update()
cur2 = sale_win.focus_get()
print(f"2. Focus after Enter on QTY (should be Units): {cur2}")

cur2.event_generate("<KeyPress>", keysym="Return")
app.update()
cur3 = sale_win.focus_get()
print(f"3. Focus after Enter on Units (should be Rate): {cur3}")

cur3.event_generate("<KeyPress>", keysym="Return")
app.update()
cur4 = sale_win.focus_get()
print(f"4. Focus after Enter on Rate (should be Per): {cur4}")

cur4.event_generate("<KeyPress>", keysym="Return")
app.update()
cur5 = sale_win.focus_get()
print(f"5. Focus after Enter on Per (Disc or Desc): {cur5}")

cur5.event_generate("<KeyPress>", keysym="Return")
app.update()
cur6 = sale_win.focus_get()
print(f"6. Focus after Enter on Disc (Tax or Desc): {cur6}")

cur6.event_generate("<KeyPress>", keysym="Return")
app.update()
cur7 = sale_win.focus_get()
print(f"7. Focus after Enter on Tax (Description): {cur7}")

cur7.event_generate("<KeyPress>", keysym="Return")
app.update()

cur8 = sale_win.focus_get()
print(f"8. Focus after YES on prompt: {cur8}")
print(f"Is focus on F9 Item Search Entry?: {cur8 == item_search_entry}")
assert cur8 == item_search_entry, "Focus should return to F9 Item search entry after YES!"

# Take full screenshot
sx = sale_win.winfo_rootx()
sy = sale_win.winfo_rooty()
sw = sale_win.winfo_width()
sh = sale_win.winfo_height()
img = ImageGrab.grab(bbox=(sx, sy, sx + sw, sy + sh))
img.save("scratch/test_voucher_enhancements_verified.png")
print("Saved screenshot to scratch/test_voucher_enhancements_verified.png")

app.destroy()
print("SUCCESS: ALL 4 REQUIREMENTS TESTED AND PASSED!")
