import os, sys
sys.path.insert(0, os.path.abspath(os.path.dirname(os.path.dirname(__file__))))
import db

dbs = [
    r"c:\Users\hk546\Downloads\Book Keeper\bookkeeper.db",
    r"C:\Users\hk546\OneDrive\Desktop\bookkeeper.db"
]

test_cases = [
    ("admin", "786"),
    ("Admin", "786"),
    ("", "786"),
    ("t1", "786"),
    ("T1", "786"),
    ("t2", "786"),
    ("Test1", "786"),
    ("test1", "786"),
    ("Muhammad Ali", "78688"),
    ("muhammad ali", "78688"),
    ("invalid_user", "wrong_pass"),
]

for p in dbs:
    if os.path.exists(p):
        print(f"\nTesting Auth on: {p}")
        for u, pwd in test_cases:
            ok, user_data, err = db.authenticate_user(p, u, pwd)
            print(f"  User: '{u}', Pass: '{pwd}' -> Authenticated: {ok}, Admin: {user_data.get('is_admin') if user_data else None}, Username: {user_data.get('username') if user_data else None}")
