import sys
import os
import tkinter as tk

# Set up paths
sys.path.insert(0, r"c:\Users\hk546\Downloads\Book Keeper")
import db
import invoice_preview

print("Testing db date sorting...")
invoices = db.get_all_invoices("expense")
print(f"Total expense vouchers: {len(invoices)}")
for inv in invoices[:10]:
    print(f"ID: {inv['id']}, Vch: {inv['invoice_no']}, Date: {inv['date']}, Total: {inv['total']}")

print("\nTesting date parser:")
print("July 25, 2026 ->", db.parse_date_for_sort("July 25, 2026"), "ISO:", db.parse_date_to_iso("July 25, 2026"))
print("2026-08-05 ->", db.parse_date_for_sort("2026-08-05"), "ISO:", db.parse_date_to_iso("2026-08-05"))

root = tk.Tk()
root.withdraw()

print("\nTesting show_invoice_preview initialization...")
if invoices:
    sample_inv = invoices[0]
    invoice_preview.show_invoice_preview(root, sample_inv, db, doc_type="expense")
    print("show_invoice_preview executed without errors!")

root.destroy()
print("\nAll automated checks passed successfully!")
