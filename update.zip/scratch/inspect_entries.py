import os
import sys
sys.path.insert(0, os.path.abspath("."))
import db
import bookkeeper
import tkinter as tk

db_file = r'C:\Users\hk546\OneDrive\Desktop\bookkeeper.db'
db.set_db_path(db_file)

app = bookkeeper.BookKeeperApp()
app.withdraw()
app._open_create_voucher('sale')
app.update()

toplevels = [w for w in app.winfo_children() if isinstance(w, tk.Toplevel)]
sale_win = toplevels[0]

def inspect_entries(w, path=''):
    for c in w.winfo_children():
        p = f"{path}/{c.__class__.__name__}"
        if isinstance(c, tk.Entry):
            print(f"{p}: width={c.cget('width')} value={repr(c.get())}")
        inspect_entries(c, p)

for c in sale_win.winfo_children():
    for sub in c.winfo_children():
        if isinstance(sub, tk.Entry) and sub.cget('width') == 34:
            sub.insert(0, 'Laptop Test')
            sub.event_generate('<KeyPress>', keysym='Return')
            app.update()
            break

inspect_entries(sale_win)
app.destroy()
