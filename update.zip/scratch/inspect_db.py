import os, sys
sys.path.insert(0, os.path.abspath("."))
import db

db_file = r"C:\Users\hk546\OneDrive\Desktop\bookkeeper.db"
if os.path.exists(db_file):
    db.set_db_path(db_file)

conn = db.get_conn()
rows = conn.execute("SELECT v_id, vch_no, v_type, date, amount, narration, detail1, detail2 FROM vouchers WHERE v_type='expense' ORDER BY v_id DESC LIMIT 20").fetchall()
print(f"Total expense vouchers found: {len(rows)}")
for r in rows:
    print(dict(r))

invs = db.get_all_invoices("expense")
print(f"\ndb.get_all_invoices('expense') returned {len(invs)} items:")
for inv in invs[:10]:
    print(inv)

conn.close()
