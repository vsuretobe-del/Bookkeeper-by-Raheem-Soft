import tkinter as tk
from tkinter import messagebox
from PIL import ImageGrab
import os
import sys

class TestVoucherItemSearchRobust(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Main App")
        self.geometry("1200x800")
        self.configure(bg="#f0f0f0")

        self.item_names_all = ["Laptop Acer", "Laptop Dell XPS", "Orange Juice 1L", "Office Chair Ergo", "Oil 5L"]

        btn_open = tk.Button(self, text="Open Sales Invoice", font=("Segoe UI", 11), command=self.open_voucher)
        btn_open.pack(pady=20)

    def _item_form(self, existing=None, callback=None, initial_name="", parent=None):
        parent_win = parent or self
        form_win = tk.Toplevel(parent_win)
        form_win.title("Create Inventory Item")
        form_win.geometry("500x350")
        form_win.configure(bg="#ffffff")
        form_win.transient(parent_win)
        form_win.grab_set()

        tk.Label(form_win, text="Item Name:", font=("Segoe UI", 10), bg="#ffffff").pack(pady=(20, 5))
        name_ent = tk.Entry(form_win, font=("Segoe UI", 10), width=30)
        name_ent.pack(pady=5)
        if initial_name:
            name_ent.insert(0, initial_name)
            name_ent.focus_set()
            name_ent.select_range(0, 'end')

        def on_save():
            item_name = name_ent.get().strip()
            if item_name:
                self.item_names_all.append(item_name)
            form_win.destroy()
            if callback:
                callback(item_name)

        tk.Button(form_win, text="F12: Save", font=("Segoe UI", 10, "bold"), command=on_save, bg="#e0e0e0").pack(pady=20)

    def open_voucher(self):
        win = tk.Toplevel(self)
        win.title("Sales Invoice")
        win.geometry("900x600")
        win.configure(bg="#ffffff")

        # Top frame
        item_top = tk.Frame(win, bg="#ffffff")
        item_top.pack(fill="x", padx=10, pady=10)

        tk.Label(item_top, text="F9: Item", bg="#ffffff", font=("Segoe UI", 10, "bold")).pack(side="left", padx=(0, 5))
        item_var = tk.StringVar()
        item_ent = tk.Entry(item_top, textvariable=item_var, font=("Segoe UI", 10), width=34, relief="solid", bd=1, bg="#ffffff")
        item_ent.pack(side="left")

        # List of added items in voucher
        grid_lb = tk.Listbox(win, font=("Segoe UI", 10), height=10)
        grid_lb.pack(fill="both", expand=True, padx=10, pady=10)

        def add_to_grid(name):
            grid_lb.insert("end", f"Item Added: {name}")

        popup_win = None
        popup_lb = None

        def hide_popup(e=None):
            nonlocal popup_win, popup_lb
            if popup_win and popup_win.winfo_exists():
                popup_win.destroy()
            popup_win = None
            popup_lb = None

        def on_select_from_popup(event=None):
            nonlocal popup_lb
            if not popup_lb or not popup_lb.winfo_exists():
                return
            cur = popup_lb.curselection()
            if cur:
                sel = popup_lb.get(cur[0])
                hide_popup()
                add_to_grid(sel)
                item_var.set("")

        def show_popup(matches):
            nonlocal popup_win, popup_lb
            if not matches:
                hide_popup()
                return

            if popup_win is None or not popup_win.winfo_exists():
                popup_win = tk.Toplevel(win)
                popup_win.wm_overrideredirect(True)
                popup_win.attributes("-topmost", True)

                border_fr = tk.Frame(popup_win, bg="#7f9db9", bd=1)
                border_fr.pack(fill="both", expand=True)

                popup_lb = tk.Listbox(border_fr, font=("Segoe UI", 10), bg="#ffffff", fg="#000000",
                                      selectbackground="#0078d7", selectforeground="#ffffff",
                                      activestyle="none", relief="flat", bd=0, highlightthickness=0)
                popup_lb.pack(fill="both", expand=True)
                popup_lb.bind("<ButtonRelease-1>", on_select_from_popup)

            popup_lb.delete(0, "end")
            for m in matches:
                popup_lb.insert("end", m)
            popup_lb.selection_set(0)
            popup_lb.activate(0)

            # Position popup under item_ent
            item_ent.update_idletasks()
            ex = item_ent.winfo_rootx()
            ey = item_ent.winfo_rooty()
            ew = item_ent.winfo_width()
            eh = item_ent.winfo_height()

            num_rows = min(len(matches), 8)
            lh = max(30, min(200, num_rows * 22 + 4))
            popup_win.geometry(f"{ew}x{lh}+{ex}+{ey + eh}")
            popup_win.lift()

        def on_key_release(e):
            if e.keysym in ("Up", "Down", "Return", "Escape", "Tab"):
                return
            typed = item_var.get().strip().lower()
            if not typed:
                hide_popup()
            else:
                matches = [n for n in self.item_names_all if typed in n.lower()]
                if matches:
                    show_popup(matches)
                else:
                    hide_popup()

        def on_key_press(e):
            nonlocal popup_lb
            if e.keysym == "Down":
                if popup_lb and popup_lb.winfo_exists():
                    cur = popup_lb.curselection()
                    next_idx = (cur[0] + 1) if cur else 0
                    if next_idx < popup_lb.size():
                        popup_lb.selection_clear(0, "end")
                        popup_lb.selection_set(next_idx)
                        popup_lb.activate(next_idx)
                        popup_lb.see(next_idx)
                    return "break"
            elif e.keysym == "Up":
                if popup_lb and popup_lb.winfo_exists():
                    cur = popup_lb.curselection()
                    prev_idx = (cur[0] - 1) if cur else 0
                    if prev_idx >= 0:
                        popup_lb.selection_clear(0, "end")
                        popup_lb.selection_set(prev_idx)
                        popup_lb.activate(prev_idx)
                        popup_lb.see(prev_idx)
                    return "break"
            elif e.keysym == "Escape":
                hide_popup()
                return "break"
            elif e.keysym == "Return":
                on_enter()
                return "break"

        def on_enter(e=None):
            nonlocal popup_lb
            if popup_lb and popup_lb.winfo_exists():
                cur = popup_lb.curselection()
                if cur:
                    sel = popup_lb.get(cur[0])
                    hide_popup()
                    add_to_grid(sel)
                    item_var.set("")
                    return "break"

            typed = item_var.get().strip()
            if not typed:
                return "break"

            match = next((n for n in self.item_names_all if n.lower() == typed.lower()), None)
            if match:
                hide_popup()
                add_to_grid(match)
                item_var.set("")
            else:
                hide_popup()
                ans = messagebox.askyesno("Query", "Inventory item doesnt exists.\nCreate new item?", parent=win)
                if ans:
                    def on_new_saved(new_name=None):
                        final_name = new_name or typed
                        add_to_grid(final_name)
                        item_var.set("")
                        try:
                            win.lift()
                            win.focus_set()
                        except Exception:
                            pass
                    self._item_form(initial_name=typed, callback=on_new_saved, parent=win)
                else:
                    item_ent.focus_set()
                    item_ent.select_range(0, "end")
            return "break"

        item_ent.bind("<KeyRelease>", on_key_release)
        item_ent.bind("<KeyPress>", on_key_press)

        def on_focus_in(e):
            item_ent.config(bg="#ffff00")

        def on_focus_out(e):
            item_ent.config(bg="#ffffff")

        item_ent.bind("<FocusIn>", on_focus_in)
        item_ent.bind("<FocusOut>", on_focus_out)

        # Close popup if user clicks on window background
        win.bind("<Button-1>", lambda e: hide_popup() if e.widget != item_ent and (not popup_lb or e.widget != popup_lb) else None)
        win.bind("<Destroy>", lambda e: hide_popup() if e.widget == win else None)

        self.test_win = win
        self.test_item_ent = item_ent
        self.test_item_var = item_var
        self.test_grid_lb = grid_lb

if __name__ == "__main__":
    app = TestVoucherItemSearchRobust()
    app.open_voucher()
    app.update()
    app.update_idletasks()

    # Simulate typing 'op'
    app.test_item_var.set("op")
    app.test_item_ent.event_generate("<KeyRelease>", keysym="p")
    app.update()
    app.update_idletasks()

    x = app.test_win.winfo_rootx()
    y = app.test_win.winfo_rooty()
    w = app.test_win.winfo_width()
    h = app.test_win.winfo_height()

    img = ImageGrab.grab(bbox=(x, y, x + w, y + h))
    img.save("scratch/test_dropdown_robust_preview.png")
    print("Screenshot saved to scratch/test_dropdown_robust_preview.png")
    app.destroy()
