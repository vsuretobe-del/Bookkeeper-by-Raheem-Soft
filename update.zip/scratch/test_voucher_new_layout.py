import os
import sys
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')
sys.path.insert(0, os.path.abspath("."))
import tkinter as tk
import tkinter.messagebox
from tkinter import messagebox
from PIL import ImageGrab
import db

db_file = r"C:\Users\hk546\OneDrive\Desktop\bookkeeper.db"
if os.path.exists(db_file):
    db.set_db_path(db_file)

import bookkeeper

# Mock askyesno
def mock_askyesno(title, message, parent=None):
    return True

tkinter.messagebox.askyesno = mock_askyesno
messagebox.askyesno = mock_askyesno
bookkeeper.messagebox.askyesno = mock_askyesno

# Ensure sample items with different units exist in DB
test_items = [
    {"item": "Laptop Test", "units_name": "Numbers", "defaultpurchaseprice": 50000.0, "defaultsellingprice": 60000.0, "stock": 10.0},
    {"item": "Sugar Bag", "units_name": "Kilogram", "defaultpurchaseprice": 120.0, "defaultsellingprice": 150.0, "stock": 50.0},
    {"item": "Cotton Fabric", "units_name": "Meter", "defaultpurchaseprice": 200.0, "defaultsellingprice": 300.0, "stock": 100.0}
]
existing_items = db.get_all_items()
existing_names = [it["name"] for it in existing_items]
for ti in test_items:
    if ti["item"] not in existing_names:
        db.add_item(ti)

print("DB Items loaded:")
for it in db.get_all_items():
    print(f" - {it['name']}: unit={it['unit']} (units_name={it.get('units_name')})")

app = bookkeeper.BookKeeperApp()
app.withdraw()

# 1. Open Sales Invoice
app._open_create_voucher("sale")
app.update()

toplevels = [w for w in app.winfo_children() if isinstance(w, tk.Toplevel)]
sale_win = next((w for w in toplevels if "Sales Invoice" in w.title()), None)
assert sale_win is not None, "Sales Invoice window not found"

# 2. Check layout labels
labels_found = {}
def scan_all_labels(w):
    for c in w.winfo_children():
        if isinstance(c, tk.Label):
            t = str(c.cget("text"))
            labels_found[t] = c
        scan_all_labels(c)

scan_all_labels(sale_win)
print("Labels found in Sales Invoice:", list(labels_found.keys()))

assert "Sub Total" in labels_found, "Label 'Sub Total' must exist!"
assert "Balance" in labels_found, "Label 'Balance' must exist!"
assert "Amount" in labels_found, "Label 'Amount' must exist under Balance!"
assert "Round Off" in labels_found, "Label 'Round Off' must exist!"
assert "Advance" in labels_found, "Label 'Advance' must exist!"
assert "Payment A/C" in labels_found, "Label 'Payment A/C' must exist!"
assert "Total Amount" not in labels_found, "'Total Amount' label should be replaced by 'Sub Total'!"
assert "Due Date" in labels_found, "Label 'Due Date' must exist!"

# 3. Check Due Date button position inside screen
due_lbl = labels_found["Due Date"]
due_x = due_lbl.winfo_rootx()
win_x = sale_win.winfo_rootx()
win_w = sale_win.winfo_width()
print(f"Due Date label x: {due_x}, Window x: {win_x}, Window width: {win_w}")
assert due_x < win_x + win_w, "Due Date label must be inside the window!"

# 4. Add items and verify unit symbols
item_search_entry = None
def find_item_search(w):
    global item_search_entry
    for c in w.winfo_children():
        if isinstance(c, tk.Entry) and c.cget("width") == 34:
            item_search_entry = c
        find_item_search(c)

find_item_search(sale_win)
assert item_search_entry is not None, "Item search entry not found"

# Add Laptop Test
item_search_entry.focus_set()
item_search_entry.delete(0, "end")
item_search_entry.insert(0, "Laptop Test")
item_search_entry.event_generate("<KeyRelease>", keysym="t")
app.update()
item_search_entry.event_generate("<KeyPress>", keysym="Return")
app.update()

# Add Sugar Bag
item_search_entry.focus_set()
item_search_entry.delete(0, "end")
item_search_entry.insert(0, "Sugar Bag")
item_search_entry.event_generate("<KeyRelease>", keysym="g")
app.update()
item_search_entry.event_generate("<KeyPress>", keysym="Return")
app.update()

app.update()

# Check values in grid
grid_entries = []
def scan_grid(w):
    for c in w.winfo_children():
        if isinstance(c, tk.Entry):
            val = c.get()
            if val:
                grid_entries.append(val)
        scan_grid(c)

scan_grid(sale_win)
print("Entries found in Sales Invoice tree:", grid_entries)

# 5. Capture screenshot
sale_win.deiconify()
sale_win.lift()
sale_win.focus_force()
app.update()
sale_win.update_idletasks()
import time
time.sleep(0.5)
app.update()
sx = sale_win.winfo_rootx()
sy = sale_win.winfo_rooty()
sw = sale_win.winfo_width()
sh = sale_win.winfo_height()
img = ImageGrab.grab(bbox=(sx, sy, sx + sw, sy + sh))
img.save("scratch/test_voucher_new_layout.png")
print("Saved screenshot to scratch/test_voucher_new_layout.png")

app.destroy()
print("SUCCESS: ALL CHECKS PASSED PERFECTLY!")
