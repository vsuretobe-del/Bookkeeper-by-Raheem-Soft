import sys, os
sys.path.insert(0, os.path.abspath(os.path.dirname(os.path.dirname(__file__))))
import tkinter as tk
import sqlite3
import db

def test_login_flow():
    app_ref = type('AppRef', (), {})()
    app_ref.current_user = None
    app_ref.active_company_path = None
    app_ref.deiconify = lambda: print("App deiconify called")
    app_ref.load_company = lambda fp: print(f"load_company called with {fp}")

    filepath = r"C:\Users\hk546\OneDrive\Desktop\bookkeeper.db"
    correct_user = "admin"
    correct_pass = "786"

    # Test user login with t1 / 786
    u = "t1"
    p = "786"

    # 1. Admin login check
    admin_match = False
    if p == str(correct_pass).strip():
        if not u or u.lower() == str(correct_user).strip().lower() or u.lower() == "admin":
            admin_match = True

    print(f"Admin match for ({u}, {p}): {admin_match}")

    # 2. Users table check
    conn = sqlite3.connect(filepath)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    u_row = c.execute(
        "SELECT * FROM users WHERE LOWER(TRIM(username))=LOWER(TRIM(?)) AND TRIM(password)=TRIM(?)",
        (u, p)
    ).fetchone()
    conn.close()

    print(f"User row found: {dict(u_row) if u_row else None}")
    assert u_row is not None, "u_row should NOT be None!"
    assert u_row["username"] == "t1"
    assert u_row["password"] == "786"
    print("SUCCESS: Login flow verified for t1 / 786")

if __name__ == "__main__":
    test_login_flow()
