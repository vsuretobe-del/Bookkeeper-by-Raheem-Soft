import tkinter as tk
from tkinter import ttk, messagebox
from PIL import ImageGrab
import os
import sys
sys.path.insert(0, os.path.abspath("."))
import db

class TestVoucherItemSearch(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Create Voucher - Item Search Test")
        self.geometry("1100x700")
        self.configure(bg="#ffffff")

        # Connect db
        db_file = r"C:\Users\hk546\OneDrive\Desktop\bookkeeper.db"
        if os.path.exists(db_file):
            db.set_db_path(db_file)

        self._build_ui()

    def _build_ui(self):
        win = self
        BG = "#ffffff"
        FONT = ("Segoe UI", 10)

        item_hint = tk.Label(win, text="  Press ENTER key to add item.",
                             bg=BG, fg="darkred", font=("Tahoma", 8, "bold"), anchor="w")
        item_hint.pack(fill="x", padx=8, pady=(10, 0))

        item_top = tk.Frame(win, bg=BG)
        item_top.pack(fill="x", padx=8, pady=4)

        # F9 Item search
        tk.Label(item_top, text="F9: Item", bg=BG, fg="#000",
                 font=FONT).pack(side="left", padx=(0, 4))
        
        self.item_search_var = tk.StringVar()
        self.all_inv_items = db.get_all_items()
        self.item_names_all = [r["name"] for r in self.all_inv_items]

        # Add sample items for testing if empty
        if not self.item_names_all:
            self.item_names_all = ["op", "op Batch#122", "Orange Juice", "Oil 1L", "Office Chair"]
            self.all_inv_items = [{"name": n, "sale_price": 100, "unit": "Nos", "stock": 10} for n in self.item_names_all]

        self.item_search_entry = tk.Entry(item_top, textvariable=self.item_search_var,
                                          font=FONT, width=36, relief="solid", bd=1, bg="#ffffff")
        self.item_search_entry.pack(side="left")

        # Units left / Item history
        self.units_lbl = tk.Label(item_top, text="  Units Left: 0", bg=BG, fg="#000",
                                  font=("Segoe UI", 10))
        self.units_lbl.pack(side="left", padx=10)
        tk.Label(item_top, text="Alt+F2: Item History", bg=BG, fg="#000000",
                 font=("Segoe UI", 10), cursor="hand2").pack(side="left", padx=8)
        tk.Label(item_top, text="View Photo", bg=BG, fg="#000000",
                 font=("Segoe UI", 10), cursor="hand2").pack(side="left")

        # Dropdown Popup state
        self.popup_list = None
        self.popup_listbox = None

        def close_dropdown(e=None):
            if self.popup_list and self.popup_list.winfo_exists():
                self.popup_list.destroy()
            self.popup_list = None
            self.popup_listbox = None

        def on_listbox_click(event):
            if not self.popup_listbox:
                return
            idx = self.popup_listbox.nearest(event.y)
            if idx >= 0:
                sel_name = self.popup_listbox.get(idx)
                close_dropdown()
                self.on_select_item_name(sel_name)

        def open_dropdown(matches):
            if not matches:
                close_dropdown()
                return

            if self.popup_list is None or not self.popup_list.winfo_exists():
                self.popup_list = tk.Toplevel(win)
                self.popup_list.wm_overrideredirect(True)
                self.popup_list.attributes("-topmost", True)

                border_fr = tk.Frame(self.popup_list, bg="#7f9db9", bd=1)
                border_fr.pack(fill="both", expand=True)

                self.popup_listbox = tk.Listbox(border_fr, font=FONT, bg="#ffffff", fg="#000000",
                                                selectbackground="#0078d7", selectforeground="#ffffff",
                                                activestyle="none", relief="flat", bd=0, highlightthickness=0)
                self.popup_listbox.pack(fill="both", expand=True)

                self.popup_listbox.bind("<ButtonRelease-1>", on_listbox_click)

            self.popup_listbox.delete(0, "end")
            for m in matches:
                self.popup_listbox.insert("end", m)

            self.popup_listbox.selection_set(0)
            self.popup_listbox.activate(0)

            self.item_search_entry.update_idletasks()
            ex = self.item_search_entry.winfo_rootx()
            ey = self.item_search_entry.winfo_rooty()
            ew = self.item_search_entry.winfo_width()
            eh = self.item_search_entry.winfo_height()

            num_rows = min(len(matches), 8)
            lh = max(30, min(200, num_rows * 22 + 4))
            self.popup_list.geometry(f"{ew}x{lh}+{ex}+{ey + eh}")
            self.popup_list.lift()

        def on_key_release(event):
            if event.keysym in ("Up", "Down", "Return", "Escape", "Tab"):
                return
            q = self.item_search_var.get().strip().lower()
            if not q:
                close_dropdown()
            else:
                matches = [n for n in self.item_names_all if q in n.lower()]
                if matches:
                    open_dropdown(matches)
                else:
                    close_dropdown()

        def on_key_down(event):
            if event.keysym == "Down":
                if self.popup_listbox and self.popup_listbox.winfo_exists():
                    cur = self.popup_listbox.curselection()
                    next_idx = (cur[0] + 1) if cur else 0
                    if next_idx < self.popup_listbox.size():
                        self.popup_listbox.selection_clear(0, "end")
                        self.popup_listbox.selection_set(next_idx)
                        self.popup_listbox.activate(next_idx)
                        self.popup_listbox.see(next_idx)
                    return "break"
            elif event.keysym == "Up":
                if self.popup_listbox and self.popup_listbox.winfo_exists():
                    cur = self.popup_listbox.curselection()
                    prev_idx = (cur[0] - 1) if cur else 0
                    if prev_idx >= 0:
                        self.popup_listbox.selection_clear(0, "end")
                        self.popup_listbox.selection_set(prev_idx)
                        self.popup_listbox.activate(prev_idx)
                        self.popup_listbox.see(prev_idx)
                    return "break"
            elif event.keysym == "Escape":
                close_dropdown()
                return "break"
            elif event.keysym == "Return":
                return self.on_enter_item(event)

        self.item_search_entry.bind("<KeyRelease>", on_key_release)
        self.item_search_entry.bind("<KeyPress>", on_key_down)

        def on_focus_in(e):
            self.item_search_entry.config(bg="#ffff00")

        def on_focus_out(e):
            self.item_search_entry.config(bg="#ffffff")
            # Close dropdown after short delay
            win.after(150, lambda: close_dropdown() if not (self.popup_list and self.popup_list.focus_get()) else None)

        self.item_search_entry.bind("<FocusIn>", on_focus_in)
        self.item_search_entry.bind("<FocusOut>", on_focus_out)

        self.close_dropdown = close_dropdown

    def on_select_item_name(self, name):
        print(f"Selected item: {name}")
        self.item_search_var.set("")

    def on_enter_item(self, event=None):
        if self.popup_listbox and self.popup_listbox.winfo_exists():
            cur = self.popup_listbox.curselection()
            if cur:
                sel_name = self.popup_listbox.get(cur[0])
                self.close_dropdown()
                self.on_select_item_name(sel_name)
                return "break"

        typed_name = self.item_search_var.get().strip()
        if not typed_name:
            return "break"

        # Check if item exists in inventory
        match = next((n for n in self.item_names_all if n.lower() == typed_name.lower()), None)
        if match:
            self.close_dropdown()
            self.on_select_item_name(match)
        else:
            self.close_dropdown()
            ans = messagebox.askyesno("Query", "Inventory item doesnt exists.\nCreate new item?", parent=self)
            if ans:
                print(f"Opening Create Inventory Item for '{typed_name}'")
            else:
                self.item_search_entry.focus_set()
                self.item_search_entry.select_range(0, "end")
        return "break"

if __name__ == "__main__":
    app = TestVoucherItemSearch()
    app.update()
    app.update_idletasks()
    
    # Simulate typing 'op'
    app.item_search_var.set("op")
    app.item_search_entry.focus_set()
    app.item_search_entry.event_generate("<KeyRelease>", keysym="p")
    app.update()
    app.update_idletasks()

    x = app.winfo_rootx()
    y = app.winfo_rooty()
    w = app.winfo_width()
    h = app.winfo_height()

    img = ImageGrab.grab(bbox=(x, y, x + w, y + h))
    img.save("scratch/test_autocomplete_preview.png")
    print("Saved to scratch/test_autocomplete_preview.png")
    app.destroy()
