import os, sqlite3

dirs = ['.', os.path.expanduser('~/OneDrive/Desktop'), os.path.expanduser('~/Desktop')]
for d in dirs:
    if os.path.exists(d):
        for f in os.listdir(d):
            if f.endswith('.db') or f.endswith('.sqlite'):
                p = os.path.join(d, f)
                try:
                    conn = sqlite3.connect(p)
                    conn.row_factory = sqlite3.Row
                    c = conn.cursor()
                    s_rows = c.execute("SELECT key, value FROM app_settings WHERE key LIKE 'company_%'").fetchall()
                    settings = {r['key']: r['value'] for r in s_rows}
                    u_rows = c.execute("SELECT id, username, password, initials FROM users").fetchall()
                    users = [dict(r) for r in u_rows]
                    print(f"FILE: {p}")
                    print(f"  Company Name: {settings.get('company_company_name')}")
                    print(f"  Enable Pwd: {settings.get('company_enable_pwd')}")
                    print(f"  Admin User: {settings.get('company_username')} / Pwd: {settings.get('company_password')}")
                    print(f"  Users in users table: {users}")
                    conn.close()
                except Exception as e:
                    print(f"FILE: {p} -> Error: {e}")
