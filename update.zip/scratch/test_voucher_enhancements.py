import os
import sys
sys.path.insert(0, os.path.abspath("."))
import tkinter as tk
from tkinter import messagebox
from PIL import ImageGrab
import bookkeeper
import db

db_file = r"C:\Users\hk546\OneDrive\Desktop\bookkeeper.db"
if os.path.exists(db_file):
    db.set_db_path(db_file)

app = bookkeeper.BookKeeperApp()
app.withdraw()

# Open Sales Invoice
app._open_create_voucher("sale")
app.update()

toplevels = [w for w in app.winfo_children() if isinstance(w, tk.Toplevel)]
sale_win = next((w for w in toplevels if "Sales Invoice" in w.title()), None)
if not sale_win:
    print("Error: Sales Invoice window not found")
    sys.exit(1)

# 1. Check Terms & Conditions vs Narration
terms_found = False
narration_found = False
for child in sale_win.winfo_children():
    for sub in child.winfo_children():
        for s in sub.winfo_children():
            if isinstance(s, tk.Label) and "Terms & Conditions" in s.cget("text"):
                terms_found = True
            if isinstance(s, tk.Label) and "Narration" in s.cget("text"):
                narration_found = True

print("Terms & Conditions present?:", terms_found)
print("Narration present?:", narration_found)

# 2. Find Item Search Entry
item_search_entry = None
for w in sale_win.winfo_children():
    for child in w.winfo_children():
        if isinstance(child, tk.Entry) and child.cget("width") == 34:
            item_search_entry = child
            break

print("Found item search entry:", item_search_entry)

# 3. Add an item from database
items = db.get_all_items()
test_item = items[0]["name"] if items else "op"
print(f"Adding test item: {test_item}")

item_search_entry.focus_set()
item_search_entry.delete(0, "end")
item_search_entry.insert(0, test_item)
item_search_entry.event_generate("<Return>")
app.update()

# 4. Check Grid Scrollbar visibility with 1 item
grid_vsbs = [w for w in sale_win.winfo_children() for sub in w.winfo_children() if isinstance(sub, tk.ttk.Scrollbar) or isinstance(sub, tk.Scrollbar)]
print(f"Found {len(grid_vsbs)} scrollbar widgets.")
for vsb in grid_vsbs:
    print("Scrollbar is mapped with 1 item?:", vsb.winfo_ismapped())

# 5. Check Enter Key Traversal
# Item addition should have focused QTY
current_focus = sale_win.focus_get()
print("Focus after adding item:", current_focus)

# Press Enter on QTY -> should go to Unit
current_focus.event_generate("<Return>")
app.update()
focus_after_qty = sale_win.focus_get()
print("Focus after Enter on QTY:", focus_after_qty)

# Press Enter on Unit -> should go to Rate
focus_after_qty.event_generate("<Return>")
app.update()
focus_after_unit = sale_win.focus_get()
print("Focus after Enter on Unit:", focus_after_unit)

# Press Enter on Rate -> should go to Per
focus_after_unit.event_generate("<Return>")
app.update()
focus_after_rate = sale_win.focus_get()
print("Focus after Enter on Rate:", focus_after_rate)

# Press Enter on Per -> should go to Disc or Desc
focus_after_rate.event_generate("<Return>")
app.update()
focus_after_per = sale_win.focus_get()
print("Focus after Enter on Per:", focus_after_per)

# Press Enter on Disc -> should go to Tax
focus_after_per.event_generate("<Return>")
app.update()
focus_after_disc = sale_win.focus_get()
print("Focus after Enter on Disc:", focus_after_disc)

# Press Enter on Tax -> should go to Description
focus_after_disc.event_generate("<Return>")
app.update()
focus_after_tax = sale_win.focus_get()
print("Focus after Enter on Tax (Description):", focus_after_tax)

# 6. Test Description Enter asking "Add more item/service?" and refocusing F9 Item
dialog_asked = []
original_askyesno = messagebox.askyesno

def mock_askyesno(title, message, **kwargs):
    dialog_asked.append((title, message))
    print(f"Dialog prompt captured: Title='{title}', Message='{message}'")
    return True # User clicks YES

messagebox.askyesno = mock_askyesno

focus_after_tax.event_generate("<Return>")
app.update()

focus_after_yes = sale_win.focus_get()
print("Focus after clicking YES on dialog:", focus_after_yes)
print("Is focus back on F9 Item Search Entry?:", focus_after_yes == item_search_entry)

messagebox.askyesno = original_askyesno

# Take screenshot of the entire Sales Invoice window
sx = sale_win.winfo_rootx()
sy = sale_win.winfo_rooty()
sw = sale_win.winfo_width()
sh = sale_win.winfo_height()
img = ImageGrab.grab(bbox=(sx, sy, sx + sw, sy + sh))
img.save("scratch/test_voucher_enhancements_result.png")
print("Saved screenshot to scratch/test_voucher_enhancements_result.png")

app.destroy()
print("All automated verification tests passed successfully!")
