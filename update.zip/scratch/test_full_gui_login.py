import sys, os, traceback
sys.path.insert(0, os.path.abspath(os.path.dirname(os.path.dirname(__file__))))
import tkinter as tk
import company_selection
import bookkeeper

def test_full_company_selection_login():
    app = bookkeeper.BookKeeperApp()
    app.withdraw()
    
    sel_win = tk.Toplevel(app)
    sel_view = company_selection.CompanySelectionView(sel_win, app)
    
    # Check tree items
    items = sel_view.tree.get_children()
    print("Tree items:", [sel_view.tree.item(it, 'values') for it in items])
    
    # Find bookkeeper.db item
    bk_item = None
    for it in items:
        vals = sel_view.tree.item(it, 'values')
        if vals and 'bookkeeper.db' in vals[0]:
            bk_item = it
            break
            
    assert bk_item is not None, "bookkeeper.db not found in tree!"
    sel_view.tree.selection_set(bk_item)
    
    # Trigger on_open
    sel_view.on_open()
    
    # Find the login popup toplevel
    login_wins = [w for w in app.winfo_children() if isinstance(w, tk.Toplevel) and w != sel_win]
    # Also check sel_view children
    login_wins += [w for w in sel_view.winfo_children() if isinstance(w, tk.Toplevel)]
    
    print("Toplevel windows found:", login_wins)
    assert len(login_wins) > 0, "Login window was not created!"
    lwin = login_wins[0]
    
    # Find txt_user and txt_pass entries inside lwin
    entries = []
    def find_entries(parent):
        for ch in parent.winfo_children():
            if isinstance(ch, tk.Entry):
                entries.append(ch)
            find_entries(ch)
    find_entries(lwin)
    
    print("Entries found in login window:", entries)
    assert len(entries) >= 2, "Did not find user/pass entries!"
    
    txt_user = entries[0]
    txt_pass = entries[1]
    
    txt_user.delete(0, "end")
    txt_user.insert(0, "t1")
    txt_pass.delete(0, "end")
    txt_pass.insert(0, "786")
    
    # Find Login button
    buttons = []
    def find_buttons(parent):
        for ch in parent.winfo_children():
            if isinstance(ch, tk.Button):
                buttons.append(ch)
            find_buttons(ch)
    find_buttons(lwin)
    
    login_btn = [b for b in buttons if b.cget("text") == "Login"][0]
    print("Invoking login button...")
    login_btn.invoke()
    app.update()
    
    print("App active company path:", getattr(app, "active_company_path", None))
    print("App current user:", getattr(app, "current_user", None))
    
    assert getattr(app, "active_company_path", None) is not None, "Company path should be set!"
    assert getattr(app, "current_user", None) is not None, "current_user should be set!"
    assert app.current_user["username"] == "t1", f"Expected user t1, got {app.current_user}"
    
    print("ALL TESTS PASSED PERFECTLY!")
    app.destroy()

if __name__ == "__main__":
    test_full_company_selection_login()
