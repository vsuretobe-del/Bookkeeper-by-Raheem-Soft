import tkinter as tk
from PIL import ImageGrab
import datetime

class TestDateLayout(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Test Date Layout")
        self.geometry("1100x600")
        self.configure(bg="#ffffff")

        self.canvas = tk.Canvas(self, bg="#ffffff", height=380, highlightthickness=0)
        self.canvas.pack(fill="both", expand=True, padx=20, pady=20)

        # Dates in Pakistani format (DD/MM/YYYY)
        self.raw_dates = [
            "2023-01-01", "2026-05-13", "2026-07-12", "2026-07-14", "2026-07-15",
            "2026-07-17", "2026-07-18", "2026-07-19", "2026-07-21", "2026-07-22",
            "2026-07-23", "2026-07-24", "2026-07-25", "2026-07-31", "2026-08-01"
        ]

        def to_pakistani_date(d_str):
            for fmt in ('%Y-%m-%d', '%B %d, %Y', '%b %d, %Y', '%d-%m-%Y', '%d/%m/%Y'):
                try:
                    dt = datetime.datetime.strptime(d_str.strip(), fmt)
                    return dt.strftime('%d/%m/%Y')
                except:
                    pass
            return d_str

        self.pak_dates = [to_pakistani_date(d) for d in self.raw_dates]

    def draw(self):
        c = self.canvas
        c.delete("all")
        W = 1060
        H = 380

        padL, padR, padT, padB = 110, 40, 30, 95
        cW = W - padL - padR
        cH = H - padT - padB

        # Draw chart border
        c.create_rectangle(padL, padT, padL + cW, padT + cH, outline="#cbd5e1", fill="#fafafa")

        # Fake Y ticks
        ticks = [150000, 100000, 50000, 0, -50000]
        rng = 200000
        max_v = 150000

        def py(v):
            return padT + ((max_v - v) / rng) * cH

        for t in ticks:
            y = py(t)
            c.create_line(padL, y, padL + cW, y, fill="#e2e8f0" if t != 0 else "#94a3b8")
            c.create_text(padL - 10, y, text=f"Rs {t:,.0f}", anchor="e", font=("Segoe UI", 9, "bold" if t == 0 else "normal"), fill="#334155")

        n = len(self.pak_dates)
        # We can add an X inset so the first and last points aren't squashed directly against the wall
        x_inset = max(18, int(cW / n * 0.4))
        plot_w = cW - 2 * x_inset

        def px(i):
            return padL + x_inset + (i / (n - 1)) * plot_w if n > 1 else padL + cW / 2

        # Draw dates
        for i, dt in enumerate(self.pak_dates):
            x = px(i)
            # Grid tick
            c.create_line(x, padT + cH - 3, x, padT + cH + 4, fill="#64748b", width=1.2)

            # Date text angled nicely at 315° (slanted) or 45°
            # With anchor="ne", angle=315:
            # Let's test anchor="ne", y = padT + cH + 8
            c.create_text(x + 2, padT + cH + 8, text=dt, anchor="ne", font=("Segoe UI", 8, "bold"), angle=315, fill="#1e293b")

        # Title
        c.create_text(W/2, 14, text="Daily Cash Flow - Pakistani Date Format (DD/MM/YYYY)", font=("Segoe UI", 12, "bold"), fill="#0f172a")

if __name__ == "__main__":
    app = TestDateLayout()
    app.update()
    app.update_idletasks()
    app.draw()
    app.update()

    x = app.winfo_rootx()
    y = app.winfo_rooty()
    w = app.winfo_width()
    h = app.winfo_height()
    img = ImageGrab.grab(bbox=(x, y, x + w, y + h))
    img.save("scratch/test_date_layout_preview.png")
    print("Saved to scratch/test_date_layout_preview.png")
    app.destroy()
