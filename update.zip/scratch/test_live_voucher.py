import os
import sys
sys.path.insert(0, os.path.abspath("."))
import tkinter as tk
from PIL import ImageGrab
import bookkeeper
import db

db_file = r"C:\Users\hk546\OneDrive\Desktop\bookkeeper.db"
if os.path.exists(db_file):
    db.set_db_path(db_file)

app = bookkeeper.BookKeeperApp()
app.withdraw()

# 1. Open Sales Invoice
app._open_create_voucher("sale")
app.update()

# 2. Open Purchase Order (multiple windows test)
app._open_create_voucher("purchase_order")
app.update()

toplevels = [w for w in app.winfo_children() if isinstance(w, tk.Toplevel)]
print(f"Total open toplevel windows: {len(toplevels)}")
for t in toplevels:
    print(f" - Window title: {t.title()}")

# Find the Sales Invoice window
sale_win = next((w for w in toplevels if "Sales Invoice" in w.title()), None)
if not sale_win:
    print("Sales invoice window not found!")
    sys.exit(1)

# Find item entry in sale_win
entry = None
for w in sale_win.winfo_children():
    for child in w.winfo_children():
        if isinstance(child, tk.Entry) and child.cget("width") == 34:
            entry = child
            break

print("Found entry widget:", entry)

if entry:
    # Test Autocomplete Dropdown
    entry.focus_set()
    entry.delete(0, "end")
    entry.insert(0, "Lap")
    entry.event_generate("<KeyRelease>", keysym="p")
    app.update()
    app.update_idletasks()

    # Capture dropdown screenshot
    sx = sale_win.winfo_rootx()
    sy = sale_win.winfo_rooty()
    sw = sale_win.winfo_width()
    sh = sale_win.winfo_height()
    img = ImageGrab.grab(bbox=(sx, sy, sx + sw, sy + sh))
    img.save("scratch/test_live_dropdown_visible.png")
    print("Saved dropdown screenshot to scratch/test_live_dropdown_visible.png")

    # Test creating item without closing any voucher windows
    app._item_form(initial_name="New Test Product 123", callback=lambda name: print(f"Item created callback: {name}"), parent=sale_win)
    app.update()

    current_toplevels = [w for w in app.winfo_children() if isinstance(w, tk.Toplevel)]
    print(f"Open windows with Create Item form active: {len(current_toplevels)}")
    for t in current_toplevels:
        print(f" * Active window: {t.title()}")

    # Find and close create item window
    item_form = next((w for w in current_toplevels if "Inventory Item" in w.title()), None)
    if item_form:
        item_form.destroy()
        app.update()

    final_toplevels = [w for w in app.winfo_children() if isinstance(w, tk.Toplevel)]
    print(f"Open windows after closing Create Item form: {len(final_toplevels)}")
    for t in final_toplevels:
        print(f" -> Preserved window: {t.title()}")

app.destroy()
print("All live voucher tests finished successfully!")
