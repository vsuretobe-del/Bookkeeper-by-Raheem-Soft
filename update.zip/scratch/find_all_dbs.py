import os, glob, sqlite3

candidates = [
    r'c:\Users\hk546\Downloads\Book Keeper\bookkeeper.db',
    r'C:\Users\hk546\OneDrive\Desktop\bookkeeper.db',
    r'C:\Users\hk546\Desktop\bookkeeper.db',
    r'C:\Users\hk546\Documents\bookkeeper.db',
    r'C:\Users\hk546\Dropbox\bookkeeper.db',
    r'c:\Users\hk546\Downloads\bookkeeper.db',
]

for p in candidates:
    if os.path.exists(p):
        try:
            conn = sqlite3.connect(p)
            conn.row_factory = sqlite3.Row
            c = conn.cursor()
            u_cnt = c.execute("SELECT count(*) as c FROM users").fetchone()['c']
            users = [dict(r) for r in c.execute("SELECT id, username, password FROM users").fetchall()]
            settings = dict(c.execute("SELECT key, value FROM app_settings WHERE key LIKE 'company_%'").fetchall())
            print(f"FOUND: {os.path.abspath(p)}")
            print(f"  Settings: {settings}")
            print(f"  Users ({u_cnt}): {users}")
            conn.close()
        except Exception as e:
            print(f"FOUND: {os.path.abspath(p)} -> Error: {e}")
