with open('bookkeeper.py', 'r', encoding='utf-8') as f:
    content = f.read()

content = content.replace('text="? Ctrl+Q: Exit"', 'text="[X] Ctrl+Q: Exit"')
content = content.replace('text="? F2: New Unit Of Measure"', 'text="[+] F2: New Unit Of Measure"')
content = content.replace('text="? Ctrl+Q: Exit"', 'text="[X] Ctrl+Q: Exit"')
content = content.replace('text="? F2: New Unit Of Measure"', 'text="[+] F2: New Unit Of Measure"')
content = content.replace('text="?? Ctrl+Q: Exit"', 'text="[X] Ctrl+Q: Exit"')
content = content.replace('text="?? F2: New Unit Of Measure"', 'text="[+] F2: New Unit Of Measure"')

with open('bookkeeper.py', 'w', encoding='utf-8') as f:
    f.write(content)
print("Replaced emoji with ASCII")
