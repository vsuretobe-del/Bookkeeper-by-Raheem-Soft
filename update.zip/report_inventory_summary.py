import tkinter as tk
from tkinter import ttk, messagebox
import db
import datetime
from autocomplete import AutocompleteCombobox

# Define Colors & Fonts (Standardized)
BLUE = "#2B548F"
WHITE = "#FFFFFF"
GRAY = "#EFEFEF"
DARK_GRAY = "#808080"
BLACK = "#000000"

FONT = ("Segoe UI", 10)
FONT_BOLD = ("Segoe UI", 10, "bold")
TITLE_FONT = ("Segoe UI", 14, "bold")

class InventorySummaryView(tk.Toplevel):
    def __init__(self, master_app):
        super().__init__(master_app)
        self.master_app = master_app
        self.title("Inventory Summary")
        self.state("zoomed")
        self.configure(bg=WHITE)
        self.geometry("1024x768")

        self.start_date = datetime.date(datetime.date.today().year, 1, 1).strftime("%Y-%m-%d")
        self.end_date = datetime.date.today().strftime("%Y-%m-%d")

        self.build_ui()
        self.populate_filters()
        self.load_data()

    def build_ui(self):
        # Top Toolbar
        toolbar = tk.Frame(self, bg=WHITE, relief="raised", bd=1)
        toolbar.pack(side="top", fill="x")
        
        btn_exit = tk.Button(toolbar, text="✕ Ctrl+Q: Exit", font=FONT, bg=WHITE, relief="flat", command=self.destroy)
        btn_exit.pack(side="left", padx=5, pady=2)
        
        btn_print = tk.Button(toolbar, text="🖨 Alt+P: Print", font=FONT, bg=WHITE, relief="flat")
        btn_print.pack(side="left", padx=5, pady=2)
        
        btn_word = tk.Button(toolbar, text="W Ctrl+W: Open In MS Word", font=FONT, bg=WHITE, relief="flat")
        btn_word.pack(side="left", padx=5, pady=2)

        # Main Layout
        self.paned = tk.PanedWindow(self, orient="horizontal", bg=WHITE, sashwidth=5)
        self.paned.pack(fill="both", expand=True)

        # Left Panel
        self.left_panel = tk.Frame(self.paned, bg=BLUE, width=280)
        self.paned.add(self.left_panel, minsize=280)

        # Right Panel
        self.right_panel = tk.Frame(self.paned, bg=WHITE)
        self.paned.add(self.right_panel, stretch="always")

        self.build_left_panel()
        self.build_right_panel()

    def build_left_panel(self):
        canvas = tk.Canvas(self.left_panel, bg=BLUE, highlightthickness=0)
        scrollbar = ttk.Scrollbar(self.left_panel, orient="vertical", command=canvas.yview)
        
        self.f = tk.Frame(canvas, bg=BLUE)
        self.f.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=self.f, anchor="nw", width=260)
        canvas.configure(yscrollcommand=scrollbar.set)
        
        # Mousewheel scrolling
        def _on_mousewheel(event):
            canvas.yview_scroll(int(-1*(event.delta/120)), "units")
        canvas.bind_all("<MouseWheel>", _on_mousewheel)
        
        canvas.pack(side="left", fill="both", expand=True, padx=(10, 0), pady=10)
        scrollbar.pack(side="right", fill="y")
        
        f = self.f

        # Dates
        tk.Label(f, text="F2: Start Date:", bg=BLUE, fg=WHITE, font=FONT).pack(anchor="w")
        self.cb_start = AutocompleteCombobox(f, font=FONT, values=[self.start_date])
        self.cb_start.set(self.start_date)
        self.cb_start.pack(fill="x", pady=(0, 5))

        tk.Label(f, text="End date:", bg=BLUE, fg=WHITE, font=FONT).pack(anchor="w")
        self.cb_end = AutocompleteCombobox(f, font=FONT, values=[self.end_date])
        self.cb_end.set(self.end_date)
        self.cb_end.pack(fill="x", pady=(0, 5))

        self.create_cat = tk.IntVar(value=0)
        tk.Checkbutton(f, text="Create Product Catalogue", variable=self.create_cat, bg=BLUE, fg=WHITE, selectcolor=BLUE, font=FONT).pack(anchor="w", pady=(0,5))

        # Cat / Subcat
        tk.Label(f, text="Item Category", bg=BLUE, fg=WHITE, font=FONT).pack(anchor="w")
        self.cb_cat = AutocompleteCombobox(f, font=FONT, state="readonly", values=["ALL"])
        self.cb_cat.set("ALL")
        self.cb_cat.pack(fill="x", pady=(0, 5))

        tk.Label(f, text="Item Subcategory", bg=BLUE, fg=WHITE, font=FONT).pack(anchor="w")
        self.cb_subcat = AutocompleteCombobox(f, font=FONT, state="readonly", values=["ALL"])
        self.cb_subcat.set("ALL")
        self.cb_subcat.pack(fill="x", pady=(0, 15))

        # Quantity Filter
        self.apply_qty = tk.IntVar(value=0)
        tk.Checkbutton(f, text="Apply Quantity Filter", variable=self.apply_qty, bg=BLUE, fg=WHITE, selectcolor=BLUE, font=FONT_BOLD).pack(anchor="w", pady=(0,5))

        qty_fr = tk.Frame(f, bg=BLUE)
        qty_fr.pack(fill="x", padx=20)
        
        self.qty_mode = tk.StringVar(value="items")
        tk.Radiobutton(qty_fr, text="About To Finish", variable=self.qty_mode, value="about", bg=BLUE, fg=WHITE, selectcolor=BLUE, font=FONT).pack(anchor="w")
        tk.Radiobutton(qty_fr, text="Items Having Units", variable=self.qty_mode, value="items", bg=BLUE, fg=WHITE, selectcolor=BLUE, font=FONT).pack(anchor="w")
        
        qty_sub = tk.Frame(qty_fr, bg=BLUE)
        qty_sub.pack(fill="x", padx=20)
        self.qty_cmp = AutocompleteCombobox(qty_sub, font=FONT, width=12, state="readonly", values=["Less Than", "Equal To", "Greater Than"])
        self.qty_cmp.set("Less Than")
        self.qty_cmp.pack(side="left")
        self.qty_val = tk.Entry(qty_sub, font=FONT, width=5)
        self.qty_val.insert(0, "11")
        self.qty_val.pack(side="left", padx=5)

        # Dynamic Checkboxes
        self.chk_vars = {}
        opts = [
            ("Show Item Image?", 0),
            ("Display SKU", 0),
            ("Display Barcode", 0),
            ("Display Units Left, Rate and Value", 1),
            ("Display Item Description", 0),
            ("Display Default Discount", 0),
            ("Display Default Tax", 0),
            ("Display Descriptive Units", 0),
        ]
        
        for text, def_val in opts:
            var = tk.IntVar(value=def_val)
            self.chk_vars[text] = var
            tk.Checkbutton(f, text=text, variable=var, bg=BLUE, fg=WHITE, selectcolor=BLUE, font=FONT).pack(anchor="w")

        # Sale Price
        self.disp_sp = tk.IntVar(value=0)
        tk.Checkbutton(f, text="Display Default Sale Price", variable=self.disp_sp, bg=BLUE, fg=WHITE, selectcolor=BLUE, font=FONT).pack(anchor="w")
        sp_fr = tk.Frame(f, bg=BLUE)
        sp_fr.pack(fill="x", padx=30)
        self.sp_inc = tk.StringVar(value="ex")
        tk.Radiobutton(sp_fr, text="(Inc-Tax)", variable=self.sp_inc, value="inc", bg=BLUE, fg=WHITE, selectcolor=BLUE, font=FONT).pack(side="left")
        tk.Radiobutton(sp_fr, text="(Ex-Tax)", variable=self.sp_inc, value="ex", bg=BLUE, fg=WHITE, selectcolor=BLUE, font=FONT).pack(side="left")

        # Purchase Price
        self.disp_pp = tk.IntVar(value=0)
        tk.Checkbutton(f, text="Display Default Purchase Price", variable=self.disp_pp, bg=BLUE, fg=WHITE, selectcolor=BLUE, font=FONT).pack(anchor="w")
        pp_fr = tk.Frame(f, bg=BLUE)
        pp_fr.pack(fill="x", padx=30)
        self.pp_inc = tk.StringVar(value="ex")
        tk.Radiobutton(pp_fr, text="(Inc-Tax)", variable=self.pp_inc, value="inc", bg=BLUE, fg=WHITE, selectcolor=BLUE, font=FONT).pack(side="left")
        tk.Radiobutton(pp_fr, text="(Ex-Tax)", variable=self.pp_inc, value="ex", bg=BLUE, fg=WHITE, selectcolor=BLUE, font=FONT).pack(side="left")

        self.disp_inout = tk.IntVar(value=0)
        tk.Checkbutton(f, text="Display Inward/Outward Quantity", variable=self.disp_inout, bg=BLUE, fg=WHITE, selectcolor=BLUE, font=FONT).pack(anchor="w")

        # Accounts
        tk.Label(f, text="Account Name", bg=BLUE, fg=WHITE, font=FONT).pack(anchor="w")
        self.cb_account = AutocompleteCombobox(f, font=FONT, values=["ALL"])
        self.cb_account.set("ALL")
        self.cb_account.pack(fill="x", pady=(0, 5))

        self.disp_active = tk.IntVar(value=0)
        tk.Checkbutton(f, text="Display Only Active Items", variable=self.disp_active, bg=BLUE, fg=WHITE, selectcolor=BLUE, font=FONT).pack(anchor="w")

        self.disp_less_used = tk.IntVar(value=0)
        tk.Checkbutton(f, text="Display Less Used Items", variable=self.disp_less_used, bg=BLUE, fg=WHITE, selectcolor=BLUE, font=FONT).pack(anchor="w", pady=(0, 15))

        btn_display = tk.Button(f, text="Display", bg="#1C3D6D", fg=WHITE, font=FONT_BOLD, relief="flat", command=self.load_data)
        btn_display.pack(fill="x", pady=(0, 20))

    def build_right_panel(self):
        # Header Info
        header_f = tk.Frame(self.right_panel, bg=WHITE, pady=10, padx=10)
        header_f.pack(fill="x")
        
        c_name = self.master_app.company_name if hasattr(self.master_app, 'company_name') else "Company Name"
        
        tk.Label(header_f, text=c_name, bg=WHITE, fg=BLUE, font=TITLE_FONT).pack(anchor="w")
        tk.Label(header_f, text="Inventory Summary", bg=WHITE, fg=BLACK, font=("Segoe UI", 12, "bold")).pack(anchor="w")
        tk.Label(header_f, text=f"{self.start_date} To {self.end_date}", bg=WHITE, fg=BLACK, font=FONT).pack(anchor="w")

        # Treeview frame
        self.tree_f = tk.Frame(self.right_panel, bg=WHITE)
        self.tree_f.pack(fill="both", expand=True, padx=10, pady=(0,10))
        
        self.tree = None

    def populate_filters(self):
        conn = db.get_conn()
        try:
            acc = conn.execute("SELECT name FROM account_detail ORDER BY name").fetchall()
            self.cb_account['values'] = ["ALL"] + [r['name'] for r in acc]
            
            cats = conn.execute("SELECT name FROM item_category ORDER BY name").fetchall()
            self.cb_cat['values'] = ["ALL"] + [r['name'] for r in cats]
        except Exception as e:
            print("Error loading filters:", e)
        finally:
            conn.close()

    def load_data(self):
        cat = self.cb_cat.get().strip()
        subcat = self.cb_subcat.get().strip()
        
        qty_filter = None
        qty_val = None
        
        if self.apply_qty.get():
            mode = self.qty_mode.get()
            if mode == 'about':
                qty_filter = 'about_to_finish'
            else:
                cmp_map = {"Less Than": "less_than", "Equal To": "equal_to", "Greater Than": "greater_than"}
                qty_filter = cmp_map.get(self.qty_cmp.get())
                try: qty_val = float(self.qty_val.get())
                except: qty_val = 0.0

        try:
            results = db.get_inventory_summary_data(
                start_date=self.cb_start.get(),
                end_date=self.cb_end.get(),
                category=cat,
                subcategory=subcat,
                qty_filter=qty_filter,
                qty_val=qty_val,
                account_name=self.cb_account.get(),
                only_active=self.disp_active.get(),
                less_used=self.disp_less_used.get()
            )
        except Exception as e:
            import traceback
            traceback.print_exc()
            messagebox.showerror("Error", f"Failed to fetch inventory summary:\n{e}")
            return

        self.build_treeview()

        # Group by category
        groups = {}
        for r in results:
            groups.setdefault(r['category'].upper(), []).append(r)
            
        grand_qty = 0
        grand_val = 0
        
        for c_name, items in groups.items():
            self.tree.insert("", "end", values=(c_name), tags=("header"))
            
            stripe = "stripe1"
            for t in items:
                v = []
                v.append("    " + t['item_name']) # Indent item name slightly
                if self.chk_vars["Display SKU"].get(): v.append(t['sku'])
                if self.chk_vars["Display Barcode"].get(): v.append(t['barcode'])
                if self.chk_vars["Display Item Description"].get(): v.append(t['desc'])
                if self.disp_inout.get():
                    v.append(f"{t['inward_qty']:g}")
                    v.append(f"{t['outward_qty']:g}")
                if self.chk_vars["Display Units Left, Rate and Value"].get():
                    v.append(f"{t['closing_qty']:g}")
                    if self.chk_vars["Display Descriptive Units"].get():
                        v.append(t['unit'])
                    else:
                        v.append(t['unit'])
                    v.append(f"{t['avg_cost']:,.2f}")
                    v.append(f"{t['value']:,.2f}")
                if self.chk_vars["Display Default Discount"].get(): v.append(f"{t['def_disc']:,.2f}")
                if self.chk_vars["Display Default Tax"].get(): v.append(t['def_tax'])
                if self.disp_sp.get(): v.append(f"{t['def_sp']:,.2f}")
                if self.disp_pp.get(): v.append(f"{t['def_pp']:,.2f}")

                self.tree.insert("", "end", values=v, tags=(stripe))
                stripe = "stripe2" if stripe == "stripe1" else "stripe1"
                
                grand_qty += t['closing_qty']
                grand_val += t['value']

        # Totals
        bot_vals = ["TOTAL VALUE"]
        # Padding empty values until the last columns
        pad_len = len(self.tree["columns"]) - 3
        if pad_len > 0:
            for i in range(pad_len - 1):
                bot_vals.append("")
            
        if self.chk_vars["Display Units Left, Rate and Value"].get():
            bot_vals.append(f"{grand_qty:g}")
            bot_vals.append("")
            bot_vals.append(f"Rs{grand_val:,.2f}")
            
        self.tree.insert("", "end", values=bot_vals, tags=("grand"))

    def build_treeview(self):
        # Clear existing treeview and scrollbars to prevent duplication
        for widget in self.tree_f.winfo_children():
            widget.destroy()
        
        self.tree = None            
        cols = ["ITEM"]
        if self.chk_vars["Display SKU"].get(): cols.append("SKU")
        if self.chk_vars["Display Barcode"].get(): cols.append("BARCODE")
        if self.chk_vars["Display Item Description"].get(): cols.append("DESCRIPTION")
        if self.disp_inout.get():
            cols.append("INWARD QTY")
            cols.append("OUTWARD QTY")
        if self.chk_vars["Display Units Left, Rate and Value"].get():
            cols.append("NO. OF UNITS")
            cols.append("UOM")
            cols.append("RATE PER UNIT")
            cols.append("VALUE")
        if self.chk_vars["Display Default Discount"].get(): cols.append("DISCOUNT")
        if self.chk_vars["Display Default Tax"].get(): cols.append("TAX")
        if self.disp_sp.get(): cols.append("SALE PRICE")
        if self.disp_pp.get(): cols.append("PURCHASE PRICE")

        self.tree = ttk.Treeview(self.tree_f, columns=cols, show="headings", height=20, selectmode="none")
        
        for c in cols:
            self.tree.heading(c, text=c)
            if c in ["ITEM", "DESCRIPTION"]:
                self.tree.column(c, width=200, minwidth=200, anchor="w", stretch=False)
            elif c in ["NO. OF UNITS", "RATE PER UNIT", "VALUE", "SALE PRICE", "PURCHASE PRICE"]:
                self.tree.column(c, width=100, minwidth=100, anchor="e", stretch=False)
            else:
                self.tree.column(c, width=100, minwidth=100, anchor="center", stretch=False)

        def disable_resize(event):
            if self.tree.identify_region(event.x, event.y) == "separator":
                return "break"
        self.tree.bind('<Button-1>', disable_resize)
        self.tree.bind('<B1-Motion>', disable_resize)
        style = ttk.Style()
        style.configure("Treeview", font=FONT, rowheight=25)
        style.configure("Treeview.Heading", font=FONT_BOLD)
        
        FONT_ITALIC = ("Segoe UI", 10, "italic")
        
        self.tree.tag_configure("header", font=FONT_ITALIC, foreground=DARK_GRAY)
        self.tree.tag_configure("grand", font=FONT_BOLD, background=WHITE)
        self.tree.tag_configure("stripe1", background="#F9F9F9")
        self.tree.tag_configure("stripe2", background=WHITE)

        ysb = ttk.Scrollbar(self.tree_f, orient="vertical", command=self.tree.yview)
        xsb = ttk.Scrollbar(self.tree_f, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscroll=ysb.set, xscroll=xsb.set)

        ysb.pack(side="right", fill="y")
        xsb.pack(side="bottom", fill="x")
        self.tree.pack(fill="both", expand=True)

if __name__ == "__main__":
    root = tk.Tk()
    root.withdraw()
    app = InventorySummaryView(root)
    app.mainloop()
