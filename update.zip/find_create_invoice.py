with open('bookkeeper.py', 'r', encoding='utf-8') as f:
    lines = f.readlines()
for i, line in enumerate(lines):
    if "create_invoice" in line:
        print(f"Found at line {i+1}: {line.strip()}")
