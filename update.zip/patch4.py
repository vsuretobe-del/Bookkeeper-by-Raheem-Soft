import re
from autocomplete import AutocompleteCombobox

with open('bookkeeper.py', 'r', encoding='utf-8') as f:
    content = f.read()

new_form = '''    def _generic_account_form(self, existing=None):
        win = tk.Toplevel(self)
        win.title("Create Account" if not existing else "Edit Account")
        win.geometry("600x650")
        win.resizable(False, False)
        win.configure(bg="#ffffff")
        win.grab_set()

        tk.Label(win, text="Press ENTER to move forward  SHIFT+ENTER to move back.", 
                 fg="darkred", bg="#ffffff", font=(FONT[0], 10, "italic", "bold")).place(x=10, y=5)

        fields = {}
        widgets = []

        def register_widget(w):
            widgets.append(w)
            w.bind("<Return>", lambda e: focus_next(w))
            w.bind("<Shift-Return>", lambda e: focus_prev(w))
            return w

        def focus_next(current):
            try:
                idx = widgets.index(current)
                widgets[(idx + 1) % len(widgets)].focus_set()
            except: pass
            return "break"

        def focus_prev(current):
            try:
                idx = widgets.index(current)
                widgets[(idx - 1) % len(widgets)].focus_set()
            except: pass
            return "break"

        def create_lbl(x, y, text):
            tk.Label(win, text=text, bg="#ffffff", fg="#000", font=FONT).place(x=x, y=y)

        def create_entry(x, y, w, bg="#ffffff"):
            e = tk.Entry(win, font=FONT, width=w, relief="solid", bd=1, bg=bg)
            e.place(x=x, y=y)
            return register_widget(e)
            
        def create_combo(x, y, w, vals, bg="#ffffff"):
            # AutocompleteCombobox doesnt easily support bg color, so we might just use default.
            # but we can try to style it or just use standard.
            c = AutocompleteCombobox(win, font=FONT, width=w-2, values=vals)
            c.place(x=x, y=y)
            return register_widget(c)

        cx1, cx2 = 10, 300

        # Col 1
        create_lbl(cx1, 35, "Account Name")
        fields['aname'] = create_entry(cx1, 55, 28)
        
        tk.Label(win, text="Video: How to Create Group/Subgroup?", fg="blue", bg="#ffffff", font=(FONT[0], 9, "underline")).place(x=cx1, y=85)
        
        create_lbl(cx1, 110, "Account Type")
        
        account_types = [
            "Cash-in-hand", "Bank A/Cs", "Sundry Debtors", "Sundry Creditors", 
            "Purchases A/C", "Purchases Return", "Sales A/C", "Sales Return", 
            "Capital A/C", "Direct Expenses", "Indirect Expenses", "Direct Income", 
            "Indirect Income", "Current Assets", "Current Liabilities", "Misc. Expenses", 
            "Misc. Income", "Loans (Liability)", "Loans & Advances", "Fixed Assets", 
            "Investments", "Bank OD A/C", "Deposits (Assets)", "Provisions", "Reserves & Surplus"
        ]
        
        fields['account_group'] = create_combo(cx1, 130, 28, account_types) # Maps to account_group in db
        
        create_lbl(cx1, 160, "Opening balance")
        fields['op_bal'] = create_entry(cx1, 180, 28)
        fields['op_bal'].insert(0, "0")

        # Col 2
        create_lbl(cx2, 35, "Display Name")
        fields['display_name'] = create_entry(cx2, 55, 25)
        
        create_lbl(cx2, 110, "Account Group")
        fields['subgroup'] = create_combo(cx2, 130, 25, []) # Not strictly needed
        
        create_lbl(cx2, 160, "Account Creation Date")
        if DateEntry:
            de = DateEntry(win, width=23, background='darkblue', foreground='white', borderwidth=2, font=FONT)
            de.place(x=cx2, y=180)
            fields['date_created'] = register_widget(de)
        else:
            fields['date_created'] = create_entry(cx2, 180, 25)
            fields['date_created'].insert(0, datetime.datetime.now().strftime("%B %d, %Y"))

        # Info text
        info_text = """Sundry Debtor : Customers/Clients
Sundry Creditor : Suppliers/Vendors

Loans(Liability) : Loans that company has borrowed
Loans & Advances : All loans & advances given by the company

Bank OD : Bank Overdraft
Deposits(Assets): Any deposit made by the company."""
        
        tk.Label(win, text=info_text, bg="#ffffff", fg="darkred", font=(FONT[0], 10), justify="left").place(x=cx1, y=350)

        if existing:
            for k, w in fields.items():
                if k in existing and existing[k] is not None:
                    if isinstance(w, tk.Entry):
                        w.delete(0, "end")
                        w.insert(0, str(existing[k]))
                    elif isinstance(w, AutocompleteCombobox):
                        w.set(str(existing[k]))

        def save(event=None):
            data = {}
            for k, w in fields.items():
                if k == 'subgroup': continue
                val = w.get() if hasattr(w, "get") else ""
                if isinstance(val, str): val = val.strip()
                data[k] = val

            if not data["aname"]:
                messagebox.showerror("Error", "Account Name is required!", parent=win)
                fields["aname"].focus_set()
                return
                
            try:
                if data.get("op_bal"): data["op_bal"] = float(data["op_bal"])
            except ValueError:
                messagebox.showerror("Error", "Opening Balance must be a number!", parent=win)
                return

            try:
                if existing:
                    db.update_account(existing["id"], data)
                else:
                    db.add_account(data)
                win.destroy()
                self._account_list(None, "All Accounts")
            except Exception as e:
                messagebox.showerror("Database Error", str(e), parent=win)

        win.bind("<Control-q>", lambda e: win.destroy())
        win.bind("<F12>", save)

        tk.Button(win, text="Ctrl+Q: Exit", bg="#e0e0e0", font=FONT, command=win.destroy, relief="solid", bd=1).place(x=10, y=605, width=120, height=30)
        tk.Button(win, text="F12:Save", bg="#e0e0e0", font=FONT, command=save, relief="solid", bd=1).place(x=450, y=605, width=120, height=30)
        
        fields["aname"].focus_set()
'''

# We need to add this method to the BookkeeperApp class, let's insert it before _edit_selected_account
end_str = "    def _edit_selected_account(self, tree, acc_type):"

if end_str in content:
    content = content.replace(end_str, new_form + "\\n" + end_str)

# Now we need to hook up the button for "New Account"
old_binding = '("?? Alt+A: New Account",       None),'
new_binding = '("?? Alt+A: New Account",       self._generic_account_form),'
content = content.replace(old_binding, new_binding)

# Actually the shortcut label might not have ??, it could be "Alt+A: New Account"
content = re.sub(r'\("([^"]*Alt\+A: New Account)",\s*None\)', r'("\1", self._generic_account_form)', content)

with open('bookkeeper.py', 'w', encoding='utf-8') as f:
    f.write(content)
print("Added generic account form")
