with open('bookkeeper.py', 'r', encoding='utf-8') as f:
    content = f.read()

target = '''            try:
                roff = float(round_var.get() or 0)
            except:
                roff = 0
            grand = tot + roff'''

replacement = '''            try:
                roff = float(round_var.get() or 0)
            except:
                roff = 0
            
            try:
                oc = other_charges_tot.get()
            except:
                oc = 0.0
                
            grand = tot + roff + oc'''

content = content.replace(target, replacement)

# 5. Fix save_voucher to use v_type instead of "sale"
t2 = '''            try:
                db.create_invoice(inv_no, "sale", acc_id, date_str,
                                  items, notes=nar_text.get("1.0", "end").strip())'''
r2 = '''            try:
                db.create_invoice(inv_no, v_type, acc_id, date_str,
                                  items, notes=nar_text.get("1.0", "end").strip())'''

content = content.replace(t2, r2)

t3 = '''                # Fetch full invoice data from DB
                invs = db.get_all_invoices("sale")'''
r3 = '''                # Fetch full invoice data from DB
                invs = db.get_all_invoices(v_type)'''

content = content.replace(t3, r3)

with open('bookkeeper.py', 'w', encoding='utf-8') as f:
    f.write(content)

print("Phase 2 Patch Applied!")
