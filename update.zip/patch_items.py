with open('bookkeeper.py', 'r', encoding='utf-8') as f:
    content = f.read()

target = '''            if view_after or print_receipt:
                # Fetch full invoice data from DB
                invs = db.get_all_invoices("sale")
                inv_data = next((i for i in invs if i["invoice_no"] == inv_no), None)
                if inv_data:
                    invoice_preview.show_invoice_preview(self, inv_data, db)'''

replacement = '''            if view_after or print_receipt:
                # Fetch full invoice data from DB
                invs = db.get_all_invoices("sale")
                inv_data = next((i for i in invs if i["invoice_no"] == inv_no), None)
                if inv_data:
                    inv_data['items'] = db.get_invoice_items(inv_data['id'])
                    invoice_preview.show_invoice_preview(self, inv_data, db)'''

if target in content:
    content = content.replace(target, replacement)
    with open('bookkeeper.py', 'w', encoding='utf-8') as f:
        f.write(content)
    print("Patch applied for items in save_voucher")
else:
    print("Target not found")
