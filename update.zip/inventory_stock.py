import tkinter as tk
from tkinter import ttk, messagebox
import db
import os

FONT = ("Segoe UI", 10)
FONT_BOLD = ("Segoe UI", 10, "bold")
FONT_TITLE = ("Segoe UI", 14, "bold")
BG = "#f0f0f0"
BG_WHITE = "#ffffff"
HIGHLIGHT_YELLOW = "#ffff00"
HIGHLIGHT_BLUE = "#0056b3"

class InventoryStockLevelWindow(tk.Toplevel):
    def __init__(self, master, app=None):
        super().__init__(master)
        self.app = app
        self.title("Inventory Stock Level")
        self.geometry("900x580")
        self.configure(bg=BG)
        self.grab_set()
        self.transient(master)

        self._build_ui()
        self._load_items()

        # Keyboard bindings
        self.bind("<Control-q>", lambda e: self.destroy())
        self.bind("<Control-Q>", lambda e: self.destroy())
        self.bind("<Escape>", lambda e: self.destroy())
        self.bind("<F12>", lambda e: self.destroy())
        self.bind("<Alt-F2>", lambda e: self._open_history())
        self.bind("<F3>", lambda e: self.ent_search.focus_set())

    def _build_ui(self):
        # 1. Top Search Frame
        top_fr = tk.Frame(self, bg=BG, padx=15, pady=10)
        top_fr.pack(fill="x")

        # Left controls
        left_ctrl = tk.Frame(top_fr, bg=BG)
        left_ctrl.pack(side="left", fill="x", expand=True)

        r1 = tk.Frame(left_ctrl, bg=BG)
        r1.pack(fill="x", pady=5)
        tk.Label(r1, text="Item:", font=FONT, bg=BG).pack(side="left", padx=(0, 10))
        self.v_search = tk.StringVar()
        self.ent_search = tk.Entry(r1, textvariable=self.v_search, font=FONT, width=60, relief="solid", bd=1)
        self.ent_search.pack(side="left", padx=5)
        self.ent_search.bind("<KeyRelease>", lambda e: self._load_items())
        self.ent_search.bind("<Return>", lambda e: self._on_enter_press())

        r2 = tk.Frame(left_ctrl, bg=BG)
        r2.pack(fill="x")
        self.lbl_history_link = tk.Label(r2, text="Alt+F2: Item History", font=("Segoe UI", 9, "underline"), fg="blue", bg=BG, cursor="hand2")
        self.lbl_history_link.pack(side="left", padx=(45, 10))
        self.lbl_history_link.bind("<Button-1>", lambda e: self._open_history())

        btn_search = tk.Button(r2, text="Search", font=FONT, bg="#e0e0e0", relief="solid", bd=1, width=15, command=self._load_items)
        btn_search.pack(side="right", padx=(0, 60))

        # Right image placeholder
        self.img_frame = tk.Label(top_fr, bg=BG_WHITE, relief="solid", bd=1, width=15, height=5)
        self.img_frame.pack(side="right", padx=10)

        # 2. Middle Notice Label
        tk.Label(self, text="Press Enter for more details.", font=("Segoe UI", 10, "bold", "italic"), fg="#8b0000", bg=BG, anchor="w").pack(fill="x", padx=15, pady=5)

        # 3. Treeview Table Frame
        tbl_frame = tk.Frame(self, bg=BG_WHITE, relief="solid", bd=1)
        tbl_frame.pack(fill="both", expand=True, padx=15, pady=(0, 10))

        style = ttk.Style()
        style.configure("Stock.Treeview", font=FONT, rowheight=28)
        style.configure("Stock.Treeview.Heading", font=FONT_BOLD)

        self.tree = ttk.Treeview(
            tbl_frame,
            columns=("item", "qty", "units", "rate", "value"),
            show="headings",
            style="Stock.Treeview"
        )
        self.tree.pack(fill="both", expand=True)

        self.tree.heading("item", text="Item")
        self.tree.heading("qty", text="QTY")
        self.tree.heading("units", text="Units")
        self.tree.heading("rate", text="Rate")
        self.tree.heading("value", text="Value")

        self.tree.column("item", width=300, anchor="w")
        self.tree.column("qty", width=100, anchor="e")
        self.tree.column("units", width=100, anchor="center")
        self.tree.column("rate", width=120, anchor="e")
        self.tree.column("value", width=150, anchor="e")

        self.tree.bind("<<TreeviewSelect>>", self._on_select)
        self.tree.bind("<Double-Button-1>", lambda e: self._open_history())
        self.tree.bind("<Return>", lambda e: self._open_history())

        # Customize Yellow selection colors for Stock Treeview
        style.map("Stock.Treeview",
            background=[("selected", HIGHLIGHT_YELLOW)],
            foreground=[("selected", "#000000")]
        )

        # 4. Bottom Frame
        bot = tk.Frame(self, bg=BG)
        bot.pack(fill="x", side="bottom")

        btn_exit = tk.Button(bot, text="Ctrl+Q: Exit", font=FONT, bg="#e0e0e0", relief="solid", bd=1, width=15, command=self.destroy)
        btn_exit.pack(side="left", padx=15, pady=10)

        btn_continue = tk.Button(bot, text="F12: Continue", font=FONT, bg="#e0e0e0", relief="solid", bd=1, width=15, command=self.destroy)
        btn_continue.pack(side="right", padx=15, pady=10)

    def _load_items(self):
        query = self.v_search.get().strip()
        conn = db.get_conn()
        sql = """
            SELECT im.item, 
                   COALESCE(st.cl_bal, 0.0) as qty, 
                   im.units_name as units, 
                   COALESCE(im.defaultsellingprice, 0.0) as rate,
                   im.detail1 as img_path
            FROM item_measure im
            LEFT JOIN stock st ON im.item = st.stock_name
            WHERE im.item LIKE ?
            ORDER BY im.item
        """
        rows = conn.execute(sql, (f"%{query}%",)).fetchall()
        conn.close()

        # Clear tree
        for item in self.tree.get_children():
            self.tree.delete(item)

        self.item_data = {}
        for r in rows:
            qty = r["qty"]
            rate = r["rate"]
            val = qty * rate
            
            # Format qty and values
            qty_str = f"{qty:,.0f}" if qty.is_integer() else f"{qty:,.2f}"
            rate_str = f"{rate:,.0f}" if rate.is_integer() else f"{rate:,.2f}"
            val_str = f"{val:,.0f}" if val.is_integer() else f"{val:,.2f}"

            item_id = self.tree.insert("", "end", values=(r["item"], qty_str, r["units"], rate_str, val_str))
            self.item_data[item_id] = r

        # Select first row by default
        children = self.tree.get_children()
        if children:
            self.tree.selection_set(children[0])
            self.tree.focus(children[0])

    def _on_select(self, event=None):
        sel = self.tree.selection()
        if not sel:
            self.img_frame.config(image="", width=15, height=5)
            self.img_frame.image = None
            return
        item_id = sel[0]
        r = self.item_data.get(item_id)
        if r and r["img_path"] and os.path.exists(r["img_path"]):
            try:
                from PIL import Image, ImageTk
                img = Image.open(r["img_path"])
                img.thumbnail((110, 80))
                photo = ImageTk.PhotoImage(img)
                self.img_frame.config(image=photo, width=110, height=80)
                self.img_frame.image = photo
            except Exception as e:
                self.img_frame.config(image="", width=15, height=5)
                self.img_frame.image = None
        else:
            self.img_frame.config(image="", width=15, height=5)
            self.img_frame.image = None

    def _on_enter_press(self):
        self._open_history()

    def _open_history(self):
        sel = self.tree.selection()
        if not sel:
            return
        item_id = sel[0]
        r = self.item_data.get(item_id)
        if r:
            ItemHistoryWindow(self, r["item"])


class ItemHistoryWindow(tk.Toplevel):
    def __init__(self, master, item_name):
        super().__init__(master)
        self.item_name = item_name
        self.title("Item History")
        self.geometry("950x640")
        self.configure(bg=BG)
        self.grab_set()
        self.transient(master)

        self._build_ui()
        self._load_history_details()

        # Keyboard bindings
        self.bind("<Control-q>", lambda e: self.destroy())
        self.bind("<Control-Q>", lambda e: self.destroy())
        self.bind("<F12>", lambda e: self.destroy())

    def _build_ui(self):
        # 1. Title Label
        tk.Label(self, text=self.item_name, font=FONT_TITLE, bg=BG).pack(pady=(15, 10))

        # 2. Defaults Frame
        def_frame = tk.Frame(self, bg=BG)
        def_frame.pack(fill="x", padx=40, pady=5)

        # Left col
        self.lbl_p1 = tk.Label(def_frame, text="Default Purchase Price(Ex-Tax) : 0", font=FONT, bg=BG, anchor="w")
        self.lbl_p1.grid(row=0, column=0, sticky="w", pady=2)
        self.lbl_p2 = tk.Label(def_frame, text="Default Purchase Price(Inc-Tax) : 0", font=FONT, bg=BG, anchor="w")
        self.lbl_p2.grid(row=1, column=0, sticky="w", pady=2)

        # Right col
        self.lbl_s1 = tk.Label(def_frame, text="Default Sale Price(Ex-Tax) : 0", font=FONT, bg=BG, anchor="w")
        self.lbl_s1.grid(row=0, column=1, sticky="w", padx=150, pady=2)
        self.lbl_s2 = tk.Label(def_frame, text="Default Sale Price(Inc-Tax) : 0", font=FONT, bg=BG, anchor="w")
        self.lbl_s2.grid(row=1, column=1, sticky="w", padx=150, pady=2)

        # 3. Last 5 Purchases
        tk.Label(self, text="Last 5 Purchase Information", font=FONT_BOLD, bg=BG).pack(pady=(15, 5))
        p_tbl_fr = tk.Frame(self, bg=BG_WHITE, relief="solid", bd=1)
        p_tbl_fr.pack(fill="both", expand=True, padx=40, pady=2)

        style = ttk.Style()
        style.configure("History.Treeview", font=FONT, rowheight=24)
        style.configure("History.Treeview.Heading", font=FONT_BOLD)

        self.p_tree = ttk.Treeview(
            p_tbl_fr,
            columns=("supp", "date", "vch_no", "qty", "rate", "rate_inc", "disc"),
            show="headings",
            style="History.Treeview"
        )
        self.p_tree.pack(fill="both", expand=True)

        self.p_tree.heading("supp", text="Customer/Supplier")
        self.p_tree.heading("date", text="Date")
        self.p_tree.heading("vch_no", text="Voucher No")
        self.p_tree.heading("qty", text="Quantity")
        self.p_tree.heading("rate", text="Rate/Unit")
        self.p_tree.heading("rate_inc", text="Rate(Inc. Tax)")
        self.p_tree.heading("disc", text="Discount %")

        self.p_tree.column("supp", width=200, anchor="w")
        self.p_tree.column("date", width=100, anchor="center")
        self.p_tree.column("vch_no", width=100, anchor="center")
        self.p_tree.column("qty", width=100, anchor="e")
        self.p_tree.column("rate", width=100, anchor="e")
        self.p_tree.column("rate_inc", width=120, anchor="e")
        self.p_tree.column("disc", width=100, anchor="e")

        # 4. Last 5 Sales
        tk.Label(self, text="Last 5 Sale Information", font=FONT_BOLD, bg=BG).pack(pady=(15, 5))
        s_tbl_fr = tk.Frame(self, bg=BG_WHITE, relief="solid", bd=1)
        s_tbl_fr.pack(fill="both", expand=True, padx=40, pady=2)

        self.s_tree = ttk.Treeview(
            s_tbl_fr,
            columns=("cust", "date", "vch_no", "qty", "rate", "rate_inc", "disc"),
            show="headings",
            style="History.Treeview"
        )
        self.s_tree.pack(fill="both", expand=True)

        self.s_tree.heading("cust", text="Customer/Supplier")
        self.s_tree.heading("date", text="Date")
        self.s_tree.heading("vch_no", text="Voucher No")
        self.s_tree.heading("qty", text="Quantity")
        self.s_tree.heading("rate", text="Rate/Unit")
        self.s_tree.heading("rate_inc", text="Rate(Inc. Tax)")
        self.s_tree.heading("disc", text="Discount %")

        self.s_tree.column("cust", width=200, anchor="w")
        self.s_tree.column("date", width=100, anchor="center")
        self.s_tree.column("vch_no", width=100, anchor="center")
        self.s_tree.column("qty", width=100, anchor="e")
        self.s_tree.column("rate", width=100, anchor="e")
        self.s_tree.column("rate_inc", width=120, anchor="e")
        self.s_tree.column("disc", width=100, anchor="e")

        # Configure Blue selection color for Sales treeview, Yellow for Purchases treeview (matches Image 3)
        style.map("Purchase.Treeview",
            background=[("selected", HIGHLIGHT_YELLOW)],
            foreground=[("selected", "#000000")]
        )
        style.map("Sale.Treeview",
            background=[("selected", HIGHLIGHT_BLUE)],
            foreground=[("selected", "#ffffff")]
        )
        self.p_tree.configure(style="Purchase.Treeview")
        self.s_tree.configure(style="Sale.Treeview")

        # 5. Bottom Frame
        bot = tk.Frame(self, bg=BG)
        bot.pack(fill="x", side="bottom")

        btn_exit = tk.Button(bot, text="Ctrl+Q: Exit", font=FONT, bg="#e0e0e0", relief="solid", bd=1, width=15, command=self.destroy)
        btn_exit.pack(side="left", padx=15, pady=10)

        btn_continue = tk.Button(bot, text="F12: Continue", font=FONT, bg="#e0e0e0", relief="solid", bd=1, width=15, command=self.destroy)
        btn_continue.pack(side="right", padx=15, pady=10)

    def _load_history_details(self):
        conn = db.get_conn()

        # 1. Fetch defaults from item_measure
        im = conn.execute("SELECT * FROM item_measure WHERE item=?", (self.item_name,)).fetchone()
        if im:
            p_price = im["defaultpurchaseprice"] or 0
            s_price = im["defaultsellingprice"] or 0
            # format values
            p_price_str = f"{p_price:,.0f}" if p_price.is_integer() else f"{p_price:,.2f}"
            s_price_str = f"{s_price:,.0f}" if s_price.is_integer() else f"{s_price:,.2f}"
            
            self.lbl_p1.config(text=f"Default Purchase Price(Ex-Tax) : {p_price_str}")
            self.lbl_p2.config(text=f"Default Purchase Price(Inc-Tax) : {p_price_str}")
            self.lbl_s1.config(text=f"Default Sale Price(Ex-Tax) : {s_price_str}")
            self.lbl_s2.config(text=f"Default Sale Price(Inc-Tax) : {s_price_str}")

        # 2. Fetch last 5 purchases
        p_rows = conn.execute("""
            SELECT COALESCE(v.credit, 'N/A') as supplier_name, p.date, v.vch_no, p.units as qty, p.cost_per_unit as rate, p.discount 
            FROM purchases p 
            JOIN vouchers v ON p.v_id = v.v_id 
            WHERE p.item = ? 
            ORDER BY p.date DESC LIMIT 5
        """, (self.item_name,)).fetchall()

        for r in p_rows:
            unit_sym = db.get_unit_symbol(im['units_name']) if (im and im.get('units_name')) else 'Nos'
            qty_str = f"{qty:,.0f} {unit_sym}"
            rate_str = f"{rate:,.0f}" if rate.is_integer() else f"{rate:,.2f}"
            disc_str = f"{r['discount']:.0f}%" if r["discount"] else "0%"
            
            self.p_tree.insert("", "end", values=(
                r["supplier_name"],
                r["date"],
                r["vch_no"],
                qty_str,
                rate_str,
                rate_str, # Inc. Tax same fallback
                disc_str
            ))

        # 3. Fetch last 5 sales
        s_rows = conn.execute("""
            SELECT COALESCE(v.debit, 'Cash') as customer_name, s.date, v.vch_no, s.units as qty, s.sp_per_unit as rate, s.discount 
            FROM sales s 
            JOIN vouchers v ON s.v_id = v.v_id 
            WHERE s.item = ? 
            ORDER BY s.date DESC LIMIT 5
        """, (self.item_name,)).fetchall()

        for r in s_rows:
            qty = r["qty"]
            rate = r["rate"]
            unit_sym = db.get_unit_symbol(im['units_name']) if (im and im.get('units_name')) else 'Nos'
            qty_str = f"{qty:,.0f} {unit_sym}"
            rate_str = f"{rate:,.0f}" if rate.is_integer() else f"{rate:,.2f}"
            disc_str = f"{r['discount']:.0f}%" if r["discount"] else "0%"

            self.s_tree.insert("", "end", values=(
                r["customer_name"],
                r["date"],
                r["vch_no"],
                qty_str,
                rate_str,
                rate_str, # Inc. Tax same fallback
                disc_str
            ))

        conn.close()

        # Set default selections
        p_children = self.p_tree.get_children()
        if p_children:
            self.p_tree.selection_set(p_children[0])
            self.p_tree.focus(p_children[0])

        s_children = self.s_tree.get_children()
        if s_children:
            self.s_tree.selection_set(s_children[0])
            self.s_tree.focus(s_children[0])
