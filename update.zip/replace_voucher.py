import re
from autocomplete import AutocompleteCombobox

with open('bookkeeper.py', 'r', encoding='utf-8') as f:
    content = f.read()

# We want to replace from # Grid header columns up to def save_voucher(print_receipt=False, view_after=False):
start_marker = "        # Grid header columns"
end_marker = "        def save_voucher(print_receipt=False, view_after=False):"

start_idx = content.find(start_marker)
end_idx = content.find(end_marker)

if start_idx == -1 or end_idx == -1:
    print("Markers not found!")
    exit(1)

new_block = '''        # Grid header columns
        col_defs = [
            ("Item",         22), ("QTY", 6), ("Units", 7),
            ("Rate",          9), ("Per", 5), ("Discount(%)", 9),
            ("Tax",           7), ("Value", 10), ("Description", 14),
        ]
        COL_WIDTHS = [d[1] for d in col_defs]

        # --- NEW HEADER FRAME (Outside Canvas to fix scroll bug) ---
        header_frame = tk.Frame(win, bg=WHITE, relief="flat", bd=0)
        header_frame.pack(fill="x", padx=8, pady=(4, 0))
        
        header_inner = tk.Frame(header_frame, bg=WHITE)
        header_inner.pack(side="left", fill="x", expand=True)
        dummy_sb_space = tk.Frame(header_frame, width=17, bg=WHITE)
        dummy_sb_space.pack(side="right", fill="y")
        
        for j, (htext, cw_) in enumerate(col_defs):
            tk.Label(header_inner, text=htext, bg=WHITE, fg="#000",
                     font=FONT_BOLD, width=cw_, anchor="w",
                     relief="flat", bd=0, padx=4, pady=4).grid(
                row=0, column=j, sticky="ew", padx=(0, 1), pady=(0, 1))
        
        header_inner.columnconfigure(0, weight=1)
        header_inner.columnconfigure(8, weight=1)

        # --- BOTTOM LAYOUT (Packed FIRST so they stay at bottom) ---
        bot_frame = tk.Frame(win, bg=BG)
        bot_frame.pack(fill="x", side="bottom", padx=8, pady=4)
        
        # Left side: Other charges + Narration
        bot_left = tk.Frame(bot_frame, bg=BG)
        bot_left.pack(side="left", fill="both", expand=True)
        
        other_var = tk.BooleanVar(value=False)
        tk.Checkbutton(bot_left, text="Other Charges", variable=other_var, bg=BG, font=FONT).pack(anchor="w", pady=(0, 4))
        
        tk.Label(bot_left, text="Narration\\nCtrl+Enter for next line",
                 bg=BG, fg="#555", font=("Tahoma", 7), anchor="w", justify="left").pack(anchor="w")
        nar_text = tk.Text(bot_left, font=FONT, width=40, height=4, relief="sunken", bd=1, bg=WHITE)
        nar_text.pack(fill="x", expand=True, padx=(0, 20))
        
        # Right side: Totals
        bot_right = tk.Frame(bot_frame, bg=BG)
        bot_right.pack(side="right", anchor="n")
        
        # Row 0: Round Off AND Total Amount
        round_var = tk.StringVar(value="0")
        total_var = tk.StringVar(value="0")
        
        tk.Label(bot_right, text="Round Off", bg=BG, font=FONT).grid(row=0, column=0, sticky="e", padx=4, pady=2)
        tk.Entry(bot_right, textvariable=round_var, font=FONT, width=12, justify="right",
                 relief="solid", bd=1).grid(row=0, column=1, sticky="w", padx=4, pady=2)
        
        tk.Label(bot_right, text="Total Amount", bg=BG, font=FONT).grid(row=0, column=2, sticky="e", padx=4, pady=2)
        tk.Entry(bot_right, textvariable=total_var, font=(FONT[0], 10, "bold"), width=15, justify="right",
                 relief="solid", bd=1, state="readonly", readonlybackground=WHITE).grid(row=0, column=3, sticky="w", padx=4, pady=2)
        
        # Row 1: Discount & Tax AND Reference Document
        disc_tax_lf = tk.LabelFrame(bot_right, text="Discount & Tax", bg=BG, font=("Tahoma", 8))
        disc_tax_lf.grid(row=1, column=0, columnspan=2, sticky="nsew", padx=4, pady=4)
        
        disc_mode_var = tk.StringVar(value="per_item")
        tk.Radiobutton(disc_tax_lf, text="On Total", variable=disc_mode_var, value="on_total", bg=BG, font=FONT).pack(anchor="w")
        tk.Radiobutton(disc_tax_lf, text="Per Item", variable=disc_mode_var, value="per_item", bg=BG, font=FONT).pack(anchor="w")
        
        ref_lf = tk.LabelFrame(bot_right, text="Reference Document", bg=BG, font=("Tahoma", 8))
        ref_lf.grid(row=1, column=2, columnspan=2, sticky="nsew", padx=4, pady=4)
        
        ref_var = tk.StringVar()
        tk.Entry(ref_lf, textvariable=ref_var, font=FONT, width=28, relief="solid", bd=1, bg=WHITE).pack(padx=4, pady=4)
        
        ref_btn_fr = tk.Frame(ref_lf, bg=BG)
        ref_btn_fr.pack(fill="x", pady=2)
        tk.Button(ref_btn_fr, text="Browse", bg="#e0e0e0", relief="flat", bd=1).pack(side="left", padx=2, fill="x", expand=True)
        tk.Button(ref_btn_fr, text="View", bg="#e0e0e0", relief="flat", bd=1).pack(side="left", padx=2, fill="x", expand=True)
        tk.Button(ref_btn_fr, text="Delete", bg="#e0e0e0", relief="flat", bd=1).pack(side="left", padx=2, fill="x", expand=True)

        # Amount row (Sub total)
        sum_row = tk.Frame(win, bg=BG)
        sum_row.pack(fill="x", side="bottom", padx=8, pady=2)
        
        amount_disp_var = tk.StringVar(value="")
        tk.Entry(sum_row, textvariable=amount_disp_var, font=FONT, justify="right",
                 width=16, relief="solid", bd=1, bg=WHITE,
                 state="readonly").pack(side="right", padx=(4, 0))
        tk.Label(sum_row, text="Amount", bg=BG, font=FONT).pack(side="right", padx=10)
        
        counts_frame = tk.Frame(sum_row, bg=WHITE, relief="solid", bd=1)
        counts_frame.pack(side="right", padx=40)
        count_var = tk.StringVar(value="Total Count: 0")
        qty_sum_var = tk.StringVar(value="Total Qty: 0")
        tk.Label(counts_frame, textvariable=count_var, bg=WHITE, font=FONT).pack(side="left", padx=5, pady=2)
        tk.Label(counts_frame, textvariable=qty_sum_var, bg=WHITE, font=FONT).pack(side="left", padx=5, pady=2)

        # --- GRID CANVAS (Fills remaining space) ---
        grid_frame = tk.Frame(win, bg=WHITE, relief="sunken", bd=2)
        grid_frame.pack(fill="both", expand=True, padx=8, pady=(0, 4))

        grid_canvas = tk.Canvas(grid_frame, bg=WHITE, highlightthickness=0)
        grid_vsb = ttk.Scrollbar(grid_frame, orient="vertical", command=grid_canvas.yview)
        grid_canvas.configure(yscrollcommand=grid_vsb.set)
        grid_vsb.pack(side="right", fill="y")
        grid_canvas.pack(side="left", fill="both", expand=True)

        grid_inner = tk.Frame(grid_canvas, bg="#cccccc")
        grid_cw = grid_canvas.create_window((0, 0), window=grid_inner, anchor="nw")

        grid_inner.bind("<Configure>", lambda e: grid_canvas.configure(scrollregion=grid_canvas.bbox("all")))
        grid_canvas.bind("<Configure>", lambda e: grid_canvas.itemconfig(grid_cw, width=e.width))
        grid_canvas.bind("<MouseWheel>", lambda e: grid_canvas.yview_scroll(-1*(e.delta//120), "units"))
        
        grid_inner.columnconfigure(0, weight=1)
        grid_inner.columnconfigure(8, weight=1)

        line_data = []

        def add_grid_row(item_name="", qty="1", unit="Nos",
                         rate="0", per="", disc="0", tax="0"):
            ri = len(line_data) + 1

            item_v  = tk.StringVar(value=item_name)
            qty_v   = tk.StringVar(value=qty)
            unit_v  = tk.StringVar(value=unit)
            rate_v  = tk.StringVar(value=rate)
            per_v   = tk.StringVar(value=per)
            disc_v  = tk.StringVar(value=disc)
            tax_v   = tk.StringVar(value=tax)
            value_v = tk.StringVar(value="0.00")
            desc_v  = tk.StringVar()

            def recalc(e=None):
                try:
                    q = float(qty_v.get() or 0)
                    r_ = float(rate_v.get() or 0)
                    d  = float(disc_v.get() or 0)
                    t  = float(tax_v.get() or 0)
                    val = q * r_ * (1 - d/100) * (1 + t/100)
                    value_v.set(f"{val:.2f}")
                    recalc_total()
                except Exception:
                    pass

            def on_item_select(e=None):
                name = item_v.get()
                for it in all_inv_items:
                    if it["name"] == name:
                        rate_v.set(str(it["sale_price"]))
                        unit_v.set(it["unit"])
                        units_lbl.config(text=f"  Units Left: {it['stock']:.0f}")
                        recalc()
                        break

            bg_color = WHITE if ri % 2 == 1 else "#f0f0f0"

            # 0. Item
            cb = tk.Entry(grid_inner, textvariable=item_v, font=FONT,
                          width=COL_WIDTHS[0]-2, relief="flat", bd=0, bg=bg_color)
            cb.grid(row=ri, column=0, padx=(0, 1), pady=(0, 1), sticky="ew", ipady=5)
            cb.bind("<FocusOut>", on_item_select)
            cb.bind("<Return>", on_item_select)

            # 1. QTY (Right aligned)
            qty_e = tk.Entry(grid_inner, textvariable=qty_v, font=FONT, justify="right",
                             width=COL_WIDTHS[1]-1, relief="flat", bd=0, bg=bg_color)
            qty_e.grid(row=ri, column=1, padx=(0, 1), pady=(0, 1), sticky="ew", ipady=5)
            qty_e.bind("<FocusOut>", recalc)
            qty_e.bind("<Return>", recalc)

            # 2. Units (Left aligned)
            unit_e = tk.Entry(grid_inner, textvariable=unit_v, font=FONT,
                              width=COL_WIDTHS[2]-1, relief="flat", bd=0, bg=bg_color)
            unit_e.grid(row=ri, column=2, padx=(0, 1), pady=(0, 1), sticky="ew", ipady=5)

            # 3. Rate (Right aligned)
            rate_e = tk.Entry(grid_inner, textvariable=rate_v, font=FONT, justify="right",
                              width=COL_WIDTHS[3]-1, relief="flat", bd=0, bg=bg_color)
            rate_e.grid(row=ri, column=3, padx=(0, 1), pady=(0, 1), sticky="ew", ipady=5)
            rate_e.bind("<FocusOut>", recalc)
            rate_e.bind("<Return>", recalc)

            # 4. Per (Combobox)
            per_cb = AutocompleteCombobox(grid_inner, textvariable=per_v, values=["nos", "pcs", "kg"],
                                  width=COL_WIDTHS[4]-2, font=FONT)
            per_cb.grid(row=ri, column=4, padx=(0, 1), pady=(0, 1), sticky="ew", ipady=3)

            # 5. Discount(%) (Right aligned)
            disc_e = tk.Entry(grid_inner, textvariable=disc_v, font=FONT, justify="right",
                              width=COL_WIDTHS[5]-1, relief="flat", bd=0, bg=bg_color)
            disc_e.grid(row=ri, column=5, padx=(0, 1), pady=(0, 1), sticky="ew", ipady=5)
            disc_e.bind("<FocusOut>", recalc)
            disc_e.bind("<Return>", recalc)

            # 6. Tax (Combobox)
            tax_cb = AutocompleteCombobox(grid_inner, textvariable=tax_v, values=["0", "5", "18"],
                                  width=COL_WIDTHS[6]-2, font=FONT)
            tax_cb.grid(row=ri, column=6, padx=(0, 1), pady=(0, 1), sticky="ew", ipady=3)

            # 7. Value (Right aligned, read-only appearance)
            val_e = tk.Entry(grid_inner, textvariable=value_v, font=FONT, justify="right",
                             width=COL_WIDTHS[7]-1, relief="flat", bd=0, bg=bg_color, state="readonly")
            val_e.grid(row=ri, column=7, padx=(0, 1), pady=(0, 1), sticky="ew", ipady=5)

            # 8. Description (Yellow bg)
            desc_e = tk.Entry(grid_inner, textvariable=desc_v, font=FONT,
                              width=COL_WIDTHS[8]-1, relief="flat", bd=0, bg="yellow")
            desc_e.grid(row=ri, column=8, padx=(0, 1), pady=(0, 1), sticky="ew", ipady=5)

            row_dict = {
                "item_v": item_v, "qty_v": qty_v, "unit_v": unit_v,
                "rate_v": rate_v, "per_v": per_v, "disc_v": disc_v,
                "tax_v": tax_v, "value_v": value_v, "desc_v": desc_v,
                "ri": ri
            }
            line_data.append(row_dict)

            def del_row(rd=row_dict):
                line_data.remove(rd)
                for widget in grid_inner.grid_slaves(row=rd["ri"]):
                    widget.destroy()
                recalc_total()
                
            # Bind Delete key to delete the row (since we removed the red X button)
            for widget in grid_inner.grid_slaves(row=ri):
                widget.bind("<Delete>", lambda e, d=row_dict: del_row(d))

        def recalc_total():
            tot = sum(float(r["value_v"].get() or 0) for r in line_data)
            count = len([r for r in line_data if r["item_v"].get().strip()])
            qty = sum(float(r["qty_v"].get() or 0) for r in line_data if r["item_v"].get().strip())
            try:
                roff = float(round_var.get() or 0)
            except:
                roff = 0
            grand = tot + roff
            total_var.set(f"{grand:,.0f}" if grand.is_integer() else f"{grand:,.2f}")
            amount_disp_var.set(f"{tot:,.0f}" if tot.is_integer() else f"{tot:,.2f}")
            count_var.set(f"Total Count: {count}")
            qty_sum_var.set(f"Total Qty: {qty:g}")

        # bind Enter on item search   add row
        def on_enter_item(e=None):
            name = item_search_var.get().strip()
            if name:
                add_grid_row(item_name=name)
                item_search_var.set("")
                recalc_total()

        item_search_cb.bind("<Return>", on_enter_item)

        # Start with 3 blank rows
        for _ in range(3):
            add_grid_row()

'''

new_content = content[:start_idx] + new_block + content[end_idx:]

with open('bookkeeper.py', 'w', encoding='utf-8') as f:
    f.write(new_content)

print("Replacement successful")
