import re

with open('bookkeeper.py', 'r', encoding='utf-8') as f:
    content = f.read()

old_unit_form = '''    def _unit_form(self, parent_win=None):
        win = tk.Toplevel(parent_win if parent_win else self)
        win.title("Create Units Of Measure")'''

new_unit_form = '''    def _unit_form(self, parent_win=None, existing=None):
        win = tk.Toplevel(parent_win if parent_win else self)
        win.title("Create Units Of Measure" if not existing else "Edit Units Of Measure")'''

content = content.replace(old_unit_form, new_unit_form)

old_save_unit = '''            try:
                db.add_unit({
                    "units_name": name,
                    "symbol": symb,
                    "isSimpleUnit": 0 if compound_var.get() else 1
                })
                win.destroy()
            except Exception as e:'''

new_save_unit = '''            try:
                data = {
                    "units_name": name,
                    "symbol": symb,
                    "isSimpleUnit": 0 if compound_var.get() else 1
                }
                if existing:
                    db.update_unit(existing["id"], data)
                else:
                    db.add_unit(data)
                win.destroy()
                if hasattr(self, 'current_list_refresh'):
                    self.current_list_refresh()
            except Exception as e:'''

content = content.replace(old_save_unit, new_save_unit)

old_fill = '''        cb.place(x=180, y=130)

        def save(event=None):'''

new_fill = '''        cb.place(x=180, y=130)

        if existing:
            u_name.insert(0, existing.get("units_name", ""))
            u_symb.insert(0, existing.get("symbol", ""))
            if not existing.get("isSimpleUnit", 1):
                compound_var.set(1)

        def save(event=None):'''

content = content.replace(old_fill, new_fill)

with open('bookkeeper.py', 'w', encoding='utf-8') as f:
    f.write(content)
print("unit_form updated")
