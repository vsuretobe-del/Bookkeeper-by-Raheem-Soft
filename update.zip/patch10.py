import re

with open('bookkeeper.py', 'r', encoding='utf-8') as f:
    content = f.read()

new_show_units = '''    def show_units(self):
        self._clear_main()
        
        tb = tk.Frame(self.main_frame, bg="#ffffff")
        tb.pack(fill="x")
        
        btn_exit = tk.Button(tb, text="? Ctrl+Q: Exit", bg="#ffffff", relief="flat", font=(FONT[0], 9), command=self.quit)
        btn_exit.pack(side="left", padx=2)
        
        btn_new = tk.Button(tb, text="? F2: New Unit Of Measure", bg="#ffffff", relief="flat", font=(FONT[0], 9), command=lambda: self._unit_form())
        btn_new.pack(side="left", padx=2)
        
        self.bind("<F2>", lambda e: self._unit_form())
        
        title_lbl = tk.Label(self.main_frame, text="Unit Of Measure", bg="#d3d3d3", font=(FONT[0], 11, "bold"))
        title_lbl.pack(fill="x")
        
        search_frame = tk.Frame(self.main_frame, bg="#d3d3d3")
        search_frame.pack(fill="x")
        tk.Label(search_frame, text="F3: Search:", bg="#d3d3d3", font=FONT).pack(side="left", padx=5, pady=5)
        search_var = tk.StringVar()
        search_entry = tk.Entry(search_frame, textvariable=search_var, font=FONT, width=40)
        search_entry.pack(side="left", pady=5)
        
        self.bind("<F3>", lambda e: search_entry.focus_set())
        
        tk.Label(self.main_frame, text="Press ENTER to edit and DELETE to delete", fg="darkred", bg="#d3d3d3", font=(FONT[0], 9, "italic", "bold"), anchor="w").pack(fill="x", padx=5)
        
        tree_frame = tk.Frame(self.main_frame, bg="#d3d3d3")
        tree_frame.pack(fill="both", expand=True, padx=5, pady=5)
        
        cols = ("Unit Name", "Symbol")
        tree = ttk.Treeview(tree_frame, columns=cols, show="headings", height=20)
        tree.heading("Unit Name", text="Unit Name")
        tree.heading("Symbol", text="Symbol")
        tree.column("Unit Name", width=200, anchor="w")
        tree.column("Symbol", width=200, anchor="w")
        
        tree.bind("<Return>", lambda e: self._edit_selected_unit(tree))
        tree.bind("<Delete>", lambda e: self._delete_selected_unit(tree))
        
        vsb = ttk.Scrollbar(tree_frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        tree.pack(fill="both", expand=True)
        
        self.main_frame.configure(bg="#d3d3d3")
        
        def load_units(*args):
            q = search_var.get().lower()
            for item in tree.get_children():
                tree.delete(item)
            for u in db.get_all_units():
                if q in u['units_name'].lower() or q in u['symbol'].lower():
                    tree.insert("", "end", iid=str(u["id"]), values=(u["units_name"], u["symbol"]))
        
        search_var.trace_add("write", load_units)
        load_units()
        
        self.current_list_refresh = load_units

    def _edit_selected_unit(self, tree):
        sel = tree.selection()
        if not sel: return
        unit_id = sel[0]
        u = next((u for u in db.get_all_units() if str(u["id"]) == unit_id), None)
        if u:
            self._unit_form(existing=u)

    def _delete_selected_unit(self, tree):
        sel = tree.selection()
        if not sel: return
        if messagebox.askyesno("Confirm", "Delete selected unit?", parent=self):
            try:
                db.delete_unit(sel[0])
                if hasattr(self, 'current_list_refresh'):
                    self.current_list_refresh()
            except Exception as e:
                messagebox.showerror("Error", str(e), parent=self)
'''

old_show_units = r'''    def show_units\(self\):.*?anchor="w", padx=24, pady=3\)\.pack\(fill="x"\)'''
content = re.sub(old_show_units, new_show_units, content, flags=re.DOTALL)

with open('bookkeeper.py', 'w', encoding='utf-8') as f:
    f.write(content)
print("show_units replaced")
