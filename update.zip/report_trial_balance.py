import tkinter as tk
from tkinter import ttk, messagebox
import db
import datetime
import os
import webbrowser
import openpyxl
from custom_calendar import DateEntry

BG_SIDEBAR = "#205493"
BG_WHITE = "#FFFFFF"
BG_GRAY_HEADER = "#EEF2F5"
BG_TOTAL = "#F5F5F5"
DARK_BLUE = "#205493"

FONT = ("Segoe UI", 9)
FONT_BOLD = ("Segoe UI", 9, "bold")
TITLE_FONT = ("Segoe UI", 12, "bold")
CO_FONT = ("Segoe UI", 11, "bold")
CELL_FONT = ("Segoe UI", 9)
CELL_FONT_BOLD = ("Segoe UI", 9, "bold")
CELL_FONT_UNDERLINE = ("Segoe UI", 9, "underline")
CELL_FONT_ITALIC = ("Segoe UI", 9, "italic")

class ReportTrialBalance(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent, bg=BG_WHITE)
        self.app_ref = parent
        self.title("Trial Balance")
        self.geometry("1150x720")
        try:
            self.state("zoomed")
        except tk.TclError:
            pass

        # Date range
        try:
            self.start_d = self.app_ref.reporting_from_dp.get_date().strftime("%Y-%m-%d")
            self.end_d = self.app_ref.reporting_to_dp.get_date().strftime("%Y-%m-%d")
        except Exception:
            today = datetime.date.today()
            fy_start_year = today.year if today.month >= 4 else today.year - 1
            self.start_d = datetime.date(fy_start_year, 4, 1).strftime("%Y-%m-%d")
            self.end_d = today.strftime("%Y-%m-%d")

        # Company Name
        try:
            co = db.get_company_details()
            self.company_name = co.get("company_name", "ALHUMDULILLAH") or "ALHUMDULILLAH"
        except Exception:
            self.company_name = "ALHUMDULILLAH"

        # Sidebar Checkbox Variables
        self.var_op_bal = tk.BooleanVar(value=False)
        self.var_tx = tk.BooleanVar(value=False)
        self.var_cl_bal = tk.BooleanVar(value=False)
        self.var_detailed = tk.BooleanVar(value=False)

        self._build_ui()
        self._bind_shortcuts()
        self.refresh_report()

    def _bind_shortcuts(self):
        self.bind("<Control-q>", lambda e: self.destroy())
        self.bind("<Control-Q>", lambda e: self.destroy())
        self.bind("<Alt-p>", lambda e: self.export_print())
        self.bind("<Alt-P>", lambda e: self.export_print())
        self.bind("<Control-w>", lambda e: self.export_word())
        self.bind("<Control-W>", lambda e: self.export_word())
        self.bind("<Control-e>", lambda e: self.export_excel())
        self.bind("<Control-E>", lambda e: self.export_excel())
        self.bind("<Control-v>", lambda e: self.export_pdf())
        self.bind("<Control-V>", lambda e: self.export_pdf())
        self.bind("<Control-h>", lambda e: self.export_browser())
        self.bind("<Control-H>", lambda e: self.export_browser())
        self.bind("<F12>", lambda e: self.refresh_report())

    def _build_ui(self):
        # 1. Top Action Toolbar
        top_bar = tk.Frame(self, bg=BG_WHITE)
        top_bar.pack(fill="x", side="top", padx=6, pady=3)

        btn_exit = tk.Button(top_bar, text="✖ Ctrl+Q: Exit", bg="black", fg="white",
                             font=("Tahoma", 8, "bold"), padx=6, pady=2, relief="flat",
                             cursor="hand2", command=self.destroy)
        btn_exit.pack(side="left", padx=2)

        btn_print = tk.Button(top_bar, text="🖶 Alt+P: Print", bg=BG_WHITE, fg="black",
                              font=("Tahoma", 8), padx=6, pady=2, relief="flat",
                              cursor="hand2", command=self.export_print)
        btn_print.pack(side="left", padx=2)

        btn_word = tk.Button(top_bar, text="📝 Ctrl+W: Open In MS Word", bg="#e8e8e8", fg="black",
                             font=("Tahoma", 8), padx=6, pady=2, relief="flat",
                             cursor="hand2", command=self.export_word)
        btn_word.pack(side="left", padx=2)

        btn_excel = tk.Button(top_bar, text="📊 Ctrl+E: Open In MS Excel", bg="#e8e8e8", fg="black",
                              font=("Tahoma", 8), padx=6, pady=2, relief="flat",
                              cursor="hand2", command=self.export_excel)
        btn_excel.pack(side="left", padx=2)

        btn_pdf = tk.Button(top_bar, text="📄 Ctrl+V: Open In PDF", bg=BG_WHITE, fg="black",
                            font=("Tahoma", 8), padx=6, pady=2, relief="flat",
                            cursor="hand2", command=self.export_pdf)
        btn_pdf.pack(side="left", padx=2)

        btn_browser = tk.Button(top_bar, text="🌐 Ctrl+H: Open In Browser", bg="black", fg="white",
                                font=("Tahoma", 8, "bold"), padx=6, pady=2, relief="flat",
                                cursor="hand2", command=self.export_browser)
        btn_browser.pack(side="left", padx=2)

        tk.Frame(self, bg="#d0d0d0", height=1).pack(fill="x")

        # 2. Main Body Container
        body_fr = tk.Frame(self, bg=BG_WHITE)
        body_fr.pack(fill="both", expand=True)

        # Left Sidebar (Blue)
        self.sidebar_fr = tk.Frame(body_fr, bg=BG_SIDEBAR, width=220)
        self.sidebar_fr.pack(side="left", fill="y")
        self.sidebar_fr.pack_propagate(False)

        self._build_sidebar()

        # Right Content Area (White Canvas / Scrollable)
        self.right_container = tk.Frame(body_fr, bg=BG_WHITE)
        self.right_container.pack(side="left", fill="both", expand=True, padx=15, pady=10)

        # Header Info
        self.hdr_fr = tk.Frame(self.right_container, bg=BG_WHITE)
        self.hdr_fr.pack(fill="x", anchor="w", pady=(5, 10))

        lbl_co = tk.Label(self.hdr_fr, text=self.company_name, font=CO_FONT, bg=BG_WHITE, fg=DARK_BLUE)
        lbl_co.pack(anchor="w")

        lbl_title = tk.Label(self.hdr_fr, text="TRIAL BALANCE", font=TITLE_FONT, bg=BG_WHITE, fg="black")
        lbl_title.pack(anchor="w")

        self.lbl_dates = tk.Label(self.hdr_fr, text=f"{self.start_d} To {self.end_d}", font=FONT, bg=BG_WHITE, fg="#333333")
        self.lbl_dates.pack(anchor="w")

        # Treeview / Table Container
        self.table_fr = tk.Frame(self.right_container, bg=BG_WHITE)
        self.table_fr.pack(fill="both", expand=True)

    def _build_sidebar(self):
        # Configure Frame (F12: Configure)
        cfg_box = tk.LabelFrame(self.sidebar_fr, text="F12: Configure", font=("Segoe UI", 9),
                                bg=BG_SIDEBAR, fg="white", bd=1, relief="solid")
        cfg_box.pack(fill="x", padx=10, pady=12, ipady=5)

        chks = [
            ("Display Opening Balance", self.var_op_bal),
            ("Display Transactions", self.var_tx),
            ("Display Closing Balance", self.var_cl_bal),
            ("Display Detailed Report", self.var_detailed)
        ]

        for text, var in chks:
            cb = tk.Checkbutton(cfg_box, text=text, variable=var, bg=BG_SIDEBAR, fg="white",
                                selectcolor=BG_SIDEBAR, activebackground=BG_SIDEBAR,
                                activeforeground="white", font=("Segoe UI", 9), anchor="w",
                                command=self.on_checkbox_toggle)
            cb.pack(fill="x", padx=6, pady=3)

        # Display Button
        btn_display = tk.Button(cfg_box, text="Display", bg=BG_SIDEBAR, fg="white",
                                activebackground="#2c67b0", activeforeground="white",
                                font=("Segoe UI", 10, "bold"), relief="solid", bd=1,
                                cursor="hand2", command=self.refresh_report)
        btn_display.pack(fill="x", padx=8, pady=(10, 4), ipady=3)

    def on_checkbox_toggle(self):
        # If any detailed checkbox is selected or changed, auto update or let user click Display
        pass

    def get_trial_balance_raw_data(self):
        """Calculates accurate Trial Balance data for all groups and accounts."""
        conn = db.get_conn()
        conn.row_factory = __import__('sqlite3').Row

        # All defined accounts
        accs = conn.execute("SELECT aname, account_group, op_bal, a_type FROM account_detail").fetchall()
        acc_dict_list = [dict(a) for a in accs]

        # Get all distinct accounts from vouchers_all to catch accounts created implicitly
        v_debits = [r[0] for r in conn.execute("SELECT DISTINCT debit FROM vouchers_all WHERE debit IS NOT NULL AND debit != ''").fetchall()]
        v_credits = [r[0] for r in conn.execute("SELECT DISTINCT credit FROM vouchers_all WHERE credit IS NOT NULL AND credit != ''").fetchall()]
        existing_names = set(a['aname'] for a in acc_dict_list)

        for v_acc in set(v_debits + v_credits):
            if v_acc not in existing_names:
                grp = "Sundry Debtors"
                v_lower = v_acc.lower()
                if "sales" in v_lower: grp = "Sales A/C"
                elif "purchase" in v_lower: grp = "Purchases A/C"
                elif "cash" in v_lower: grp = "Cash-in-hand"
                elif "bank" in v_lower: grp = "Bank A/Cs"
                elif "expense" in v_lower or "rent" in v_lower or "adver" in v_lower: grp = "Indirect Expenses"
                elif "income" in v_lower or "interest" in v_lower: grp = "Indirect Income"
                acc_dict_list.append({'aname': v_acc, 'account_group': grp, 'op_bal': 0.0, 'a_type': None})
                existing_names.add(v_acc)

        # Standard Chart of Accounts Group Order matching the exact layout
        group_definitions = [
            ("Cash-in-hand", "Dr", ["Cash-in-hand", "cash", "Cash Account"]),
            ("Bank A/Cs", "Dr", ["Bank A/Cs", "bank", "Bank Account"]),
            ("Sundry Debtors", "Dr", ["Sundry Debtors", "debtor", "debtors", "customer"]),
            ("Sundry Creditors", "Cr", ["Sundry Creditors", "creditor", "creditors", "supplier"]),
            ("Purchases A/C", "Dr", ["Purchases A/C", "purchase", "purchases", "Purchase Account"]),
            ("Purchases Return", "Cr", ["Purchases Return", "debit_note"]),
            ("Sales A/C", "Cr", ["Sales A/C", "sale", "sales", "Sales Account"]),
            ("Sales Return", "Dr", ["Sales Return", "credit_note"]),
            ("Capital A/C", "Cr", ["Capital A/C", "capital"]),
            ("Direct Expenses", "Dr", ["Direct Expenses"]),
            ("Indirect Expenses", "Dr", ["Indirect Expenses"]),
            ("Direct Income", "Cr", ["Direct Income"]),
            ("Indirect Income", "Cr", ["Indirect Income"]),
            ("Current Assets", "Dr", ["Current Assets"]),
            ("Current Liabilities", "Cr", ["Current Liabilities"]),
            ("Misc. Expenses", "Dr", ["Misc. Expenses"]),
            ("Misc. Income", "Cr", ["Misc. Income"]),
            ("Loans (Liability)", "Cr", ["Loans (Liability)"]),
            ("Loans & Advances", "Dr", ["Loans & Advances", "Loans & Advances (Asset)"]),
            ("Fixed Assets", "Dr", ["Fixed Assets"]),
            ("Investments", "Dr", ["Investments"]),
            ("Bank OD A/C", "Cr", ["Bank OD A/C"]),
            ("Deposits (Assets)", "Dr", ["Deposits (Assets)"]),
            ("Provisions", "Cr", ["Provisions"]),
            ("Reserves & Surplus", "Cr", ["Reserves & Surplus"]),
            ("Duties & Taxes", "Cr", ["Duties & Taxes", "tax"])
        ]

        # Opening inventory calculation
        open_inv_val = 0.0
        try:
            sd_obj = datetime.datetime.strptime(self.start_d, "%Y-%m-%d")
            prev_day = (sd_obj - datetime.timedelta(days=1)).strftime("%Y-%m-%d")
            open_inv_val = db.get_inventory_value_as_of(prev_day)
        except Exception:
            open_inv_val = 0.0

        if open_inv_val == 0.0:
            try:
                open_inv_val = db.get_inventory_value_as_of(self.start_d)
            except Exception:
                open_inv_val = 0.0

        results = []
        tot_open_dr = 0.0
        tot_open_cr = 0.0
        tot_tx_dr = 0.0
        tot_tx_cr = 0.0
        tot_close_dr = 0.0
        tot_close_cr = 0.0

        for grp_title, normal_side, grp_matches in group_definitions:
            matches_lower = [m.lower() for m in grp_matches]
            matched_accs = []
            for a in acc_dict_list:
                agrp = (a.get('account_group') or '').strip().lower()
                atype = (a.get('a_type') or '').strip().lower()
                aname = (a.get('aname') or '').strip()

                is_match = False
                if agrp in matches_lower or aname.lower() in matches_lower:
                    is_match = True
                elif grp_title == "Sundry Debtors" and (atype == "customer" or "debtor" in agrp):
                    is_match = True
                elif grp_title == "Sundry Creditors" and (atype == "supplier" or "creditor" in agrp):
                    is_match = True

                if is_match:
                    matched_accs.append(a)

            # Deduplicate by aname
            unique_accs = {}
            for a in matched_accs:
                unique_accs[a['aname']] = a
            matched_accs = list(unique_accs.values())

            grp_open = 0.0
            grp_dr_tx = 0.0
            grp_cr_tx = 0.0
            grp_close = 0.0
            sub_items = []

            for a in matched_accs:
                name = a['aname']
                op = float(a.get('op_bal') or 0.0)

                # Prior vouchers before start_d
                prior = conn.execute("""
                    SELECT 
                        SUM(CASE WHEN debit = ? THEN amount ELSE 0 END) as dr,
                        SUM(CASE WHEN credit = ? THEN amount ELSE 0 END) as cr
                    FROM vouchers_all WHERE date < ?
                """, (name, name, self.start_d)).fetchone()
                p_dr = float(prior['dr'] or 0.0) if prior else 0.0
                p_cr = float(prior['cr'] or 0.0) if prior else 0.0

                # Current period transactions
                curr = conn.execute("""
                    SELECT 
                        SUM(CASE WHEN debit = ? THEN amount ELSE 0 END) as dr,
                        SUM(CASE WHEN credit = ? THEN amount ELSE 0 END) as cr
                    FROM vouchers_all WHERE date >= ? AND date <= ?
                """, (name, name, self.start_d, self.end_d)).fetchone()
                c_dr = float(curr['dr'] or 0.0) if curr else 0.0
                c_cr = float(curr['cr'] or 0.0) if curr else 0.0

                if normal_side == "Dr":
                    acc_open = op + p_dr - p_cr
                    acc_close = acc_open + c_dr - c_cr
                else:
                    acc_open = op + p_cr - p_dr
                    acc_close = acc_open + c_cr - c_dr

                grp_open += acc_open
                grp_dr_tx += c_dr
                grp_cr_tx += c_cr
                grp_close += acc_close

                sub_items.append({
                    "name": name,
                    "opening": acc_open,
                    "dr_tx": c_dr,
                    "cr_tx": c_cr,
                    "closing": acc_close,
                    "normal_side": normal_side
                })

            # Add to running totals
            if normal_side == "Dr":
                tot_open_dr += grp_open
                tot_close_dr += grp_close
            else:
                tot_open_cr += grp_open
                tot_close_cr += grp_close

            tot_tx_dr += grp_dr_tx
            tot_tx_cr += grp_cr_tx

            results.append({
                "group_title": grp_title,
                "normal_side": normal_side,
                "opening": grp_open,
                "dr_tx": grp_dr_tx,
                "cr_tx": grp_cr_tx,
                "closing": grp_close,
                "sub_items": sub_items
            })

        # Add Opening Inventory to Debit totals
        if open_inv_val > 0:
            tot_open_dr += open_inv_val
            tot_close_dr += open_inv_val

        # Difference in Opening Balance calculation
        diff_open = tot_close_dr - tot_close_cr
        diff_side = "Cr" if diff_open > 0 else "Dr"
        diff_val = abs(diff_open)

        # Balanced Totals
        final_debit_total = max(tot_close_dr, tot_close_cr)
        final_credit_total = final_debit_total

        conn.close()

        return {
            "groups": results,
            "opening_inventory": open_inv_val,
            "diff_opening_val": diff_val,
            "diff_opening_side": diff_side,
            "tot_open_dr": tot_open_dr,
            "tot_open_cr": tot_open_cr,
            "tot_tx_dr": tot_tx_dr,
            "tot_tx_cr": tot_tx_cr,
            "tot_close_dr": tot_close_dr,
            "tot_close_cr": tot_close_cr,
            "final_debit_total": final_debit_total,
            "final_credit_total": final_credit_total
        }

    def format_val(self, val, with_suffix=False, normal_side="Dr", is_sub=False):
        """Formats numbers with comma grouping, zero, and optional Dr/Cr suffix."""
        if val is None or abs(val) < 0.0001:
            if with_suffix and not is_sub:
                return f"0 {normal_side}"
            return "0"

        # Format number
        if val < 0:
            formatted = f"-{abs(val):,.0f}"
        else:
            formatted = f"{val:,.0f}"

        if with_suffix and not is_sub:
            suffix = f" {normal_side}"
            return f"{formatted}{suffix}"

        return formatted

    def refresh_report(self):
        """Re-renders the Trial Balance grid based on current sidebar selections."""
        for widget in self.table_fr.winfo_children():
            widget.destroy()

        # Update date label
        self.lbl_dates.config(text=f"{self.start_d} To {self.end_d}")

        is_detailed_report = self.var_detailed.get()
        show_opening = self.var_op_bal.get()
        show_tx = self.var_tx.get()
        show_closing = self.var_cl_bal.get()

        # If any of opening, tx, closing is checked OR detailed report is checked, use multi-column mode
        is_multi_col = show_opening or show_tx or show_closing or is_detailed_report

        data = self.get_trial_balance_raw_data()
        groups = data['groups']

        if not is_multi_col:
            # ══════════════════════════════════════════════════════════════════
            # MODE 1: SUMMARY / 2-COLUMN VIEW (Matching Image 1)
            # ══════════════════════════════════════════════════════════════════
            cols = ["PARTICULARS", "DEBIT", "CREDIT"]
            tree = ttk.Treeview(self.table_fr, columns=cols, show="headings", height=28, selectmode="browse")

            tree.heading("PARTICULARS", text="PARTICULARS", anchor="w")
            tree.column("PARTICULARS", width=420, anchor="w")

            tree.heading("DEBIT", text="DEBIT", anchor="e")
            tree.column("DEBIT", width=180, anchor="e")

            tree.heading("CREDIT", text="CREDIT", anchor="e")
            tree.column("CREDIT", width=180, anchor="e")

            style = ttk.Style()
            style.theme_use("clam")
            style.configure("Treeview", font=CELL_FONT, rowheight=24, background=BG_WHITE, fieldbackground=BG_WHITE)
            style.configure("Treeview.Heading", font=FONT_BOLD, background=BG_GRAY_HEADER, foreground="black")
            style.map("Treeview", background=[("selected", "#ffffa0")], foreground=[("selected", "black")])

            tree.tag_configure("normal", font=CELL_FONT, background=BG_WHITE)
            tree.tag_configure("bold", font=CELL_FONT_BOLD, background=BG_WHITE)
            tree.tag_configure("underline", font=CELL_FONT_UNDERLINE, background=BG_WHITE)
            tree.tag_configure("italic", font=CELL_FONT_ITALIC, background=BG_WHITE)
            tree.tag_configure("total_row", font=CELL_FONT_BOLD, background=BG_GRAY_HEADER)

            # Insert Groups
            for g in groups:
                title = g['group_title']
                side = g['normal_side']
                close_val = g['closing']

                dr_str = ""
                cr_str = ""
                if side == "Dr":
                    dr_str = self.format_val(close_val)
                else:
                    cr_str = self.format_val(close_val)

                tree.insert("", "end", values=(title, dr_str, cr_str), tags=("normal",))

            # Opening Inventory Row
            if data['opening_inventory'] > 0:
                inv_val_str = self.format_val(data['opening_inventory'])
                tree.insert("", "end", values=("Opening Inventory", inv_val_str, ""), tags=("underline",))

            # Difference In Opening Balance Row
            if data['diff_opening_val'] > 0:
                diff_val_str = self.format_val(data['diff_opening_val'])
                if data['diff_opening_side'] == "Cr":
                    tree.insert("", "end", values=("Difference In Opening Balance", "", diff_val_str), tags=("italic",))
                else:
                    tree.insert("", "end", values=("Difference In Opening Balance", diff_val_str, ""), tags=("italic",))

            # Blank row before total
            tree.insert("", "end", values=("", "", ""), tags=("normal",))

            # Grand Total Row
            tot_dr_str = f"Rs{data['final_debit_total']:,.0f}"
            tot_cr_str = f"Rs{data['final_credit_total']:,.0f}"
            tree.insert("", "end", values=("TOTAL", tot_dr_str, tot_cr_str), tags=("total_row",))

            vsb = ttk.Scrollbar(self.table_fr, orient="vertical", command=tree.yview)
            hsb = ttk.Scrollbar(self.table_fr, orient="horizontal", command=tree.xview)
            tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)

            vsb.pack(side="right", fill="y")
            hsb.pack(side="bottom", fill="x")
            tree.pack(fill="both", expand=True)

        else:
            # ══════════════════════════════════════════════════════════════════
            # MODE 2: DETAILED / MULTI-COLUMN VIEW (Matching Images 2, 3, 4)
            # ══════════════════════════════════════════════════════════════════
            # Determine active columns
            cols = ["PARTICULARS"]
            if show_opening or is_detailed_report:
                cols.append("OPENING_BAL")
            if show_tx or is_detailed_report:
                cols.append("TX_DEBIT")
                cols.append("TX_CREDIT")
            if show_closing or is_detailed_report or (not show_opening and not show_tx):
                cols.append("CLOSING_BAL")

            # Canvas with Custom Header & Table Rows for Pixel-Perfect Multi-Tier Layout
            tree = ttk.Treeview(self.table_fr, columns=cols, show="headings", height=28, selectmode="browse")

            tree.heading("PARTICULARS", text="PARTICULARS", anchor="w")
            tree.column("PARTICULARS", width=340, anchor="w")

            if "OPENING_BAL" in cols:
                tree.heading("OPENING_BAL", text="OPENING BALANCE", anchor="e")
                tree.column("OPENING_BAL", width=150, anchor="e")

            if "TX_DEBIT" in cols and "TX_CREDIT" in cols:
                tree.heading("TX_DEBIT", text="TRANSACTIONS (DEBIT)", anchor="e")
                tree.column("TX_DEBIT", width=130, anchor="e")
                tree.heading("TX_CREDIT", text="TRANSACTIONS (CREDIT)", anchor="e")
                tree.column("TX_CREDIT", width=130, anchor="e")

            if "CLOSING_BAL" in cols:
                tree.heading("CLOSING_BAL", text="CLOSING BALANCE", anchor="e")
                tree.column("CLOSING_BAL", width=150, anchor="e")

            style = ttk.Style()
            style.theme_use("clam")
            style.configure("Treeview", font=CELL_FONT, rowheight=22, background=BG_WHITE, fieldbackground=BG_WHITE)
            style.configure("Treeview.Heading", font=FONT_BOLD, background=BG_GRAY_HEADER, foreground="black")
            style.map("Treeview", background=[("selected", "#ffffa0")], foreground=[("selected", "black")])

            tree.tag_configure("group_bold", font=CELL_FONT_BOLD, background=BG_WHITE)
            tree.tag_configure("sub_item", font=CELL_FONT, background=BG_WHITE)
            tree.tag_configure("total_row", font=CELL_FONT_BOLD, background=BG_GRAY_HEADER)

            for g in groups:
                title = g['group_title']
                side = g['normal_side']

                # Group Row values
                vals = [title]
                if "OPENING_BAL" in cols:
                    vals.append(self.format_val(g['opening'], with_suffix=True, normal_side=side))
                if "TX_DEBIT" in cols and "TX_CREDIT" in cols:
                    vals.append(self.format_val(g['dr_tx']))
                    vals.append(self.format_val(g['cr_tx']))
                if "CLOSING_BAL" in cols:
                    vals.append(self.format_val(g['closing'], with_suffix=True, normal_side=side))

                tree.insert("", "end", values=vals, tags=("group_bold",))

                # Sub-items if Detailed Report is selected
                if is_detailed_report:
                    for sub in g['sub_items']:
                        sub_vals = [f"    {sub['name']}"]
                        if "OPENING_BAL" in cols:
                            sub_vals.append(self.format_val(sub['opening'], with_suffix=False, is_sub=True))
                        if "TX_DEBIT" in cols and "TX_CREDIT" in cols:
                            sub_vals.append(self.format_val(sub['dr_tx']))
                            sub_vals.append(self.format_val(sub['cr_tx']))
                        if "CLOSING_BAL" in cols:
                            sub_vals.append(self.format_val(sub['closing'], with_suffix=False, is_sub=True))

                        tree.insert("", "end", values=sub_vals, tags=("sub_item",))

            vsb = ttk.Scrollbar(self.table_fr, orient="vertical", command=tree.yview)
            hsb = ttk.Scrollbar(self.table_fr, orient="horizontal", command=tree.xview)
            tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)

            vsb.pack(side="right", fill="y")
            hsb.pack(side="bottom", fill="x")
            tree.pack(fill="both", expand=True)

    # ═════════════════════════════════════════════════════════════════════════
    #  EXPORTS: HTML, BROWSER, PRINT, EXCEL, WORD, PDF
    # ═════════════════════════════════════════════════════════════════════════

    def generate_html_report(self, for_print=False):
        """Generates high-fidelity HTML report identical to images."""
        data = self.get_trial_balance_raw_data()
        groups = data['groups']

        is_detailed_report = self.var_detailed.get()
        show_opening = self.var_op_bal.get()
        show_tx = self.var_tx.get()
        show_closing = self.var_cl_bal.get()
        is_multi_col = show_opening or show_tx or show_closing or is_detailed_report

        html = f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Trial Balance - {self.company_name}</title>
<style>
    @page {{ size: A4; margin: 15mm; }}
    body {{
        font-family: 'Segoe UI', Arial, sans-serif;
        color: #000;
        background-color: #f8f9fa;
        margin: 0;
        padding: 20px;
    }}
    .container {{
        max-width: 950px;
        margin: 0 auto;
        background: #fff;
        padding: 30px;
        box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }}
    .header {{
        margin-bottom: 20px;
    }}
    .company-name {{
        font-size: 16px;
        font-weight: bold;
        color: #205493;
        text-transform: uppercase;
        margin-bottom: 4px;
    }}
    .report-title {{
        font-size: 15px;
        font-weight: bold;
        color: #000;
        text-transform: uppercase;
        margin-bottom: 4px;
    }}
    .date-range {{
        font-size: 13px;
        color: #444;
    }}
    table {{
        width: 100%;
        border-collapse: collapse;
        margin-top: 15px;
        font-size: 13px;
    }}
    th {{
        background-color: #EEF2F5;
        color: #000;
        font-weight: bold;
        padding: 8px 10px;
        border-top: 1px solid #ccc;
        border-bottom: 1px solid #ccc;
        text-align: left;
    }}
    th.right {{ text-align: right; }}
    th.center {{ text-align: center; }}
    td {{
        padding: 6px 10px;
        border-bottom: 1px solid #f0f0f0;
    }}
    td.right {{ text-align: right; }}
    tr.group-row td {{
        font-weight: bold;
    }}
    tr.sub-row td {{
        font-weight: normal;
        color: #333;
    }}
    tr.sub-row td.particulars {{
        padding-left: 28px;
    }}
    tr.total-row td {{
        font-weight: bold;
        background-color: #EEF2F5;
        border-top: 1px solid #999;
        border-bottom: 2px solid #333;
        padding: 8px 10px;
    }}
    .underline {{ text-decoration: underline; }}
    .italic {{ font-style: italic; }}
    @media print {{
        body {{ background: #fff; padding: 0; }}
        .container {{ box-shadow: none; padding: 0; }}
        .no-print {{ display: none; }}
    }}
</style>
</head>
<body>
<div class="container">
    <div class="header">
        <div class="company-name">{self.company_name}</div>
        <div class="report-title">TRIAL BALANCE</div>
        <div class="date-range">{self.start_d} To {self.end_d}</div>
    </div>
"""

        if not is_multi_col:
            # 2-Column Summary Table
            html += """
    <table>
        <thead>
            <tr>
                <th style="width: 55%;">PARTICULARS</th>
                <th class="right" style="width: 22%;">DEBIT</th>
                <th class="right" style="width: 23%;">CREDIT</th>
            </tr>
        </thead>
        <tbody>
"""
            for g in groups:
                title = g['group_title']
                side = g['normal_side']
                close_val = g['closing']
                dr_str = self.format_val(close_val) if side == "Dr" else ""
                cr_str = self.format_val(close_val) if side == "Cr" else ""
                html += f"""
            <tr>
                <td>{title}</td>
                <td class="right">{dr_str}</td>
                <td class="right">{cr_str}</td>
            </tr>"""

            if data['opening_inventory'] > 0:
                inv_str = self.format_val(data['opening_inventory'])
                html += f"""
            <tr>
                <td class="underline">Opening Inventory</td>
                <td class="right">{inv_str}</td>
                <td class="right"></td>
            </tr>"""

            if data['diff_opening_val'] > 0:
                diff_str = self.format_val(data['diff_opening_val'])
                if data['diff_opening_side'] == "Cr":
                    html += f"""
            <tr>
                <td class="italic">Difference In Opening Balance</td>
                <td class="right"></td>
                <td class="right">{diff_str}</td>
            </tr>"""
                else:
                    html += f"""
            <tr>
                <td class="italic">Difference In Opening Balance</td>
                <td class="right">{diff_str}</td>
                <td class="right"></td>
            </tr>"""

            tot_dr_str = f"Rs{data['final_debit_total']:,.0f}"
            tot_cr_str = f"Rs{data['final_credit_total']:,.0f}"
            html += f"""
            <tr class="total-row">
                <td>TOTAL</td>
                <td class="right">{tot_dr_str}</td>
                <td class="right">{tot_cr_str}</td>
            </tr>
        </tbody>
    </table>
"""
        else:
            # Multi-Column Detailed Table
            html += """
    <table>
        <thead>
            <tr>
                <th rowspan="2" style="vertical-align: bottom; width: 35%;">PARTICULARS</th>
                <th class="right" rowspan="2" style="vertical-align: bottom; width: 18%;">OPENING BALANCE</th>
                <th class="center" colspan="2" style="border-bottom: 1px solid #ccc;">TRANSACTIONS</th>
                <th class="right" rowspan="2" style="vertical-align: bottom; width: 18%;">CLOSING BALANCE</th>
            </tr>
            <tr>
                <th class="right" style="width: 14%;">DEBIT</th>
                <th class="right" style="width: 15%;">CREDIT</th>
            </tr>
        </thead>
        <tbody>
"""
            for g in groups:
                title = g['group_title']
                side = g['normal_side']
                op_str = self.format_val(g['opening'], with_suffix=True, normal_side=side)
                dr_str = self.format_val(g['dr_tx'])
                cr_str = self.format_val(g['cr_tx'])
                cl_str = self.format_val(g['closing'], with_suffix=True, normal_side=side)

                html += f"""
            <tr class="group-row">
                <td>{title}</td>
                <td class="right">{op_str}</td>
                <td class="right">{dr_str}</td>
                <td class="right">{cr_str}</td>
                <td class="right">{cl_str}</td>
            </tr>"""

                if is_detailed_report:
                    for sub in g['sub_items']:
                        s_op = self.format_val(sub['opening'], with_suffix=False, is_sub=True)
                        s_dr = self.format_val(sub['dr_tx'])
                        s_cr = self.format_val(sub['cr_tx'])
                        s_cl = self.format_val(sub['closing'], with_suffix=False, is_sub=True)

                        html += f"""
            <tr class="sub-row">
                <td class="particulars">{sub['name']}</td>
                <td class="right">{s_op}</td>
                <td class="right">{s_dr}</td>
                <td class="right">{s_cr}</td>
                <td class="right">{s_cl}</td>
            </tr>"""

            html += """
        </tbody>
    </table>
"""

        if for_print:
            html += """
    <script>
        window.onload = function() { window.print(); }
    </script>
"""

        html += """
</div>
</body>
</html>
"""
        return html

    def export_browser(self):
        html = self.generate_html_report(for_print=False)
        out_path = os.path.abspath("temp_trial_balance.html")
        with open(out_path, "w", encoding="utf-8") as f:
            f.write(html)
        webbrowser.open("file://" + out_path)

    def export_print(self):
        html = self.generate_html_report(for_print=True)
        out_path = os.path.abspath("temp_trial_balance_print.html")
        with open(out_path, "w", encoding="utf-8") as f:
            f.write(html)
        webbrowser.open("file://" + out_path)

    def export_pdf(self):
        self.export_print()

    def export_word(self):
        html = self.generate_html_report(for_print=False)
        out_path = os.path.abspath("Trial_Balance.doc")
        with open(out_path, "w", encoding="utf-8") as f:
            f.write(html)
        try:
            os.startfile(out_path)
        except Exception:
            webbrowser.open("file://" + out_path)

    def export_excel(self):
        try:
            wb = openpyxl.Workbook()
            ws = wb.active
            ws.title = "Trial Balance"

            from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
            bold_font = Font(name="Segoe UI", size=10, bold=True)
            normal_font = Font(name="Segoe UI", size=9)
            header_font = Font(name="Segoe UI", size=12, bold=True)
            co_font = Font(name="Segoe UI", size=11, bold=True, color="205493")

            header_fill = PatternFill(start_color="EEF2F5", end_color="EEF2F5", fill_type="solid")
            thin_border = Border(
                left=Side(style='thin', color='D0D0D0'),
                right=Side(style='thin', color='D0D0D0'),
                top=Side(style='thin', color='D0D0D0'),
                bottom=Side(style='thin', color='D0D0D0')
            )

            # Header
            ws["A1"] = self.company_name
            ws["A1"].font = co_font
            ws["A2"] = "TRIAL BALANCE"
            ws["A2"].font = header_font
            ws["A3"] = f"{self.start_d} To {self.end_d}"
            ws["A3"].font = normal_font

            data = self.get_trial_balance_raw_data()
            groups = data['groups']
            is_detailed = self.var_detailed.get()

            row_idx = 5
            ws.cell(row=row_idx, column=1, value="PARTICULARS").font = bold_font
            ws.cell(row=row_idx, column=2, value="OPENING BALANCE").font = bold_font
            ws.cell(row=row_idx, column=3, value="DEBIT TX").font = bold_font
            ws.cell(row=row_idx, column=4, value="CREDIT TX").font = bold_font
            ws.cell(row=row_idx, column=5, value="CLOSING BALANCE").font = bold_font

            for c in range(1, 6):
                ws.cell(row=row_idx, column=c).fill = header_fill
                ws.cell(row=row_idx, column=c).border = thin_border

            row_idx += 1
            for g in groups:
                side = g['normal_side']
                ws.cell(row=row_idx, column=1, value=g['group_title']).font = bold_font
                ws.cell(row=row_idx, column=2, value=self.format_val(g['opening'], with_suffix=True, normal_side=side)).font = bold_font
                ws.cell(row=row_idx, column=3, value=g['dr_tx']).font = bold_font
                ws.cell(row=row_idx, column=4, value=g['cr_tx']).font = bold_font
                ws.cell(row=row_idx, column=5, value=self.format_val(g['closing'], with_suffix=True, normal_side=side)).font = bold_font
                row_idx += 1

                if is_detailed:
                    for sub in g['sub_items']:
                        ws.cell(row=row_idx, column=1, value=f"    {sub['name']}").font = normal_font
                        ws.cell(row=row_idx, column=2, value=sub['opening']).font = normal_font
                        ws.cell(row=row_idx, column=3, value=sub['dr_tx']).font = normal_font
                        ws.cell(row=row_idx, column=4, value=sub['cr_tx']).font = normal_font
                        ws.cell(row=row_idx, column=5, value=sub['closing']).font = normal_font
                        row_idx += 1

            ws.column_dimensions['A'].width = 35
            ws.column_dimensions['B'].width = 20
            ws.column_dimensions['C'].width = 16
            ws.column_dimensions['D'].width = 16
            ws.column_dimensions['E'].width = 20

            out_path = os.path.abspath("Trial_Balance.xlsx")
            wb.save(out_path)
            try:
                os.startfile(out_path)
            except Exception:
                pass
            messagebox.showinfo("Success", f"Excel exported successfully:\n{out_path}", parent=self)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to export Excel:\n{e}", parent=self)

if __name__ == "__main__":
    root = tk.Tk()
    root.withdraw()
    app = ReportTrialBalance(root)
    root.mainloop()
