with open('invoice_preview.py', 'r', encoding='utf-8') as f:
    content = f.read()

t1 = '''    title_text = "PURCHASE" if v_type == "purchase" else "SALES INVOICE"'''
r1 = '''    title_text = "PURCHASE ORDER" if v_type == "purchase_order" else ("PURCHASE" if v_type == "purchase" else "SALES INVOICE")'''
content = content.replace(t1, r1)

t2 = '''    tk.Label(bill_to_fr, text="Bill From:" if v_type == "purchase" else "Bill To:", font=("Arial", 10, "bold"), bg="white").pack(anchor="w")'''
r2 = '''    tk.Label(bill_to_fr, text="Bill From:" if v_type in ["purchase", "purchase_order"] else "Bill To:", font=("Arial", 10, "bold"), bg="white").pack(anchor="w")'''
content = content.replace(t2, r2)

t3 = '''    tk.Label(details_fr, text="Purchase No" if v_type == "purchase" else "Invoice No", font=("Arial", 9, "bold"), bg="white", width=12, anchor="w").grid(row=0, column=0, sticky="w", pady=2)'''
r3 = '''    tk.Label(details_fr, text="Purchase Order No" if v_type == "purchase_order" else ("Purchase No" if v_type == "purchase" else "Invoice No"), font=("Arial", 9, "bold"), bg="white", width=12, anchor="w").grid(row=0, column=0, sticky="w", pady=2)'''
content = content.replace(t3, r3)

t4 = '''    if v_type == "purchase":
        tk.Label(details_fr, text="Supplier Invoice No", font=("Arial", 9, "bold"), bg="white", width=15, anchor="w").grid(row=2, column=0, sticky="w", pady=2)'''
r4 = '''    if v_type in ["purchase", "purchase_order"]:
        tk.Label(details_fr, text="Supplier Ref No" if v_type == "purchase_order" else "Supplier Invoice No", font=("Arial", 9, "bold"), bg="white", width=15, anchor="w").grid(row=2, column=0, sticky="w", pady=2)'''
content = content.replace(t4, r4)

t5 = '''    tk.Label(bot_frame, text=f"Total: {round(total_val)}", font=("Arial", 12, "bold"), bg="white").pack(side="right", padx=10)'''
r5 = '''    tk.Label(bot_frame, text=f"Total: {round(total_val)}", font=("Arial", 12, "bold"), bg="white").pack(side="right", padx=10)
    
    terms = inv_data.get("terms", "")
    if terms:
        terms_fr = tk.Frame(container, bg="white")
        terms_fr.pack(fill="x", pady=20)
        tk.Label(terms_fr, text="Terms & Conditions:", font=("Arial", 10, "bold"), bg="white").pack(anchor="w")
        tk.Label(terms_fr, text=terms, font=("Arial", 9), bg="white", justify="left").pack(anchor="w", pady=4)'''
content = content.replace(t5, r5)

with open('invoice_preview.py', 'w', encoding='utf-8') as f:
    f.write(content)

print("Patch applied for invoice_preview!")
