import re
from autocomplete import AutocompleteCombobox

with open('bookkeeper.py', 'r', encoding='utf-8') as f:
    content = f.read()

new_form = '''    def _account_form(self, acc_type, existing=None):
        win = tk.Toplevel(self)
        win.title("Create Account" if not existing else "Edit Account")
        win.geometry("900x650")
        win.resizable(False, False)
        win.configure(bg="#ffffff")
        win.grab_set()

        tk.Label(win, text="Press ENTER to move forward  SHIFT+ENTER to move back.", 
                 fg="darkred", bg="#ffffff", font=(FONT[0], 10, "italic", "bold")).place(x=10, y=5)

        fields = {}
        widgets = []

        def register_widget(w):
            widgets.append(w)
            w.bind("<Return>", lambda e: focus_next(w))
            w.bind("<Shift-Return>", lambda e: focus_prev(w))
            return w

        def focus_next(current):
            try:
                idx = widgets.index(current)
                widgets[(idx + 1) % len(widgets)].focus_set()
            except: pass
            return "break"

        def focus_prev(current):
            try:
                idx = widgets.index(current)
                widgets[(idx - 1) % len(widgets)].focus_set()
            except: pass
            return "break"

        def create_lbl(x, y, text):
            tk.Label(win, text=text, bg="#ffffff", fg="#000", font=FONT).place(x=x, y=y)

        def create_entry(x, y, w, bg="#ffffff"):
            e = tk.Entry(win, font=FONT, width=w, relief="solid", bd=1, bg=bg)
            e.place(x=x, y=y)
            return register_widget(e)
            
        def create_combo(x, y, w, vals):
            c = AutocompleteCombobox(win, font=FONT, width=w-2, values=vals)
            c.place(x=x, y=y)
            return register_widget(c)

        cx1, cx2, cx3 = 10, 300, 560

        # Col 1
        create_lbl(cx1, 35, "Account Name")
        fields['aname'] = create_entry(cx1, 55, 28, bg="#ffff00")
        
        tk.Label(win, text="Video: How to Create Group/Subgroup?", fg="blue", bg="#ffffff", font=(FONT[0], 9, "underline")).place(x=cx1, y=85)
        
        create_lbl(cx1, 110, "Account Type")
        fields['a_type'] = create_combo(cx1, 130, 28, ["Account", "Subgroup", "Group"])
        fields['a_type'].set(acc_type or "Account")
        
        create_lbl(cx1, 160, "Opening balance")
        fields['op_bal'] = create_entry(cx1, 180, 28)
        fields['op_bal'].insert(0, "0")
        
        tk.Label(win, text="For credit balance of customers,\\nEnter amount in negative (-)", bg="#ffffff", fg="#000", justify="left").place(x=cx1, y=205)
        
        bank_var = tk.IntVar()
        cb = tk.Checkbutton(win, text="Bank Details", variable=bank_var, bg="#ffffff", fg="#000")
        cb.place(x=cx1, y=280)
        register_widget(cb)

        # Col 2
        create_lbl(cx2, 35, "Display Name")
        fields['display_name'] = create_entry(cx2, 55, 25)
        
        create_lbl(cx2, 110, "Account Group")
        fields['account_group'] = create_combo(cx2, 130, 25, ["Sundry Debtors", "Sundry Creditors", "Cash-in-hand", "Bank A/Cs"])
        fields['account_group'].set("Sundry Debtors" if acc_type == 'customer' else "Sundry Creditors")
        
        create_lbl(cx2, 160, "Account Creation Date")
        if DateEntry:
            de = DateEntry(win, width=23, background='darkblue', foreground='white', borderwidth=2, font=FONT)
            de.place(x=cx2, y=180)
            fields['date_created'] = register_widget(de)
        else:
            fields['date_created'] = create_entry(cx2, 180, 25)
            fields['date_created'].insert(0, datetime.datetime.now().strftime("%B %d, %Y"))

        # Col 3
        create_lbl(cx3, 10, "GST No")
        fields['tax_regn'] = create_entry(cx3, 30, 18)
        
        create_lbl(cx3, 60, "Country")
        fields['country'] = create_combo(cx3, 80, 30, ["Pakistan", "India", "USA", "UK"])
        fields['country'].set("Pakistan")
        
        create_lbl(cx3, 110, "ZIP Code")
        fields['pincode'] = create_entry(cx3, 130, 30)
        
        create_lbl(cx3, 160, "Address")
        fields['address'] = create_entry(cx3, 180, 30)
        fields['address2'] = create_entry(cx3, 205, 30)
        
        create_lbl(cx3, 235, "Shipping Address")
        same_var = tk.IntVar()
        cb2 = tk.Checkbutton(win, text="Same As Above", variable=same_var, bg="#ffffff", fg="#000")
        cb2.place(x=cx3+120, y=235)
        register_widget(cb2)
        fields['ship_addr_1'] = create_entry(cx3, 255, 30)
        fields['ship_addr_2'] = create_entry(cx3, 280, 30)
        
        create_lbl(cx3, 310, "Credit Period")
        sb = ttk.Spinbox(win, from_=0, to=365, width=8, font=FONT)
        sb.place(x=cx3, y=330)
        sb.set("0")
        fields['credit_period'] = register_widget(sb)
        
        create_lbl(cx3+120, 310, "Credit Limit")
        fields['credit_limit'] = create_entry(cx3+120, 330, 16)
        
        create_lbl(cx3, 360, "Discount Type")
        fields['discount_type'] = create_combo(cx3, 380, 30, ["Item Default Discount", "Percentage", "Amount"])
        fields['discount_type'].set("Item Default Discount")
        
        create_lbl(cx3, 410, "Phone Number")
        fields['phone'] = create_entry(cx3, 430, 30)
        
        create_lbl(cx3, 460, "Email id")
        fields['email_id'] = create_entry(cx3, 480, 30)
        
        create_lbl(cx3, 510, "Tax No. 2")
        fields['tax_regn2'] = create_entry(cx3, 530, 13)
        
        create_lbl(cx3+140, 510, "Tax No. 3")
        fields['tax_regn3'] = create_entry(cx3+140, 530, 13)
        
        create_lbl(cx3, 560, "Remarks")
        fields['remarks'] = create_entry(cx3, 580, 30)
        
        tk.Label(win, text="You can change address/tax labels in Settings >\\nTemplate Settings.", bg="#ffffff", fg="#000", justify="left", font=(FONT[0], 8)).place(x=cx3, y=605)

        if existing:
            for k, w in fields.items():
                if k in existing and existing[k] is not None:
                    if isinstance(w, tk.Entry):
                        w.delete(0, "end")
                        w.insert(0, str(existing[k]))
                    elif isinstance(w, AutocompleteCombobox):
                        w.set(str(existing[k]))

        def save(event=None):
            data = {}
            for k, w in fields.items():
                val = w.get() if hasattr(w, "get") else ""
                if isinstance(val, str): val = val.strip()
                data[k] = val

            if not data["aname"]:
                messagebox.showerror("Error", "Account Name is required!", parent=win)
                fields["aname"].focus_set()
                return
                
            try:
                if data.get("op_bal"): data["op_bal"] = float(data["op_bal"])
            except ValueError:
                messagebox.showerror("Error", "Opening Balance must be a number!", parent=win)
                return

            try:
                if existing:
                    db.update_account(existing["id"], data)
                else:
                    db.add_account(data)
                win.destroy()
                self._account_list(acc_type, "Accounts")
            except Exception as e:
                messagebox.showerror("Database Error", str(e), parent=win)

        win.bind("<Control-q>", lambda e: win.destroy())
        win.bind("<F12>", save)

        tk.Button(win, text="Ctrl+Q: Exit", bg="#e0e0e0", font=FONT, command=win.destroy, relief="solid", bd=1).place(x=10, y=605, width=120, height=30)
        tk.Button(win, text="F12:Save", bg="#e0e0e0", font=FONT, command=save, relief="solid", bd=1).place(x=cx2, y=605, width=120, height=30)
        
        fields["aname"].focus_set()
'''

pattern = re.compile(r"    def _account_form\(self, acc_type, existing=None\):.*?        make_button\(bf, \"  .*?  Cancel  \", command=win\.destroy, width=10\)\.pack\(side=\"left\", padx=6\)", re.DOTALL)
content = pattern.sub(new_form, content)

# Add tkcalendar import if not present
if "from tkcalendar import DateEntry" not in content:
    content = content.replace("import tkinter as tk", "try:\\n    from tkcalendar import DateEntry\\nexcept ImportError:\\n    DateEntry = None\\n\\nimport tkinter as tk", 1)

with open('bookkeeper.py', 'w', encoding='utf-8') as f:
    f.write(content)
