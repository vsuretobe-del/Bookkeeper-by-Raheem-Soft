with open('bookkeeper.py', 'r', encoding='utf-8') as f:
    lines = f.readlines()

new_lines = lines[:2216] + lines[2268:]

with open('bookkeeper.py', 'w', encoding='utf-8') as f:
    f.writelines(new_lines)
print("Deleted duplicate block by line numbers")
