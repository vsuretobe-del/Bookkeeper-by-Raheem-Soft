with open('bookkeeper.py', 'r', encoding='utf-8') as f:
    lines = f.readlines()

# find the exact start and end line indices
start_idx = -1
end_idx = -1

for i, line in enumerate(lines):
    if "                # Narration + totals section" in line and "bot_frame = tk.Frame(win, bg=BG)" in lines[i+1]:
        start_idx = i
    if "lambda e: grid_canvas.yview_scroll(-1*(e.delta//120), \"units\"))" in line and "        # Grid header columns" in lines[i+2]:
        end_idx = i

if start_idx != -1 and end_idx != -1 and start_idx < end_idx:
    print(f"Deleting lines from {start_idx} to {end_idx}")
    new_lines = lines[:start_idx] + lines[end_idx+1:]
    with open('bookkeeper.py', 'w', encoding='utf-8') as f:
        f.writelines(new_lines)
    print("Success")
else:
    print(f"Failed to find indices: start={start_idx}, end={end_idx}")

