import traceback
import sys
import os

try:
    import bookkeeper
    import db
    conn = db.get_conn()
    conn.row_factory = __import__('sqlite3').Row
    v = conn.execute("SELECT * FROM vouchers WHERE v_type='expense' LIMIT 1").fetchone()
    if v:
        v_dict = dict(v)
        v_dict['id'] = v_dict['v_id']
        app = bookkeeper.BookKeeperApp()
        app._open_expense_voucher(edit_inv=v_dict)
        print('Expense window opened successfully')
    else:
        print('No expense voucher found')
except Exception as e:
    print('Exception in expense:')
    traceback.print_exc()

try:
    v2 = conn.execute("SELECT * FROM vouchers WHERE v_type='sale' LIMIT 1").fetchone()
    if v2:
        v2_dict = dict(v2)
        v2_dict['id'] = v2_dict['v_id']
        app2 = bookkeeper.BookKeeperApp()
        app2._open_create_voucher('sale', edit_inv=v2_dict)
        print('Sale window opened successfully')
except Exception as e:
    print('Exception in sale:')
    traceback.print_exc()
