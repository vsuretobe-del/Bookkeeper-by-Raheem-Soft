import re

with open('bookkeeper.py', 'r', encoding='utf-8') as f:
    content = f.read()

start_marker = "        if existing:"
end_marker = "            except ValueError:"

start_idx = content.find(start_marker)
end_idx = content.find(end_marker)

if start_idx == -1 or end_idx == -1:
    print("Markers not found")
    exit(1)

new_code = '''        if existing:
            for k, w in fields.items():
                if k in existing and existing[k] is not None:
                    if hasattr(w, 'set'):
                        w.set(existing[k])
                    elif hasattr(w, 'insert'):
                        w.delete(0, "end")
                        w.insert(0, str(existing[k]))
                    elif hasattr(w, 'delete'):
                        w.delete("1.0", "end")
                        w.insert("1.0", str(existing[k]))
            calc_inc()

        def save(e=None):
            data = {}
            for k, var in fields.items():
                data[k] = var.get() if hasattr(var, 'get') else var.get("1.0", "end-1c").strip()
                
            name = data.get('item', '').strip()
            if not name:
                messagebox.showerror("Error", "Item Name is required!", parent=win)
                fields['item'].focus_set()
                return

            try:
'''

new_content = content[:start_idx] + new_code + content[end_idx:]

with open('bookkeeper.py', 'w', encoding='utf-8') as f:
    f.write(new_content)

print("Patch applied for existing")
