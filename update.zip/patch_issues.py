with open('bookkeeper.py', 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Fix 3 blank rows
content = content.replace("for _ in range(3):\n            add_grid_row()", "for _ in range(1):\n            add_grid_row()")

# 2. Fix Auto Rate on add_grid_row
target_row = '''            for widget in grid_inner.grid_slaves(row=ri):
                widget.bind("<Delete>", lambda e, d=row_dict: del_row(d))'''
replacement_row = '''            for widget in grid_inner.grid_slaves(row=ri):
                widget.bind("<Delete>", lambda e, d=row_dict: del_row(d))
            if item_name:
                on_item_select()'''
content = content.replace(target_row, replacement_row)

# 3. Fix Reference Document buttons
target_ref = '''        tk.Button(ref_btn_fr, text="Browse", bg="#e0e0e0", relief="flat", bd=1).pack(side="left", padx=2, fill="x", expand=True)
        tk.Button(ref_btn_fr, text="View", bg="#e0e0e0", relief="flat", bd=1).pack(side="left", padx=2, fill="x", expand=True)
        tk.Button(ref_btn_fr, text="Delete", bg="#e0e0e0", relief="flat", bd=1).pack(side="left", padx=2, fill="x", expand=True)'''

replacement_ref = '''        def on_browse_ref():
            from tkinter import filedialog
            path = filedialog.askopenfilename(parent=win, title="Select Reference Document")
            if path: ref_var.set(path)
                
        def on_view_ref():
            import os
            path = ref_var.get()
            if path and os.path.exists(path):
                try: os.startfile(path)
                except Exception as e: messagebox.showerror("Error", str(e), parent=win)
            else: messagebox.showerror("Error", "Document not found or path is empty.", parent=win)
                
        def on_delete_ref():
            ref_var.set("")
            
        tk.Button(ref_btn_fr, text="Browse", bg="#e0e0e0", relief="flat", bd=1, command=on_browse_ref).pack(side="left", padx=2, fill="x", expand=True)
        tk.Button(ref_btn_fr, text="View", bg="#e0e0e0", relief="flat", bd=1, command=on_view_ref).pack(side="left", padx=2, fill="x", expand=True)
        tk.Button(ref_btn_fr, text="Delete", bg="#e0e0e0", relief="flat", bd=1, command=on_delete_ref).pack(side="left", padx=2, fill="x", expand=True)'''

content = content.replace(target_ref, replacement_ref)

with open('bookkeeper.py', 'w', encoding='utf-8') as f:
    f.write(content)

print("Patch applied for 3 issues!")
