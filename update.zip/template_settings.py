import tkinter as tk
from tkinter import ttk, messagebox
import db
from autocomplete import AutocompleteCombobox

FONT = ("Segoe UI", 10)
FONT_BOLD = ("Segoe UI", 10, "bold")
FONT_TITLE = ("Segoe UI", 12, "bold")
BG = "#f0f0f0"
BG_WHITE = "#ffffff"

class TemplateSettingsWindow(tk.Toplevel):
    def __init__(self, master):
        super().__init__(master)
        self.title("Template Settings")
        self.geometry("1100x750")
        self.configure(bg=BG)
        self.grab_set()
        self.transient(master)

        self._load_settings()
        self._build_ui()
        self._update_preview()

        # Keyboard bindings
        self.bind("<Control-q>", lambda e: self.destroy())
        self.bind("<Control-Q>", lambda e: self.destroy())
        self.bind("<F12>", lambda e: self.save_settings())

    def _load_settings(self):
        self.settings = {
            "tmpl_invoice_template": db.get_setting("tmpl_invoice_template", "Template1-Box"),
            "tmpl_printer_type": db.get_setting("tmpl_printer_type", "Default (A4 / A5)"),
            "tmpl_font_size": db.get_setting("tmpl_font_size", "15"),
            "tmpl_font_style": db.get_setting("tmpl_font_style", "Calibri"),
            "tmpl_items_per_page": db.get_setting("tmpl_items_per_page", "Default"),
            "tmpl_row_spacing": db.get_setting("tmpl_row_spacing", "1"),

            "tmpl_hdr_show_logo": int(db.get_setting("tmpl_hdr_show_logo", "1")),
            "tmpl_hdr_show_name": int(db.get_setting("tmpl_hdr_show_name", "1")),
            "tmpl_hdr_show_addr": int(db.get_setting("tmpl_hdr_show_addr", "1")),
            "tmpl_hdr_show_tax": int(db.get_setting("tmpl_hdr_show_tax", "1")),
            "tmpl_hdr_show_contact": int(db.get_setting("tmpl_hdr_show_contact", "1")),
            "tmpl_hdr_doc_title": db.get_setting("tmpl_hdr_doc_title", "Sales Invoice"),

            "tmpl_tbl_show_sr": int(db.get_setting("tmpl_tbl_show_sr", "1")),
            "tmpl_tbl_show_hsn": int(db.get_setting("tmpl_tbl_show_hsn", "1")),
            "tmpl_tbl_show_brand": int(db.get_setting("tmpl_tbl_show_brand", "0")),
            "tmpl_tbl_show_batch": int(db.get_setting("tmpl_tbl_show_batch", "0")),
            "tmpl_tbl_show_expiry": int(db.get_setting("tmpl_tbl_show_expiry", "0")),
            "tmpl_tbl_show_mrp": int(db.get_setting("tmpl_tbl_show_mrp", "0")),
            "tmpl_tbl_show_disc": int(db.get_setting("tmpl_tbl_show_disc", "1")),
            "tmpl_tbl_show_tax": int(db.get_setting("tmpl_tbl_show_tax", "1")),

            "tmpl_ftr_show_bank": int(db.get_setting("tmpl_ftr_show_bank", "1")),
            "tmpl_ftr_show_terms": int(db.get_setting("tmpl_ftr_show_terms", "1")),
            "tmpl_ftr_show_sig": int(db.get_setting("tmpl_ftr_show_sig", "1")),
            "tmpl_ftr_show_words": int(db.get_setting("tmpl_ftr_show_words", "1")),
            "tmpl_ftr_terms_text": db.get_setting("tmpl_ftr_terms_text", "1. Goods once sold will not be taken back.\n2. Interest @ 18% will be charged if payment not received within due date."),
            "tmpl_ftr_declaration": db.get_setting("tmpl_ftr_declaration", "This is computer generated invoice"),

            "tmpl_misc_round": int(db.get_setting("tmpl_misc_round", "1")),
            "tmpl_misc_outstanding": int(db.get_setting("tmpl_misc_outstanding", "1")),
            "tmpl_misc_duplicate_mark": int(db.get_setting("tmpl_misc_duplicate_mark", "0")),

            "tmpl_cust_header_color": db.get_setting("tmpl_cust_header_color", "#e0e0e0"),
            "tmpl_cust_text_color": db.get_setting("tmpl_cust_text_color", "#000000"),
            "tmpl_cust_border_color": db.get_setting("tmpl_cust_border_color", "#cccccc")
        }

    def _build_ui(self):
        # Top Tab Notebook
        self.nb = ttk.Notebook(self)
        self.nb.pack(fill="both", expand=True, padx=10, pady=(10, 50))

        # Define Tabs
        self.tab_template = tk.Frame(self.nb, bg=BG_WHITE)
        self.tab_header = tk.Frame(self.nb, bg=BG_WHITE)
        self.tab_table = tk.Frame(self.nb, bg=BG_WHITE)
        self.tab_footer = tk.Frame(self.nb, bg=BG_WHITE)
        self.tab_misc = tk.Frame(self.nb, bg=BG_WHITE)
        self.tab_customize = tk.Frame(self.nb, bg=BG_WHITE)

        self.nb.add(self.tab_template, text="Template")
        self.nb.add(self.tab_header, text="Header")
        self.nb.add(self.tab_table, text="Item Table")
        self.nb.add(self.tab_footer, text="Footer")
        self.nb.add(self.tab_misc, text="Misc.")
        self.nb.add(self.tab_customize, text="Customize")

        # Setup each tab
        self._setup_template_tab()
        self._setup_header_tab()
        self._setup_table_tab()
        self._setup_footer_tab()
        self._setup_misc_tab()
        self._setup_customize_tab()

        # Bottom Frame
        bot = tk.Frame(self, bg=BG)
        bot.pack(fill="x", side="bottom", ipady=5)
        
        btn_exit = tk.Button(bot, text="Ctrl+Q: Exit", font=FONT, bg="#e0e0e0", relief="solid", bd=1, width=15, command=self.destroy)
        btn_exit.pack(side="left", padx=15, pady=8)

        lbl_video = tk.Label(bot, text="Video: How to Change Template Settings", font=("Segoe UI", 9, "underline"), fg="blue", bg=BG, cursor="hand2")
        lbl_video.pack(side="left", expand=True)

        btn_save = tk.Button(bot, text="F12: Save", font=FONT, bg="#e0e0e0", relief="solid", bd=1, width=15, command=self.save_settings)
        btn_save.pack(side="right", padx=15, pady=8)

    def _setup_template_tab(self):
        # Two panes: Left for Comboboxes, Right for Canvas Invoice Preview and Sample Font Text
        self.tab_template.columnconfigure(0, weight=1)
        self.tab_template.columnconfigure(1, weight=1)

        left_pane = tk.Frame(self.tab_template, bg=BG_WHITE, padx=20, pady=20)
        left_pane.grid(row=0, column=0, sticky="nsew")

        right_pane = tk.Frame(self.tab_template, bg=BG_WHITE, padx=20, pady=20)
        right_pane.grid(row=0, column=1, sticky="nsew")

        # Left controls
        tk.Label(left_pane, text="Invoice Template", font=FONT, bg=BG_WHITE).pack(anchor="w", pady=(5, 2))
        self.v_tmpl = tk.StringVar(value=self.settings["tmpl_invoice_template"])
        self.cb_tmpl = AutocompleteCombobox(left_pane, textvariable=self.v_tmpl, font=FONT, state="readonly", width=40)
        self.cb_tmpl["values"] = ["Default", "None", "Template1", "Template1-Box", "Template1-FullBox", "Template1-ColorBox", "Template2", "Template3", "Template3-Box", "Template3-ColorBox"]
        self.cb_tmpl.pack(anchor="w", pady=(0, 10))
        self.cb_tmpl.bind("<<ComboboxSelected>>", self._on_tmpl_changed)

        tk.Label(left_pane, text="Printer Type", font=FONT, bg=BG_WHITE).pack(anchor="w", pady=(5, 2))
        self.v_print_type = tk.StringVar(value=self.settings["tmpl_printer_type"])
        self.cb_print_type = AutocompleteCombobox(left_pane, textvariable=self.v_print_type, font=FONT, state="readonly", width=40)
        self.cb_print_type["values"] = ["Default (A4 / A5)", "Thermal Printer (2\" or 58 mm Paper Roll)", "Thermal Printer (3\" or 80 mm Paper Roll)", "Dot Matrix Printer"]
        self.cb_print_type.pack(anchor="w", pady=(0, 10))

        tk.Label(left_pane, text="Font Size", font=FONT, bg=BG_WHITE).pack(anchor="w", pady=(5, 2))
        self.v_font_size = tk.StringVar(value=self.settings["tmpl_font_size"])
        self.cb_font_size = AutocompleteCombobox(left_pane, textvariable=self.v_font_size, font=FONT, state="readonly", width=40)
        self.cb_font_size["values"] = ["8", "10", "12", "15", "17", "20", "22"]
        self.cb_font_size.pack(anchor="w", pady=(0, 10))
        self.cb_font_size.bind("<<ComboboxSelected>>", self._on_font_changed)

        tk.Label(left_pane, text="Font Style", font=FONT, bg=BG_WHITE).pack(anchor="w", pady=(5, 2))
        self.v_font_style = tk.StringVar(value=self.settings["tmpl_font_style"])
        self.cb_font_style = AutocompleteCombobox(left_pane, textvariable=self.v_font_style, font=FONT, state="readonly", width=40)
        self.cb_font_style["values"] = ["Arial Narrow", "Calibri", "Comic Sans MS", "Ganeva", "Georgia", "Lucida Calligraphy", "Monospace", "Monotype Corsiva", "Palatino Linotype", "Serif", "Times New Roman"]
        self.cb_font_style.pack(anchor="w", pady=(0, 10))
        self.cb_font_style.bind("<<ComboboxSelected>>", self._on_font_changed)

        tk.Label(left_pane, text="Number of Items Per Page", font=FONT, bg=BG_WHITE).pack(anchor="w", pady=(5, 2))
        self.v_items_page = tk.StringVar(value=self.settings["tmpl_items_per_page"])
        self.cb_items_page = AutocompleteCombobox(left_pane, textvariable=self.v_items_page, font=FONT, state="readonly", width=40)
        self.cb_items_page["values"] = ["Default", "5", "10", "15", "20", "30"]
        self.cb_items_page.pack(anchor="w", pady=(0, 10))

        tk.Label(left_pane, text="Row Spacing Between Items", font=FONT, bg=BG_WHITE).pack(anchor="w", pady=(5, 2))
        self.v_row_spacing = tk.StringVar(value=self.settings["tmpl_row_spacing"])
        self.cb_row_spacing = AutocompleteCombobox(left_pane, textvariable=self.v_row_spacing, font=FONT, state="readonly", width=40)
        self.cb_row_spacing["values"] = ["0.5", "1", "1.5", "2"]
        self.cb_row_spacing.pack(anchor="w", pady=(0, 10))

        # Right pane preview
        # 1. Mock Invoice Canvas drawing
        self.preview_canvas = tk.Canvas(right_pane, width=320, height=420, bg="#ffffff", highlightthickness=1, highlightbackground="#cccccc")
        self.preview_canvas.pack(pady=10)

        # 2. Dynamic Text Sample Label
        self.lbl_sample = tk.Label(right_pane, text="This is sample", bg=BG_WHITE, fg="#000000")
        self.lbl_sample.pack(pady=15)

    def _setup_header_tab(self):
        p = tk.Frame(self.tab_header, bg=BG_WHITE, padx=30, pady=30)
        p.pack(fill="both", expand=True)

        self.vars = {}
        def check(var_name, label_text):
            self.vars[var_name] = tk.IntVar(value=self.settings[var_name])
            tk.Checkbutton(p, text=label_text, variable=self.vars[var_name], font=FONT, bg=BG_WHITE, activebackground=BG_WHITE).pack(anchor="w", pady=4)

        check("tmpl_hdr_show_logo", "Show Company Logo")
        check("tmpl_hdr_show_name", "Show Company Name")
        check("tmpl_hdr_show_addr", "Show Company Address")
        check("tmpl_hdr_show_tax", "Show Tax/GST Number")
        check("tmpl_hdr_show_contact", "Show Contact Details (Phone/Email)")

        tk.Label(p, text="Document Title (e.g. Sales Invoice)", font=FONT, bg=BG_WHITE).pack(anchor="w", pady=(15, 2))
        self.v_doc_title = tk.StringVar(value=self.settings["tmpl_hdr_doc_title"])
        tk.Entry(p, textvariable=self.v_doc_title, font=FONT, width=40, relief="solid", bd=1).pack(anchor="w")

    def _setup_table_tab(self):
        p = tk.Frame(self.tab_table, bg=BG_WHITE, padx=30, pady=30)
        p.pack(fill="both", expand=True)

        def check(var_name, label_text):
            self.vars[var_name] = tk.IntVar(value=self.settings[var_name])
            tk.Checkbutton(p, text=label_text, variable=self.vars[var_name], font=FONT, bg=BG_WHITE, activebackground=BG_WHITE).pack(anchor="w", pady=4)

        check("tmpl_tbl_show_sr", "Show Sr No. Column")
        check("tmpl_tbl_show_hsn", "Show HSN/SAC Column")
        check("tmpl_tbl_show_brand", "Show Brand Column")
        check("tmpl_tbl_show_batch", "Show Batch Number")
        check("tmpl_tbl_show_expiry", "Show Expiry Date")
        check("tmpl_tbl_show_mrp", "Show MRP Column")
        check("tmpl_tbl_show_disc", "Show Discount Column")
        check("tmpl_tbl_show_tax", "Show Tax Percentage/Amount Column")

    def _setup_footer_tab(self):
        p = tk.Frame(self.tab_footer, bg=BG_WHITE, padx=30, pady=30)
        p.pack(fill="both", expand=True)

        def check(var_name, label_text):
            self.vars[var_name] = tk.IntVar(value=self.settings[var_name])
            tk.Checkbutton(p, text=label_text, variable=self.vars[var_name], font=FONT, bg=BG_WHITE, activebackground=BG_WHITE).pack(anchor="w", pady=4)

        check("tmpl_ftr_show_bank", "Show Bank Account details (IFSC/Account No)")
        check("tmpl_ftr_show_terms", "Show Terms & Conditions")
        check("tmpl_ftr_show_sig", "Show Signature Block")
        check("tmpl_ftr_show_words", "Show Grand Total in Words")

        tk.Label(p, text="Terms & Conditions text", font=FONT, bg=BG_WHITE).pack(anchor="w", pady=(15, 2))
        self.txt_terms = tk.Text(p, font=FONT, width=65, height=4, relief="solid", bd=1)
        self.txt_terms.pack(anchor="w", pady=(0, 10))
        self.txt_terms.insert("1.0", self.settings["tmpl_ftr_terms_text"])

        tk.Label(p, text="Footer Declaration / Note", font=FONT, bg=BG_WHITE).pack(anchor="w", pady=(5, 2))
        self.v_decl = tk.StringVar(value=self.settings["tmpl_ftr_declaration"])
        tk.Entry(p, textvariable=self.v_decl, font=FONT, width=65, relief="solid", bd=1).pack(anchor="w")

    def _setup_misc_tab(self):
        p = tk.Frame(self.tab_misc, bg=BG_WHITE, padx=30, pady=30)
        p.pack(fill="both", expand=True)

        def check(var_name, label_text):
            self.vars[var_name] = tk.IntVar(value=self.settings[var_name])
            tk.Checkbutton(p, text=label_text, variable=self.vars[var_name], font=FONT, bg=BG_WHITE, activebackground=BG_WHITE).pack(anchor="w", pady=4)

        check("tmpl_misc_round", "Round off grand total to nearest integer")
        check("tmpl_misc_outstanding", "Show outstanding balances of customer/supplier on invoice")
        check("tmpl_misc_duplicate_mark", "Show 'DUPLICATE' watermark for reprinted copies")

    def _setup_customize_tab(self):
        p = tk.Frame(self.tab_customize, bg=BG_WHITE, padx=30, pady=30)
        p.pack(fill="both", expand=True)

        tk.Label(p, text="Color Customization for Premium Templates", font=FONT_TITLE, bg=BG_WHITE).pack(anchor="w", pady=(0, 20))

        # Color entries
        tk.Label(p, text="Template Accent / Header Color", font=FONT, bg=BG_WHITE).pack(anchor="w", pady=2)
        self.v_accent_color = tk.StringVar(value=self.settings["tmpl_cust_header_color"])
        tk.Entry(p, textvariable=self.v_accent_color, font=FONT, width=20, relief="solid", bd=1).pack(anchor="w", pady=(0, 10))

        tk.Label(p, text="Table Borders Color", font=FONT, bg=BG_WHITE).pack(anchor="w", pady=2)
        self.v_border_color = tk.StringVar(value=self.settings["tmpl_cust_border_color"])
        tk.Entry(p, textvariable=self.v_border_color, font=FONT, width=20, relief="solid", bd=1).pack(anchor="w", pady=(0, 10))

        tk.Label(p, text="Accent Text Color", font=FONT, bg=BG_WHITE).pack(anchor="w", pady=2)
        self.v_text_color = tk.StringVar(value=self.settings["tmpl_cust_text_color"])
        tk.Entry(p, textvariable=self.v_text_color, font=FONT, width=20, relief="solid", bd=1).pack(anchor="w", pady=(0, 10))

    def _on_tmpl_changed(self, event=None):
        self._update_preview()

    def _on_font_changed(self, event=None):
        try:
            sz = int(self.v_font_size.get())
        except:
            sz = 14
        family = self.v_font_style.get()
        self.lbl_sample.configure(font=(family, sz))

    def _update_preview(self):
        self.preview_canvas.delete("all")
        tmpl = self.v_tmpl.get()
        
        # Draw paper background
        self.preview_canvas.create_rectangle(10, 10, 310, 410, fill="#ffffff", outline="#dddddd")

        # Mock drawing based on selected template
        if tmpl == "None":
            # Just plain text list
            self.preview_canvas.create_text(160, 40, text="Plain Sheet Invoice", font=("Courier", 10, "bold"), fill="#333333")
            self.preview_canvas.create_line(20, 60, 300, 60, fill="#cccccc")
            self.preview_canvas.create_text(40, 80, text="Item 1..........500", font=("Courier", 8), anchor="w")
            self.preview_canvas.create_text(40, 100, text="Item 2..........500", font=("Courier", 8), anchor="w")
        elif "ColorBox" in tmpl:
            # Color header banner
            self.preview_canvas.create_rectangle(15, 15, 305, 55, fill="#b8c0d0", outline="")
            self.preview_canvas.create_text(160, 35, text="TAX INVOICE", font=("Arial", 11, "bold"), fill="#ffffff")
            # Logo circle mock
            self.preview_canvas.create_oval(25, 20, 45, 40, fill="red", outline="")
            
            # Grid
            self.preview_canvas.create_rectangle(15, 80, 305, 320, fill="", outline="#cccccc")
            self.preview_canvas.create_line(15, 105, 305, 105, fill="#cccccc")
            self.preview_canvas.create_line(70, 80, 70, 320, fill="#cccccc")
            self.preview_canvas.create_line(230, 80, 230, 320, fill="#cccccc")
            
            # Content
            self.preview_canvas.create_text(40, 92, text="Desc", font=("Arial", 7, "bold"), fill="#000")
            self.preview_canvas.create_text(150, 92, text="Qty", font=("Arial", 7, "bold"), fill="#000")
            self.preview_canvas.create_text(260, 92, text="Amount", font=("Arial", 7, "bold"), fill="#000")
        elif "Box" in tmpl or "FullBox" in tmpl:
            # Standard boxed invoice layout
            self.preview_canvas.create_rectangle(15, 15, 305, 385, fill="", outline="#333333", width=1)
            # Header separator
            self.preview_canvas.create_line(15, 65, 305, 65, fill="#333333")
            self.preview_canvas.create_text(160, 35, text="Demo Traders Pvt Ltd", font=("Calibri", 10, "bold"), fill="#000")
            
            # Table border box
            self.preview_canvas.create_rectangle(20, 90, 300, 280, fill="", outline="#333333")
            self.preview_canvas.create_line(20, 110, 300, 110, fill="#333333")
            self.preview_canvas.create_line(60, 90, 60, 280, fill="#333333")
            self.preview_canvas.create_line(220, 90, 220, 280, fill="#333333")

            # Signature line
            self.preview_canvas.create_line(210, 360, 290, 360, fill="#333333")
            self.preview_canvas.create_text(250, 370, text="Authorized Signatory", font=("Calibri", 6), fill="#000")
        else:
            # Default elegant format
            self.preview_canvas.create_oval(25, 25, 55, 55, fill="#8fed8f", outline="")
            self.preview_canvas.create_text(160, 40, text="Demo Traders Pvt Ltd", font=("Segoe UI", 11, "bold"), fill="#333333")
            self.preview_canvas.create_line(15, 75, 305, 75, fill="#8fed8f", width=2)
            
            self.preview_canvas.create_text(25, 95, text="Invoice No: INV-0001", font=("Segoe UI", 7), anchor="w")
            self.preview_canvas.create_text(25, 110, text="Date: 2026-07-23", font=("Segoe UI", 7), anchor="w")

            # Item lines
            self.preview_canvas.create_line(15, 140, 305, 140, fill="#cccccc")
            self.preview_canvas.create_text(25, 155, text="1. Item Description 1", font=("Segoe UI", 7), anchor="w")
            self.preview_canvas.create_text(280, 155, text="$1,200.00", font=("Segoe UI", 7), anchor="e")
            self.preview_canvas.create_line(15, 180, 305, 180, fill="#cccccc")

        # Initialise sample font display
        self._on_font_changed()

    def save_settings(self):
        # Read values from fields
        db.set_setting("tmpl_invoice_template", self.v_tmpl.get())
        db.set_setting("tmpl_printer_type", self.v_print_type.get())
        db.set_setting("tmpl_font_size", self.v_font_size.get())
        db.set_setting("tmpl_font_style", self.v_font_style.get())
        db.set_setting("tmpl_items_per_page", self.v_items_page.get())
        db.set_setting("tmpl_row_spacing", self.v_row_spacing.get())

        # Header variables
        for k, var in self.vars.items():
            db.set_setting(k, str(var.get()))

        db.set_setting("tmpl_hdr_doc_title", self.v_doc_title.get())
        db.set_setting("tmpl_ftr_terms_text", self.txt_terms.get("1.0", "end").strip())
        db.set_setting("tmpl_ftr_declaration", self.v_decl.get())

        db.set_setting("tmpl_cust_header_color", self.v_accent_color.get())
        db.set_setting("tmpl_cust_border_color", self.v_border_color.get())
        db.set_setting("tmpl_cust_text_color", self.v_text_color.get())

        messagebox.showinfo("Saved", "Template Settings saved successfully!", parent=self)
        self.destroy()
