with open('bookkeeper.py', 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Update signature
t1 = '''def _open_create_voucher(self, v_type="sale"):'''
r1 = '''def _open_create_voucher(self, v_type="sale", linked_po=None):'''
content = content.replace(t1, r1)

# 2. Update title string
t2 = '''lbl(hdr, "Purchase No" if v_type == "purchase" else "Invoice No", 0, 0)'''
r2 = '''lbl(hdr, "Purchase Order No" if v_type == "purchase_order" else ("Purchase No" if v_type == "purchase" else "Invoice No"), 0, 0)'''
content = content.replace(t2, r2)

# 3. Update prefix for invoice generation
t3 = '''inv_no_var, _ = entry_field(hdr, 0, 1, 14, db.get_next_invoice_no())'''
r3 = '''prefix = "PO" if v_type == "purchase_order" else ("PUR" if v_type == "purchase" else "INV")
        inv_no_var, _ = entry_field(hdr, 0, 1, 14, db.get_next_invoice_no(prefix, v_type))'''
content = content.replace(t3, r3)

# 4. Update dynamic accounts
t4 = '''        if v_type == "purchase":
            party_type = "supplier"
            txn_type = "purchase"
        else:
            party_type = "customer"
            txn_type = "sales"'''
r4 = '''        if v_type in ["purchase", "purchase_order"]:
            party_type = "supplier"
            txn_type = "purchase"
        else:
            party_type = "customer"
            txn_type = "sales"'''
content = content.replace(t4, r4)

# 5. Terms Conditions UI
t5 = '''        nar_text = tk.Text(bot_left, font=FONT, width=40, height=4, relief="sunken", bd=1, bg=WHITE)
        nar_text.pack(fill="x", expand=True, padx=(0, 20))'''
r5 = '''        nar_text = tk.Text(bot_left, font=FONT, width=40, height=4, relief="sunken", bd=1, bg=WHITE)
        nar_text.pack(fill="x", expand=True, padx=(0, 20))
        
        tk.Label(bot_left, text="Terms & Conditions", bg=BG, fg="#555", font=("Tahoma", 8, "bold"), anchor="w").pack(anchor="w", pady=(10,0))
        terms_text = tk.Text(bot_left, font=FONT, width=40, height=3, relief="sunken", bd=1, bg=WHITE)
        terms_text.pack(fill="x", expand=True, padx=(0, 20))'''
content = content.replace(t5, r5)

# 6. Database save logic
t6 = '''            try:
                db.create_invoice(inv_no, v_type, acc_id, date_str,
                                  items, notes=nar_text.get("1.0", "end").strip())'''
r6 = '''            try:
                status = "OPEN" if v_type == "purchase_order" else None
                terms_val = terms_text.get("1.0", "end").strip()
                linked_id = linked_po["id"] if linked_po else None
                
                db.create_invoice(inv_no, v_type, acc_id, date_str,
                                  items, notes=nar_text.get("1.0", "end").strip(), status=status, terms=terms_val, linked_po_id=linked_id)'''
content = content.replace(t6, r6)

# 7. Add linked_po auto-fill near the end of initialization
t7 = '''        bottom = tk.Frame(win, bg=BG, relief="raised", bd=1)'''
r7 = '''        
        if linked_po:
            cust_var.set(linked_po["account_name"])
            nar_text.insert("1.0", f"Buyers Purchase Order Reference: {linked_po['vch_no']}")
            # Delay item population slightly to ensure grid is ready
            def fill_po_items():
                for widget in grid_inner.grid_slaves():
                    widget.destroy()
                line_data.clear()
                
                po_items = db.get_invoice_items(linked_po["id"])
                for p_item in po_items:
                    add_grid_row(item_name=p_item["item"], qty=str(p_item["qty"]), rate=str(p_item["cost_per_unit"]))
                if not po_items:
                    add_grid_row()
            win.after(100, fill_po_items)

        bottom = tk.Frame(win, bg=BG, relief="raised", bd=1)'''
content = content.replace(t7, r7)

with open('bookkeeper.py', 'w', encoding='utf-8') as f:
    f.write(content)

print("Patch applied for _open_create_voucher!")
