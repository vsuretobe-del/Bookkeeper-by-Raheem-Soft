with open('bookkeeper.py', 'r', encoding='utf-8') as f:
    lines = f.readlines()

new_lines = []
for line in lines:
    if "bot_frame = tk.Frame(win, bg=BG)" in line:
        new_lines.append(line)
        new_lines.append('        bot_frame.pack(fill="x", side="bottom", padx=8, pady=4)\n')
        new_lines.append('        \n')
        new_lines.append('        nar_lbl = tk.Label(bot_frame, text="Narration\\\\nCtrl+Enter for next line",\n')
        new_lines.append('                           bg=BG, fg="#000", font=("Tahoma", 8, "italic"), justify="left")\n')
        new_lines.append('        nar_lbl.grid(row=0, column=0, sticky="nw", padx=4, pady=4)\n')
        new_lines.append('        nar_text = tk.Text(bot_frame, font=FONT, height=3, width=50, relief="solid", bd=1)\n')
        new_lines.append('        nar_text.grid(row=0, column=1, padx=4, pady=4, sticky="nsew")\n')
        new_lines.append('\n')
        new_lines.append('        rt_frame = tk.Frame(bot_frame, bg=BG)\n')
        new_lines.append('        rt_frame.grid(row=0, column=2, sticky="ne", padx=(40, 0))\n')
        new_lines.append('        \n')
        new_lines.append('        tk.Label(rt_frame, text="Round Off", bg=BG, font=FONT).grid(row=0, column=0, sticky="e", pady=2)\n')
        new_lines.append('        round_var = tk.StringVar(value="0")\n')
        new_lines.append('        tk.Entry(rt_frame, textvariable=round_var, font=FONT, width=12, justify="right",\n')
        new_lines.append('                 relief="solid", bd=1).grid(row=0, column=1, padx=4, pady=2)\n')
        new_lines.append('        \n')
        new_lines.append('        tk.Label(rt_frame, text="Total Amount", bg=BG, font=FONT).grid(row=1, column=0, sticky="e", pady=2)\n')
        new_lines.append('        total_var = tk.StringVar(value="")\n')
        new_lines.append('        tk.Entry(rt_frame, textvariable=total_var, font=(FONT[0], 10, "bold"), width=12, justify="right",\n')
        new_lines.append('                 relief="solid", bd=1, state="readonly").grid(row=1, column=1, padx=4, pady=2)\n')
        new_lines.append('        \n')
        new_lines.append('        ref_frame = tk.Frame(rt_frame, bg=BG)\n')
        new_lines.append('        ref_frame.grid(row=2, column=0, columnspan=2, sticky="e", pady=10)\n')
        new_lines.append('        \n')
        new_lines.append('        ref_box = tk.LabelFrame(ref_frame, text="Reference Document", bg=BG, font=("Tahoma", 8))\n')
        new_lines.append('        ref_box.pack(side="right")\n')
        new_lines.append('        \n')
        new_lines.append('        tk.Entry(ref_box, bg=WHITE, width=28, relief="solid", bd=1).pack(padx=4, pady=2)\n')
        new_lines.append('        btn_frame = tk.Frame(ref_box, bg=BG)\n')
        new_lines.append('        btn_frame.pack(fill="x", pady=(0, 4))\n')
        new_lines.append('        tk.Button(btn_frame, text="Browse", bg="#e0e0e0", relief="flat", bd=1).pack(side="left", padx=4, fill="x", expand=True)\n')
        new_lines.append('        tk.Button(btn_frame, text="View", bg="#e0e0e0", relief="flat", bd=1).pack(side="left", padx=4, fill="x", expand=True)\n')
        new_lines.append('        tk.Button(btn_frame, text="Delete", bg="#e0e0e0", relief="flat", bd=1).pack(side="left", padx=4, fill="x", expand=True)\n')
        continue
        
    if 'bot_frame.pack(fill="x", side="bottom", padx=8, pady=4)' in line: continue
    if 'btn_frame.pack(fill="x", pady=(0, 4))' in line: continue
    if 'tk.Button(btn_frame, text="Browse"' in line: continue
    if 'tk.Button(btn_frame, text="View"' in line: continue
    if 'tk.Button(btn_frame, text="Delete"' in line: continue
    
    new_lines.append(line)

with open('bookkeeper.py', 'w', encoding='utf-8') as f:
    f.writelines(new_lines)
print("Restored deleted lines")
