"""
Book Keeper Clone - Authentic Database Layer
Uses the exact sample_schema.sql from the real Book Keeper software!
"""
import sqlite3
import os
import datetime

def parse_date_for_sort(d_str):
    if not d_str:
        return datetime.date.min
    if isinstance(d_str, datetime.date):
        return d_str
    d_str = str(d_str).strip()
    for fmt in ("%Y-%m-%d", "%B %d, %Y", "%b %d, %Y", "%d-%m-%Y", "%d/%m/%Y", "%m/%d/%Y", "%Y/%m/%d"):
        try:
            return datetime.datetime.strptime(d_str, fmt).date()
        except Exception:
            pass
    return datetime.date.min

def parse_date_to_iso(d_str):
    if not d_str:
        return ""
    if isinstance(d_str, datetime.date):
        return d_str.isoformat()
    d_str = str(d_str).strip()
    for fmt in ("%Y-%m-%d", "%B %d, %Y", "%b %d, %Y", "%d-%m-%Y", "%d/%m/%Y", "%m/%d/%Y", "%Y/%m/%d"):
        try:
            return datetime.datetime.strptime(d_str, fmt).date().isoformat()
        except Exception:
            pass
    return d_str

import sys

def get_base_path():
    if getattr(sys, 'frozen', False) and hasattr(sys, '_MEIPASS'):
        return sys._MEIPASS
    return os.path.dirname(os.path.abspath(__file__))

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "bookkeeper.db")
SCHEMA_PATH = os.path.join(get_base_path(), "authentic_schema.sql")

def set_db_path(path):
    global DB_PATH
    DB_PATH = path
    try:
        init_db()
    except Exception as e:
        print("Error initializing DB on set_db_path:", e)

def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def _ensure_schema(conn):
    c = conn.cursor()
    # Always ensure 'app_settings' and 'users' tables exist
    c.execute('''
        CREATE TABLE IF NOT EXISTS app_settings (
            key TEXT PRIMARY KEY,
            value TEXT
        )
    ''')
    c.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE,
            password TEXT,
            initials TEXT,
            acc_create INTEGER DEFAULT 0,
            acc_view INTEGER DEFAULT 0,
            inv_create INTEGER DEFAULT 0,
            inv_view INTEGER DEFAULT 0,
            journal_create INTEGER DEFAULT 0,
            journal_view_all INTEGER DEFAULT 0,
            sales_create INTEGER DEFAULT 0,
            sales_view INTEGER DEFAULT 0,
            purchase_create INTEGER DEFAULT 0,
            purchase_view INTEGER DEFAULT 0,
            banking_create INTEGER DEFAULT 0,
            banking_view INTEGER DEFAULT 0,
            exp_inc_create INTEGER DEFAULT 0,
            exp_inc_view INTEGER DEFAULT 0,
            reports_view INTEGER DEFAULT 0,
            mod_delete INTEGER DEFAULT 0,
            mod_edit INTEGER DEFAULT 0,
            other_backdated INTEGER DEFAULT 0,
            other_edit_vch_no INTEGER DEFAULT 0,
            other_mod_rate INTEGER DEFAULT 0
        )
    ''')

    # Ensure columns on vouchers
    try:
        vouchers_cols = [r[1] for r in c.execute("PRAGMA table_info(vouchers)").fetchall()]
        if vouchers_cols:
            v_cols = [
                ("status", "TEXT"),
                ("terms", "TEXT"),
                ("linked_po_id", "INTEGER"),
                ("paid_amount", "REAL DEFAULT 0.0"),
                ("discount", "REAL DEFAULT 0.0"),
                ("round_off", "REAL DEFAULT 0.0"),
                ("detail1", "TEXT"),
                ("detail2", "TEXT"),
                ("detail3", "TEXT"),
                ("detail4", "TEXT"),
                ("remarks", "TEXT"),
            ]
            for col, col_type in v_cols:
                if col not in vouchers_cols:
                    try:
                        c.execute(f"ALTER TABLE vouchers ADD COLUMN {col} {col_type}")
                    except Exception:
                        pass
    except Exception:
        pass

    # Ensure columns on account_detail
    try:
        acc_cols = [r[1] for r in c.execute("PRAGMA table_info(account_detail)").fetchall()]
        if acc_cols:
            acc_cols_to_add = [
                ("bank_name", "TEXT"),
                ("acc_number", "TEXT"),
                ("ifsc_code", "TEXT"),
                ("bank_branch", "TEXT"),
                ("has_bank_details", "INTEGER DEFAULT 0"),
                ("account_type", "TEXT"),
                ("address", "TEXT"),
                ("email", "TEXT"),
                ("phone_no", "TEXT"),
                ("contact_person", "TEXT"),
                ("pan_no", "TEXT"),
                ("tin_no", "TEXT"),
            ]
            for col, col_type in acc_cols_to_add:
                if col not in acc_cols:
                    try:
                        c.execute(f"ALTER TABLE account_detail ADD COLUMN {col} {col_type}")
                    except Exception:
                        pass
    except Exception:
        pass

    # Ensure columns on item_measure
    try:
        item_cols = [r[1] for r in c.execute("PRAGMA table_info(item_measure)").fetchall()]
        if item_cols:
            item_cols_to_add = [
                ("item_type", "TEXT DEFAULT 'Goods'"),
                ("reorder_qty", "REAL DEFAULT 0"),
                ("defaultpurchaseprice", "REAL DEFAULT 0"),
                ("defaultsellingprice", "REAL DEFAULT 0"),
                ("tax_pct", "REAL DEFAULT 0"),
                ("hsn_sac", "TEXT"),
            ]
            for col, col_type in item_cols_to_add:
                if col not in item_cols:
                    try:
                        c.execute(f"ALTER TABLE item_measure ADD COLUMN {col} {col_type}")
                    except Exception:
                        pass
    except Exception:
        pass

    conn.commit()

def init_db():
    db_existed = os.path.exists(DB_PATH)
    conn = get_conn()
    try:
        c = conn.cursor()

        if not db_existed:
            try:
                with open(SCHEMA_PATH, 'r', encoding='utf-16le') as f:
                    schema_sql = f.read()
                c.executescript(schema_sql)
            except Exception as e:
                print("Schema init error:", e)

            try:
                c.execute("INSERT OR IGNORE INTO company (c_name) VALUES ('ALHUMDULLILLAH')")
            except Exception:
                pass

            default_accounts = [
                ('Cash', 'Cash-in-hand', 0.0),
                ('Bank', 'Bank A/Cs', 0.0),
                ('Purchase', 'Purchases A/C', 0.0),
                ('Purchases Return', 'Purchases Return', 0.0),
                ('Sales', 'Sales A/C', 0.0),
                ('Sales Return', 'Sales Return', 0.0),
                ('Capital', 'Capital A/C', 0.0),
                ('Profit & Loss A/c', 'Capital A/C', 0.0),
                ('Cartage', 'Direct Expenses', 0.0),
                ('Discount On Sale', 'Direct Expenses', 0.0),
                ('Discount given', 'Direct Expenses', 0.0),
                ('Advertisement expenses', 'Indirect Expenses', 0.0),
                ('Rent paid', 'Indirect Expenses', 0.0),
                ('Round off', 'Indirect Expenses', 0.0),
                ('Discount On Purchase', 'Direct Income', 0.0),
                ('Discount received', 'Direct Income', 0.0),
                ('Cartage charged', 'Indirect Income', 0.0),
                ('Interest received', 'Indirect Income', 0.0),
                ('Round Off', 'Indirect Income', 0.0),
                ('Shipping', 'Indirect Income', 0.0),
                ('Tax Deducted Receivable', 'Current Assets', 0.0),
                ('Salary Payable', 'Current Liabilities', 0.0),
                ('Tax Deducted Payable', 'Current Liabilities', 0.0),
                ('Advance Salary', 'Loans & Advances (Asset)', 0.0),
                ('Furniture', 'Fixed Assets', 0.0),
                ('Vehicle', 'Fixed Assets', 0.0),
            ]
            for aname, acc_group, cl_bal in default_accounts:
                try:
                    c.execute("INSERT OR IGNORE INTO account_detail (aname, account_group, cl_bal, op_bal) VALUES (?, ?, ?, ?)", 
                              (aname, acc_group, cl_bal, cl_bal))
                except Exception:
                    pass
            conn.commit()

        # Run migrations for all existing and new databases
        _ensure_schema(conn)
    finally:
        conn.close()

# ── Dashboard queries ───────────────────────────────────────────────────────

def get_company_name():
    conn = get_conn()
    row = conn.execute("SELECT c_name FROM company LIMIT 1").fetchone()
    conn.close()
    return row['c_name'] if row else 'My Company'

def get_dashboard_accounts():
    conn = get_conn()
    rows = conn.execute("""
        SELECT aname as name, cl_bal as balance FROM account_detail
        WHERE account_group IN ('Cash-in-hand','Bank A/Cs')
        UNION ALL
        SELECT 'Customer/Debtor', COALESCE(SUM(cl_bal),0) FROM account_detail WHERE account_group='Sundry Debtors'
        UNION ALL
        SELECT 'Supplier/Creditor', COALESCE(SUM(cl_bal),0) FROM account_detail WHERE account_group='Sundry Creditors'
    """).fetchall()
    conn.close()
    return rows

def get_overdue_invoices_count():
    conn = get_conn()
    row = conn.execute("""
        SELECT COUNT(*) as cnt FROM vouchers
        WHERE v_type='sale' AND (amount - COALESCE(paid_amount,0)) > 0 AND date < date('now')
    """).fetchone()
    conn.close()
    return row['cnt'] if row else 0

def get_unpaid_invoices_count():
    conn = get_conn()
    row = conn.execute("""
        SELECT COUNT(*) as cnt FROM vouchers WHERE v_type='sale' AND (amount - COALESCE(paid_amount,0)) > 0
    """).fetchone()
    conn.close()
    return row['cnt'] if row else 0

def get_today_cash_collection():
    conn = get_conn()
    row = conn.execute("""
        SELECT COALESCE(SUM(amount),0) as total FROM vouchers_all
        WHERE date=date('now') AND debit IN (SELECT aname FROM account_detail WHERE account_group='Cash-in-hand')
    """).fetchone()
    conn.close()
    return row['total'] if row else 0

def get_today_bank_collection():
    conn = get_conn()
    row = conn.execute("""
        SELECT COALESCE(SUM(amount),0) as total FROM vouchers_all
        WHERE date=date('now') AND debit IN (SELECT aname FROM account_detail WHERE account_group='Bank A/Cs')
    """).fetchone()
    conn.close()
    return row['total'] if row else 0

def get_monthly_sales():
    conn = get_conn()
    rows = conn.execute("""
        SELECT strftime('%b-%Y', date) as month, COALESCE(SUM(amount),0) as total
        FROM vouchers WHERE v_type='sale'
        GROUP BY strftime('%Y-%m', date)
        ORDER BY date DESC LIMIT 12
    """).fetchall()
    conn.close()
    return list(reversed(rows))

def get_daily_cash_flow(limit=25):
    """
    Returns daily cash flow data points: list of dicts:
    [{'date': 'YYYY-MM-DD', 'cash': float, 'bank': float, 'total': float}, ...]
    Accurately extracts all real cash and bank movements from database vouchers.
    """
    conn = get_conn()
    conn.row_factory = __import__('sqlite3').Row

    cash_accounts = set()
    bank_accounts = set()
    try:
        acc_rows = conn.execute("SELECT aname, account_group FROM account_detail").fetchall()
        for a in acc_rows:
            grp = (a['account_group'] or '').lower()
            name = (a['aname'] or '')
            if 'cash' in grp or 'cash' in name.lower():
                cash_accounts.add(name)
            elif 'bank' in grp or 'bank' in name.lower():
                bank_accounts.add(name)
    except Exception:
        pass

    if not cash_accounts:
        cash_accounts = {'Cash-in-hand', 'cash', 'Cash', 'Cash Account'}
    if not bank_accounts:
        bank_accounts = {'Bank A/Cs', 'bank', 'Bank', 'Bank Account'}

    import datetime
    def parse_date_str(d_str):
        if not d_str:
            return None
        d_clean = str(d_str).strip()
        for fmt in ('%Y-%m-%d', '%B %d, %Y', '%b %d, %Y', '%d-%m-%Y', '%d/%m/%Y', '%Y/%m/%d'):
            try:
                return datetime.datetime.strptime(d_clean, fmt).strftime('%Y-%m-%d')
            except Exception:
                pass
        if len(d_clean) >= 10 and d_clean[4] == '-' and d_clean[7] == '-':
            return d_clean[:10]
        return d_clean

    daily_map = {}

    # 1. Process vouchers_all table
    try:
        v_all_rows = conn.execute("SELECT date, debit, credit, amount FROM vouchers_all WHERE amount != 0").fetchall()
        for r in v_all_rows:
            d = parse_date_str(r['date'])
            if not d:
                continue
            if d not in daily_map:
                daily_map[d] = {'cash': 0.0, 'bank': 0.0}
            amt = float(r['amount'] or 0.0)
            deb = r['debit']
            crd = r['credit']
            if deb in cash_accounts:
                daily_map[d]['cash'] += amt
            if crd in cash_accounts:
                daily_map[d]['cash'] -= amt
            if deb in bank_accounts:
                daily_map[d]['bank'] += amt
            if crd in bank_accounts:
                daily_map[d]['bank'] -= amt
    except Exception:
        pass

    # 2. Process vouchers table if needed
    has_activity = any(v['cash'] != 0 or v['bank'] != 0 for v in daily_map.values())
    if not has_activity:
        try:
            v_rows = conn.execute("""
                SELECT date, v_type, debit, credit, amount, paid_amount, payment_mode FROM vouchers
                WHERE amount != 0 OR paid_amount != 0
            """).fetchall()
            for r in v_rows:
                d = parse_date_str(r['date'])
                if not d:
                    continue
                if d not in daily_map:
                    daily_map[d] = {'cash': 0.0, 'bank': 0.0}
                amt = float(r['amount'] or r['paid_amount'] or 0.0)
                vt = (r['v_type'] or '').lower()
                deb = r['debit']
                crd = r['credit']
                pm = (r['payment_mode'] or '').lower()

                if deb in cash_accounts:
                    daily_map[d]['cash'] += amt
                elif crd in cash_accounts:
                    daily_map[d]['cash'] -= amt
                elif deb in bank_accounts:
                    daily_map[d]['bank'] += amt
                elif crd in bank_accounts:
                    daily_map[d]['bank'] -= amt
                elif vt in ('sale', 'receipt', 'income'):
                    if 'bank' in pm or 'bank' in str(deb).lower():
                        daily_map[d]['bank'] += amt
                    else:
                        daily_map[d]['cash'] += amt
                elif vt in ('purchase', 'payment', 'expense'):
                    if 'bank' in pm or 'bank' in str(crd).lower():
                        daily_map[d]['bank'] -= amt
                    else:
                        daily_map[d]['cash'] -= amt
        except Exception:
            pass

    conn.close()

    sorted_dates = sorted(daily_map.keys())
    if sorted_dates and any(v['cash'] != 0 or v['bank'] != 0 for v in daily_map.values()):
        recent_dates = sorted_dates[-limit:]
        result = []
        for d in recent_dates:
            c_val = round(daily_map[d]['cash'], 2)
            b_val = round(daily_map[d]['bank'], 2)
            result.append({
                'date': d,
                'cash': c_val,
                'bank': b_val,
                'total': round(c_val + b_val, 2)
            })
        return result

    # Standard clean preview series for new companies with no transactions
    sample_dates = [
        "2026-07-15", "2026-07-18", "2026-07-20", "2026-07-22", "2026-07-25",
        "2026-07-28", "2026-07-30", "2026-08-01", "2026-08-03", "2026-08-05"
    ]
    sample_cash = [15000.0, 22000.0, -3200.0, 35000.0, 48000.0, 18800.0, 52000.0, 42000.0, 28000.0, 35000.0]
    sample_bank = [12000.0, 18500.0, 5000.0, 28000.0, 39000.0, 15200.0, 41000.0, 31000.0, 22000.0, 30000.0]

    result = []
    for i in range(len(sample_dates)):
        result.append({
            'date': sample_dates[i],
            'cash': sample_cash[i],
            'bank': sample_bank[i],
            'total': sample_cash[i] + sample_bank[i]
        })
    return result

# ── Accounts ────────────────────────────────────────────────────────────────

def get_all_accounts(account_type=None):
    conn = get_conn()
    query = "SELECT *, aname as id, aname as name, account_group as type, cl_bal as balance FROM account_detail"
    # Maps friendly type name to possible DB values (some DBs use lowercase, some use full names)
    type_map = {
        'customer':  ['Sundry Debtors'],
        'supplier':  ['Sundry Creditors'],
        'cash':      ['cash', 'Cash-in-hand'],
        'bank':      ['bank', 'Bank A/Cs'],
        'sales':     ['sales', 'Sales Accounts', 'Sales'],
        'purchase':  ['purchase', 'Purchase Accounts', 'Purchase'],
    }

    if account_type:
        mapped_types = type_map.get(account_type, [account_type])
        placeholders = ",".join("?" * len(mapped_types))
        rows = conn.execute(
            query + f" WHERE account_group IN ({placeholders}) ORDER BY aname",
            tuple(mapped_types)
        ).fetchall()
    else:
        rows = conn.execute(query + " ORDER BY aname").fetchall()
    conn.close()
    return [dict(r) for r in rows]

def _ensure_account_detail_columns(conn):
    existing_cols = [r[1] for r in conn.execute("PRAGMA table_info(account_detail)").fetchall()]
    new_cols = [
        ("bank_name", "TEXT"),
        ("acc_number", "TEXT"),
        ("ifsc_code", "TEXT"),
        ("bank_branch", "TEXT"),
        ("has_bank_details", "INTEGER DEFAULT 0"),
    ]
    for col, col_type in new_cols:
        if col not in existing_cols:
            try:
                conn.execute(f"ALTER TABLE account_detail ADD COLUMN {col} {col_type}")
                conn.commit()
            except Exception:
                pass

def add_account(data):
    conn = get_conn()
    try:
        _ensure_account_detail_columns(conn)
        if 'op_bal' in data and 'cl_bal' not in data:
            data['cl_bal'] = data['op_bal']
        
        valid_cols = [r[1] for r in conn.execute("PRAGMA table_info(account_detail)").fetchall()]
        filtered_data = {k: v for k, v in data.items() if k in valid_cols}
        
        cols = ", ".join(filtered_data.keys())
        placeholders = ", ".join("?" * len(filtered_data))
        query = f"INSERT INTO account_detail ({cols}) VALUES ({placeholders})"
        conn.execute(query, tuple(filtered_data.values()))
        conn.commit()
    finally:
        conn.close()

def update_account(acc_id, data):
    conn = get_conn()
    try:
        _ensure_account_detail_columns(conn)
        if 'op_bal' in data and 'cl_bal' not in data:
            data['cl_bal'] = data['op_bal']

        valid_cols = [r[1] for r in conn.execute("PRAGMA table_info(account_detail)").fetchall()]
        filtered_data = {k: v for k, v in data.items() if k in valid_cols}

        set_clause = ", ".join(f"{k}=?" for k in filtered_data.keys())
        values = tuple(filtered_data.values()) + (acc_id,)
        
        conn.execute(f"UPDATE account_detail SET {set_clause} WHERE aname=?", values)
        
        if 'aname' in data and data['aname'] != acc_id:
            new_name = data['aname']
            conn.execute("UPDATE vouchers_all SET debit=? WHERE debit=?", (new_name, acc_id))
            conn.execute("UPDATE vouchers_all SET credit=? WHERE credit=?", (new_name, acc_id))
            
        conn.commit()
    finally:
        conn.close()

def delete_account(acc_id):
    conn = get_conn()
    try:
        conn.execute("DELETE FROM account_detail WHERE aname=?", (acc_id,))
        conn.commit()
    finally:
        conn.close()

# ── Items / Inventory ────────────────────────────────────────────────────────

UNIT_SYMBOL_MAP = {
    "numbers": "Nos",
    "number": "Nos",
    "nos": "Nos",
    "no": "Nos",
    "kilogram": "Kg",
    "kilograms": "Kg",
    "kg": "Kg",
    "kgs": "Kg",
    "pieces": "Pcs",
    "piece": "Pcs",
    "pcs": "Pcs",
    "pc": "Pcs",
    "packet": "Pkt",
    "packets": "Pkt",
    "pkt": "Pkt",
    "pkts": "Pkt",
    "meter": "Mtr",
    "meters": "Mtr",
    "metre": "Mtr",
    "metres": "Mtr",
    "mt": "Mtr",
    "mtr": "Mtr",
    "m": "Mtr",
    "litre": "Ltr",
    "litres": "Ltr",
    "liter": "Ltr",
    "liters": "Ltr",
    "lt": "Ltr",
    "ltr": "Ltr",
    "l": "Ltr",
    "box": "Box",
    "boxes": "Box",
    "bx": "Box",
    "unit": "Nos",
    "units": "Nos",
    "u": "Nos",
    "dozen": "Dzn",
    "dozens": "Dzn",
    "dz": "Dzn",
    "gram": "Gm",
    "grams": "Gm",
    "gm": "Gm",
    "g": "Gm",
    "foot": "Ft",
    "feet": "Ft",
    "ft": "Ft",
    "inch": "In",
    "inches": "In",
}

def get_unit_symbol(unit_name):
    if not unit_name:
        return "Nos"
    s = str(unit_name).strip()
    if s.lower() in UNIT_SYMBOL_MAP:
        return UNIT_SYMBOL_MAP[s.lower()]
    try:
        conn = get_conn()
        row = conn.execute("SELECT symbol FROM units_measure WHERE LOWER(units_name)=? OR LOWER(symbol)=?", (s.lower(), s.lower())).fetchone()
        conn.close()
        if row and row['symbol']:
            sym = str(row['symbol']).strip()
            return UNIT_SYMBOL_MAP.get(sym.lower(), sym.capitalize() if len(sym) <= 3 else sym)
    except Exception:
        pass
    return s

def get_all_items():
    conn = get_conn()
    rows = conn.execute("""
        SELECT *, item as id, item as name, sku as code, units_name as unit, 
               defaultpurchaseprice as purchase_price, defaultsellingprice as sale_price, 
               COALESCE((SELECT cl_bal FROM stock WHERE stock_name=item_measure.item LIMIT 1), 0.0) as stock, 
               reorder_qty as low_stock_alert 
        FROM item_measure ORDER BY item
    """).fetchall()
    conn.close()
    items = []
    for r in rows:
        d = dict(r)
        raw_u = d.get('units_name') or d.get('unit') or 'Nos'
        sym = get_unit_symbol(raw_u)
        d['unit'] = sym
        d['units_name'] = sym
        items.append(d)
    return items

def add_item(data):
    conn = get_conn()
    stock_qty = data.pop('stock', 0)
    
    cols = ", ".join(data.keys())
    placeholders = ", ".join("?" * len(data))
    query = f"INSERT INTO item_measure ({cols}) VALUES ({placeholders})"
    
    conn.execute(query, tuple(data.values()))
    if 'item' in data:
        conn.execute("INSERT INTO stock (stock_name, cl_bal) VALUES (?,?)", (data['item'], stock_qty))
    conn.commit()
    conn.close()

def update_item(item_id, data):
    conn = get_conn()
    stock_qty = data.pop('stock', 0)
    
    set_clause = ", ".join(f"{k}=?" for k in data.keys())
    values = tuple(data.values()) + (item_id,)
    
    conn.execute(f"UPDATE item_measure SET {set_clause} WHERE item=?", values)
    
    if 'item' in data:
        new_name = data['item']
        conn.execute("UPDATE stock SET stock_name=?, cl_bal=? WHERE stock_name=?", (new_name, stock_qty, item_id))
        
        if new_name != item_id:
            conn.execute("UPDATE sales SET item_name=? WHERE item_name=?", (new_name, item_id))
            conn.execute("UPDATE purchases SET item_name=? WHERE item_name=?", (new_name, item_id))
            
    conn.commit()
    conn.close()

def delete_item(item_id):
    conn = get_conn()
    conn.execute("DELETE FROM item_measure WHERE item=?", (item_id,))
    conn.execute("DELETE FROM stock WHERE stock_name=?", (item_id,))
    conn.commit()
    conn.close()

# ── Invoices ─────────────────────────────────────────────────────────────────

def get_next_invoice_no(prefix='INV', v_type='sale'):
    conn = get_conn()
    row = conn.execute("SELECT COUNT(*) as cnt FROM vouchers WHERE v_type=?", (v_type,)).fetchone()
    conn.close()
    num = (row['cnt'] if row else 0) + 1
    return f"{prefix}-{num:04d}"

def create_invoice(invoice_no, inv_type, account_id, date, line_items, notes='', status=None, terms='', linked_po_id=None, paid_amount=0.0, is_template=0):
    conn = get_conn()
    total = sum(item['total'] for item in line_items)
    
    account_name = account_id

    if inv_type in ('sale', 'estimate', 'credit_note'):
        debit, credit = account_name, None
    else:
        debit, credit = None, account_name

    v_id = conn.execute(
        "INSERT INTO vouchers (vch_no, v_type, date, amount, narration, paid_amount, status, terms, linked_po_id, debit, credit, is_template) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
        (invoice_no, inv_type, date, total, notes, paid_amount, status, terms, linked_po_id, debit, credit, is_template)
    ).lastrowid
    
    if linked_po_id:
        conn.execute("UPDATE vouchers SET status='CLOSED' WHERE v_id=?", (linked_po_id,))

    
    for item in line_items:
        if inv_type == 'sale':
            conn.execute("""INSERT INTO sales (v_id, date, item, sp_per_unit, units, discount, desc) 
                            VALUES (?,?,?,?,?,?,?)""",
                         (v_id, date, item['name'], item['price'], item['qty'], item.get('tax_pct', 0), ''))
            conn.execute("UPDATE stock SET cl_bal=cl_bal-? WHERE stock_name=?", (item['qty'], item['name']))
        elif inv_type == 'purchase':
            ex_c = item.get('extra_costs', '[]')
            conn.execute("""INSERT INTO purchases (v_id, date, item, cost_per_unit, units, discount, desc, extra_costs) 
                            VALUES (?,?,?,?,?,?,?,?)""",
                         (v_id, date, item['name'], item['price'], item['qty'], item.get('tax_pct', 0), '', ex_c))
            
            # Moving Average Cost Update
            import json
            try:
                extra_total = sum(float(c.get("amount", 0)) for c in json.loads(ex_c))
            except:
                extra_total = 0.0
            new_qty = float(item['qty'])
            new_price = float(item['price']) + extra_total
            
            curr = conn.execute("SELECT cl_bal FROM stock WHERE stock_name=?", (item['name'],)).fetchone()
            curr_qty = float(curr['cl_bal']) if curr else 0.0
            
            im = conn.execute("SELECT defaultpurchaseprice FROM item_measure WHERE item=?", (item['name'],)).fetchone()
            curr_price = float(im['defaultpurchaseprice'] or 0.0) if im else 0.0
            
            if curr_qty + new_qty > 0:
                new_avg = ((curr_qty * curr_price) + (new_qty * new_price)) / (curr_qty + new_qty)
            else:
                new_avg = new_price
                
            conn.execute("UPDATE item_measure SET defaultpurchaseprice=? WHERE item=?", (new_avg, item['name']))
            
            # Stock Update
            conn.execute("UPDATE stock SET cl_bal=cl_bal+? WHERE stock_name=?", (new_qty, item['name']))
        elif inv_type == 'purchase_order':
            # PO line items go to purchases table but don't affect stock
            conn.execute("""INSERT INTO purchases (v_id, date, item, cost_per_unit, units, discount, desc) 
                            VALUES (?,?,?,?,?,?,?)""",
                         (v_id, date, item['name'], item['price'], item['qty'], item.get('tax_pct', 0), ''))
        elif inv_type == 'estimate':
            # Estimate line items go to sales table but don't affect stock
            conn.execute("""INSERT INTO sales (v_id, date, item, sp_per_unit, units, discount, desc) 
                            VALUES (?,?,?,?,?,?,?)""",
                         (v_id, date, item['name'], item['price'], item['qty'], item.get('tax_pct', 0), ''))
        
    if inv_type == 'sale':
        conn.execute("INSERT INTO vouchers_all (v_id, debit, credit, amount, date) VALUES (?,?,?,?,?)",
                     (v_id, account_name, 'Sales Account', total, date))
        conn.execute("UPDATE account_detail SET cl_bal=cl_bal+? WHERE aname=?", (total, account_name))
    elif inv_type == 'purchase':
        conn.execute("INSERT INTO vouchers_all (v_id, debit, credit, amount, date) VALUES (?,?,?,?,?)",
                     (v_id, 'Purchase Account', account_name, total, date))
        conn.execute("UPDATE account_detail SET cl_bal=cl_bal+? WHERE aname=?", (total, account_name))

    conn.commit()
    conn.close()
    return v_id

def get_all_invoices(inv_type=None):
    conn = get_conn()
    if inv_type and inv_type != "all":
        rows = conn.execute("""
            SELECT v.v_id as id, v.vch_no as invoice_no, v.v_type as type, v.date, v.amount as total,
                   v.paid_amount as paid, (v.amount - COALESCE(v.paid_amount,0)) as due,
                   v.narration as notes, v.status as status, v.linked_po_id, v.debit, v.credit,
                   COALESCE((SELECT debit FROM vouchers_all va WHERE va.v_id = v.v_id LIMIT 1), v.debit, v.credit) as account_id,
                   COALESCE((SELECT debit FROM vouchers_all va WHERE va.v_id = v.v_id LIMIT 1), v.debit, v.credit) as account_name,
                   COALESCE((SELECT credit FROM vouchers_all va WHERE va.v_id = v.v_id LIMIT 1), v.credit, v.debit) as credit_name
            FROM vouchers v
            WHERE v.v_type=? AND COALESCE(v.is_template, 0) = 0 ORDER BY v.date DESC
        """, (inv_type,)).fetchall()
    else:
        rows = conn.execute("""
            SELECT v.v_id as id, v.vch_no as invoice_no, v.v_type as type, v.date, v.amount as total,
                   v.paid_amount as paid, (v.amount - COALESCE(v.paid_amount,0)) as due,
                   v.narration as notes, v.status as status, v.linked_po_id, v.debit, v.credit,
                   COALESCE((SELECT debit FROM vouchers_all va WHERE va.v_id = v.v_id LIMIT 1), v.debit, v.credit) as account_id,
                   COALESCE((SELECT debit FROM vouchers_all va WHERE va.v_id = v.v_id LIMIT 1), v.debit, v.credit) as account_name,
                   COALESCE((SELECT credit FROM vouchers_all va WHERE va.v_id = v.v_id LIMIT 1), v.credit, v.debit) as credit_name
            FROM vouchers v
            WHERE COALESCE(v.is_template, 0) = 0
            ORDER BY v.date DESC
        """).fetchall()
    conn.close()

    result = []
    for r in rows:
        d = dict(r)
        v_type = d.get('type') or ''
        
        deb = r['debit'] or r['account_name'] or ''
        cred = r['credit'] or r['credit_name'] or ''
        
        if deb == cred:
            cred = ''
            
        if v_type == 'sale':
            if not deb: deb = 'Cash'
            cred = 'Sales'
        elif v_type == 'purchase':
            if not cred: cred = 'Cash'
            deb = 'Purchase'
            
        if deb and cred:
            d['account_name'] = f"{deb}\n{cred}"
        elif deb:
            d['account_name'] = deb
        elif cred:
            d['account_name'] = cred
        else:
            d['account_name'] = ''
            
        result.append(d)
    result.sort(key=lambda x: (parse_date_for_sort(x.get('date')), x.get('id') or 0), reverse=True)
    return result

# ── Reports ──────────────────────────────────────────────────────────────────

def get_profit_loss(from_date, to_date):
    conn = get_conn()
    sales = conn.execute("SELECT COALESCE(SUM(amount),0) as t FROM vouchers WHERE v_type='sale' AND date BETWEEN ? AND ?",
                         (from_date, to_date)).fetchone()['t']
    purchases = conn.execute("SELECT COALESCE(SUM(amount),0) as t FROM vouchers WHERE v_type='purchase' AND date BETWEEN ? AND ?",
                              (from_date, to_date)).fetchone()['t']
    expenses = conn.execute("SELECT COALESCE(SUM(amount),0) as t FROM vouchers WHERE v_type='expense' AND date BETWEEN ? AND ?",
                             (from_date, to_date)).fetchone()['t']
    conn.close()
    return {'sales': sales, 'purchases': purchases, 'expenses': expenses, 'profit': sales - purchases - expenses}

def get_ledger(account_id, from_date, to_date):
    conn = get_conn()
    rows = conn.execute("""
        SELECT va.date, v.narration as description, 
               CASE WHEN va.debit=? THEN va.amount ELSE 0 END as debit,
               CASE WHEN va.credit=? THEN va.amount ELSE 0 END as credit,
               0 as balance
        FROM vouchers_all va
        LEFT JOIN vouchers v ON v.v_id = va.v_id
        WHERE (va.debit=? OR va.credit=?) AND va.date BETWEEN ? AND ?
        ORDER BY va.date
    """, (account_id, account_id, account_id, account_id, from_date, to_date)).fetchall()
    
    bal = 0
    results = []
    for r in rows:
        d = dict(r)
        bal += (d['credit'] - d['debit'])
        d['balance'] = bal
        results.append(d)
        
    conn.close()
    return results




def create_income(invoice_no, date, received_into_acc, received_from_acc, line_items, notes='', status=None, ref_doc=''):
    conn = get_conn()
    total = sum(float(item['total']) for item in line_items)
    
    # Store received_from_acc in detail1 so we can retrieve it
    # Store ref_doc in detail2
    v_id = conn.execute(
        "INSERT INTO vouchers (vch_no, v_type, date, amount, narration, detail1, detail2, status) VALUES (?,?,?,?,?,?,?,?)",
        (invoice_no, 'income', date, total, notes, received_from_acc, ref_doc, status)
    ).lastrowid
    
    for item in line_items:
        amt = float(item['total'])
        conn.execute("INSERT INTO vouchers_all (v_id, debit, credit, amount, date) VALUES (?,?,?,?,?)",
                     (v_id, received_into_acc, item['name'], amt, date))
        conn.execute("UPDATE account_detail SET cl_bal=cl_bal+? WHERE aname=?", (amt, received_into_acc))
        conn.execute("UPDATE account_detail SET cl_bal=cl_bal-? WHERE aname=?", (amt, item['name']))
        
    conn.commit()
    conn.close()
    return v_id

def create_contra(invoice_no, date, to_account, from_account, amount, notes='', status=None, ref_doc=''):
    conn = get_conn()
    amt = float(amount)
    
    # Store to_account in detail1 and ref_doc in detail2
    v_id = conn.execute(
        "INSERT INTO vouchers (vch_no, v_type, date, amount, narration, detail1, detail2, status) VALUES (?,?,?,?,?,?,?,?)",
        (invoice_no, 'contra', date, amt, notes, to_account, ref_doc, status)
    ).lastrowid
    
    conn.execute("INSERT INTO vouchers_all (v_id, debit, credit, amount, date) VALUES (?,?,?,?,?)",
                 (v_id, to_account, from_account, amt, date))
    
    # Update balances: To account is receiving (Debit +), From account is giving (Credit -)
    conn.execute("UPDATE account_detail SET cl_bal=cl_bal+? WHERE aname=?", (amt, to_account))
    conn.execute("UPDATE account_detail SET cl_bal=cl_bal-? WHERE aname=?", (amt, from_account))
    
    conn.commit()
    conn.close()
    return v_id

def create_expense(invoice_no, date, paid_from_acc, paid_to_acc, line_items, notes='', status=None, ref_doc=''):
    conn = get_conn()
    total = sum(float(item['total']) for item in line_items)
    
    # Store paid_to_acc in detail1 so we can retrieve it
    # Store ref_doc in detail2
    v_id = conn.execute(
        "INSERT INTO vouchers (vch_no, v_type, date, amount, narration, detail1, detail2, status) VALUES (?,?,?,?,?,?,?,?)",
        (invoice_no, 'expense', date, total, notes, paid_to_acc, ref_doc, status)
    ).lastrowid
    
    for item in line_items:
        amt = float(item['total'])
        conn.execute("INSERT INTO vouchers_all (v_id, debit, credit, amount, date) VALUES (?,?,?,?,?)",
                     (v_id, item['name'], paid_from_acc, amt, date))
        conn.execute("UPDATE account_detail SET cl_bal=cl_bal+? WHERE aname=?", (amt, item['name']))
        
    conn.execute("UPDATE account_detail SET cl_bal=cl_bal-? WHERE aname=?", (total, paid_from_acc))

    conn.commit()
    conn.close()
    return v_id

def get_invoice_items(invoice_id):
    conn = get_conn()
    conn.row_factory = __import__('sqlite3').Row
    v_row = conn.execute("SELECT v_type, narration, debit, credit, amount FROM vouchers WHERE v_id=?", (invoice_id,)).fetchone()
    rows = []
    if v_row:
        vt = v_row['v_type']
        if vt in ('sale', 'estimate', 'credit_note', 'delivery_note'):
            rows = conn.execute("""
                SELECT s.item as item_name, s.units as qty, s.sp_per_unit as price, 
                       s.discount as discount, s.scheme_name as tax_pct, (s.units * s.sp_per_unit) as total,
                       s.desc as desc, COALESCE(im.units_name, 'nos') as unit
                FROM sales s
                LEFT JOIN item_measure im ON im.item = s.item
                WHERE s.v_id=?
            """, (invoice_id,)).fetchall()
        elif vt in ('purchase', 'purchase_order', 'debit_note'):
            rows = conn.execute("""
                SELECT p.item as item_name, p.units as qty, p.cost_per_unit as price, 
                       p.discount as discount, p.scheme_name as tax_pct, (p.units * p.cost_per_unit) as total,
                       p.desc as desc, p.extra_costs as extra_costs, COALESCE(im.units_name, 'nos') as unit
                FROM purchases p
                LEFT JOIN item_measure im ON im.item = p.item
                WHERE p.v_id=?
            """, (invoice_id,)).fetchall()
        
        # If no items found in sales or purchases table:
        if not rows:
            va_rows = conn.execute("SELECT debit, credit, amount FROM vouchers_all WHERE v_id=?", (invoice_id,)).fetchall()
            if va_rows:
                for va in va_rows:
                    desc_text = v_row['narration'] or f"{va['debit']} / {va['credit']}"
                    rows.append({
                        'item_name': desc_text,
                        'qty': 1,
                        'unit': 'nos',
                        'price': float(va['amount'] or 0),
                        'discount': 0,
                        'tax_pct': '',
                        'total': float(va['amount'] or 0),
                        'desc': ''
                    })
            elif float(v_row['amount'] or 0) > 0:
                rows.append({
                    'item_name': v_row['narration'] or 'Transaction',
                    'qty': 1,
                    'unit': 'nos',
                    'price': float(v_row['amount'] or 0),
                    'discount': 0,
                    'tax_pct': '',
                    'total': float(v_row['amount'] or 0),
                    'desc': ''
                })
    conn.close()
    return [dict(r) for r in rows]

# ── Reports ──────────────────────────────────────────────────────────────────

def get_profit_loss(from_date, to_date):
    conn = get_conn()
    sales = conn.execute("SELECT COALESCE(SUM(amount),0) as t FROM vouchers WHERE v_type='sale' AND date BETWEEN ? AND ?",
                         (from_date, to_date)).fetchone()['t']
    purchases = conn.execute("SELECT COALESCE(SUM(amount),0) as t FROM vouchers WHERE v_type='purchase' AND date BETWEEN ? AND ?",
                              (from_date, to_date)).fetchone()['t']
    expenses = conn.execute("SELECT COALESCE(SUM(amount),0) as t FROM vouchers WHERE v_type='expense' AND date BETWEEN ? AND ?",
                             (from_date, to_date)).fetchone()['t']
    conn.close()
    return {'sales': sales, 'purchases': purchases, 'expenses': expenses, 'profit': sales - purchases - expenses}

def get_ledger(account_id, from_date, to_date):
    conn = get_conn()
    rows = conn.execute("""
        SELECT va.date, v.narration as description, 
               CASE WHEN va.debit=? THEN va.amount ELSE 0 END as debit,
               CASE WHEN va.credit=? THEN va.amount ELSE 0 END as credit,
               0 as balance
        FROM vouchers_all va
        LEFT JOIN vouchers v ON v.v_id = va.v_id
        WHERE (va.debit=? OR va.credit=?) AND va.date BETWEEN ? AND ?
        ORDER BY va.date
    """, (account_id, account_id, account_id, account_id, from_date, to_date)).fetchall()
    
    bal = 0
    results = []
    for r in rows:
        d = dict(r)
        bal += (d['credit'] - d['debit'])
        d['balance'] = bal
        results.append(d)
        
    conn.close()
    return results


def get_all_units():
    conn = get_conn()
    rows = conn.execute("SELECT * FROM units_measure ORDER BY units_name").fetchall()
    conn.close()
    return [dict(r) for r in rows]

def add_unit(data):
    conn = get_conn()
    cols = ", ".join(data.keys())
    placeholders = ", ".join("?" * len(data))
    query = f"INSERT INTO units_measure ({cols}) VALUES ({placeholders})"
    conn.execute(query, tuple(data.values()))
    conn.commit()
    conn.close()

def delete_unit(unit_name):
    conn = get_conn()
    conn.execute("DELETE FROM units_measure WHERE units_name=?", (unit_name,))
    conn.commit()
    conn.close()

def update_unit(old_name, data):
    conn = get_conn()
    set_clause = ", ".join(f"{k}=?" for k in data.keys())
    query = f"UPDATE units_measure SET {set_clause} WHERE units_name=?"
    conn.execute(query, tuple(data.values()) + (old_name,))
    conn.commit()
    conn.close()

def get_all_services():
    conn = get_conn()
    conn.row_factory = __import__('sqlite3').Row
    rows = conn.execute("SELECT * FROM service ORDER BY service_name").fetchall()
    conn.close()
    return [dict(r) for r in rows]

def get_service(service_name):
    conn = get_conn()
    conn.row_factory = __import__('sqlite3').Row
    row = conn.execute("SELECT * FROM service WHERE service_name=?", (service_name,)).fetchone()
    conn.close()
    return dict(row) if row else None

def add_service(data):
    conn = get_conn()
    cols = ", ".join(data.keys())
    placeholders = ", ".join("?" * len(data))
    query = f"INSERT INTO service ({cols}) VALUES ({placeholders})"
    conn.execute(query, tuple(data.values()))
    conn.commit()
    conn.close()

def update_service(old_name, data):
    conn = get_conn()
    set_clause = ", ".join(f"{k}=?" for k in data.keys())
    query = f"UPDATE service SET {set_clause} WHERE service_name=?"
    conn.execute(query, tuple(data.values()) + (old_name,))
    conn.commit()
    conn.close()

def delete_service(service_name):
    conn = get_conn()
    conn.execute("DELETE FROM service WHERE service_name=?", (service_name,))
    conn.commit()
    conn.close()

def get_all_taxes():
    conn = get_conn()
    conn.row_factory = __import__('sqlite3').Row
    try:
        rows = conn.execute("SELECT * FROM tax ORDER BY scheme_name").fetchall()
    except Exception:
        rows = []
    conn.close()
    return [dict(r) for r in rows]

def update_po_status(po_id, status):
    conn = get_conn()
    conn.execute("UPDATE vouchers SET status=? WHERE v_id=?", (status, po_id))
    conn.commit()
    conn.close()

def get_account_balance(account_name):
    conn = get_conn()
    row = conn.execute("SELECT cl_bal FROM account_detail WHERE aname=?", (account_name,)).fetchone()
    conn.close()
    if row:
        return row['cl_bal']
    return 0.0

def create_receipt(receipt_no, date, received_into, received_from, sub_total, discount, tax, grand_total, narration, selected_vouchers):
    conn = get_conn()
    
    # 1. Insert into vouchers table
    v_id = conn.execute(
        "INSERT INTO vouchers (vch_no, v_type, date, amount, narration, paid_amount, debit, credit) VALUES (?,?,?,?,?,?,?,?)",
        (receipt_no, 'receipt', date, grand_total, narration, 0.0, received_into, received_from)
    ).lastrowid
    
    # 2. Update paid_amount in selected sale vouchers
    if selected_vouchers:
        for item in selected_vouchers:
            v_no = item[0]
            amount_paid = item[1]
            v_type = item[2] if len(item) > 2 else 'sale'
            conn.execute("UPDATE vouchers SET paid_amount = COALESCE(paid_amount, 0) + ? WHERE vch_no = ? AND v_type=?", (amount_paid, v_no, v_type))
    else:
        # Auto-apply using FIFO if none explicitly selected
        unpaid = conn.execute("SELECT vch_no, amount, paid_amount, v_type FROM vouchers WHERE v_type IN ('sale', 'journal', 'credit_note') AND (debit=? OR credit=?) AND (amount - COALESCE(paid_amount,0)) > 0.01 ORDER BY date ASC", (received_from, received_from)).fetchall()
        remaining = grand_total
        for r in unpaid:
            if remaining <= 0: break
            due = r[1] - (r[2] if r[2] else 0)
            pay = min(due, remaining)
            conn.execute("UPDATE vouchers SET paid_amount = COALESCE(paid_amount, 0) + ? WHERE vch_no = ? AND v_type=?", (pay, r[0], r[3]))
            remaining -= pay
        
    # 3. Insert into vouchers_all for ledger
    conn.execute("INSERT INTO vouchers_all (v_id, debit, credit, amount, date) VALUES (?,?,?,?,?)",
                 (v_id, received_into, received_from, grand_total, date))
                 
    # 4. Update Customer balance (decrease balance)
    conn.execute("UPDATE account_detail SET cl_bal=cl_bal-? WHERE aname=?", (grand_total, received_from))
    
    # 5. Update Cash/Bank balance (increase balance)
    conn.execute("UPDATE account_detail SET cl_bal=cl_bal+? WHERE aname=?", (grand_total, received_into))
    
    conn.commit()
    conn.close()
    return v_id

def delete_voucher(v_id):
    conn = get_conn()
    vch = conn.execute("SELECT v_type, amount, status, linked_po_id FROM vouchers WHERE v_id=?", (v_id,)).fetchone()
    if not vch:
        return
    v_type, amount, status, linked_po_id = vch
    
    if v_type == 'sale':
        items = conn.execute("SELECT item, units FROM sales WHERE v_id=?", (v_id,)).fetchall()
        for item in items:
            conn.execute("UPDATE stock SET cl_bal=cl_bal+? WHERE stock_name=?", (item['units'], item['item']))
        conn.execute("DELETE FROM sales WHERE v_id=?", (v_id,))
    elif v_type == 'purchase':
        items = conn.execute("SELECT item, units FROM purchases WHERE v_id=?", (v_id,)).fetchall()
        for item in items:
            conn.execute("UPDATE stock SET cl_bal=cl_bal-? WHERE stock_name=?", (item['units'], item['item']))
        conn.execute("DELETE FROM purchases WHERE v_id=?", (v_id,))
    elif v_type == 'purchase_order':
        conn.execute("DELETE FROM purchases WHERE v_id=?", (v_id,))
    elif v_type == 'estimate':
        conn.execute("DELETE FROM sales WHERE v_id=?", (v_id,))
        
    if v_type in ('expense', 'income', 'contra'):
        va_rows = conn.execute("SELECT debit, credit, amount FROM vouchers_all WHERE v_id=?", (v_id,)).fetchall()
        for va in va_rows:
            conn.execute("UPDATE account_detail SET cl_bal=cl_bal-? WHERE aname=?", (va['amount'], va['debit']))
            conn.execute("UPDATE account_detail SET cl_bal=cl_bal+? WHERE aname=?", (va['amount'], va['credit']))
        conn.execute("DELETE FROM vouchers_all WHERE v_id=?", (v_id,))
    else:
        va = conn.execute("SELECT debit, credit FROM vouchers_all WHERE v_id=?", (v_id,)).fetchone()
        if va:
            if v_type == 'sale':
                conn.execute("UPDATE account_detail SET cl_bal=cl_bal-? WHERE aname=?", (amount, va['debit']))
            elif v_type == 'purchase':
                conn.execute("UPDATE account_detail SET cl_bal=cl_bal+? WHERE aname=?", (amount, va['credit']))
            elif v_type == 'receipt':
                conn.execute("UPDATE account_detail SET cl_bal=cl_bal-? WHERE aname=?", (amount, va['debit']))
                conn.execute("UPDATE account_detail SET cl_bal=cl_bal+? WHERE aname=?", (amount, va['credit']))
            conn.execute("DELETE FROM vouchers_all WHERE v_id=?", (v_id,))

    if linked_po_id:
        conn.execute("UPDATE vouchers SET status='OPEN' WHERE v_id=?", (linked_po_id,))
        
    conn.execute("DELETE FROM vouchers WHERE v_id=?", (v_id,))
    conn.commit()
    conn.close()

def cancel_voucher(v_id):
    conn = get_conn()
    vch = conn.execute("SELECT v_type, amount, status, linked_po_id FROM vouchers WHERE v_id=?", (v_id,)).fetchone()
    if not vch or vch['status'] == 'CANCELLED':
        return
    v_type, amount, status, linked_po_id = vch
    
    if v_type == 'sale':
        items = conn.execute("SELECT item, units FROM sales WHERE v_id=?", (v_id,)).fetchall()
        for item in items:
            conn.execute("UPDATE stock SET cl_bal=cl_bal+? WHERE stock_name=?", (item['units'], item['item']))
    elif v_type == 'purchase':
        items = conn.execute("SELECT item, units FROM purchases WHERE v_id=?", (v_id,)).fetchall()
        for item in items:
            conn.execute("UPDATE stock SET cl_bal=cl_bal-? WHERE stock_name=?", (item['units'], item['item']))
            
    if v_type in ('expense', 'income', 'contra'):
        va_rows = conn.execute("SELECT debit, credit, amount FROM vouchers_all WHERE v_id=?", (v_id,)).fetchall()
        for va in va_rows:
            conn.execute("UPDATE account_detail SET cl_bal=cl_bal-? WHERE aname=?", (va['amount'], va['debit']))
            conn.execute("UPDATE account_detail SET cl_bal=cl_bal+? WHERE aname=?", (va['amount'], va['credit']))
    else:
        va = conn.execute("SELECT debit, credit FROM vouchers_all WHERE v_id=?", (v_id,)).fetchone()
        if va:
            if v_type == 'sale':
                conn.execute("UPDATE account_detail SET cl_bal=cl_bal-? WHERE aname=?", (amount, va['debit']))
            elif v_type == 'purchase':
                conn.execute("UPDATE account_detail SET cl_bal=cl_bal+? WHERE aname=?", (amount, va['credit']))
            elif v_type == 'receipt':
                conn.execute("UPDATE account_detail SET cl_bal=cl_bal-? WHERE aname=?", (amount, va['debit']))
                conn.execute("UPDATE account_detail SET cl_bal=cl_bal+? WHERE aname=?", (amount, va['credit']))
            
    if linked_po_id:
        conn.execute("UPDATE vouchers SET status='OPEN' WHERE v_id=?", (linked_po_id,))
        
    conn.execute("UPDATE vouchers SET status='CANCELLED', amount=0, paid_amount=0 WHERE v_id=?", (v_id,))
    conn.commit()
    conn.close()


def get_setting(key, default=None):
    conn = get_conn()
    try:
        row = conn.execute("SELECT value FROM app_settings WHERE key=?", (key,)).fetchone()
        if row:
            return row[0]
        return default
    except sqlite3.OperationalError:
        return default
    finally:
        conn.close()

def set_setting(key, value):
    conn = get_conn()
    try:
        conn.execute("CREATE TABLE IF NOT EXISTS app_settings (key TEXT PRIMARY KEY, value TEXT)")
        conn.execute("INSERT OR REPLACE INTO app_settings (key, value) VALUES (?, ?)", (key, str(value)))
        conn.commit()
    finally:
        conn.close()

def get_overdue_invoices_sum():
    conn = get_conn()
    row = conn.execute('''
        SELECT SUM(amount - COALESCE(paid_amount,0)) as total FROM vouchers
        WHERE v_type='sale' AND (amount - COALESCE(paid_amount,0)) > 0 AND date < date('now')
    ''').fetchone()
    conn.close()
    return row['total'] if row and row['total'] else 0

def get_unpaid_invoices_sum():
    conn = get_conn()
    row = conn.execute('''
        SELECT SUM(amount - COALESCE(paid_amount,0)) as total FROM vouchers WHERE v_type='sale' AND (amount - COALESCE(paid_amount,0)) > 0
    ''').fetchone()
    conn.close()
    return row['total'] if row and row['total'] else 0


def create_payment(payment_no, date, paid_to, paid_from, sub_total, discount, tax, grand_total, narration, selected_vouchers):
    conn = get_conn()
    
    # 1. Insert into vouchers table
    v_id = conn.execute(
        "INSERT INTO vouchers (vch_no, v_type, date, amount, narration, paid_amount, debit, credit) VALUES (?,?,?,?,?,?,?,?)",
        (payment_no, 'payment', date, grand_total, narration, 0.0, paid_to, paid_from)
    ).lastrowid
    
    # 2. Update paid_amount in selected purchase vouchers
    if selected_vouchers:
        for item in selected_vouchers:
            v_no = item[0]
            amount_paid = item[1]
            v_type = item[2] if len(item) > 2 else 'purchase'
            conn.execute("UPDATE vouchers SET paid_amount = COALESCE(paid_amount, 0) + ? WHERE vch_no = ? AND v_type=?", (amount_paid, v_no, v_type))
    else:
        # Auto-apply using FIFO if none explicitly selected
        unpaid = conn.execute("SELECT vch_no, amount, paid_amount, v_type FROM vouchers WHERE v_type IN ('purchase', 'journal', 'debit_note') AND (debit=? OR credit=?) AND (amount - COALESCE(paid_amount,0)) > 0.01 ORDER BY date ASC", (paid_to, paid_to)).fetchall()
        remaining = grand_total
        for r in unpaid:
            if remaining <= 0: break
            due = r[1] - (r[2] if r[2] else 0)
            pay = min(due, remaining)
            conn.execute("UPDATE vouchers SET paid_amount = COALESCE(paid_amount, 0) + ? WHERE vch_no = ? AND v_type=?", (pay, r[0], r[3]))
            remaining -= pay
        
    # 3. Insert into vouchers_all for ledger
    conn.execute("INSERT INTO vouchers_all (v_id, debit, credit, amount, date) VALUES (?,?,?,?,?)",
                 (v_id, paid_to, paid_from, grand_total, date))
                 
    # 4. Update Supplier balance (decrease balance)
    conn.execute("UPDATE account_detail SET cl_bal=cl_bal-? WHERE aname=?", (grand_total, paid_to))
    
    # 5. Update Cash/Bank balance (decrease balance)
    conn.execute("UPDATE account_detail SET cl_bal=cl_bal-? WHERE aname=?", (grand_total, paid_from))
    
    conn.commit()
    conn.close()
    return v_id


def get_next_journal_no():
    conn = get_conn()
    row = conn.execute("SELECT COUNT(*) as cnt FROM vouchers WHERE v_type='journal'").fetchone()
    conn.close()
    num = (row['cnt'] if row else 0) + 1
    return f"JRN{num}"

def create_journal(journal_no, date, line_items, narration='', ref_doc=''):
    conn = get_conn()
    
    total_amount = sum(float(item.get('debit', 0) or 0) for item in line_items)
    
    debit_names = [item['account'] for item in line_items if float(item.get('debit', 0) or 0) > 0]
    credit_names = [item['account'] for item in line_items if float(item.get('credit', 0) or 0) > 0]
    
    debit_str = "\n".join(debit_names)
    credit_str = "\n".join(credit_names)
    
    # 1. Insert main voucher row
    v_id = conn.execute(
        "INSERT INTO vouchers (vch_no, v_type, date, amount, narration, paid_amount, debit, credit) VALUES (?,?,?,?,?,?,?,?)",
        (journal_no, 'journal', date, total_amount, narration, 0.0, debit_str, credit_str)
    ).lastrowid
    
    # 2. Insert line items into vouchers_all & update account_detail balances
    for item in line_items:
        acc_name = item['account']
        d_amt = float(item.get('debit', 0) or 0)
        c_amt = float(item.get('credit', 0) or 0)
        
        conn.execute(
            "INSERT INTO vouchers_all (v_id, debit, credit, amount, date) VALUES (?,?,?,?,?)",
            (v_id, acc_name if d_amt > 0 else '', acc_name if c_amt > 0 else '', d_amt if d_amt > 0 else c_amt, date)
        )
        
        if d_amt > 0:
            conn.execute("UPDATE account_detail SET cl_bal=cl_bal+? WHERE aname=?", (d_amt, acc_name))
        elif c_amt > 0:
            conn.execute("UPDATE account_detail SET cl_bal=cl_bal-? WHERE aname=?", (c_amt, acc_name))
            
    conn.commit()
    conn.close()
    return v_id


def get_next_credit_note_no():
    conn = get_conn()
    row = conn.execute("SELECT COUNT(*) as cnt FROM vouchers WHERE v_type='credit_note'").fetchone()
    conn.close()
    num = (row['cnt'] if row else 0) + 1
    return f"SLR{num}"

def create_credit_note(credit_note_no, date, debit_acc, customer_acc, line_items, narration='', ref_doc='', round_off=0.0, other_charges=0.0):
    conn = get_conn()
    total = sum(float(item.get('total', 0) or 0) for item in line_items) + float(other_charges or 0) + float(round_off or 0)
    
    # 1. Insert main voucher row
    v_id = conn.execute(
        "INSERT INTO vouchers (vch_no, v_type, date, amount, narration, paid_amount, debit, credit, detail1) VALUES (?,?,?,?,?,?,?,?,?)",
        (credit_note_no, 'credit_note', date, total, narration, 0.0, debit_acc, customer_acc, ref_doc)
    ).lastrowid
    
    # 2. Insert line items into sales table & update stock (returned stock increases)
    for item in line_items:
        conn.execute("""INSERT INTO sales (v_id, date, item, sp_per_unit, units, discount, desc) 
                        VALUES (?,?,?,?,?,?,?)""",
                     (v_id, date, item['name'], item['price'], item['qty'], item.get('discount', 0), item.get('desc', '')))
        conn.execute("UPDATE stock SET cl_bal=cl_bal+? WHERE stock_name=?", (item['qty'], item['name']))
        
    # 3. Update account balances: Sales Return (debit_acc) increases balance, Customer (customer_acc) decreases balance
    conn.execute("UPDATE account_detail SET cl_bal=cl_bal+? WHERE aname=?", (total, debit_acc))
    conn.execute("UPDATE account_detail SET cl_bal=cl_bal-? WHERE aname=?", (total, customer_acc))
    
    # 4. Insert into vouchers_all for ledger
    conn.execute("INSERT INTO vouchers_all (v_id, debit, credit, amount, date) VALUES (?,?,?,?,?)",
                 (v_id, debit_acc, customer_acc, total, date))
                 
    conn.commit()
    conn.close()
    return v_id


def get_next_debit_note_no():
    conn = get_conn()
    row = conn.execute("SELECT COUNT(*) as cnt FROM vouchers WHERE v_type='debit_note'").fetchone()
    conn.close()
    num = (row['cnt'] if row else 0) + 1
    return f"PRR{num}"

def create_debit_note(debit_note_no, date, supplier_acc, credit_acc, line_items, narration='', ref_doc='', round_off=0.0, other_charges=0.0):
    conn = get_conn()
    total = sum(float(item.get('total', 0) or 0) for item in line_items) + float(other_charges or 0) + float(round_off or 0)
    
    # 1. Insert main voucher row
    v_id = conn.execute(
        "INSERT INTO vouchers (vch_no, v_type, date, amount, narration, paid_amount, debit, credit, detail1) VALUES (?,?,?,?,?,?,?,?,?)",
        (debit_note_no, 'debit_note', date, total, narration, 0.0, supplier_acc, credit_acc, ref_doc)
    ).lastrowid
    
    # 2. Insert line items into purchases table & update stock (returned stock decreases)
    for item in line_items:
        conn.execute("""INSERT INTO purchases (v_id, date, item, cost_per_unit, units, discount, desc) 
                        VALUES (?,?,?,?,?,?,?)""",
                     (v_id, date, item['name'], item['price'], item['qty'], item.get('discount', 0), item.get('desc', '')))
        conn.execute("UPDATE stock SET cl_bal=cl_bal-? WHERE stock_name=?", (item['qty'], item['name']))
        
    # 3. Update account balances: Supplier (supplier_acc) decreases balance (debited), Purchases Return (credit_acc) increases balance (credited)
    conn.execute("UPDATE account_detail SET cl_bal=cl_bal-? WHERE aname=?", (total, supplier_acc))
    conn.execute("UPDATE account_detail SET cl_bal=cl_bal+? WHERE aname=?", (total, credit_acc))
    
    # 4. Insert into vouchers_all for ledger
    conn.execute("INSERT INTO vouchers_all (v_id, debit, credit, amount, date) VALUES (?,?,?,?,?)",
                 (v_id, supplier_acc, credit_acc, total, date))
                 
    conn.commit()
    conn.close()
    return v_id


def get_all_categories():
    conn = get_conn()
    # Check if empty, pre-populate with default
    cnt = conn.execute("SELECT COUNT(*) as cnt FROM item_category").fetchone()['cnt']
    if cnt == 0:
        conn.execute("INSERT INTO item_category (category_name) VALUES ('default')")
        conn.commit()
    rows = conn.execute("SELECT category_id as id, category_name as name FROM item_category").fetchall()
    conn.close()
    return [dict(r) for r in rows]

def get_subcategories_by_category(category_id):
    conn = get_conn()
    # Check if empty, pre-populate default linked to this category
    cnt = conn.execute("SELECT COUNT(*) as cnt FROM item_subcategory WHERE category_id=?", (category_id,)).fetchone()['cnt']
    if cnt == 0:
        conn.execute("INSERT INTO item_subcategory (subcategory_name, category_id) VALUES ('default', ?)", (category_id,))
        conn.commit()
    rows = conn.execute("SELECT subcategory_id as id, subcategory_name as name, category_id FROM item_subcategory WHERE category_id=?", (category_id,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]

def add_category(name):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("INSERT INTO item_category (category_name) VALUES (?)", (name,))
    cat_id = cur.lastrowid
    # Also add a default subcategory for this category so it's not empty
    cur.execute("INSERT INTO item_subcategory (subcategory_name, category_id) VALUES ('default', ?)", (cat_id,))
    conn.commit()
    conn.close()
    return cat_id

def update_category(category_id, name):
    conn = get_conn()
    conn.execute("UPDATE item_category SET category_name=? WHERE category_id=?", (name, category_id))
    conn.commit()
    conn.close()

def delete_category(category_id):
    conn = get_conn()
    # Delete subcategories referencing this category
    sub_ids = [r['subcategory_id'] for r in conn.execute("SELECT subcategory_id FROM item_subcategory WHERE category_id=?", (category_id,)).fetchall()]
    for sid in sub_ids:
        # Update items pointing to this subcategory to NULL or default (id=1)
        conn.execute("UPDATE item_measure SET item_subcategory_id=NULL WHERE item_subcategory_id=?", (sid,))
    conn.execute("DELETE FROM item_subcategory WHERE category_id=?", (category_id,))
    conn.execute("DELETE FROM item_category WHERE category_id=?", (category_id,))
    conn.commit()
    conn.close()

def add_subcategory(name, category_id):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("INSERT INTO item_subcategory (subcategory_name, category_id) VALUES (?, ?)", (name, category_id))
    sub_id = cur.lastrowid
    conn.commit()
    conn.close()
    return sub_id

def update_subcategory(subcategory_id, name):
    conn = get_conn()
    conn.execute("UPDATE item_subcategory SET subcategory_name=? WHERE subcategory_id=?", (name, subcategory_id))
    conn.commit()
    conn.close()

def delete_subcategory(subcategory_id):
    conn = get_conn()
    conn.execute("UPDATE item_measure SET item_subcategory_id=NULL WHERE item_subcategory_id=?", (subcategory_id,))
    conn.execute("DELETE FROM item_subcategory WHERE subcategory_id=?", (subcategory_id,))
    conn.commit()
    conn.close()

# ── User Management ────────────────────────────────────────────────────────
def get_all_users():
    conn = get_conn()
    rows = conn.execute("SELECT * FROM users ORDER BY id ASC").fetchall()
    conn.close()
    return [dict(r) for r in rows]

def add_user(data):
    conn = get_conn()
    cols = ', '.join(data.keys())
    placeholders = ', '.join(['?'] * len(data))
    try:
        conn.execute(f"INSERT INTO users ({cols}) VALUES ({placeholders})", tuple(data.values()))
        conn.commit()
        success = True
    except Exception as e:
        print("add_user error:", e)
        success = False # duplicate username or error
    conn.close()
    return success

def update_user(user_id_or_username, data):
    conn = get_conn()
    sets = ', '.join([f"{k} = ?" for k in data.keys()])
    try:
        if isinstance(user_id_or_username, int) or (isinstance(user_id_or_username, str) and str(user_id_or_username).isdigit()):
            values = tuple(data.values()) + (int(user_id_or_username),)
            conn.execute(f"UPDATE users SET {sets} WHERE id = ?", values)
        else:
            values = tuple(data.values()) + (str(user_id_or_username),)
            conn.execute(f"UPDATE users SET {sets} WHERE username = ?", values)
        conn.commit()
        success = True
    except Exception as e:
        print("update_user error:", e)
        success = False
    conn.close()
    return success

def delete_user(user_id_or_username):
    conn = get_conn()
    if isinstance(user_id_or_username, int) or (isinstance(user_id_or_username, str) and str(user_id_or_username).isdigit()):
        conn.execute("DELETE FROM users WHERE id = ?", (int(user_id_or_username),))
    else:
        conn.execute("DELETE FROM users WHERE username = ?", (str(user_id_or_username),))
    conn.commit()
    conn.close()

def authenticate_user(db_path, entered_user, entered_pass):
    """
    Validates entered username and password against Company Admin settings
    and sub-users in the users table.
    Returns: (is_authenticated: bool, user_dict_or_admin: dict, error_message: str)
    """
    import os, sqlite3
    if not os.path.exists(db_path):
        return False, None, "Database file not found."
        
    u_str = str(entered_user or "").strip()
    p_str = str(entered_pass or "").strip()
    
    try:
        conn = sqlite3.connect(os.path.abspath(db_path))
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        
        # 1. Fetch company password settings
        s_rows = c.execute(
            "SELECT key, value FROM app_settings WHERE key IN ('company_enable_pwd', 'company_username', 'company_password')"
        ).fetchall()
        settings = {r['key']: str(r['value'] or '') for r in s_rows}
        
        enable_pwd = settings.get('company_enable_pwd', '0')
        admin_user = settings.get('company_username', '')
        admin_pwd = settings.get('company_password', '')
        
        # If company password is not enabled, allow instant access
        if enable_pwd != "1" or not admin_pwd:
            print("DB AUTH: Instant access granted. Returning admin.")
            conn.close()
            return True, {"username": admin_user or "admin", "is_admin": True, "initials": ""}, ""
            
        # 2. Check Admin credentials
        # Admin matches if password matches AND (username is blank, matches admin_user, or is 'admin')
        print(f"DB AUTH: p_str='{p_str}', admin_pwd='{admin_pwd}', u_str='{u_str}', admin_user='{admin_user}'")
        if p_str == admin_pwd.strip():
            if not u_str or u_str.lower() == admin_user.strip().lower() or u_str.lower() == "admin":
                print("DB AUTH: Admin matched.")
                conn.close()
                return True, {"username": admin_user or "admin", "is_admin": True, "initials": ""}, ""
                
        # 3. Check Sub-Users table (case-insensitive username, whitespace-trimmed)
        try:
            u_row = c.execute(
                "SELECT * FROM users WHERE LOWER(TRIM(username)) = LOWER(?) AND TRIM(CAST(password AS TEXT)) = ?",
                (u_str, p_str)
            ).fetchone()
            if u_row:
                user_dict = dict(u_row)
                user_dict["is_admin"] = False
                print(f"DB AUTH: Sub-user matched: {user_dict['username']}")
                conn.close()
                return True, user_dict, ""
        except Exception as e_sql:
            print("Users table query exception:", e_sql)
            
        conn.close()
        return False, None, "Invalid username or password"
    except Exception as e:
        print("authenticate_user general error:", e)
        return False, None, str(e)

def get_ledger_advanced(is_group, name_or_group, from_date, to_date, voucher_type="ALL"):
    conn = get_conn()
    if is_group:
        acc_rows = conn.execute("SELECT aname FROM account_detail WHERE account_group=?", (name_or_group,)).fetchall()
        accounts = [r['aname'] for r in acc_rows]
    else:
        accounts = [name_or_group]
    if not accounts:
        conn.close()
        return 0, []
    
    placeholders = ",".join("?" * len(accounts))
    
    op_bal_row = conn.execute(f"SELECT COALESCE(SUM(op_bal), 0) as total FROM account_detail WHERE aname IN ({placeholders})", tuple(accounts)).fetchone()
    base_op_bal = op_bal_row['total'] if op_bal_row else 0
    
    prev_debit_row = conn.execute(f"SELECT COALESCE(SUM(amount), 0) as total FROM vouchers_all WHERE debit IN ({placeholders}) AND date < ?", tuple(accounts) + (from_date,)).fetchone()
    prev_credit_row = conn.execute(f"SELECT COALESCE(SUM(amount), 0) as total FROM vouchers_all WHERE credit IN ({placeholders}) AND date < ?", tuple(accounts) + (from_date,)).fetchone()
    
    prev_debit = prev_debit_row['total'] if prev_debit_row else 0
    prev_credit = prev_credit_row['total'] if prev_credit_row else 0
    
    opening_balance = base_op_bal + prev_debit - prev_credit
    
    params = tuple(accounts) * 5 + (from_date, to_date)
    v_type_clause = ""
    if voucher_type != "ALL":
        v_type_clause = " AND v.v_type = ?"
        params += (voucher_type.lower(),)
        
    query = f"""
        SELECT va.date, 
               CASE WHEN va.debit IN ({placeholders}) THEN va.credit ELSE va.debit END as particulars,
               v.vch_no,
               v.ref_no,
               v.v_type,
               CASE WHEN va.debit IN ({placeholders}) THEN va.amount ELSE 0 END as debit,
               CASE WHEN va.credit IN ({placeholders}) THEN va.amount ELSE 0 END as credit
        FROM vouchers_all va
        LEFT JOIN vouchers v ON va.v_id = v.v_id
        WHERE (va.debit IN ({placeholders}) OR va.credit IN ({placeholders}))
          AND va.date BETWEEN ? AND ?
          {v_type_clause}
        ORDER BY va.date ASC, va.v_id ASC
    """
    rows = conn.execute(query, params).fetchall()
    results = [dict(r) for r in rows]
    conn.close()
    return opening_balance, results

def get_customer_supplier_list(is_customer, as_on_date):
    conn = get_conn()
    account_group = "Sundry Debtors" if is_customer else "Sundry Creditors"
    rows = conn.execute("SELECT * FROM account_detail WHERE account_group=?", (account_group,)).fetchall()
    results = []
    for r in rows:
        d = dict(r)
        aname = d['aname']
        op_bal = d['op_bal'] if d['op_bal'] else 0
        deb_row = conn.execute("SELECT COALESCE(SUM(amount), 0) as total FROM vouchers_all WHERE debit=? AND date <= ?", (aname, as_on_date)).fetchone()
        deb = deb_row['total'] if deb_row else 0
        cre_row = conn.execute("SELECT COALESCE(SUM(amount), 0) as total FROM vouchers_all WHERE credit=? AND date <= ?", (aname, as_on_date)).fetchone()
        cre = cre_row['total'] if cre_row else 0
        d['calculated_balance'] = op_bal + deb - cre if is_customer else op_bal + cre - deb
        results.append(d)
    conn.close()
    return results

def get_aging_data(is_receivable, name_or_group, is_group, as_on_date):
    conn = get_conn()
    base_group = "Sundry Debtors" if is_receivable else "Sundry Creditors"
    if is_group:
        if name_or_group == "ALL":
            acc_rows = conn.execute("SELECT aname FROM account_detail WHERE account_group=?", (base_group,)).fetchall()
        else:
            acc_rows = conn.execute("SELECT aname FROM account_detail WHERE account_group=?", (name_or_group,)).fetchall()
        accounts = [r['aname'] for r in acc_rows]
    else:
        if name_or_group == "ALL":
            accounts = [r['aname'] for r in conn.execute("SELECT aname FROM account_detail WHERE account_group=?", (base_group,)).fetchall()]
        else:
            accounts = [name_or_group]
    results = []
    for aname in accounts:
        row = conn.execute("SELECT op_bal FROM account_detail WHERE aname=?", (aname,)).fetchone()
        if not row: continue
        op_bal = row['op_bal'] if row['op_bal'] else 0
        deb_row = conn.execute("SELECT COALESCE(SUM(amount), 0) as total FROM vouchers_all WHERE debit=? AND date <= ?", (aname, as_on_date)).fetchone()
        deb = deb_row['total'] if deb_row else 0
        cre_row = conn.execute("SELECT COALESCE(SUM(amount), 0) as total FROM vouchers_all WHERE credit=? AND date <= ?", (aname, as_on_date)).fetchone()
        cre = cre_row['total'] if cre_row else 0
        
        outstanding = op_bal + deb - cre if is_receivable else op_bal + cre - deb
        if outstanding <= 0:
            results.append({'name': aname, '0-14': 0, '15-30': 0, '31-60': 0, '61-90': 0, '90+': 0, 'total': outstanding})
            continue
            
        vch_type = 'sales' if is_receivable else 'purchase'
        invoices = conn.execute("""
            SELECT v.date, va.amount 
            FROM vouchers_all va
            JOIN vouchers v ON va.v_id = v.v_id
            WHERE (va.debit=? OR va.credit=?) AND v.v_type=? AND va.date <= ?
            ORDER BY va.date DESC
        """, (aname, aname, vch_type, as_on_date)).fetchall()
        
        rem = outstanding
        buckets = {'0-14': 0, '15-30': 0, '31-60': 0, '61-90': 0, '90+': 0}
        from datetime import datetime
        as_dt = datetime.strptime(as_on_date, "%Y-%m-%d")
        
        for inv in invoices:
            if rem <= 0: break
            inv_amt = inv['amount']
            inv_dt = datetime.strptime(inv['date'], "%Y-%m-%d")
            days = (as_dt - inv_dt).days
            amt_to_take = min(rem, inv_amt)
            if days <= 14: buckets['0-14'] += amt_to_take
            elif days <= 30: buckets['15-30'] += amt_to_take
            elif days <= 60: buckets['31-60'] += amt_to_take
            elif days <= 90: buckets['61-90'] += amt_to_take
            else: buckets['90+'] += amt_to_take
            rem -= amt_to_take
            
        if rem > 0:
            buckets['90+'] += rem
            
        results.append({
            'name': aname,
            '0-14': buckets['0-14'],
            '15-30': buckets['15-30'],
            '31-60': buckets['31-60'],
            '61-90': buckets['61-90'],
            '90+': buckets['90+'],
            'total': outstanding
        })
    conn.close()
    return results

def get_outstanding_data(is_receivable, name_or_group, is_group, start_date, end_date):
    conn = get_conn()
    base_group = "Sundry Debtors" if is_receivable else "Sundry Creditors"
    
    if is_group:
        if name_or_group == "ALL":
            acc_rows = conn.execute("SELECT aname, phone, credit_period FROM account_detail WHERE account_group=?", (base_group,)).fetchall()
        else:
            acc_rows = conn.execute("SELECT aname, phone, credit_period FROM account_detail WHERE account_group=?", (name_or_group,)).fetchall()
    else:
        if name_or_group == "ALL":
            acc_rows = conn.execute("SELECT aname, phone, credit_period FROM account_detail WHERE account_group=?", (base_group,)).fetchall()
        else:
            acc_rows = conn.execute("SELECT aname, phone, credit_period FROM account_detail WHERE aname=?", (name_or_group,)).fetchall()
            
    results = []
    from datetime import datetime, timedelta
    
    for row in acc_rows:
        aname = row['aname']
        phone = row['phone'] if row['phone'] else ""
        cp = row['credit_period'] if row['credit_period'] else 0
        
        ob_row = conn.execute("SELECT op_bal FROM account_detail WHERE aname=?", (aname,)).fetchone()
        op_bal = ob_row['op_bal'] if ob_row and ob_row['op_bal'] else 0
        
        invoices = []
        if is_receivable:
            tot_credits_row = conn.execute("SELECT COALESCE(SUM(amount), 0) as total FROM vouchers_all WHERE credit=? AND date <= ?", (aname, end_date)).fetchone()
            total_payments = tot_credits_row['total']
            
            if op_bal > 0:
                invoices.append({'date': 'Opening', 'vch_no': 'op', 'ref_no': '', 'amount': op_bal, 'is_op': True})
            elif op_bal < 0:
                total_payments += abs(op_bal)
                
            debits = conn.execute("""
                SELECT v.date, v.vch_no, v.ref_no, va.amount
                FROM vouchers_all va
                JOIN vouchers v ON va.v_id = v.v_id
                WHERE va.debit=? AND va.date BETWEEN ? AND ?
                ORDER BY va.date ASC, va.v_id ASC
            """, (aname, start_date, end_date)).fetchall()
            
            for d in debits: invoices.append({'date': d['date'], 'vch_no': d['vch_no'], 'ref_no': d['ref_no'], 'amount': d['amount'], 'is_op': False})
                
        else:
            tot_debits_row = conn.execute("SELECT COALESCE(SUM(amount), 0) as total FROM vouchers_all WHERE debit=? AND date <= ?", (aname, end_date)).fetchone()
            total_payments = tot_debits_row['total']
            
            if op_bal > 0:
                invoices.append({'date': 'Opening', 'vch_no': 'op', 'ref_no': '', 'amount': op_bal, 'is_op': True})
            elif op_bal < 0:
                total_payments += abs(op_bal)
                
            credits = conn.execute("""
                SELECT v.date, v.vch_no, v.ref_no, va.amount
                FROM vouchers_all va
                JOIN vouchers v ON va.v_id = v.v_id
                WHERE va.credit=? AND va.date BETWEEN ? AND ?
                ORDER BY va.date ASC, va.v_id ASC
            """, (aname, start_date, end_date)).fetchall()
            
            for c in credits: invoices.append({'date': c['date'], 'vch_no': c['vch_no'], 'ref_no': c['ref_no'], 'amount': c['amount'], 'is_op': False})
                
        for inv in invoices:
            if total_payments >= inv['amount']:
                total_payments -= inv['amount']
                inv['outstanding'] = 0
            else:
                inv['outstanding'] = inv['amount'] - total_payments
                total_payments = 0
                
            if inv['outstanding'] > 0:
                if inv['is_op']:
                    due_date = ""
                    overdue = ""
                else:
                    try:
                        dt = datetime.strptime(inv['date'], "%Y-%m-%d")
                        due_dt = dt + timedelta(days=cp)
                        due_date = due_dt.strftime("%Y-%m-%d")
                        overdue = (datetime.today() - due_dt).days
                        if overdue < 0: overdue = 0
                    except:
                        due_date = ""
                        overdue = ""
                        
                results.append({
                    'date': inv['date'],
                    'vch_no': inv['vch_no'],
                    'ref_no': inv['ref_no'] if inv['ref_no'] else "",
                    'party_name': aname,
                    'phone': phone,
                    'invoice_amount': inv['amount'],
                    'outstanding_amount': inv['outstanding'],
                    'due_date': due_date,
                    'overdue_days': overdue
                })

    conn.close()
    return results

def get_inventory_item_details(category, subcategory, item_name, account_name, voucher_type, start_date, end_date):
    conn = get_conn()
    
    # Filter items based on category, subcategory, item_name
    item_query = "SELECT item, units_name FROM item_measure WHERE 1=1"
    item_params = []
    
    if item_name and item_name != "ALL":
        item_query += " AND item = ?"
        item_params.append(item_name)
    else:
        # Category filtering could be added here if needed, but for simplicity assuming item_name or ALL is primarily used
        pass
        
    items = conn.execute(item_query, tuple(item_params)).fetchall()
    results = []
    
    for it in items:
        i_name = it['item']
        unit = it['units_name'] if it['units_name'] else ""
        
        # Calculate opening balance ON start_date
        # Current balance is in stock table
        stock_row = conn.execute("SELECT cl_bal FROM stock WHERE stock_name=?", (i_name,)).fetchone()
        curr_bal = stock_row['cl_bal'] if stock_row else 0.0
        
        # Find all transactions from start_date to infinity
        # We subtract inwards and add outwards to curr_bal to walk backwards to start_date
        inwards_future = conn.execute("""
            SELECT SUM(p.units) as qty FROM purchases p
            JOIN vouchers v ON p.v_id = v.v_id
            WHERE p.item = ? AND v.date >= ?
        """, (i_name, start_date)).fetchone()['qty']
        
        outwards_future = conn.execute("""
            SELECT SUM(s.units) as qty FROM sales s
            JOIN vouchers v ON s.v_id = v.v_id
            WHERE s.item = ? AND v.date >= ?
        """, (i_name, start_date)).fetchone()['qty']
        
        in_fut = inwards_future if inwards_future else 0.0
        out_fut = outwards_future if outwards_future else 0.0
        
        opening_qty = curr_bal - in_fut + out_fut
        # Opening cost? We can assume average cost is same as default purchase price for simplicity, or 0
        im_row = conn.execute("SELECT defaultpurchaseprice FROM item_measure WHERE item=?", (i_name,)).fetchone()
        avg_cost = im_row['defaultpurchaseprice'] if im_row and im_row['defaultpurchaseprice'] else 0.0
        
        opening_value = opening_qty * avg_cost
        
        # Fetch transactions strictly between start and end date
        # Inwards
        in_rows = conn.execute("""
            SELECT v.date, v.v_type, COALESCE(v.credit, 'Cash') as particulars, v.vch_no, 
                   p.cost_per_unit as rate, p.units as in_qty, (p.cost_per_unit * p.units) as in_val,
                   0.0 as out_qty, 0.0 as out_val, v.narration
            FROM purchases p
            JOIN vouchers v ON p.v_id = v.v_id
            WHERE p.item = ? AND v.date BETWEEN ? AND ?
        """, (i_name, start_date, end_date)).fetchall()
        
        # Outwards
        out_rows = conn.execute("""
            SELECT v.date, v.v_type, COALESCE(v.debit, 'Cash') as particulars, v.vch_no, 
                   s.sp_per_unit as rate, 0.0 as in_qty, 0.0 as in_val,
                   s.units as out_qty, (s.sp_per_unit * s.units) as out_val, v.narration
            FROM sales s
            JOIN vouchers v ON s.v_id = v.v_id
            WHERE s.item = ? AND v.date BETWEEN ? AND ?
        """, (i_name, start_date, end_date)).fetchall()
        
        all_trans = []
        for r in in_rows: all_trans.append(dict(r))
        for r in out_rows: all_trans.append(dict(r))
        
        # Filter by voucher type or account name if needed
        if voucher_type != "ALL":
            all_trans = [t for t in all_trans if t['v_type'].lower() == voucher_type.lower()]
        if account_name != "ALL":
            all_trans = [t for t in all_trans if t['particulars'].lower() == aname.lower()]
            
        # Sort by date, then by inward first, then outward
        all_trans.sort(key=lambda x: (x['date'], x['out_qty'] > 0))
        
        running_qty = opening_qty
        processed_trans = []
        
        tot_in_qty = 0
        tot_in_val = 0
        tot_out_qty = 0
        tot_out_val = 0
        tot_cost = 0
        tot_gp = 0
        
        for t in all_trans:
            running_qty += t['in_qty'] - t['out_qty']
            t['closing_qty'] = running_qty
            
            # Profit calc for outwards
            if t['out_qty'] > 0:
                t['cost'] = t['out_qty'] * avg_cost
                t['gross_profit'] = t['out_val'] - t['cost']
                t['profit_percent'] = (t['gross_profit'] / t['cost'] * 100) if t['cost'] > 0 else 0
                tot_cost += t['cost']
                tot_gp += t['gross_profit']
            else:
                t['cost'] = 0
                t['gross_profit'] = 0
                t['profit_percent'] = 0
                # Update avg cost on inwards
                if (running_qty) > 0 and t['in_val'] > 0:
                    old_val = (running_qty - t['in_qty']) * avg_cost
                    avg_cost = (old_val + t['in_val']) / running_qty
                    
            tot_in_qty += t['in_qty']
            tot_in_val += t['in_val']
            tot_out_qty += t['out_qty']
            tot_out_val += t['out_val']
            
            processed_trans.append(t)
            
        closing_value = running_qty * avg_cost
        
        if opening_qty == 0 and tot_in_qty == 0 and tot_out_qty == 0:
            continue # Skip fully empty items if zero qty is not requested (can handle outside)
            
        results.append({
            'item_name': i_name,
            'unit': unit,
            'opening_qty': opening_qty,
            'opening_value': opening_value,
            'avg_cost': avg_cost,
            'transactions': processed_trans,
            'closing_qty': running_qty,
            'closing_value': closing_value,
            'totals': {
                'in_qty': tot_in_qty,
                'in_val': tot_in_val,
                'out_qty': tot_out_qty,
                'out_val': tot_out_val,
                'cost': tot_cost,
                'gp': tot_gp
            }
        })
        
    conn.close()
    return results

def get_inventory_summary_data(start_date, end_date, category="ALL", subcategory="ALL", 
                               qty_filter=None, qty_val=None, account_name="ALL", 
                               only_active=False, less_used=False):
    conn = get_conn()
    
    query = """
        SELECT m.*, c.category_name, sc.subcategory_name 
        FROM item_measure m
        LEFT JOIN item_subcategory sc ON m.item_subcategory_id = sc.subcategory_id
        LEFT JOIN item_category c ON sc.category_id = c.category_id
        WHERE 1=1
    """
    params = []
    
    if category != "ALL":
        query += " AND c.category_name = ?"
        params.append(category)
        
    items = conn.execute(query, tuple(params)).fetchall()
    
    results = []
    for it in items:
        i_name = it['item']
        keys = it.keys()
        cat_name = it['category_name'] if 'category_name' in keys and it['category_name'] else 'DEFAULT'
        unit = it['units_name'] if 'units_name' in keys and it['units_name'] else ""
        sku = it['sku'] if 'sku' in keys and it['sku'] else ""
        barcode = it['barcode'] if 'barcode' in keys and it['barcode'] else ""
        desc = it['description'] if 'description' in keys and it['description'] else ""
        def_disc = float(it['defaultdiscountpercent']) if 'defaultdiscountpercent' in keys and it['defaultdiscountpercent'] else 0.0
        def_tax = it['defaulttax'] if 'defaulttax' in keys and it['defaulttax'] else ""
        def_sp = float(it['defaultsellingprice']) if 'defaultsellingprice' in keys and it['defaultsellingprice'] else 0.0
        def_pp = float(it['defaultpurchaseprice']) if 'defaultpurchaseprice' in keys and it['defaultpurchaseprice'] else 0.0

        
        # We need to simulate from the beginning to end_date to get the exact cost
        # Wait, if start_date is provided, the UI shows stock between start_date and end_date?
        # Actually Inventory Summary usually shows closing stock AS OF end_date.
        # But we'll calculate all transactions up to end_date.
        
        # Get all transactions for this item up to end_date
        in_rows = conn.execute("""
            SELECT v.date, p.cost_per_unit as rate, p.units as in_qty, 0.0 as out_qty
            FROM purchases p
            JOIN vouchers v ON p.v_id = v.v_id
            WHERE p.item = ? AND v.date <= ?
        """, (i_name, end_date)).fetchall()
        
        out_rows = conn.execute("""
            SELECT v.date, s.sp_per_unit as rate, 0.0 as in_qty, s.units as out_qty
            FROM sales s
            JOIN vouchers v ON s.v_id = v.v_id
            WHERE s.item = ? AND v.date <= ?
        """, (i_name, end_date)).fetchall()
        
        all_trans = []
        for r in in_rows: all_trans.append(dict(r))
        for r in out_rows: all_trans.append(dict(r))
        
        all_trans.sort(key=lambda x: (x['date'], x['out_qty'] > 0))
        
        # Base balance is current stock, but we must wind back to the beginning of time if we don't know the exact starting point.
        # Actually, in Book Keeper, `stock` table holds current stock.
        # If we calculate entirely from transactions, we might miss the initial stock if it wasn't entered as a voucher!
        # Initial stock is in stock table? Or is stock table just a cache?
        # Let's get current stock from stock table:
        stock_row = conn.execute("SELECT cl_bal FROM stock WHERE stock_name=?", (i_name,)).fetchone()
        curr_bal = stock_row['cl_bal'] if stock_row else 0.0
        
        # Calculate future transactions after end_date to subtract from current stock to find stock AT end_date
        in_fut = conn.execute("""
            SELECT SUM(p.units) as qty FROM purchases p
            JOIN vouchers v ON p.v_id = v.v_id
            WHERE p.item = ? AND v.date > ?
        """, (i_name, end_date)).fetchone()['qty']
        
        out_fut = conn.execute("""
            SELECT SUM(s.units) as qty FROM sales s
            JOIN vouchers v ON s.v_id = v.v_id
            WHERE s.item = ? AND v.date > ?
        """, (i_name, end_date)).fetchone()['qty']
        
        in_fut = in_fut if in_fut else 0.0
        out_fut = out_fut if out_fut else 0.0
        
        closing_qty = curr_bal - in_fut + out_fut
        
        # For average cost, we run forward
        running_qty = 0
        avg_cost = def_pp if def_pp else 0.0
        
        tot_in_qty = 0
        tot_out_qty = 0
        
        for t in all_trans:
            if t['date'] >= start_date:
                tot_in_qty += t['in_qty']
                tot_out_qty += t['out_qty']
                
            running_qty += t['in_qty'] - t['out_qty']
            if t['in_qty'] > 0 and t['rate'] > 0:
                # Update avg cost
                old_val = (running_qty - t['in_qty']) * avg_cost
                if old_val < 0: old_val = 0
                avg_cost = (old_val + (t['in_qty'] * t['rate'])) / running_qty if running_qty > 0 else avg_cost
        
        # Apply quantity filter
        if qty_filter == 'less_than' and qty_val is not None:
            if closing_qty >= qty_val: continue
        elif qty_filter == 'equal_to' and qty_val is not None:
            if closing_qty != qty_val: continue
        elif qty_filter == 'greater_than' and qty_val is not None:
            if closing_qty <= qty_val: continue
        elif qty_filter == 'about_to_finish':
            if closing_qty > 10: continue
            
        results.append({
            'category': cat_name,
            'item_name': i_name,
            'unit': unit,
            'sku': sku,
            'barcode': barcode,
            'desc': desc,
            'def_disc': def_disc,
            'def_tax': def_tax,
            'def_sp': def_sp,
            'def_pp': def_pp,
            'closing_qty': closing_qty,
            'inward_qty': tot_in_qty,
            'outward_qty': tot_out_qty,
            'avg_cost': avg_cost,
            'value': closing_qty * avg_cost
        })
        
    conn.close()
    return results

def get_daybook_data(start_date, end_date, account_name="ALL", voucher_type="ALL"):
    conn = get_conn()
    
    query = """
        SELECT date, debit, credit, v_type, vch_no, amount
        FROM vouchers
        WHERE date >= ? AND date <= ?
    """
    params = [start_date, end_date]
    
    if account_name != "ALL":
        query += " AND (debit = ? OR credit = ?)"
        params.extend([account_name, account_name])
        
    if voucher_type != "ALL":
        query += " AND v_type = ?"
        params.append(voucher_type)
        
    query += " ORDER BY date ASC, v_id ASC"
    
    rows = conn.execute(query, tuple(params)).fetchall()
    
    results = []
    for r in rows:
        results.append({
            'date': r['date'],
            'debit': r['debit'] if r['debit'] else "",
            'credit': r['credit'] if r['credit'] else "",
            'v_type': r['v_type'],
            'vch_no': r['vch_no'],
            'amount': float(r['amount']) if r['amount'] else 0.0
        })
        
    conn.close()
    return results

def get_cash_flow_data(start_date, end_date):
    """
    Returns categorized cash flow data based on Book Keeper account groups using the indirect method.
    Positive value = cash inflow.
    Negative value = cash outflow.
    """
    conn = get_conn()
    conn.row_factory = __import__('sqlite3').Row
    
    # Helper to get the change in balance for a specific group of accounts
    # For assets: Opening - Closing (decrease is positive cash flow)
    # For liabilities/equity: Closing - Opening (increase is positive cash flow)
    def get_group_change(group_name, is_asset=True):
        query = """
            SELECT SUM(
                CASE WHEN debit = aname THEN amount ELSE 0 END -
                CASE WHEN credit = aname THEN amount ELSE 0 END
            ) as net_debit
            FROM account_detail
            JOIN vouchers ON (account_detail.aname = vouchers.debit OR account_detail.aname = vouchers.credit)
            WHERE account_detail.account_group = ? AND vouchers.date >= ? AND vouchers.date <= ?
        """
        # Since net_debit is (Debit - Credit)
        # For Assets, Debit is positive, Credit is negative. So net_debit = Closing - Opening.
        # Thus for Assets, cash flow (Opening - Closing) = -net_debit.
        # For Liabilities, Credit is positive, Debit is negative. So (Credit - Debit) = Closing - Opening.
        # Thus for Liabilities, cash flow (Closing - Opening) = -net_debit.
        # It turns out BOTH are mathematically -net_debit because:
        # Asset increases (net_debit > 0) -> Cash outflow (negative)
        # Liability increases (net_credit > 0 -> net_debit < 0) -> Cash inflow (positive)
        
        row = conn.execute(query, (group_name, start_date, end_date)).fetchone()
        net_debit = float(row['net_debit']) if row and row['net_debit'] else 0.0
        return -net_debit

    # Net Income: Total Income - Total Expenses
    inc_query = """
        SELECT SUM(
            CASE WHEN credit = aname THEN amount ELSE 0 END -
            CASE WHEN debit = aname THEN amount ELSE 0 END
        ) as net_credit
        FROM account_detail
        JOIN vouchers ON (account_detail.aname = vouchers.debit OR account_detail.aname = vouchers.credit)
        WHERE (account_detail.account_group = 'Direct Income' OR account_detail.account_group = 'Indirect Incomes')
        AND vouchers.date >= ? AND vouchers.date <= ?
    """
    row_inc = conn.execute(inc_query, (start_date, end_date)).fetchone()
    total_income = float(row_inc['net_credit']) if row_inc and row_inc['net_credit'] else 0.0
    
    exp_query = """
        SELECT SUM(
            CASE WHEN debit = aname THEN amount ELSE 0 END -
            CASE WHEN credit = aname THEN amount ELSE 0 END
        ) as net_debit
        FROM account_detail
        JOIN vouchers ON (account_detail.aname = vouchers.debit OR account_detail.aname = vouchers.credit)
        WHERE (account_detail.account_group = 'Direct Expenses' OR account_detail.account_group = 'Indirect Expenses' OR account_detail.account_group = 'Purchase Accounts')
        AND vouchers.date >= ? AND vouchers.date <= ?
    """
    row_exp = conn.execute(exp_query, (start_date, end_date)).fetchone()
    total_expense = float(row_exp['net_debit']) if row_exp and row_exp['net_debit'] else 0.0
    
    # Wait, Sales Accounts are also income!
    sales_query = """
        SELECT SUM(
            CASE WHEN credit = aname THEN amount ELSE 0 END -
            CASE WHEN debit = aname THEN amount ELSE 0 END
        ) as net_credit
        FROM account_detail
        JOIN vouchers ON (account_detail.aname = vouchers.debit OR account_detail.aname = vouchers.credit)
        WHERE account_detail.account_group = 'Sales Accounts'
        AND vouchers.date >= ? AND vouchers.date <= ?
    """
    row_sales = conn.execute(sales_query, (start_date, end_date)).fetchone()
    total_sales = float(row_sales['net_credit']) if row_sales and row_sales['net_credit'] else 0.0
    
    net_income = (total_income + total_sales) - total_expense

    # Customers Balance (Sundry Debtors)
    customers_balance = get_group_change('Sundry Debtors')
    
    # Suppliers Balance (Sundry Creditors)
    suppliers_balance = get_group_change('Sundry Creditors')
    
    # Stock (Stock-in-Hand)
    stock = get_group_change('Stock-in-Hand')
    
    # Current Assets
    current_assets = get_group_change('Current Assets')
    
    # Current Liability
    current_liability = get_group_change('Current Liabilities')
    
    # Tax Payable (Duties and Taxes)
    tax_payable = get_group_change('Duties and Taxes')
    
    # Fixed Assets
    fixed_assets = get_group_change('Fixed Assets')
    
    # Capital A/C
    capital_ac = get_group_change('Capital Account')
    
    # Loans & Advances
    loans_advances = get_group_change('Loans & Advances (Asset)')
    loans_liability = get_group_change('Loans (Liability)')

    conn.close()
    
    return {
        "Net Income": net_income,
        "Customers Balance": customers_balance,
        "Suppliers Balance": suppliers_balance,
        "Stock": stock,
        "Current Assets": current_assets,
        "Current Liability": current_liability,
        "Tax Payable": tax_payable,
        "Fixed Assets": fixed_assets,
        "Capital A/C": capital_ac,
        "Loans & Advances": loans_advances + loans_liability
    }

def get_sales_register_data(start_date, end_date, account_name="ALL", compute_profit=True):
    conn = get_conn()
    conn.row_factory = __import__('sqlite3').Row
    
    # Base query for Sales vouchers
    query = """
        SELECT v.*, a.account_group as group_name 
        FROM vouchers v
        LEFT JOIN account_detail a ON v.debit = a.aname
        WHERE v.v_type = 'sale' AND v.date >= ? AND v.date <= ?
    """
    params = [start_date, end_date]
    
    if account_name != "ALL":
        query += " AND v.debit = ?"
        params.append(account_name)
        
    query += " ORDER BY v.date ASC, v.v_id ASC"
    
    vouchers = conn.execute(query, params).fetchall()
    
    results = []
    
    for v in vouchers:
        v_id = v['v_id']
        trans_val = float(v['amount'] or 0.0)
        
        # Calculate Received Amount
        group_name = v['group_name']
        if group_name in ["Cash-in-Hand", "Bank Accounts"]:
            received_amt = trans_val
        else:
            rec_row = conn.execute("SELECT SUM(amount) as amt FROM bill_receipt_payment WHERE b_v_id = ?", (v_id,)).fetchone()
            received_amt = float(rec_row['amt']) if rec_row and rec_row['amt'] else 0.0
            
        outstanding_amt = trans_val - received_amt
        
        # Calculate Cost
        cost = 0.0
        if compute_profit:
            items = conn.execute("SELECT item, units FROM sales WHERE v_id = ?", (v_id,)).fetchall()
            for itm in items:
                im = conn.execute("SELECT defaultpurchaseprice FROM item_measure WHERE item = ?", (itm['item'],)).fetchone()
                if im and im['defaultpurchaseprice']:
                    cost += float(im['defaultpurchaseprice']) * float(itm['units'] or 0.0)
                    
        gross_rev = trans_val
        gross_profit = gross_rev - cost
        profit_percent = (gross_profit / gross_rev * 100) if gross_rev > 0 else 0.0
        
        results.append({
            "date": v['date'],
            "particulars": v['debit'],
            "vchno": v['vch_no'],
            "po_no": v['linked_po_id'] or "", # actually, linked_po_id is an integer. Let's just leave it blank or fetch po_no if needed
            "trans_value": trans_val,
            "received": received_amt,
            "outstanding": outstanding_amt,
            "gross_rev": gross_rev,
            "cost": cost,
            "gross_profit": gross_profit,
            "profit_percent": profit_percent,
            "narration": v['narration'] or ""
        })
        
    conn.close()
    return results

def get_purchase_register_data(start_date, end_date, account_name="ALL", fetch_items=False):
    conn = get_conn()
    conn.row_factory = __import__('sqlite3').Row
    
    # Base query for Purchase vouchers
    query = """
        SELECT v.*, a.account_group as group_name 
        FROM vouchers v
        LEFT JOIN account_detail a ON v.credit = a.aname
        WHERE v.v_type = 'purchase' AND v.date >= ? AND v.date <= ?
    """
    params = [start_date, end_date]
    
    if account_name != "ALL":
        query += " AND v.credit = ?"
        params.append(account_name)
        
    query += " ORDER BY v.date ASC, v.v_id ASC"
    
    vouchers = conn.execute(query, params).fetchall()
    
    results = []
    
    for v in vouchers:
        v_id = v['v_id']
        trans_val = float(v['amount'] or 0.0)
        
        # Calculate Tax
        tax_row = conn.execute("SELECT SUM(amount) as amt FROM voucher_tax WHERE voucher_id = ?", (v_id,)).fetchone()
        tax_amt = float(tax_row['amt']) if tax_row and tax_row['amt'] else 0.0
        
        # Calculate Total Quantity
        qty_row = conn.execute("SELECT SUM(units) as total_qty FROM purchases WHERE v_id = ?", (v_id,)).fetchone()
        total_qty = float(qty_row['total_qty']) if qty_row and qty_row['total_qty'] else 0.0
        
        items = []
        if fetch_items:
            itm_rows = conn.execute("SELECT item, units, cost_per_unit, desc FROM purchases WHERE v_id = ?", (v_id,)).fetchall()
            for row in itm_rows:
                items.append({
                    "item": row['item'],
                    "qty": row['units'],
                    "rate": row['cost_per_unit'],
                    "desc": row['desc'] or ""
                })
        
        results.append({
            "date": v['date'],
            "particulars": v['credit'] or "Cash", # usually credit is the supplier for purchase
            "vchno": v['vch_no'],
            "supplier_inv_no": v['ref_no'] or "",
            "quantity": total_qty,
            "tax": tax_amt,
            "voucher_value": trans_val,
            "narration": v['narration'] or "",
            "items": items
        })
        
    conn.close()
    return results



def get_monthly_breakdown_data(start_date, end_date):
    import datetime
    conn = get_conn()
    conn.row_factory = __import__('sqlite3').Row
    
    months = []
    sd = datetime.datetime.strptime(start_date, "%Y-%m-%d")
    ed = datetime.datetime.strptime(end_date, "%Y-%m-%d")
    curr = sd.replace(day=1)
    while curr <= ed:
        months.append(curr.strftime("%Y-%m"))
        curr = (curr + datetime.timedelta(days=32)).replace(day=1)
        
    result = {
        "INCOME": {
            "PURCHASES RETURN": {"Purchases Return": {m: 0.0 for m in months}},
            "SALES A/C": {"Sales": {m: 0.0 for m in months}},
            "DIRECT INCOME": {
                "Discount On Purchase": {m: 0.0 for m in months},
                "Discount received": {m: 0.0 for m in months}
            },
            "INDIRECT INCOME": {
                "Cartage charged": {m: 0.0 for m in months},
                "Interest received": {m: 0.0 for m in months},
                "Round Off": {m: 0.0 for m in months},
                "Shipping": {m: 0.0 for m in months}
            }
        },
        "EXPENSE": {
            "PURCHASES A/C": {"Purchase": {m: 0.0 for m in months}},
            "SALES RETURN": {"Sales Return": {m: 0.0 for m in months}},
            "DIRECT EXPENSES": {
                "Cartage": {m: 0.0 for m in months},
                "Discount On Sale": {m: 0.0 for m in months},
                "Discount given": {m: 0.0 for m in months}
            },
            "INDIRECT EXPENSES": {
                "Advertisement expenses": {m: 0.0 for m in months},
                "Rent paid": {m: 0.0 for m in months},
                "Round off": {m: 0.0 for m in months},
                "test": {m: 0.0 for m in months}
            }
        }
    }
    
    query = """
        SELECT va.debit, va.credit, va.amount, va.date, v.v_type 
        FROM vouchers_all va
        JOIN vouchers v ON va.v_id = v.v_id
        WHERE va.date >= ? AND va.date <= ?
    """
    rows = conn.execute(query, (start_date, end_date)).fetchall()
    
    for row in rows:
        v_type = row['v_type']
        debit = row['debit']
        credit = row['credit']
        amt = float(row['amount'] or 0.0)
        
        try:
            mth = datetime.datetime.strptime(row['date'], "%Y-%m-%d").strftime("%Y-%m")
        except:
            try:
                mth = datetime.datetime.strptime(row['date'], "%B %d, %Y").strftime("%Y-%m")
            except:
                mth = months[0] if months else ""
                
        acc_name = None
        category = None
        group = None
        
        if v_type == 'sale' and credit == 'Sales Account':
            acc_name = "Sales"
            category = "INCOME"
            group = "SALES A/C"
        elif v_type == 'debit_note' and credit == 'Purchases Return':
            acc_name = "Purchases Return"
            category = "INCOME"
            group = "PURCHASES RETURN"
        elif v_type == 'income' and credit:
            acc_name = credit
            category = "INCOME"
            if acc_name.lower() in ["discount on purchase", "discount received"]:
                group = "DIRECT INCOME"
            else:
                group = "INDIRECT INCOME"
                
        elif v_type == 'purchase' and debit == 'Purchase Account':
            acc_name = "Purchase"
            category = "EXPENSE"
            group = "PURCHASES A/C"
        elif v_type == 'credit_note' and debit == 'Sales Return':
            acc_name = "Sales Return"
            category = "EXPENSE"
            group = "SALES RETURN"
        elif v_type == 'expense' and debit:
            acc_name = debit
            category = "EXPENSE"
            if acc_name.lower() in ["cartage", "discount on sale", "discount given"]:
                group = "DIRECT EXPENSES"
            else:
                group = "INDIRECT EXPENSES"
                
        if acc_name and category and group and mth in months:
            if acc_name not in result[category][group]:
                result[category][group][acc_name] = {m: 0.0 for m in months}
            result[category][group][acc_name][mth] += amt
            
    final_result = {"INCOME": {}, "EXPENSE": {}}
    for cat in result:
        for grp in result[cat]:
            final_result[cat][grp] = []
            for acc_name, m_data in result[cat][grp].items():
                final_result[cat][grp].append({"account": acc_name, "months": m_data})
                
    conn.close()
    return {"months": months, "data": final_result}

def get_best_customers_data(start_date, end_date):
    conn = get_conn()
    conn.row_factory = __import__('sqlite3').Row
    
    # Fetch all customers
    accounts = conn.execute("SELECT aname, op_bal FROM account_detail WHERE a_type = 'customer' OR account_group = 'Sundry Debtors'").fetchall()
    
    results = []
    
    for acc in accounts:
        name = acc['aname']
        op_bal = float(acc['op_bal'] or 0.0)
        
        # Calculate B/F: op_bal + debits before start_date - credits before start_date
        bf_query = """
            SELECT 
                SUM(CASE WHEN debit = ? THEN amount ELSE 0 END) as tot_deb,
                SUM(CASE WHEN credit = ? THEN amount ELSE 0 END) as tot_cred
            FROM vouchers_all
            WHERE (debit = ? OR credit = ?) AND date < ?
        """
        bf_row = conn.execute(bf_query, (name, name, name, name, start_date)).fetchone()
        tot_deb_before = float(bf_row['tot_deb'] or 0.0)
        tot_cred_before = float(bf_row['tot_cred'] or 0.0)
        bf = op_bal + tot_deb_before - tot_cred_before
        
        # Calculate SALES within date range (where v_type='sale' and debit=customer)
        # Note: Sales amount in vouchers table INCLUDES tax. We also need to fetch tax.
        sales_query = """
            SELECT v.v_id, v.amount 
            FROM vouchers v
            WHERE v.v_type = 'sale' AND v.debit = ? AND v.date >= ? AND v.date <= ?
        """
        sales_vouchers = conn.execute(sales_query, (name, start_date, end_date)).fetchall()
        
        tot_sales_inc = 0.0
        tot_tax = 0.0
        
        for v in sales_vouchers:
            v_id = v['v_id']
            tot_sales_inc += float(v['amount'] or 0.0)
            
            tax_row = conn.execute("SELECT SUM(amount) as t FROM voucher_tax WHERE voucher_id = ?", (v_id,)).fetchone()
            tot_tax += float(tax_row['t'] or 0.0)
            
        tot_sales_exc = tot_sales_inc - tot_tax
        
        # If no activity during the period, skip
        if tot_sales_inc == 0 and tot_tax == 0:
            continue
            
        # Calculate C/F: B/F + debits during period - credits during period
        cf_query = """
            SELECT 
                SUM(CASE WHEN debit = ? THEN amount ELSE 0 END) as tot_deb,
                SUM(CASE WHEN credit = ? THEN amount ELSE 0 END) as tot_cred
            FROM vouchers_all
            WHERE (debit = ? OR credit = ?) AND date >= ? AND date <= ?
        """
        cf_row = conn.execute(cf_query, (name, name, name, name, start_date, end_date)).fetchone()
        tot_deb_during = float(cf_row['tot_deb'] or 0.0)
        tot_cred_during = float(cf_row['tot_cred'] or 0.0)
        
        cf = bf + tot_deb_during - tot_cred_during
        
        results.append({
            "name": name,
            "bf": bf,
            "sales_inc": tot_sales_inc,
            "sales_exc": tot_sales_exc,
            "tax": tot_tax,
            "cf": cf
        })
        
    conn.close()
    
    # Sort by sales_inc descending
    results.sort(key=lambda x: x['sales_inc'], reverse=True)
    return results

def get_top_suppliers_data(start_date, end_date):
    conn = get_conn()
    conn.row_factory = __import__('sqlite3').Row
    
    # Fetch all suppliers
    accounts = conn.execute("SELECT aname, op_bal FROM account_detail WHERE a_type = 'supplier' OR account_group = 'Sundry Creditors'").fetchall()
    
    results = []
    
    for acc in accounts:
        name = acc['aname']
        # For suppliers, op_bal is generally a credit balance.
        op_bal = float(acc['op_bal'] or 0.0)
        
        # Calculate B/F: op_bal + credits before start_date - debits before start_date
        bf_query = """
            SELECT 
                SUM(CASE WHEN credit = ? THEN amount ELSE 0 END) as tot_cred,
                SUM(CASE WHEN debit = ? THEN amount ELSE 0 END) as tot_deb
            FROM vouchers_all
            WHERE (credit = ? OR debit = ?) AND date < ?
        """
        bf_row = conn.execute(bf_query, (name, name, name, name, start_date)).fetchone()
        tot_cred_before = float(bf_row['tot_cred'] or 0.0)
        tot_deb_before = float(bf_row['tot_deb'] or 0.0)
        bf = op_bal + tot_cred_before - tot_deb_before
        
        # Calculate PURCHASES within date range (where v_type='purchase' and credit=supplier)
        purch_query = """
            SELECT v.v_id, v.amount 
            FROM vouchers v
            WHERE v.v_type = 'purchase' AND v.credit = ? AND v.date >= ? AND v.date <= ?
        """
        purch_vouchers = conn.execute(purch_query, (name, start_date, end_date)).fetchall()
        
        tot_purch_inc = 0.0
        tot_tax = 0.0
        
        for v in purch_vouchers:
            v_id = v['v_id']
            tot_purch_inc += float(v['amount'] or 0.0)
            
            tax_row = conn.execute("SELECT SUM(amount) as t FROM voucher_tax WHERE voucher_id = ?", (v_id,)).fetchone()
            tot_tax += float(tax_row['t'] or 0.0)
            
        tot_purch_exc = tot_purch_inc - tot_tax
        
        # If no activity during the period, skip
        if tot_purch_inc == 0 and tot_tax == 0:
            continue
            
        # Calculate C/F: B/F + credits during period - debits during period
        cf_query = """
            SELECT 
                SUM(CASE WHEN credit = ? THEN amount ELSE 0 END) as tot_cred,
                SUM(CASE WHEN debit = ? THEN amount ELSE 0 END) as tot_deb
            FROM vouchers_all
            WHERE (credit = ? OR debit = ?) AND date >= ? AND date <= ?
        """
        cf_row = conn.execute(cf_query, (name, name, name, name, start_date, end_date)).fetchone()
        tot_cred_during = float(cf_row['tot_cred'] or 0.0)
        tot_deb_during = float(cf_row['tot_deb'] or 0.0)
        
        cf = bf + tot_cred_during - tot_deb_during
        
        results.append({
            "name": name,
            "bf": bf,
            "purch_inc": tot_purch_inc,
            "purch_exc": tot_purch_exc,
            "tax": tot_tax,
            "cf": cf
        })
        
    conn.close()
    
    # Sort by purch_inc descending
    results.sort(key=lambda x: x['purch_inc'], reverse=True)
    return results


def get_inventory_value_as_of(date_str):
    # Quick helper to get total inventory value at a specific date
    try:
        data = get_inventory_summary_data(date_str, date_str)
        return sum(d.get('value', 0.0) for d in data)
    except:
        return 0.0

def get_detailed_profit_loss(start_date, end_date):
    import datetime
    conn = get_conn()
    conn.row_factory = __import__('sqlite3').Row
    
    # Calculate Opening and Closing Inventory
    try:
        sd_obj = datetime.datetime.strptime(start_date, "%Y-%m-%d")
        prev_day = (sd_obj - datetime.timedelta(days=1)).strftime("%Y-%m-%d")
        open_inv = get_inventory_value_as_of(prev_day)
    except:
        open_inv = 0.0
    
    close_inv = get_inventory_value_as_of(end_date)
    
    # We will use vouchers and vouchers_all to get exactly the same balances 
    # as the monthly breakdown, but aggregated.
    query = """
        SELECT va.debit, va.credit, va.amount, v.v_type 
        FROM vouchers_all va
        JOIN vouchers v ON va.v_id = v.v_id
        WHERE va.date >= ? AND va.date <= ?
    """
    rows = conn.execute(query, (start_date, end_date)).fetchall()
    
    # Trading Account (Direct)
    purchases = 0.0
    purchases_return = 0.0
    sales = 0.0
    sales_return = 0.0
    direct_expenses = 0.0
    direct_income = 0.0
    
    # P/L Account (Indirect)
    indirect_expenses = 0.0
    indirect_income = 0.0
    
    for row in rows:
        v_type = row['v_type']
        debit = row['debit']
        credit = row['credit']
        amt = float(row['amount'] or 0.0)
        
        # Determine category based on logic similar to monthly breakdown
        if v_type == 'sale' and credit == 'Sales Account':
            sales += amt
        elif v_type == 'debit_note' and credit == 'Purchases Return':
            purchases_return += amt
        elif v_type == 'income' and credit:
            acc_name = credit
            if acc_name.lower() in ["discount on purchase", "discount received"]:
                direct_income += amt
            else:
                indirect_income += amt
                
        elif v_type == 'purchase' and debit == 'Purchase Account':
            purchases += amt
        elif v_type == 'credit_note' and debit == 'Sales Return':
            sales_return += amt
        elif v_type == 'expense' and debit:
            acc_name = debit
            if acc_name.lower() in ["cartage", "discount on sale", "discount given"]:
                direct_expenses += amt
            else:
                indirect_expenses += amt
                
    # Calculate Gross Profit
    trading_dr = open_inv + purchases + sales_return + direct_expenses
    trading_cr = close_inv + sales + purchases_return + direct_income
    
    gross_profit = 0.0
    gross_loss = 0.0
    if trading_cr > trading_dr:
        gross_profit = trading_cr - trading_dr
        trading_dr += gross_profit # balance
    elif trading_dr > trading_cr:
        gross_loss = trading_dr - trading_cr
        trading_cr += gross_loss # balance
        
    trading_total = trading_dr # Both sides are equal now
    
    # Calculate Net Profit
    pl_dr = indirect_expenses + gross_loss
    pl_cr = indirect_income + gross_profit
    
    net_profit = 0.0
    net_loss = 0.0
    if pl_cr > pl_dr:
        net_profit = pl_cr - pl_dr
        pl_dr += net_profit
    elif pl_dr > pl_cr:
        net_loss = pl_dr - pl_cr
        pl_cr += net_loss
        
    pl_total = pl_dr
    
    conn.close()
    
    return {
        "trading": {
            "dr": [
                {"name": "Opening Inventory", "val": open_inv},
                {"name": "Purchases A/C", "val": purchases},
                {"name": "Sales Return", "val": sales_return},
                {"name": "Direct Expenses", "val": direct_expenses}
            ],
            "cr": [
                {"name": "Closing Inventory", "val": close_inv},
                {"name": "Sales A/C", "val": sales},
                {"name": "Purchases Return", "val": purchases_return},
                {"name": "Direct Income", "val": direct_income}
            ],
            "gp": gross_profit,
            "gl": gross_loss,
            "total": trading_total
        },
        "pl": {
            "dr": [
                {"name": "Gross Loss b/f", "val": gross_loss},
                {"name": "Indirect Expenses", "val": indirect_expenses}
            ],
            "cr": [
                {"name": "Gross Profit b/f", "val": gross_profit},
                {"name": "Indirect Income", "val": indirect_income}
            ],
            "np": net_profit,
            "nl": net_loss,
            "total": pl_total
        },
        "net_profit_val": net_profit - net_loss
    }

def get_detailed_balance_sheet(end_date):
    # Usually balance sheet is cumulative from the beginning up to end_date
    conn = get_conn()
    conn.row_factory = __import__('sqlite3').Row
    
    # Calculate entire net profit up to end_date
    # To do this correctly, we can reuse get_detailed_profit_loss with a very early start date
    # Or just sum all income/expense
    early_date = "1970-01-01"
    pl_data = get_detailed_profit_loss(early_date, end_date)
    net_profit = pl_data['net_profit_val']
    
    # Closing Inventory as of end_date
    close_inv = get_inventory_value_as_of(end_date)
    
    # Fetch all other account balances
    accs = conn.execute("SELECT aname, account_group, op_bal, a_type FROM account_detail").fetchall()
    
    sundry_creditors = 0.0
    capital_ac = 0.0
    current_liabilities = 0.0
    
    cash_in_hand = 0.0
    bank_acs = 0.0
    sundry_debtors = 0.0
    
    for row in accs:
        aname = row['aname']
        grp = row['account_group'] or ''
        op_bal = float(row['op_bal'] or 0.0)
        
        # Get total debits and credits up to end_date
        sums = conn.execute("""
            SELECT 
                SUM(CASE WHEN debit = ? THEN amount ELSE 0 END) as tot_deb,
                SUM(CASE WHEN credit = ? THEN amount ELSE 0 END) as tot_cred
            FROM vouchers_all WHERE date <= ?
        """, (aname, aname, end_date)).fetchone()
        
        t_deb = float(sums['tot_deb'] or 0.0)
        t_cred = float(sums['tot_cred'] or 0.0)
        
        # Debtors/Assets usually have debit balance: op_bal + debits - credits
        # Creditors/Liab usually have credit balance: op_bal + credits - debits
        if row['a_type'] == 'customer' or grp.lower() == 'sundry debtors':
            bal = op_bal + t_deb - t_cred
            sundry_debtors += bal
        elif row['a_type'] == 'supplier' or grp.lower() == 'sundry creditors':
            bal = op_bal + t_cred - t_deb
            sundry_creditors += bal
        elif grp.lower() == 'cash' or grp.lower() == 'cash-in-hand':
            bal = op_bal + t_deb - t_cred
            cash_in_hand += bal
        elif grp.lower() == 'bank' or grp.lower() == 'bank a/cs':
            bal = op_bal + t_deb - t_cred
            bank_acs += bal
        elif grp.lower() == 'capital a/c':
            bal = op_bal + t_cred - t_deb
            capital_ac += bal
        elif grp.lower() == 'current liabilities':
            bal = op_bal + t_cred - t_deb
            current_liabilities += bal
            
    conn.close()
    
    # Prepare Liabilities
    liab = [
        {"name": "Sundry Creditors", "val": sundry_creditors},
        {"name": "Capital A/C", "val": capital_ac},
        {"name": "Current Liabilities", "val": current_liabilities},
        {"name": "Profit & Loss A/c", "val": net_profit}
    ]
    
    # Prepare Assets
    assets = [
        {"name": "Cash-in-hand", "val": cash_in_hand},
        {"name": "Bank A/Cs", "val": bank_acs},
        {"name": "Sundry Debtors", "val": sundry_debtors},
        {"name": "Closing Inventory", "val": close_inv}
    ]
    
    tot_liab = sum(x['val'] for x in liab)
    tot_assets = sum(x['val'] for x in assets)
    
    diff = tot_assets - tot_liab
    if diff > 0:
        liab.append({"name": "Difference In Opening Balance", "val": diff})
        tot_liab += diff
    elif diff < 0:
        assets.append({"name": "Difference In Opening Balance", "val": -diff})
        tot_assets += -diff
        
    return {
        "liabilities": liab,
        "assets": assets,
        "total": tot_liab
    }

def get_estimate_templates():
    conn = get_conn()
    conn.row_factory = __import__('sqlite3').Row
    rows = conn.execute("""
        SELECT v.v_id as id, v.vch_no as invoice_no, v.v_type as type, v.date, v.amount as total,
               v.narration as notes, v.debit, v.credit,
               COALESCE((SELECT debit FROM vouchers_all va WHERE va.v_id = v.v_id LIMIT 1), v.debit, v.credit) as account_id
        FROM vouchers v
        WHERE v.v_type='estimate' AND v.is_template=1
        ORDER BY v.date DESC
    """).fetchall()
    conn.close()
    return [dict(r) for r in rows]
