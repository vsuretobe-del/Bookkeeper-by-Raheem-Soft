import re

with open('bookkeeper.py', 'r', encoding='utf-8') as f:
    content = f.read()

# The section we want to replace starts at create_lbl(rx-80, 290, "Default Purchase Price", width=20)
# and ends right before create_lbl(rx-80, 350, "Default Discount %", width=20)

start_marker = 'create_lbl(rx-80, 290, "Default Purchase Price", width=20)'
end_marker = 'create_lbl(rx-80, 350, "Default Discount %", width=20)'

start_idx = content.find(start_marker)
end_idx = content.find(end_marker)

if start_idx == -1 or end_idx == -1:
    print("Markers not found")
    exit(1)

new_code = '''create_lbl(rx-80, 290, "Default Purchase Price", width=20)
        exc_pur = create_entry(rx+70, 290, 12)
        fields['defaultpurchaseprice'] = exc_pur
        exc_pur.insert(0, "0")
        inc_pur = create_entry(rx+190, 290, 12)
        inc_pur.insert(0, "0")
        
        create_lbl(rx-80, 320, "Default Sale Price", width=20)
        exc_sal = create_entry(rx+70, 320, 12)
        fields['defaultsellingprice'] = exc_sal
        exc_sal.insert(0, "0")
        inc_sal = create_entry(rx+190, 320, 12)
        inc_sal.insert(0, "0")
        
        def get_tax_pct():
            t_str = fields['tax_regn'].get()
            try:
                import re
                m = re.search(r'(\d+)', t_str)
                return float(m.group(1)) if m else 0.0
            except: return 0.0

        def calc_inc(e=None):
            pct = get_tax_pct()
            try:
                p_exc = float(exc_pur.get() or 0)
                if p_exc == 0.0: inc_pur.delete(0, "end"); inc_pur.insert(0, "0")
                else: inc_pur.delete(0, "end"); inc_pur.insert(0, f"{p_exc * (1 + pct/100):.2f}")
            except: pass
            try:
                s_exc = float(exc_sal.get() or 0)
                if s_exc == 0.0: inc_sal.delete(0, "end"); inc_sal.insert(0, "0")
                else: inc_sal.delete(0, "end"); inc_sal.insert(0, f"{s_exc * (1 + pct/100):.2f}")
            except: pass

        def calc_exc(e=None):
            pct = get_tax_pct()
            try:
                p_inc = float(inc_pur.get() or 0)
                if p_inc == 0.0: exc_pur.delete(0, "end"); exc_pur.insert(0, "0")
                else: exc_pur.delete(0, "end"); exc_pur.insert(0, f"{p_inc / (1 + pct/100):.2f}")
            except: pass
            try:
                s_inc = float(inc_sal.get() or 0)
                if s_inc == 0.0: exc_sal.delete(0, "end"); exc_sal.insert(0, "0")
                else: exc_sal.delete(0, "end"); exc_sal.insert(0, f"{s_inc / (1 + pct/100):.2f}")
            except: pass

        exc_pur.bind("<KeyRelease>", calc_inc)
        exc_sal.bind("<KeyRelease>", calc_inc)
        fields['tax_regn'].bind("<<ComboboxSelected>>", calc_inc)
        inc_pur.bind("<KeyRelease>", calc_exc)
        inc_sal.bind("<KeyRelease>", calc_exc)

        '''

new_content = content[:start_idx] + new_code + content[end_idx:]

with open('bookkeeper.py', 'w', encoding='utf-8') as f:
    f.write(new_content)

print("Patch applied for calc")
