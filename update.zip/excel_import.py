"""
excel_import.py - Excel Import and Export Module for Book Keeper Windows
Handles importing and exporting Inventory Items, Services, Customers, Suppliers, Other Accounts, and Employees.
"""

import os
import sys
import datetime
import traceback
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

import db
from autocomplete import AutocompleteCombobox

# Typography & Colors
FONT_MAIN = ("Segoe UI", 9)
FONT_BOLD = ("Segoe UI", 9, "bold")
FONT_TITLE = ("Segoe UI", 11, "bold")
FONT_LINK = ("Segoe UI", 9, "underline")
FONT_CONSOLE = ("Consolas", 9)

COLOR_BG = "#ffffff"
COLOR_HEADER_BG = "#ffffff"
COLOR_LINK = "#0066cc"
COLOR_BTN_BG = "#e0e0e0"
COLOR_BORDER = "#b0b0b0"


def _style_header_cell(cell):
    cell.font = Font(name="Segoe UI", size=10, bold=True, color="FFFFFF")
    cell.fill = PatternFill(start_color="1F4E79", end_color="1F4E79", fill_type="solid")
    cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    thin_border = Border(
        left=Side(style='thin', color='D9D9D9'),
        right=Side(style='thin', color='D9D9D9'),
        top=Side(style='thin', color='D9D9D9'),
        bottom=Side(style='thin', color='D9D9D9')
    )
    cell.border = thin_border


def _style_data_cell(cell, align="left"):
    cell.font = Font(name="Segoe UI", size=10)
    cell.alignment = Alignment(horizontal=align, vertical="center")
    thin_border = Border(
        left=Side(style='thin', color='E0E0E0'),
        right=Side(style='thin', color='E0E0E0'),
        top=Side(style='thin', color='E0E0E0'),
        bottom=Side(style='thin', color='E0E0E0')
    )
    cell.border = thin_border


def _auto_fit_columns(ws):
    for col in ws.columns:
        max_len = 0
        col_letter = get_column_letter(col[0].column)
        for cell in col:
            val_str = str(cell.value or '')
            if len(val_str) > max_len:
                max_len = len(val_str)
        ws.column_dimensions[col_letter].width = max(max_len + 4, 14)


# ─────────────────────────────────────────────────────────────────────────────
# SAMPLE EXCEL GENERATORS
# ─────────────────────────────────────────────────────────────────────────────

def generate_sample_inventory_item_excel(filepath):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Inventory Items"

    headers = [
        "Item Name", "Item Description", "Unit", "Category", "Sub Category",
        "Purchase Price", "Selling Price", "Opening Stock", "Low Stock Alert",
        "Barcode", "SKU", "Tax Rate (%)", "HSN/SAC Code"
    ]
    ws.append(headers)
    for col_idx in range(1, len(headers) + 1):
        _style_header_cell(ws.cell(row=1, column=col_idx))

    sample_rows = [
        ["DP Box", "High Quality Distribution Box", "pcs", "Electrical", "Boxes", 450, 600, 25, 5, "8901234567890", "DPB-01", 0, "8537"],
        ["Circuit Breaker 32A", "Single Pole MCB 32 Amp", "nos", "Electrical", "Breakers", 280, 380, 50, 10, "8901234567891", "MCB-32", 0, "8536"],
        ["LED Bulb 12W", "Cool Daylight Energy Saver", "box", "Lighting", "LED", 150, 220, 100, 15, "8901234567892", "LED-12W", 0, "8539"]
    ]
    for row in sample_rows:
        ws.append(row)
        for col_idx, val in enumerate(row, start=1):
            align = "right" if isinstance(val, (int, float)) else "left"
            _style_data_cell(ws.cell(row=ws.max_row, column=col_idx), align=align)

    _auto_fit_columns(ws)
    wb.save(filepath)


def generate_sample_service_excel(filepath):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Services"

    headers = [
        "Service Name", "Service Description", "Unit", "Selling Price",
        "Tax Rate (%)", "SKU", "SAC Code"
    ]
    ws.append(headers)
    for col_idx in range(1, len(headers) + 1):
        _style_header_cell(ws.cell(row=1, column=col_idx))

    sample_rows = [
        ["Electrical Installation", "Complete home and office wiring service", "hours", 1500, 0, "SRV-INST", "9987"],
        ["Maintenance & Repair", "General equipment maintenance contract", "months", 5000, 0, "SRV-MAIN", "9987"],
        ["Consultation Fee", "Professional electrical audit", "nos", 3000, 0, "SRV-CONS", "9983"]
    ]
    for row in sample_rows:
        ws.append(row)
        for col_idx, val in enumerate(row, start=1):
            align = "right" if isinstance(val, (int, float)) else "left"
            _style_data_cell(ws.cell(row=ws.max_row, column=col_idx), align=align)

    _auto_fit_columns(ws)
    wb.save(filepath)


def generate_sample_customer_excel(filepath):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Customers"

    headers = [
        "Customer Name", "Opening Balance", "Balance Type", "Phone Number", "Email",
        "Contact Person", "Address", "City", "State", "Country",
        "Account Group", "Credit Period (Days)", "Credit Limit", "Tax Number / NTN"
    ]
    ws.append(headers)
    for col_idx in range(1, len(headers) + 1):
        _style_header_cell(ws.cell(row=1, column=col_idx))

    sample_rows = [
        ["Ali Traders", 5000, "Dr", "03001234567", "ali@example.com", "Muhammad Ali", "Shop # 12, Main Market", "Lahore", "Punjab", "Pakistan", "Customers/Debtors", 30, 100000, "1234567-8"],
        ["Hassan Electronics", 0, "Dr", "03219876543", "hassan@example.com", "Hassan Raza", "Hall Road Plaza", "Lahore", "Punjab", "Pakistan", "Customers/Debtors", 15, 50000, "9876543-1"],
        ["Metro Commercial Mart", 12500, "Dr", "03335554433", "metro@example.com", "Usman Tariq", "Block C, Blue Area", "Islamabad", "ICT", "Pakistan", "Customers/Debtors", 45, 250000, "5544332-9"]
    ]
    for row in sample_rows:
        ws.append(row)
        for col_idx, val in enumerate(row, start=1):
            align = "right" if isinstance(val, (int, float)) else "left"
            _style_data_cell(ws.cell(row=ws.max_row, column=col_idx), align=align)

    _auto_fit_columns(ws)
    wb.save(filepath)


def generate_sample_supplier_excel(filepath):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Suppliers"

    headers = [
        "Supplier Name", "Opening Balance", "Balance Type", "Phone Number", "Email",
        "Contact Person", "Address", "City", "State", "Country",
        "Account Group", "Credit Period (Days)", "Credit Limit", "Tax Number / NTN"
    ]
    ws.append(headers)
    for col_idx in range(1, len(headers) + 1):
        _style_header_cell(ws.cell(row=1, column=col_idx))

    sample_rows = [
        ["Pak Cable Industries", 25000, "Cr", "04235551122", "sales@pakcables.com", "Kamran Javed", "Plot 45, Industrial Estate", "Lahore", "Punjab", "Pakistan", "Suppliers/Creditors", 30, 500000, "7788990-1"],
        ["Orient Electric Co", 8000, "Cr", "02134445566", "info@orientelectric.com", "Bilal Sheikh", "S.I.T.E Area", "Karachi", "Sindh", "Pakistan", "Suppliers/Creditors", 45, 300000, "6655443-2"]
    ]
    for row in sample_rows:
        ws.append(row)
        for col_idx, val in enumerate(row, start=1):
            align = "right" if isinstance(val, (int, float)) else "left"
            _style_data_cell(ws.cell(row=ws.max_row, column=col_idx), align=align)

    _auto_fit_columns(ws)
    wb.save(filepath)


def generate_sample_other_accounts_excel(filepath):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Other Accounts"

    headers = [
        "Account Name", "Account Group", "Opening Balance", "Balance Type",
        "Phone Number", "Email", "Address", "Bank Name", "Account Number", "Branch / IFSC Code"
    ]
    ws.append(headers)
    for col_idx in range(1, len(headers) + 1):
        _style_header_cell(ws.cell(row=1, column=col_idx))

    sample_rows = [
        ["HBL Main Current Account", "Bank Accounts", 350000, "Dr", "042111111425", "branch@hbl.com", "Mall Road", "Habib Bank Limited", "01234567890123", "HBL0012"],
        ["Office Rent Expense", "Indirect Expenses", 0, "Dr", "", "", "", "", "", ""],
        ["Electricity Bills", "Direct Expenses", 0, "Dr", "", "", "", "", "", ""],
        ["Shop Petty Cash", "Cash-in-hand", 25000, "Dr", "", "", "", "", "", ""]
    ]
    for row in sample_rows:
        ws.append(row)
        for col_idx, val in enumerate(row, start=1):
            align = "right" if isinstance(val, (int, float)) else "left"
            _style_data_cell(ws.cell(row=ws.max_row, column=col_idx), align=align)

    _auto_fit_columns(ws)
    wb.save(filepath)


def generate_sample_employee_excel(filepath):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Employees"

    headers = [
        "Employee Name", "Employee Code", "Gender", "Phone", "Email",
        "Department", "Designation", "Date of Joining", "Date of Birth",
        "Father Name", "National ID / CNIC", "Current Address", "Bank Name", "Account Number"
    ]
    ws.append(headers)
    for col_idx in range(1, len(headers) + 1):
        _style_header_cell(ws.cell(row=1, column=col_idx))

    sample_rows = [
        ["Zubair Ahmed", "EMP-001", "Male", "03339876543", "zubair@company.com", "Accounts", "Senior Accountant", "2024-01-15", "1995-06-20", "Ahmed Din", "35201-1234567-1", "House 14, Street 2, Lahore", "Meezan Bank", "01010101010101"],
        ["Fatima Zahra", "EMP-002", "Female", "03451122334", "fatima@company.com", "Sales", "Sales Executive", "2024-03-01", "1998-11-10", "Tariq Mehmood", "35202-7654321-2", "Model Town, Lahore", "HBL", "02020202020202"]
    ]
    for row in sample_rows:
        ws.append(row)
        for col_idx, val in enumerate(row, start=1):
            align = "right" if isinstance(val, (int, float)) else "left"
            _style_data_cell(ws.cell(row=ws.max_row, column=col_idx), align=align)

    _auto_fit_columns(ws)
    wb.save(filepath)


# ─────────────────────────────────────────────────────────────────────────────
# EXPORT EXISTING DATA TO EXCEL
# ─────────────────────────────────────────────────────────────────────────────

def export_existing_items_to_excel(filepath, export_type="Inventory Item"):
    wb = openpyxl.Workbook()
    ws = wb.active

    if export_type == "Inventory Item":
        ws.title = "Existing Items"
        headers = [
            "Item Name", "Item Description", "Unit", "Category", "Sub Category",
            "Purchase Price", "Selling Price", "Opening Stock", "Low Stock Alert",
            "Barcode", "SKU", "Tax Rate (%)", "HSN/SAC Code"
        ]
        ws.append(headers)
        for col_idx in range(1, len(headers) + 1):
            _style_header_cell(ws.cell(row=1, column=col_idx))

        items = db.get_all_items()
        conn = db.get_conn()
        for it in items:
            cat_name = ""
            subcat_name = ""
            sub_id = it.get("item_subcategory_id")
            if sub_id:
                try:
                    s_row = conn.execute("""
                        SELECT s.subcategory_name, c.category_name 
                        FROM item_subcategory s 
                        LEFT JOIN item_category c ON s.category_id = c.category_id 
                        WHERE s.subcategory_id=?
                    """, (sub_id)).fetchone()
                    if s_row:
                        subcat_name = s_row[0] or ""
                        cat_name = s_row[1] or ""
                except Exception:
                    pass

            row = [
                it.get("item") or it.get("name") or "",
                it.get("item_desc") or "",
                it.get("units_name") or it.get("unit") or "nos",
                cat_name,
                subcat_name,
                float(it.get("defaultpurchaseprice") or it.get("purchase_price") or 0.0),
                float(it.get("defaultsellingprice") or it.get("sale_price") or 0.0),
                float(it.get("stock") or 0.0),
                float(it.get("reorder_qty") or it.get("low_stock_alert") or 0.0),
                it.get("barcode") or "",
                it.get("sku") or it.get("code") or "",
                float(it.get("tax_pct") or 0.0),
                it.get("hsn_sac") or ""
            ]
            ws.append(row)
            for col_idx, val in enumerate(row, start=1):
                align = "right" if isinstance(val, (int, float)) else "left"
                _style_data_cell(ws.cell(row=ws.max_row, column=col_idx), align=align)
        conn.close()

    else:  # Service
        ws.title = "Existing Services"
        headers = [
            "Service Name", "Service Description", "Unit", "Selling Price",
            "Tax Rate (%)", "SKU", "SAC Code"
        ]
        ws.append(headers)
        for col_idx in range(1, len(headers) + 1):
            _style_header_cell(ws.cell(row=1, column=col_idx))

        services = db.get_all_services()
        for s in services:
            row = [
                s.get("service_name") or "",
                s.get("service_desc") or "",
                s.get("units_name") or "nos",
                float(s.get("defaultsellingprice") or 0.0),
                float(s.get("tax_pct") or 0.0),
                s.get("sku") or "",
                s.get("hsn_sac") or ""
            ]
            ws.append(row)
            for col_idx, val in enumerate(row, start=1):
                align = "right" if isinstance(val, (int, float)) else "left"
                _style_data_cell(ws.cell(row=ws.max_row, column=col_idx), align=align)

    _auto_fit_columns(ws)
    wb.save(filepath)


# ─────────────────────────────────────────────────────────────────────────────
# IMPORT PROCESSING ENGINES
# ─────────────────────────────────────────────────────────────────────────────

def _clean_str(val):
    if val is None:
        return ""
    return str(val).strip()


def _clean_float(val, default=0.0):
    if val is None:
        return default
    if isinstance(val, (int, float)):
        return float(val)
    s = str(val).replace(",", "").replace("$", "").replace("Rs", "").strip()
    try:
        return float(s)
    except Exception:
        return default


def _get_header_map(row_values):
    """Maps header strings to standard field keys."""
    mapping = {}
    for idx, raw in enumerate(row_values):
        if not raw:
            continue
        h = str(raw).strip().lower().replace("_", " ").replace("-", " ")
        # Item Fields
        if h in ["item name", "item", "product name", "product", "item_name", "items"]:
            mapping["item_name"] = idx
        elif h in ["item description", "description", "desc", "details", "item desc"]:
            mapping["description"] = idx
        elif h in ["unit", "units", "unit of measure", "uom", "unit_name", "units name"]:
            mapping["unit"] = idx
        elif h in ["category", "item category", "cat"]:
            mapping["category"] = idx
        elif h in ["subcategory", "sub category", "item subcategory", "subcat"]:
            mapping["subcategory"] = idx
        elif h in ["purchase price", "cost price", "purchase rate", "buy price", "defaultpurchaseprice", "cost"]:
            mapping["purchase_price"] = idx
        elif h in ["selling price", "sale price", "sales price", "mrp", "retail price", "rate", "defaultsellingprice", "price"]:
            mapping["selling_price"] = idx
        elif h in ["opening stock", "stock", "qty", "quantity", "units left", "opening qty", "opening balance"]:
            mapping["stock"] = idx
        elif h in ["low stock alert", "reorder qty", "min stock", "alert qty", "reorder_qty"]:
            mapping["low_stock_alert"] = idx
        elif h in ["barcode", "bar code", "upc", "ean"]:
            mapping["barcode"] = idx
        elif h in ["sku", "item code", "code", "service code"]:
            mapping["sku"] = idx
        elif h in ["tax rate (%)", "tax rate", "tax %", "tax", "gst %", "vat %", "tax pct", "tax_pct"]:
            mapping["tax_pct"] = idx
        elif h in ["hsn/sac code", "hsn code", "sac code", "hsn", "sac", "hsn_sac"]:
            mapping["hsn_sac"] = idx

        # Service Fields
        elif h in ["service name", "service", "service_name"]:
            mapping["service_name"] = idx

        # Account Fields
        elif h in ["customer name", "supplier name", "account name", "party name", "name", "aname"]:
            mapping["account_name"] = idx
        elif h in ["opening balance", "op bal", "opening bal", "op_bal", "balance"]:
            mapping["op_bal"] = idx
        elif h in ["balance type", "dr/cr", "debit/credit", "type"]:
            mapping["bal_type"] = idx
        elif h in ["phone number", "phone", "mobile", "contact no", "mobile no", "phone_no"]:
            mapping["phone"] = idx
        elif h in ["email", "email id", "e-mail", "email_id"]:
            mapping["email"] = idx
        elif h in ["contact person", "contact", "person", "contact_person"]:
            mapping["contact_person"] = idx
        elif h in ["address", "address line 1", "street", "addr", "address1"]:
            mapping["address"] = idx
        elif h in ["address line 2", "address 2", "address2"]:
            mapping["address2"] = idx
        elif h in ["city"]:
            mapping["city"] = idx
        elif h in ["state"]:
            mapping["state"] = idx
        elif h in ["country"]:
            mapping["country"] = idx
        elif h in ["pincode", "zip code", "zip", "postal code", "pin"]:
            mapping["pincode"] = idx
        elif h in ["account group", "group", "group name", "account_group"]:
            mapping["account_group"] = idx
        elif h in ["credit period (days)", "credit period", "credit_period", "days"]:
            mapping["credit_period"] = idx
        elif h in ["credit limit", "credit_limit", "limit"]:
            mapping["credit_limit"] = idx
        elif h in ["tax number / ntn", "tax number", "ntn", "gst", "vat", "tax regn", "pan / ntn", "tax_regn", "pan_no"]:
            mapping["tax_regn"] = idx
        elif h in ["bank name", "bank", "bank_name"]:
            mapping["bank_name"] = idx
        elif h in ["account number", "acc number", "bank account no", "account no", "acc_number"]:
            mapping["acc_number"] = idx
        elif h in ["branch / ifsc code", "ifsc code", "branch code", "ifsc", "ifsc_code", "branch_name"]:
            mapping["ifsc_code"] = idx

        # Employee Fields
        elif h in ["employee name", "emp name", "empname"]:
            mapping["emp_name"] = idx
        elif h in ["employee code", "emp code", "empcode"]:
            mapping["emp_code"] = idx
        elif h in ["gender", "sex"]:
            mapping["gender"] = idx
        elif h in ["department", "dept"]:
            mapping["department"] = idx
        elif h in ["designation", "role", "position"]:
            mapping["designation"] = idx
        elif h in ["date of joining", "doj", "joining date"]:
            mapping["doj"] = idx
        elif h in ["date of birth", "dob", "birth date"]:
            mapping["dob"] = idx
        elif h in ["father name", "father's name", "fathername"]:
            mapping["father_name"] = idx
        elif h in ["national id / cnic", "cnic", "aadhaar", "id card", "national id", "pan"]:
            mapping["cnic"] = idx
        elif h in ["current address", "cadd1"]:
            mapping["current_address"] = idx

    return mapping


def _get_or_create_unit(unit_name):
    if not unit_name:
        return "nos"
    conn = db.get_conn()
    try:
        row = conn.execute("SELECT units_name FROM units_measure WHERE LOWER(units_name)=?", (unit_name.lower())).fetchone()
        if not row:
            conn.execute("INSERT INTO units_measure (units_name, symbol, isSimpleUnit) VALUES (?,?,1)", (unit_name, unit_name))
            conn.commit()
            return unit_name
        return row[0]
    except Exception:
        return unit_name
    finally:
        conn.close()


def _get_or_create_subcat(cat_name, subcat_name):
    if not cat_name:
        return None
    conn = db.get_conn()
    try:
        c_row = conn.execute("SELECT category_id FROM item_category WHERE LOWER(category_name)=?", (cat_name.lower())).fetchone()
        if not c_row:
            cur = conn.execute("INSERT INTO item_category (category_name) VALUES (?)", (cat_name))
            conn.commit()
            cat_id = cur.lastrowid
        else:
            cat_id = c_row[0]

        sub_name = subcat_name if subcat_name else cat_name
        s_row = conn.execute("SELECT subcategory_id FROM item_subcategory WHERE LOWER(subcategory_name)=? AND category_id=?", (sub_name.lower(), cat_id)).fetchone()
        if not s_row:
            cur2 = conn.execute("INSERT INTO item_subcategory (subcategory_name, category_id) VALUES (?,?)", (sub_name, cat_id))
            conn.commit()
            return cur2.lastrowid
        else:
            return s_row[0]
    except Exception:
        return None
    finally:
        conn.close()


def import_inventory_items_from_excel(filepath, update_existing=False, log_callback=None):
    def log(msg, tag="info"):
        if log_callback:
            log_callback(msg, tag)

    wb = openpyxl.load_workbook(filepath, data_only=True)
    ws = wb.active
    rows = list(ws.iter_rows(values_only=True))
    if not rows:
        raise ValueError("The selected Excel file is empty.")

    # Find Header Row
    header_row_idx = 0
    header_map = {}
    for idx, r in enumerate(rows):
        hmap = _get_header_map(r)
        if "item_name" in hmap or "selling_price" in hmap or "purchase_price" in hmap:
            header_row_idx = idx
            header_map = hmap
            break

    if "item_name" not in header_map and len(rows) > 0:
        # Fallback to first non-empty row
        header_map = _get_header_map(rows[0])
        header_row_idx = 0

    if "item_name" not in header_map:
        raise ValueError("Could not find 'Item Name' header column in Excel file.")

    log(f"Starting import from '{os.path.basename(filepath)}'...", "info")
    log(f"Detected columns: {', '.join(header_map.keys())}", "info")

    conn = db.get_conn()
    existing_items = {r[0].lower(): r[0] for r in conn.execute("SELECT item FROM item_measure").fetchall()}
    conn.close()

    inserted_count = 0
    updated_count = 0
    skipped_count = 0
    error_count = 0

    for row_num, row_data in enumerate(rows[header_row_idx + 1:], start=header_row_idx + 2):
        if not any(row_data):
            continue

        item_name = _clean_str(row_data[header_map["item_name"]]) if "item_name" in header_map and header_map["item_name"] < len(row_data) else ""
        if not item_name:
            continue

        try:
            desc = _clean_str(row_data[header_map["description"]]) if "description" in header_map and header_map["description"] < len(row_data) else ""
            raw_unit = _clean_str(row_data[header_map["unit"]]) if "unit" in header_map and header_map["unit"] < len(row_data) else "nos"
            unit = _get_or_create_unit(raw_unit)

            cat_str = _clean_str(row_data[header_map["category"]]) if "category" in header_map and header_map["category"] < len(row_data) else ""
            subcat_str = _clean_str(row_data[header_map["subcategory"]]) if "subcategory" in header_map and header_map["subcategory"] < len(row_data) else ""
            subcat_id = _get_or_create_subcat(cat_str, subcat_str)

            purchase_price = _clean_float(row_data[header_map["purchase_price"]]) if "purchase_price" in header_map and header_map["purchase_price"] < len(row_data) else 0.0
            selling_price = _clean_float(row_data[header_map["selling_price"]]) if "selling_price" in header_map and header_map["selling_price"] < len(row_data) else 0.0
            stock_qty = _clean_float(row_data[header_map["stock"]]) if "stock" in header_map and header_map["stock"] < len(row_data) else 0.0
            low_stock = _clean_float(row_data[header_map["low_stock_alert"]]) if "low_stock_alert" in header_map and header_map["low_stock_alert"] < len(row_data) else 0.0
            barcode = _clean_str(row_data[header_map["barcode"]]) if "barcode" in header_map and header_map["barcode"] < len(row_data) else ""
            sku = _clean_str(row_data[header_map["sku"]]) if "sku" in header_map and header_map["sku"] < len(row_data) else ""
            tax_pct = _clean_float(row_data[header_map["tax_pct"]]) if "tax_pct" in header_map and header_map["tax_pct"] < len(row_data) else 0.0
            hsn_sac = _clean_str(row_data[header_map["hsn_sac"]]) if "hsn_sac" in header_map and header_map["hsn_sac"] < len(row_data) else ""

            data_dict = {
                "item": item_name,
                "item_desc": desc,
                "units_name": unit,
                "item_subcategory_id": subcat_id,
                "defaultpurchaseprice": purchase_price,
                "defaultsellingprice": selling_price,
                "reorder_qty": low_stock,
                "barcode": barcode,
                "sku": sku,
                "tax_pct": tax_pct,
                "hsn_sac": hsn_sac,
                "status": 1
            }

            if item_name.lower() in existing_items:
                if not update_existing:
                    skipped_count += 1
                    log(f"Row {row_num}: Item '{item_name}' already exists. (Ignored)", "warning")
                    continue
                else:
                    # Update Existing
                    db.update_item(existing_items[item_name.lower()], {**data_dict, "stock": stock_qty})
                    updated_count += 1
                    log(f"Row {row_num}: Item '{item_name}' updated successfully.", "success")
            else:
                # Insert New Item
                db.add_item({**data_dict, "stock": stock_qty})
                existing_items[item_name.lower()] = item_name
                inserted_count += 1
                log(f"Row {row_num}: Item '{item_name}' added successfully.", "success")

        except Exception as ex:
            error_count += 1
            log(f"Row {row_num}: Error processing '{item_name}' - {str(ex)}", "error")

    summary = f"Import Finished!\nInserted: {inserted_count} | Updated: {updated_count} | Ignored: {skipped_count} | Errors: {error_count}"
    log("------------------------------------------", "info")
    log(summary, "success" if error_count == 0 else "warning")
    return {"inserted": inserted_count, "updated": updated_count, "skipped": skipped_count, "errors": error_count}


def import_services_from_excel(filepath, update_existing=False, log_callback=None):
    def log(msg, tag="info"):
        if log_callback:
            log_callback(msg, tag)

    wb = openpyxl.load_workbook(filepath, data_only=True)
    ws = wb.active
    rows = list(ws.iter_rows(values_only=True))
    if not rows:
        raise ValueError("The selected Excel file is empty.")

    header_map = {}
    header_row_idx = 0
    for idx, r in enumerate(rows):
        hmap = _get_header_map(r)
        if "service_name" in hmap or "item_name" in hmap or "selling_price" in hmap:
            header_map = hmap
            header_row_idx = idx
            break

    name_key = "service_name" if "service_name" in header_map else "item_name"
    if name_key not in header_map:
        raise ValueError("Could not find 'Service Name' or 'Name' column in Excel file.")

    conn = db.get_conn()
    existing_services = {r[0].lower(): r[0] for r in conn.execute("SELECT service_name FROM service").fetchall()}

    inserted_count = 0
    updated_count = 0
    skipped_count = 0
    error_count = 0

    log(f"Starting service import from '{os.path.basename(filepath)}'...", "info")

    for row_num, row_data in enumerate(rows[header_row_idx + 1:], start=header_row_idx + 2):
        if not any(row_data):
            continue

        srv_name = _clean_str(row_data[header_map[name_key]]) if header_map[name_key] < len(row_data) else ""
        if not srv_name:
            continue

        try:
            desc = _clean_str(row_data[header_map["description"]]) if "description" in header_map and header_map["description"] < len(row_data) else ""
            unit = _clean_str(row_data[header_map["unit"]]) if "unit" in header_map and header_map["unit"] < len(row_data) else "nos"
            selling_price = _clean_float(row_data[header_map["selling_price"]]) if "selling_price" in header_map and header_map["selling_price"] < len(row_data) else 0.0
            tax_pct = _clean_float(row_data[header_map["tax_pct"]]) if "tax_pct" in header_map and header_map["tax_pct"] < len(row_data) else 0.0
            sku = _clean_str(row_data[header_map["sku"]]) if "sku" in header_map and header_map["sku"] < len(row_data) else ""
            hsn_sac = _clean_str(row_data[header_map["hsn_sac"]]) if "hsn_sac" in header_map and header_map["hsn_sac"] < len(row_data) else ""

            srv_dict = {
                "service_name": srv_name,
                "service_desc": desc,
                "units_name": unit,
                "defaultsellingprice": selling_price,
                "tax_pct": tax_pct,
                "sku": sku,
                "hsn_sac": hsn_sac
            }

            if srv_name.lower() in existing_services:
                if not update_existing:
                    skipped_count += 1
                    log(f"Row {row_num}: Service '{srv_name}' already exists. (Ignored)", "warning")
                else:
                    db.update_service(existing_services[srv_name.lower()], srv_dict)
                    updated_count += 1
                    log(f"Row {row_num}: Service '{srv_name}' updated successfully.", "success")
            else:
                db.add_service(srv_dict)
                existing_services[srv_name.lower()] = srv_name
                inserted_count += 1
                log(f"Row {row_num}: Service '{srv_name}' added successfully.", "success")

        except Exception as ex:
            error_count += 1
            log(f"Row {row_num}: Error processing '{srv_name}' - {str(ex)}", "error")

    conn.close()
    summary = f"Import Finished!\nInserted: {inserted_count} | Updated: {updated_count} | Ignored: {skipped_count} | Errors: {error_count}"
    log("──────────────────────────────────────────", "info")
    log(summary, "success" if error_count == 0 else "warning")
    return {"inserted": inserted_count, "updated": updated_count, "skipped": skipped_count, "errors": error_count}


def import_accounts_from_excel(filepath, acc_type="customer", update_existing=False, log_callback=None):
    def log(msg, tag="info"):
        if log_callback:
            log_callback(msg, tag)

    wb = openpyxl.load_workbook(filepath, data_only=True)
    ws = wb.active
    rows = list(ws.iter_rows(values_only=True))
    if not rows:
        raise ValueError("The selected Excel file is empty.")

    header_map = {}
    header_row_idx = 0
    for idx, r in enumerate(rows):
        hmap = _get_header_map(r)
        if "account_name" in hmap or "op_bal" in hmap or "phone" in hmap:
            header_map = hmap
            header_row_idx = idx
            break

    if "account_name" not in header_map:
        raise ValueError("Could not find 'Account Name', 'Customer Name', or 'Supplier Name' column in Excel file.")

    conn = db.get_conn()
    existing_accounts = {r[0].lower(): r[0] for r in conn.execute("SELECT aname FROM account_detail").fetchall()}

    inserted_count = 0
    updated_count = 0
    skipped_count = 0
    error_count = 0

    type_label = "Customer" if acc_type == "customer" else "Supplier" if acc_type == "supplier" else "Account"
    log(f"Starting {type_label} import from '{os.path.basename(filepath)}'...", "info")

    default_group = "Customers/Debtors" if acc_type == "customer" else "Suppliers/Creditors" if acc_type == "supplier" else "Other Accounts"

    for row_num, row_data in enumerate(rows[header_row_idx + 1:], start=header_row_idx + 2):
        if not any(row_data):
            continue

        acc_name = _clean_str(row_data[header_map["account_name"]]) if header_map["account_name"] < len(row_data) else ""
        if not acc_name:
            continue

        try:
            op_bal = _clean_float(row_data[header_map["op_bal"]]) if "op_bal" in header_map and header_map["op_bal"] < len(row_data) else 0.0
            bal_type = _clean_str(row_data[header_map["bal_type"]]) if "bal_type" in header_map and header_map["bal_type"] < len(row_data) else ""
            if not bal_type:
                bal_type = "Dr" if acc_type == "customer" else "Cr" if acc_type == "supplier" else "Dr"
            
            # Signed balance adjustment if needed
            phone = _clean_str(row_data[header_map["phone"]]) if "phone" in header_map and header_map["phone"] < len(row_data) else ""
            email = _clean_str(row_data[header_map["email"]]) if "email" in header_map and header_map["email"] < len(row_data) else ""
            contact_person = _clean_str(row_data[header_map["contact_person"]]) if "contact_person" in header_map and header_map["contact_person"] < len(row_data) else ""
            address = _clean_str(row_data[header_map["address"]]) if "address" in header_map and header_map["address"] < len(row_data) else ""
            address2 = _clean_str(row_data[header_map["address2"]]) if "address2" in header_map and header_map["address2"] < len(row_data) else ""
            city = _clean_str(row_data[header_map["city"]]) if "city" in header_map and header_map["city"] < len(row_data) else ""
            state = _clean_str(row_data[header_map["state"]]) if "state" in header_map and header_map["state"] < len(row_data) else ""
            country = _clean_str(row_data[header_map["country"]]) if "country" in header_map and header_map["country"] < len(row_data) else "Pakistan"
            pincode = _clean_str(row_data[header_map["pincode"]]) if "pincode" in header_map and header_map["pincode"] < len(row_data) else ""
            group = _clean_str(row_data[header_map["account_group"]]) if "account_group" in header_map and header_map["account_group"] < len(row_data) else default_group
            if not group:
                group = default_group

            credit_period = int(_clean_float(row_data[header_map["credit_period"]])) if "credit_period" in header_map and header_map["credit_period"] < len(row_data) else 0
            credit_limit = _clean_float(row_data[header_map["credit_limit"]]) if "credit_limit" in header_map and header_map["credit_limit"] < len(row_data) else 0.0
            tax_regn = _clean_str(row_data[header_map["tax_regn"]]) if "tax_regn" in header_map and header_map["tax_regn"] < len(row_data) else ""
            bank_name = _clean_str(row_data[header_map["bank_name"]]) if "bank_name" in header_map and header_map["bank_name"] < len(row_data) else ""
            acc_number = _clean_str(row_data[header_map["acc_number"]]) if "acc_number" in header_map and header_map["acc_number"] < len(row_data) else ""
            ifsc_code = _clean_str(row_data[header_map["ifsc_code"]]) if "ifsc_code" in header_map and header_map["ifsc_code"] < len(row_data) else ""

            today_str = datetime.date.today().strftime("%Y-%m-%d")
            data_dict = {
                "aname": acc_name,
                "a_type": acc_type,
                "type": bal_type,
                "op_bal": op_bal,
                "cl_bal": op_bal,
                "phone": phone,
                "phone_no": phone,
                "email": email,
                "email_id": email,
                "contact_person": contact_person,
                "address": address,
                "address2": address2,
                "state": state,
                "country": country,
                "pincode": pincode,
                "account_group": group,
                "credit_period": credit_period,
                "credit_limit": credit_limit,
                "tax_regn": tax_regn,
                "bank_name": bank_name,
                "acc_number": acc_number,
                "ifsc_code": ifsc_code,
                "has_bank_details": 1 if (bank_name or acc_number) else 0,
                "date_created": today_str,
                "status": 1
            }

            if acc_name.lower() in existing_accounts:
                if not update_existing:
                    skipped_count += 1
                    log(f"Row {row_num}: Account '{acc_name}' already exists. (Ignored)", "warning")
                else:
                    db.update_account(existing_accounts[acc_name.lower()], data_dict)
                    updated_count += 1
                    log(f"Row {row_num}: Account '{acc_name}' updated successfully.", "success")
            else:
                db.add_account(data_dict)
                existing_accounts[acc_name.lower()] = acc_name
                inserted_count += 1
                log(f"Row {row_num}: Account '{acc_name}' added successfully.", "success")

        except Exception as ex:
            error_count += 1
            log(f"Row {row_num}: Error processing '{acc_name}' - {str(ex)}", "error")

    conn.close()
    summary = f"Import Finished!\nInserted: {inserted_count} | Updated: {updated_count} | Ignored: {skipped_count} | Errors: {error_count}"
    log("──────────────────────────────────────────", "info")
    log(summary, "success" if error_count == 0 else "warning")
    return {"inserted": inserted_count, "updated": updated_count, "skipped": skipped_count, "errors": error_count}


def import_employees_from_excel(filepath, log_callback=None):
    def log(msg, tag="info"):
        if log_callback:
            log_callback(msg, tag)

    wb = openpyxl.load_workbook(filepath, data_only=True)
    ws = wb.active
    rows = list(ws.iter_rows(values_only=True))
    if not rows:
        raise ValueError("The selected Excel file is empty.")

    header_map = {}
    header_row_idx = 0
    for idx, r in enumerate(rows):
        hmap = _get_header_map(r)
        if "emp_name" in hmap or "emp_code" in hmap or "account_name" in hmap:
            header_map = hmap
            header_row_idx = idx
            break

    name_key = "emp_name" if "emp_name" in header_map else "account_name"
    if name_key not in header_map:
        raise ValueError("Could not find 'Employee Name' or 'Name' column in Excel file.")

    conn = db.get_conn()
    existing_employees = {r[0].lower(): r[0] for r in conn.execute("SELECT empName FROM employee").fetchall()}

    inserted_count = 0
    skipped_count = 0
    error_count = 0

    log(f"Starting employee import from '{os.path.basename(filepath)}'...", "info")

    for row_num, row_data in enumerate(rows[header_row_idx + 1:], start=header_row_idx + 2):
        if not any(row_data):
            continue

        emp_name = _clean_str(row_data[header_map[name_key]]) if header_map[name_key] < len(row_data) else ""
        if not emp_name:
            continue

        try:
            emp_code = _clean_str(row_data[header_map["emp_code"]]) if "emp_code" in header_map and header_map["emp_code"] < len(row_data) else ""
            gender = _clean_str(row_data[header_map["gender"]]) if "gender" in header_map and header_map["gender"] < len(row_data) else "Male"
            phone = _clean_str(row_data[header_map["phone"]]) if "phone" in header_map and header_map["phone"] < len(row_data) else ""
            email = _clean_str(row_data[header_map["email"]]) if "email" in header_map and header_map["email"] < len(row_data) else ""
            dept = _clean_str(row_data[header_map["department"]]) if "department" in header_map and header_map["department"] < len(row_data) else ""
            desig = _clean_str(row_data[header_map["designation"]]) if "designation" in header_map and header_map["designation"] < len(row_data) else ""
            doj = _clean_str(row_data[header_map["doj"]]) if "doj" in header_map and header_map["doj"] < len(row_data) else ""
            dob = _clean_str(row_data[header_map["dob"]]) if "dob" in header_map and header_map["dob"] < len(row_data) else ""
            father = _clean_str(row_data[header_map["father_name"]]) if "father_name" in header_map and header_map["father_name"] < len(row_data) else ""
            cnic = _clean_str(row_data[header_map["cnic"]]) if "cnic" in header_map and header_map["cnic"] < len(row_data) else ""
            addr = _clean_str(row_data[header_map["current_address"]]) if "current_address" in header_map and header_map["current_address"] < len(row_data) else ""
            bank_name = _clean_str(row_data[header_map["bank_name"]]) if "bank_name" in header_map and header_map["bank_name"] < len(row_data) else ""
            acc_number = _clean_str(row_data[header_map["acc_number"]]) if "acc_number" in header_map and header_map["acc_number"] < len(row_data) else ""

            if emp_name.lower() in existing_employees:
                skipped_count += 1
                log(f"Row {row_num}: Employee '{emp_name}' already exists. (Ignored)", "warning")
            else:
                conn.execute("""
                    INSERT INTO employee (empCode, empName, gender, phone, email, department, designation, DOJ, DOB, fatherName, aadhaar, cAdd1, bankName, accNumber)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """, (emp_code, emp_name, gender, phone, email, dept, desig, doj, dob, father, cnic, addr, bank_name, acc_number))
                conn.commit()
                existing_employees[emp_name.lower()] = emp_name
                inserted_count += 1
                log(f"Row {row_num}: Employee '{emp_name}' added successfully.", "success")

        except Exception as ex:
            error_count += 1
            log(f"Row {row_num}: Error processing '{emp_name}' - {str(ex)}", "error")

    conn.close()
    summary = f"Import Finished!\nInserted: {inserted_count} | Ignored: {skipped_count} | Errors: {error_count}"
    log("──────────────────────────────────────────", "info")
    log(summary, "success" if error_count == 0 else "warning")
    return {"inserted": inserted_count, "updated": 0, "skipped": skipped_count, "errors": error_count}


# ─────────────────────────────────────────────────────────────────────────────
# UI DIALOG WINDOWS
# ─────────────────────────────────────────────────────────────────────────────

class ExcelImportDialog(tk.Toplevel):
    """
    Excel Import Dialog Window with step indicators matching authentic design.
    Supports mode="items" (Inventory Item, Service)
    and mode="accounts" (Customer, Supplier, Other Accounts, Employee).
    """

    def __init__(self, master, mode="items", app=None):
        super().__init__(master)
        self.master_app = master
        self.app = app or master
        self.mode = mode  # "items" or "accounts"

        if self.mode == "items":
            self.title("Import From Excel")
            self.import_types = ["Inventory Item", "Service"]
        else:
            self.title("Import Accounts & Employees From Excel")
            self.import_types = ["Customer", "Supplier", "Other Accounts", "Employee"]

        self.geometry("640x540")
        self.minsize(580, 480)
        self.configure(bg=COLOR_BG)
        self.transient(master)
        self.grab_set()

        # Variables
        self.selected_type_var = tk.StringVar(value=self.import_types[0])
        self.selected_file_var = tk.StringVar(value="")
        self.existing_option_var = tk.StringVar(value="ignore")  # "update" or "ignore"

        self._build_ui()
        self._bind_shortcuts()

        # Center on screen
        self.update_idletasks()
        try:
            x = master.winfo_rootx() + (master.winfo_width() - self.winfo_width()) // 2
            y = master.winfo_rooty() + (master.winfo_height() - self.winfo_height()) // 2
            self.geometry(f"+{max(10, x)}+{max(10, y)}")
        except Exception:
            pass

    def _bind_shortcuts(self):
        self.bind("<Control-q>", lambda e: self.destroy())
        self.bind("<Control-Q>", lambda e: self.destroy())
        self.bind("<Escape>", lambda e: self.destroy())

    def _build_ui(self):
        # 1. Top Bar with [✕] Ctrl+Q: Exit
        top_bar = tk.Frame(self, bg=COLOR_HEADER_BG, height=32)
        top_bar.pack(fill="x", side="top")

        exit_btn_frame = tk.Frame(top_bar, bg=COLOR_HEADER_BG, cursor="hand2")
        exit_btn_frame.pack(side="left", padx=8, pady=4)

        lbl_x = tk.Label(exit_btn_frame, text="✕", font=("Segoe UI", 9, "bold"), fg="#ffffff", bg="#000000", width=2)
        lbl_x.pack(side="left")
        lbl_x.bind("<Button-1>", lambda e: self.destroy())

        btn_exit = tk.Button(exit_btn_frame, text="Ctrl+Q: Exit", font=FONT_MAIN, bg=COLOR_HEADER_BG,
                             activebackground="#e8e8e8", relief="flat", bd=0, command=self.destroy, cursor="hand2")
        btn_exit.pack(side="left", padx=(2, 0))

        # Thin Separator
        tk.Frame(self, bg="#dcdcdc", height=1).pack(fill="x")

        # 2. Main Middle Area (Vertical Step Indicators + Controls)
        main_frame = tk.Frame(self, bg=COLOR_BG, padx=25, pady=12)
        main_frame.pack(fill="both", expand=True)

        # Left Step Canvas for (1) | (2) | (3)
        self.canvas_steps = tk.Canvas(main_frame, width=50, height=220, bg=COLOR_BG, highlightthickness=0)
        self.canvas_steps.pack(side="left", fill="y", padx=(10, 20), pady=4)
        self._draw_step_indicators()

        # Right Form Controls
        right_frame = tk.Frame(main_frame, bg=COLOR_BG)
        right_frame.pack(side="left", fill="both", expand=True)

        # ── Step 1 Controls ──────────────────────────────────────────────────
        step1_frame = tk.Frame(right_frame, bg=COLOR_BG)
        step1_frame.pack(fill="x", pady=(0, 10))

        tk.Label(step1_frame, text="Select Import Type", font=FONT_TITLE, bg=COLOR_BG, fg="#000000").pack(anchor="w")

        self.cb_type = AutocompleteCombobox(step1_frame, textvariable=self.selected_type_var,
                                    values=self.import_types, state="readonly", width=25, font=FONT_MAIN)
        self.cb_type.pack(anchor="w", pady=(4, 6))
        self.cb_type.bind("<<ComboboxSelected>>", self._on_type_changed)

        # Download Sample Excel File link
        lbl_sample = tk.Label(step1_frame, text="Download Sample Excel File", font=FONT_LINK,
                              fg=COLOR_LINK, bg=COLOR_BG, cursor="hand2")
        lbl_sample.pack(anchor="w", pady=(0, 2))
        lbl_sample.bind("<Button-1>", lambda e: self.cmd_download_sample())

        # Download Existing Item in Excel link (if items mode)
        self.lbl_existing_export = tk.Label(step1_frame, text="Download Existing Item in Excel", font=FONT_LINK,
                                            fg=COLOR_LINK, bg=COLOR_BG, cursor="hand2")
        if self.mode == "items":
            self.lbl_existing_export.pack(anchor="w", pady=(0, 2))
            self.lbl_existing_export.bind("<Button-1>", lambda e: self.cmd_download_existing())

        # ── Step 2 Controls ──────────────────────────────────────────────────
        step2_frame = tk.Frame(right_frame, bg=COLOR_BG)
        step2_frame.pack(fill="x", pady=(8, 10))

        tk.Label(step2_frame, text="Select Your Excel File", font=FONT_TITLE, bg=COLOR_BG, fg="#000000").pack(anchor="w")

        browse_row = tk.Frame(step2_frame, bg=COLOR_BG)
        browse_row.pack(anchor="w", pady=(4, 4))

        btn_browse = tk.Button(browse_row, text="Browse", font=FONT_MAIN, bg=COLOR_BTN_BG,
                               activebackground="#d0d0d0", relief="solid", bd=1, width=18, command=self.cmd_browse, cursor="hand2")
        btn_browse.pack(side="left")

        self.lbl_file_display = tk.Label(browse_row, text="No file selected", font=("Segoe UI", 8, "italic"),
                                         fg="#666666", bg=COLOR_BG, padx=8)
        self.lbl_file_display.pack(side="left")

        # Radio options (Update / Ignore)
        self.radio_frame = tk.Frame(step2_frame, bg=COLOR_BG)
        if self.mode == "items":
            self.radio_frame.pack(anchor="w", pady=(4, 0))
            r_update = tk.Radiobutton(self.radio_frame, text="Update Existing Items", variable=self.existing_option_var,
                                      value="update", font=FONT_MAIN, bg=COLOR_BG, activebackground=COLOR_BG)
            r_update.pack(anchor="w")
            r_ignore = tk.Radiobutton(self.radio_frame, text="Ignore Existing Items", variable=self.existing_option_var,
                                      value="ignore", font=FONT_MAIN, bg=COLOR_BG, activebackground=COLOR_BG)
            r_ignore.pack(anchor="w")

        # ── Step 3 Controls ──────────────────────────────────────────────────
        step3_frame = tk.Frame(right_frame, bg=COLOR_BG)
        step3_frame.pack(fill="x", pady=(8, 4))

        btn_start = tk.Button(step3_frame, text="Start Import", font=FONT_MAIN, bg=COLOR_BTN_BG,
                              activebackground="#d0d0d0", relief="solid", bd=1, width=18,
                              command=self.cmd_start_import, cursor="hand2")
        btn_start.pack(anchor="w")

        # 3. Log Output Area (Bordered scrollable text box)
        log_frame = tk.Frame(self, bg=COLOR_BG, padx=25, pady=(0, 8))
        log_frame.pack(fill="both", expand=True)

        text_border = tk.Frame(log_frame, bg=COLOR_BORDER, bd=1)
        text_border.pack(fill="both", expand=True)

        self.log_text = tk.Text(text_border, bg="#ffffff", fg="#222222", font=FONT_CONSOLE,
                                height=6, wrap="word", relief="flat", bd=4)
        scrollbar = ttk.Scrollbar(text_border, orient="vertical", command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=scrollbar.set)

        self.log_text.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        # Text Tags
        self.log_text.tag_config("info", foreground="#1a3b5c")
        self.log_text.tag_config("success", foreground="#007700", font=("Consolas", 9, "bold"))
        self.log_text.tag_config("warning", foreground="#b35900")
        self.log_text.tag_config("error", foreground="#cc0000", font=("Consolas", 9, "bold"))

        # Initial Welcome Log
        self.append_log(f"Ready. Please choose import type and select your Excel file (.xlsx).", "info")

        # 4. Bottom Footer Link
        footer_frame = tk.Frame(self, bg=COLOR_BG, height=28)
        footer_frame.pack(fill="x", side="bottom", pady=(0, 6))

        lbl_video = tk.Label(footer_frame, text="Video: How to Import Transactions?", font=FONT_LINK,
                             fg=COLOR_LINK, bg=COLOR_BG, cursor="hand2")
        lbl_video.pack(anchor="center")
        lbl_video.bind("<Button-1>", lambda e: self.cmd_help_video())

    def _draw_step_indicators(self):
        self.canvas_steps.delete("all")
        # Line connecting 1 -> 2 -> 3
        self.canvas_steps.create_line(24, 20, 24, 185, fill="#000000", width=2)

        # Circle 1
        self.canvas_steps.create_oval(9, 5, 39, 35, fill="#000000", outline="#000000")
        self.canvas_steps.create_text(24, 20, text="1", fill="#ffffff", font=("Segoe UI", 12, "bold"))

        # Circle 2
        self.canvas_steps.create_oval(9, 85, 39, 115, fill="#000000", outline="#000000")
        self.canvas_steps.create_text(24, 100, text="2", fill="#ffffff", font=("Segoe UI", 12, "bold"))

        # Circle 3
        self.canvas_steps.create_oval(9, 165, 39, 195, fill="#000000", outline="#000000")
        self.canvas_steps.create_text(24, 180, text="3", fill="#ffffff", font=("Segoe UI", 12, "bold"))

    def _on_type_changed(self, event=None):
        t = self.selected_type_var.get()
        if self.mode == "items":
            if t == "Service":
                self.lbl_existing_export.config(text="Download Existing Service in Excel")
            else:
                self.lbl_existing_export.config(text="Download Existing Item in Excel")

    def append_log(self, msg, tag="info"):
        self.log_text.insert("end", msg + "\n", tag)
        self.log_text.see("end")
        self.update_idletasks()

    def cmd_browse(self):
        f = filedialog.askopenfilename(
            parent=self,
            title="Select Excel File",
            filetypes=[("Excel Files", "*.xlsx *.xls"), ("All Files", "*.*")]
        )
        if f:
            self.selected_file_var.set(f)
            fname = os.path.basename(f)
            self.lbl_file_display.config(text=f"Selected: {fname}", fg="#006600")
            self.append_log(f"Selected file: {f}", "info")

    def cmd_download_sample(self):
        imp_type = self.selected_type_var.get()
        default_name = f"Sample_{imp_type.replace(' ', '_')}.xlsx"
        dest = filedialog.asksaveasfilename(
            parent=self,
            title=f"Save Sample {imp_type} Excel File",
            initialfile=default_name,
            defaultextension=".xlsx",
            filetypes=[("Excel Workbook", "*.xlsx")]
        )
        if not dest:
            return

        try:
            if imp_type == "Inventory Item":
                generate_sample_inventory_item_excel(dest)
            elif imp_type == "Service":
                generate_sample_service_excel(dest)
            elif imp_type == "Customer":
                generate_sample_customer_excel(dest)
            elif imp_type == "Supplier":
                generate_sample_supplier_excel(dest)
            elif imp_type == "Other Accounts":
                generate_sample_other_accounts_excel(dest)
            elif imp_type == "Employee":
                generate_sample_employee_excel(dest)

            self.append_log(f"Sample template saved to: {dest}", "success")
            # Ask if user wants to open the file
            if messagebox.askyesno("File Saved", f"Sample template saved successfully.\nWould you like to open it now?", parent=self):
                try:
                    os.startfile(dest)
                except Exception:
                    pass
        except Exception as e:
            messagebox.showerror("Error", f"Failed to generate sample file: {e}", parent=self)
            self.append_log(f"Error generating sample file: {e}", "error")

    def cmd_download_existing(self):
        imp_type = self.selected_type_var.get()
        default_name = f"Existing_{imp_type.replace(' ', '_')}_{datetime.date.today().strftime('%Y%m%d')}.xlsx"
        dest = filedialog.asksaveasfilename(
            parent=self,
            title=f"Export Existing {imp_type} in Excel",
            initialfile=default_name,
            defaultextension=".xlsx",
            filetypes=[("Excel Workbook", "*.xlsx")]
        )
        if not dest:
            return

        try:
            export_existing_items_to_excel(dest, export_type=imp_type)
            self.append_log(f"Existing {imp_type} exported to: {dest}", "success")
            if messagebox.askyesno("Export Complete", f"Exported successfully to:\n{dest}\nWould you like to open it now?", parent=self):
                try:
                    os.startfile(dest)
                except Exception:
                    pass
        except Exception as e:
            messagebox.showerror("Error", f"Failed to export data: {e}", parent=self)
            self.append_log(f"Error exporting data: {e}", "error")

    def cmd_start_import(self):
        filepath = self.selected_file_var.get().strip()
        if not filepath or not os.path.exists(filepath):
            messagebox.showwarning("File Required", "Please select an Excel file first using the Browse button.", parent=self)
            return

        imp_type = self.selected_type_var.get()
        update_existing = (self.existing_option_var.get() == "update")

        self.append_log(f"── Starting import for {imp_type} ──", "info")

        try:
            if imp_type == "Inventory Item":
                res = import_inventory_items_from_excel(filepath, update_existing=update_existing, log_callback=self.append_log)
                if hasattr(self.app, "show_inventory"):
                    try:
                        self.app.show_inventory()
                    except Exception:
                        pass
            elif imp_type == "Service":
                res = import_services_from_excel(filepath, update_existing=update_existing, log_callback=self.append_log)
            elif imp_type == "Customer":
                res = import_accounts_from_excel(filepath, acc_type="customer", update_existing=True, log_callback=self.append_log)
                if hasattr(self.app, "show_accounts"):
                    try:
                        self.app.show_accounts("customer")
                    except Exception:
                        pass
            elif imp_type == "Supplier":
                res = import_accounts_from_excel(filepath, acc_type="supplier", update_existing=True, log_callback=self.append_log)
                if hasattr(self.app, "show_accounts"):
                    try:
                        self.app.show_accounts("supplier")
                    except Exception:
                        pass
            elif imp_type == "Other Accounts":
                res = import_accounts_from_excel(filepath, acc_type="other", update_existing=True, log_callback=self.append_log)
                if hasattr(self.app, "show_accounts"):
                    try:
                        self.app.show_accounts("all")
                    except Exception:
                        pass
            elif imp_type == "Employee":
                res = import_employees_from_excel(filepath, log_callback=self.append_log)

            msg = f"Import Process Completed!\n\nInserted: {res.get('inserted', 0)}\nUpdated: {res.get('updated', 0)}\nIgnored/Skipped: {res.get('skipped', 0)}\nErrors: {res.get('errors', 0)}"
            messagebox.showinfo("Import Complete", msg, parent=self)

        except Exception as e:
            traceback.print_exc()
            self.append_log(f"Import Failed: {str(e)}", "error")
            messagebox.showerror("Import Error", f"Failed to import data:\n{str(e)}", parent=self)

    def cmd_help_video(self):
        import webbrowser
        webbrowser.open("https://bookkeeperapp.net/tutorials/import-excel/")


# ─────────────────────────────────────────────────────────────────────────────
# MODULE ENTRY POINTS
# ─────────────────────────────────────────────────────────────────────────────

def open_import_items_dialog(master_app):
    return ExcelImportDialog(master_app, mode="items", app=master_app)


def open_import_accounts_dialog(master_app):
    return ExcelImportDialog(master_app, mode="accounts", app=master_app)
