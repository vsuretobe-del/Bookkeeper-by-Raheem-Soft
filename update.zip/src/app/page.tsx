'use client';
import React, { useEffect, useRef } from 'react';

// ── Chart ──────────────────────────────────────────────────────────────────
function DashboardChart() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (!canvasRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const W = canvas.width;
    const H = canvas.height;
    const padL = 60, padR = 20, padT = 10, padB = 50;
    const chartW = W - padL - padR;
    const chartH = H - padT - padB;

    const labels = ['Apr-2026','May-2026','Jun-2026','Jul-2026','Aug-2026','Sep-2026','Oct-2026','Nov-2026','Dec-2026','Jan-2027','Feb-2027','Mar-2027'];
    const values = [-3200,-3200,-3200,-3200,-3200,-3200,-3200,-3200,-3200,-3200,-3200,-3200];
    const minVal = -3200, maxVal = 1;
    const range = maxVal - minVal;

    const yTicks = [1.00, -639.20, -1279.40, -1919.60, -2559.80, -3200.00];

    ctx.clearRect(0, 0, W, H);
    ctx.fillStyle = '#fff';
    ctx.fillRect(0, 0, W, H);

    // grid lines
    ctx.strokeStyle = '#dde';
    ctx.lineWidth = 1;
    yTicks.forEach(tick => {
      const y = padT + ((maxVal - tick) / range) * chartH;
      ctx.beginPath();
      ctx.moveTo(padL, y);
      ctx.lineTo(padL + chartW, y);
      ctx.stroke();
      ctx.fillStyle = '#555';
      ctx.font = '10px Tahoma';
      ctx.textAlign = 'right';
      ctx.fillText(tick.toFixed(2), padL - 4, y + 3);
    });

    // x-axis labels
    ctx.fillStyle = '#555';
    ctx.font = '10px Tahoma';
    ctx.textAlign = 'center';
    labels.forEach((lbl, i) => {
      const x = padL + (i / (labels.length - 1)) * chartW;
      ctx.save();
      ctx.translate(x, H - padB + 10);
      ctx.rotate(-Math.PI / 4);
      ctx.fillText(lbl, 0, 0);
      ctx.restore();
    });

    // area fill
    ctx.beginPath();
    values.forEach((v, i) => {
      const x = padL + (i / (values.length - 1)) * chartW;
      const y = padT + ((maxVal - v) / range) * chartH;
      i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
    });
    ctx.lineTo(padL + chartW, padT + chartH);
    ctx.lineTo(padL, padT + chartH);
    ctx.closePath();
    ctx.fillStyle = 'rgba(170,200,240,0.5)';
    ctx.fill();

    // line
    ctx.beginPath();
    values.forEach((v, i) => {
      const x = padL + (i / (values.length - 1)) * chartW;
      const y = padT + ((maxVal - v) / range) * chartH;
      i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
    });
    ctx.strokeStyle = '#4488cc';
    ctx.lineWidth = 1.5;
    ctx.stroke();

    // dots (diamond shape)
    ctx.fillStyle = '#cc8822';
    values.forEach((v, i) => {
      const x = padL + (i / (values.length - 1)) * chartW;
      const y = padT + ((maxVal - v) / range) * chartH;
      ctx.beginPath();
      ctx.moveTo(x, y - 4);
      ctx.lineTo(x + 4, y);
      ctx.lineTo(x, y + 4);
      ctx.lineTo(x - 4, y);
      ctx.closePath();
      ctx.fill();
    });

    // green x-axis line
    ctx.beginPath();
    const baseY = padT + ((maxVal - minVal) / range) * chartH;
    ctx.moveTo(padL, baseY);
    ctx.lineTo(padL + chartW, baseY);
    ctx.strokeStyle = '#00aa00';
    ctx.lineWidth = 2;
    ctx.stroke();

    // arrow on right
    ctx.beginPath();
    ctx.moveTo(padL + chartW, baseY);
    ctx.lineTo(padL + chartW + 8, baseY - 4);
    ctx.lineTo(padL + chartW + 8, baseY + 4);
    ctx.fillStyle = '#555';
    ctx.fill();

    // arrow on top (y-axis)
    ctx.beginPath();
    ctx.moveTo(padL, padT);
    ctx.lineTo(padL - 4, padT + 8);
    ctx.lineTo(padL + 4, padT + 8);
    ctx.fill();

    // axes
    ctx.strokeStyle = '#555';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(padL, padT);
    ctx.lineTo(padL, padT + chartH);
    ctx.lineTo(padL + chartW + 8, padT + chartH);
    ctx.stroke();

  }, []);

  return (
    <canvas
      ref={canvasRef}
      width={680}
      height={230}
      style={{ width: '100%', height: '100%', display: 'block' }}
    />
  );
}

// ── Accounts Table ─────────────────────────────────────────────────────────
const accounts = [
  { name: 'Cash-in-hand',      amount: -3200, highlight: true },
  { name: 'Bank A/Cs',         amount: 0,     highlight: false },
  { name: 'Customer/Debtor',   amount: -89,   highlight: false },
  { name: 'Supplier/Creditor', amount: 89,    highlight: false },
];

// ── Right shortcuts panel ──────────────────────────────────────────────────
type ShortcutItem =
  | { type: 'link'; key: string; label: string; bold?: boolean; arrow?: boolean }
  | { type: 'period' }
  | { type: 'sep' };

const shortcuts: ShortcutItem[] = [
  { type: 'link', key: 'Alt+F1:', label: 'Switch Company/New Company' },
  { type: 'period' },
  { type: 'link', key: 'Alt+E:', label: 'Expense', arrow: true },
  { type: 'link', key: 'Alt+I:', label: 'Income', arrow: true },
  { type: 'link', key: 'F4:', label: 'Contra', arrow: true },
  { type: 'link', key: 'F5:', label: 'Payment To Supplier', arrow: true },
  { type: 'link', key: 'F6:', label: 'Receipt From Customer', arrow: true },
  { type: 'link', key: 'F7:', label: 'Journal', arrow: true },
  { type: 'link', key: 'F8:', label: 'Sale/Invoice/Bill', bold: true, arrow: true },
  { type: 'link', key: 'F9:', label: 'Purchase', arrow: true },
  { type: 'link', key: 'Alt+F4:', label: 'Purchase Order', arrow: true },
  { type: 'link', key: 'Alt+F5:', label: 'Estimate', arrow: true },
  { type: 'link', key: 'Alt+F8:', label: 'Credit Note/Sales Return', arrow: true },
  { type: 'link', key: 'Alt+F9:', label: 'Debit Note/Purchase Return', arrow: true },
  { type: 'sep' },
  { type: 'link', key: 'Alt+T:', label: 'View All Transactions' },
  { type: 'link', key: 'Alt+M:', label: 'Manage Category/Subcategory' },
  { type: 'link', key: 'Alt+S:', label: 'Item Stock Level Enquiry' },
];

// ── Main ────────────────────────────────────────────────────────────────────
export default function Dashboard() {
  return (
    <div style={{ display: 'flex', flex: 1, height: '100%', overflow: 'hidden' }}>

      {/* ── CENTER CONTENT ────────────────────────────────────── */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', background: '#d4d0c8', overflow: 'hidden' }}>

        {/* Tab strip */}
        <div style={{ display: 'flex', alignItems: 'flex-end', borderBottom: '1px solid #808080', background: '#d4d0c8', paddingTop: '4px', paddingLeft: '4px' }}>
          <div style={{
            background: '#fff',
            border: '1px solid #808080',
            borderBottom: '2px solid #fff',
            padding: '3px 16px',
            fontSize: '12px',
            fontWeight: 'bold',
            marginBottom: '-1px',
            cursor: 'pointer',
          }}>Today</div>
        </div>

        {/* White content area */}
        <div style={{ flex: 1, background: '#fff', overflowY: 'auto', display: 'flex', flexDirection: 'column' }}>

          {/* Mini toolbar inside white area */}
          <div style={{
            background: '#d4d0c8',
            borderBottom: '1px solid #aaa',
            padding: '2px 8px',
            display: 'flex', gap: '16px',
            fontSize: '12px',
            alignItems: 'center',
            flexShrink: 0,
          }}>
            <span style={{ color: '#cc0000', fontWeight: 'bold', display: 'flex', alignItems: 'center', gap: '3px', cursor: 'pointer' }}>
              <span style={{ background: '#cc0000', color: '#fff', padding: '0 3px', fontSize: '10px', fontWeight: 'bold' }}>✕</span>
              Ctrl+Q: Exit
            </span>
            <span style={{ color: '#00aa00', fontWeight: 'bold', display: 'flex', alignItems: 'center', gap: '3px', cursor: 'pointer' }}>
              <span style={{ fontSize: '13px' }}>⚡</span>
              Ctrl+R: Reload/Refresh
            </span>
          </div>

          {/* Dashboard body */}
          <div style={{ padding: '12px 16px', flex: 1 }}>

            {/* Heading row */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
              <span style={{ fontWeight: 'bold', fontSize: '20px', color: '#000', fontFamily: 'Tahoma, Arial' }}>ALHUMDULLILLAH</span>
              <span style={{ fontWeight: 'bold', fontSize: '20px', color: '#007700', fontFamily: 'Tahoma, Arial' }}>Today</span>
            </div>

            {/* Row: Invoice cards + account table */}
            <div style={{ display: 'flex', gap: '24px', alignItems: 'flex-start', marginBottom: '16px' }}>

              {/* Left side: invoice boxes + collection */}
              <div style={{ display: 'flex', flexDirection: 'column' }}>
                <div style={{ display: 'flex', gap: '8px', marginBottom: '5px' }}>
                  {/* Overdue Invoices */}
                  <div style={{
                    background: '#cc4444',
                    color: '#fff',
                    borderRadius: '5px',
                    width: '145px',
                    padding: '10px 12px 8px',
                    textAlign: 'center',
                    cursor: 'pointer',
                  }}>
                    <div style={{ fontSize: '38px', fontWeight: 'bold', lineHeight: '1' }}>0</div>
                    <div style={{ fontSize: '12px', margin: '6px 0 8px' }}>Overdue Invoices</div>
                    <div style={{ borderTop: '1px solid rgba(255,255,255,0.4)', paddingTop: '5px', fontSize: '13px', fontWeight: 'bold' }}>0</div>
                  </div>
                  {/* Unpaid Invoices */}
                  <div style={{
                    background: '#e07830',
                    color: '#fff',
                    borderRadius: '5px',
                    width: '145px',
                    padding: '10px 12px 8px',
                    textAlign: 'center',
                    cursor: 'pointer',
                  }}>
                    <div style={{ fontSize: '38px', fontWeight: 'bold', lineHeight: '1' }}>0</div>
                    <div style={{ fontSize: '12px', margin: '6px 0 8px' }}>Unpaid Invoices</div>
                    <div style={{ borderTop: '1px solid rgba(255,255,255,0.4)', paddingTop: '5px', fontSize: '13px', fontWeight: 'bold' }}>0</div>
                  </div>
                </div>

                {/* Cash / Bank collection bars */}
                <div style={{ display: 'flex', justifyContent: 'space-between', background: '#33bb55', color: '#fff', padding: '5px 10px', fontSize: '12px', fontWeight: 'bold', marginBottom: '3px', width: '298px' }}>
                  <span>Today&apos;s Cash Collection:</span><span>Rs0</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', background: '#229944', color: '#fff', padding: '5px 10px', fontSize: '12px', fontWeight: 'bold', width: '298px' }}>
                  <span>Today&apos;s Bank Collection:</span><span>Rs0</span>
                </div>
              </div>

              {/* Right side: Account table */}
              <table style={{ borderCollapse: 'collapse', minWidth: '240px', fontSize: '12px', border: '1px solid #aaa' }}>
                <thead>
                  <tr style={{ background: '#e0e0e0' }}>
                    <th style={{ padding: '4px 10px', border: '1px solid #aaa', textAlign: 'left', fontWeight: 'bold' }}>Account</th>
                    <th style={{ padding: '4px 10px', border: '1px solid #aaa', textAlign: 'right', fontWeight: 'bold' }}>Amount</th>
                  </tr>
                </thead>
                <tbody>
                  {accounts.map((acc, i) => (
                    <tr key={i} style={{ background: acc.highlight ? '#1155bb' : (i % 2 === 1 ? '#f0f0f0' : '#fff') }}>
                      <td style={{ padding: '4px 10px', border: '1px solid #ccc', color: acc.highlight ? '#fff' : '#000' }}>{acc.name}</td>
                      <td style={{
                        padding: '4px 10px', border: '1px solid #ccc', textAlign: 'right',
                        color: acc.highlight ? '#fff' : acc.amount < 0 ? '#cc0000' : acc.amount > 0 ? '#007700' : '#000',
                      }}>
                        {acc.amount.toLocaleString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Chart */}
            <div style={{ height: '230px', marginTop: '4px' }}>
              <DashboardChart />
            </div>

            {/* Legend */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginTop: '10px', fontSize: '11px', color: '#333' }}>
              <div style={{ width: '22px', height: '13px', background: '#aaccee', border: '1px solid #888' }} />
              <span>: 0</span>
            </div>
          </div>
        </div>
      </div>

      {/* ── RIGHT PANEL ───────────────────────────────────────── */}
      <div style={{
        width: '195px',
        minWidth: '195px',
        background: '#d4d0c8',
        borderLeft: '2px solid #808080',
        overflowY: 'auto',
        flexShrink: 0,
        fontSize: '12px',
      }}>
        {shortcuts.map((sc, i) => {
          if (sc.type === 'sep') {
            return <div key={i} style={{ height: '8px', borderBottom: '1px solid #aaa' }} />;
          }
          if (sc.type === 'period') {
            return (
              <div key={i} style={{ padding: '5px 8px', background: '#e0e0f0', borderBottom: '1px solid #bbb' }}>
                <div style={{ fontWeight: 'bold', marginBottom: '4px', fontSize: '11px' }}>
                  Alt+F2: Reporting Period
                </div>
                <table style={{ fontSize: '11px', width: '100%' }}>
                  <tbody>
                    <tr>
                      <td style={{ paddingRight: '4px', whiteSpace: 'nowrap' }}>From</td>
                      <td><input readOnly value="April  1, 2026" style={{ width: '95px', fontSize: '11px', padding: '1px 3px', border: '1px inset #999', background: '#fff' }} /></td>
                      <td><span style={{ cursor: 'pointer' }}>▼</span></td>
                    </tr>
                    <tr>
                      <td style={{ paddingRight: '4px', whiteSpace: 'nowrap', paddingTop: '3px' }}>To</td>
                      <td style={{ paddingTop: '3px' }}><input readOnly value="July   8, 2026" style={{ width: '95px', fontSize: '11px', padding: '1px 3px', border: '1px inset #999', background: '#fff' }} /></td>
                      <td style={{ paddingTop: '3px' }}><span style={{ cursor: 'pointer' }}>▼</span></td>
                    </tr>
                  </tbody>
                </table>
              </div>
            );
          }
          // normal link row
          return (
            <div key={i} style={{
              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
              padding: '4px 8px',
              borderBottom: '1px solid #ccc',
              cursor: 'pointer',
              color: '#003399',
              fontWeight: sc.bold ? 'bold' : 'normal',
              fontSize: '11px',
            }}
              onMouseOver={e => { (e.currentTarget as HTMLElement).style.background = '#b8c0d0'; }}
              onMouseOut={e => { (e.currentTarget as HTMLElement).style.background = 'transparent'; }}
            >
              <span>{sc.key} {sc.label}</span>
              {sc.arrow && <span style={{ color: '#555', fontSize: '10px' }}>▶</span>}
            </div>
          );
        })}
      </div>
    </div>
  );
}
