import type { Metadata } from "next";
import "./globals.css";
import Sidebar from "@/components/Sidebar";

export const metadata: Metadata = {
  title: "Book Keeper - v7.3.9",
  description: "GST Billing & Accounting Software",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" style={{ height: "100%" }}>
      <body style={{ margin: 0, padding: 0, fontFamily: "Tahoma, Segoe UI, Arial, sans-serif", display: "flex", flexDirection: "column", height: "100vh", background: "#d4d0c8", overflow: "hidden" }}>

        {/* TOP MENU BAR */}
        <div style={{
          background: "#d4d0c8",
          borderBottom: "1px solid #808080",
          padding: "2px 8px",
          display: "flex",
          alignItems: "center",
          gap: "10px",
          fontSize: "12px",
          color: "#000",
          flexShrink: 0,
        }}>
          <span style={{ color: "#cc0000", fontWeight: "bold", cursor: "pointer", display: "flex", alignItems: "center", gap: "3px" }}>
            <span style={{ background: "#cc0000", color: "#fff", fontWeight: "bold", padding: "0 3px", fontSize: "11px" }}>✕</span>
            Ctrl+Q: Exit
          </span>
          <span style={{ fontWeight: "bold", color: "#cc6600" }}>
            🏢 ALHUMDULLILLAH
          </span>
          {["Settings", "Tools", "Addons", "Help"].map(m => (
            <span key={m} style={{ cursor: "pointer", padding: "1px 6px" }}>{m}</span>
          ))}
          <span style={{ marginLeft: "auto", color: "#333", fontSize: "12px" }}>
            🔍 Ctrl+F: Universal Search
          </span>
        </div>

        {/* STATUS BAR */}
        <div style={{
          background: "#d4d0c8",
          borderBottom: "2px solid #808080",
          padding: "2px 8px",
          display: "flex",
          alignItems: "center",
          gap: "16px",
          fontSize: "12px",
          color: "#000",
          flexShrink: 0,
        }}>
          <span style={{ display: "flex", alignItems: "center", gap: "4px" }}>
            <span style={{ background: "#cc0000", color: "#fff", padding: "0 3px", fontSize: "10px" }}>✕</span>
            Company File Is Local, Not Syncing
          </span>
          <span style={{ display: "flex", alignItems: "center", gap: "4px" }}>
            <span>👤</span>
            Logged In As Admin
          </span>
          <span style={{ marginLeft: "auto" }}>↻ Shift+F5: Import User Data ▼</span>
        </div>

        {/* BODY */}
        <div style={{ display: "flex", flex: 1, overflow: "hidden" }}>
          <Sidebar />
          <main style={{ flex: 1, marginLeft: "185px", overflowY: "auto", display: "flex", flexDirection: "column" }}>
            {children}
          </main>
        </div>
      </body>
    </html>
  );
}
