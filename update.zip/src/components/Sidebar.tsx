'use client';
import Link from "next/link";
import { usePathname } from "next/navigation";

const sidebarData = [
  {
    section: "ACCOUNTS",
    bold: true,
    items: [
      { label: "Customers/Debtors", href: "/customers", icon: "👤" },
      { label: "Suppliers/Creditors", href: "/suppliers", icon: "👥" },
      { label: "All Accounts", href: "/accounts", icon: "💰" },
    ],
  },
  {
    section: "Transactions",
    bold: true,
    items: [],
  },
  {
    section: "INVENTORY",
    bold: true,
    items: [
      { label: "Inventory Item", href: "/inventory", icon: "🛒" },
      { label: "Unit Of Measure", href: "/units", icon: "⚖️" },
      { label: "Service", href: "/service", icon: "🔧" },
    ],
  },
  {
    section: "Reports",
    bold: false,
    italic: true,
    items: [
      { label: "Balance Sheet", href: "/reports/balance-sheet", icon: "📈" },
      { label: "Profit and Loss", href: "/reports/profit-loss", icon: "%" },
      { label: "Account Statement/Ledger", href: "/reports/ledger", icon: "📋" },
      { label: "Day Book", href: "/reports/daybook", icon: "📖" },
      { label: "Sales Register", href: "/reports/sales", icon: "〰️" },
      { label: "Inventory Item Details", href: "/reports/inventory-items", icon: "🛒" },
      { label: "Inventory Summary", href: "/reports/inventory-summary", icon: "📊" },
      { label: "Tax Register", href: "/reports/tax", icon: "💰" },
      { label: "All Reports", href: "/reports", icon: "📊" },
    ],
  },
];

export default function Sidebar() {
  const pathname = usePathname();

  return (
    <div style={{
      width: "185px",
      minWidth: "185px",
      backgroundColor: "#d4d0c8",
      color: "#000",
      display: "flex",
      flexDirection: "column",
      height: "100%",
      position: "fixed",
      top: 0,
      left: 0,
      overflowY: "auto",
      fontSize: "13px",
      borderRight: "1px solid #999",
      zIndex: 10,
    }}>
      {/* DASHBOARD yellow header */}
      <Link href="/" style={{ textDecoration: "none" }}>
        <div style={{
          backgroundColor: "#ffff00",
          color: "#000",
          padding: "6px 10px",
          fontWeight: "bold",
          fontSize: "13px",
          display: "flex",
          alignItems: "center",
          gap: "6px",
          cursor: "pointer",
          borderBottom: "1px solid #999",
        }}>
          <span>😊</span>
          <span>DASHBOARD</span>
        </div>
      </Link>

      {/* Menu Sections */}
      {sidebarData.map(({ section, bold, italic, items }) => (
        <div key={section}>
          {/* Section Header */}
          <div style={{
            padding: "10px 10px 4px 10px",
            fontWeight: bold ? "bold" : "normal",
            fontStyle: italic ? "italic" : "normal",
            fontSize: "13px",
            color: "#000",
          }}>
            {section}
          </div>

          {/* Items */}
          {items.map((item) => {
            const isActive = pathname === item.href;
            return (
              <Link
                key={item.href}
                href={item.href}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "6px",
                  padding: "3px 8px 3px 16px",
                  color: isActive ? "#fff" : "#003399",
                  backgroundColor: isActive ? "#003399" : "transparent",
                  textDecoration: "none",
                  fontSize: "12px",
                  cursor: "pointer",
                }}
              >
                <span style={{ fontSize: "13px", minWidth: "18px" }}>{item.icon}</span>
                <span style={{ textDecoration: "underline" }}>{item.label}</span>
              </Link>
            );
          })}
        </div>
      ))}
    </div>
  );
}

