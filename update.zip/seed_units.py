import sqlite3

c = sqlite3.connect('bookkeeper.db')

default_units = [
    ("Kilogram", "kg"),
    ("Litre", "lt"),
    ("Meter", "mt"),
    ("Numbers", "nos"),
    ("Packet", "pkt"),
    ("Pieces", "pc"),
    ("Unit", "u")
]

for name, symbol in default_units:
    try:
        c.execute("INSERT INTO units_measure (units_name, symbol, isSimpleUnit) VALUES (?, ?, 1)", (name, symbol))
    except sqlite3.IntegrityError:
        pass

c.commit()
c.close()
print("Seeded default units")
