import sqlite3
c = sqlite3.connect('bookkeeper.db')
print([r[1] for r in c.execute('PRAGMA table_info(units_measure)').fetchall()])
