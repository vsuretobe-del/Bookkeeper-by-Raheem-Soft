with open('authentic_schema.sql', 'r', encoding='utf-16le') as f:
    schema = f.read()
if "inc_pur" in schema.lower() or "inclusive" in schema.lower():
    print("Found inclusive columns")
else:
    print("No inclusive columns")
