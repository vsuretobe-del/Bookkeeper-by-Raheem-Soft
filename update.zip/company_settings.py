import tkinter as tk
from tkinter import ttk
import tkinter.messagebox as messagebox
from tkinter import filedialog
from PIL import Image, ImageTk
import db
import os
import datetime
import json
from autocomplete import AutocompleteCombobox

BG = "#ffffff"
BG_GREEN = "#1f6e2b"  # Deep green used for sidebars
RED = "#b20000"
BLUE_LINK = "#0000ff"
YELLOW = "#ffff00"
FONT = ("Segoe UI", 10)
FONT_BOLD = ("Segoe UI", 10, "bold")
FONT_TITLE = ("Segoe UI", 12, "bold")
FONT_ITALIC = ("Segoe UI", 10, "bold", "italic")

class AlterCompanyWindow(tk.Toplevel):
    def __init__(self, master, is_new=False, app_ref=None):
        super().__init__(master)
        self.is_new = is_new
        self.app_ref = app_ref
        self.title("Company Setup" if is_new else "Alter Company")
        self.geometry("820x720")
        self.minsize(780, 650)
        self.configure(bg=BG)

        # Center the window
        self.update_idletasks()
        try:
            sw = self.winfo_screenwidth()
            sh = self.winfo_screenheight()
            x = max(20, (sw - 820) // 2)
            y = max(20, (sh - 720) // 2)
            self.geometry(f"820x720+{x}+{y}")
        except:
            pass

        if master:
            try:
                self.transient(master)
            except:
                pass
        self.lift()
        self.focus_force()
        try:
            self.grab_set()  # Make window modal
        except:
            pass

        # Bottom buttons
        bottom_frame = tk.Frame(self, bg=BG)
        bottom_frame.pack(fill="x", side="bottom", padx=10, pady=10)

        btn_exit = tk.Button(bottom_frame, text="Ctrl+Q: Exit", font=FONT, bg="#e0e0e0", relief="flat", width=15, command=self.destroy)
        btn_exit.pack(side="left", ipadx=5, ipady=5)

        btn_save = tk.Button(bottom_frame, text="F12:Save", font=FONT, bg="#e0e0e0", relief="flat", width=15, command=self.save_data)
        btn_save.pack(side="right", ipadx=5, ipady=5)

        # Main wrapper to leave some padding for bottom buttons
        self.main_container = tk.Frame(self, bg=BG)
        self.main_container.pack(fill="both", expand=True, padx=10, pady=(10, 5))

        # Top instructional text
        top_lbl = tk.Label(self.main_container, text="Press ENTER to move forward  SHIFT+ENTER to move back.", 
                           bg=BG, fg=RED, font=FONT_ITALIC)
        top_lbl.pack(anchor="w", pady=(0, 10))

        # Middle frame for sidebars and notebook
        mid_frame = tk.Frame(self.main_container, bg=BG, highlightthickness=1, highlightbackground="#cccccc")
        mid_frame.pack(fill="both", expand=True)

        # Left green sidebar
        self.left_sidebar = tk.Canvas(mid_frame, bg=BG_GREEN, width=50, highlightthickness=0, cursor="hand2")
        self.left_sidebar.pack(side="left", fill="y", padx=10, pady=10)
        self.left_sidebar.bind("<Button-1>", lambda e: self._prev_tab())
        # Draw left arrow
        self.left_sidebar.create_polygon(40, 300, 40, 320, 10, 310, fill="white")

        # Right green sidebar
        self.right_sidebar = tk.Canvas(mid_frame, bg=BG_GREEN, width=50, highlightthickness=0, cursor="hand2")
        self.right_sidebar.pack(side="right", fill="y", padx=10, pady=10)
        self.right_sidebar.bind("<Button-1>", lambda e: self._next_tab())
        # Draw right arrow
        self.right_sidebar.create_polygon(10, 300, 10, 320, 40, 310, fill="white")

        # Notebook styling to remove thick borders
        style = ttk.Style()
        style.configure("TNotebook", background=BG, borderwidth=0)
        style.configure("TNotebook.Tab", font=FONT, padding=[10, 2])
        style.map("TNotebook.Tab", background=[("selected", BG)])
        
        self.notebook = ttk.Notebook(mid_frame, style="TNotebook")
        self.notebook.pack(side="left", fill="both", expand=True, pady=10)

        # Tabs
        self.tab_company = tk.Frame(self.notebook, bg=BG)
        self.tab_tax = tk.Frame(self.notebook, bg=BG)
        self.tab_features = tk.Frame(self.notebook, bg=BG)
        self.tab_password = tk.Frame(self.notebook, bg=BG)
        self.tab_logo = tk.Frame(self.notebook, bg=BG)

        self.notebook.add(self.tab_company, text="Company Details")
        self.notebook.add(self.tab_tax, text="Tax Details")
        self.notebook.add(self.tab_features, text="Features")
        self.notebook.add(self.tab_password, text="Password")
        self.notebook.add(self.tab_logo, text="Logo/Signature")

        self.widgets = {} # To store variables/entries

        self._build_company_tab()
        self._build_tax_tab()
        self._build_features_tab()
        self._build_password_tab()
        self._build_logo_tab()

        self._load_data()



        # Bindings
        self.bind("<Control-q>", lambda e: self.destroy())
        self.bind("<Control-Q>", lambda e: self.destroy())
        self.bind("<F12>", lambda e: self.save_data())
        self._bind_enter_navigation(self)

    def _bind_enter_navigation(self, parent):
        """Binds Enter to tab forward and Shift+Enter to tab backward"""
        def focus_next(event):
            event.widget.tk_focusNext().focus()
            return "break"
        def focus_prev(event):
            event.widget.tk_focusPrev().focus()
            return "break"
        
        # We need to bind on class level for this window so it applies globally inside it
        self.bind_class("Entry", "<Return>", focus_next)
        self.bind_class("Entry", "<Shift-Return>", focus_prev)
        self.bind_class("TCombobox", "<Return>", focus_next)
        self.bind_class("TCombobox", "<Shift-Return>", focus_prev)

    def _prev_tab(self):
        curr = self.notebook.index("current")
        if curr > 0:
            self.notebook.select(curr - 1)

    def _next_tab(self):
        curr = self.notebook.index("current")
        if curr < 4:
            self.notebook.select(curr + 1)

    # --- Build Tabs ---
    
    def _create_row(self, parent, label_text, widget_type="entry", width=40, pady=10):
        row = tk.Frame(parent, bg=BG)
        row.pack(fill="x", pady=pady)
        lbl = tk.Label(row, text=label_text, bg=BG, font=FONT, width=20, anchor="e")
        lbl.pack(side="left", padx=(0, 10))
        
        var = tk.StringVar()
        if widget_type == "entry":
            widget = tk.Entry(row, textvariable=var, font=FONT, width=width, relief="solid", bd=1)
            widget.pack(side="left")
        elif widget_type == "combo":
            widget = AutocompleteCombobox(row, textvariable=var, font=FONT, width=width-2, state="readonly")
            widget.pack(side="left")
        
        return var, widget, row

    def _build_company_tab(self):
        v_name, w_name, _ = self._create_row(self.tab_company, "Company Name")
        v_country, w_country, _ = self._create_row(self.tab_company, "Country", "combo")
        w_country["values"] = ["Pakistan", "India", "United States", "United Kingdom", "UAE"]
        
        v_maintains, w_maintains, row_maintains = self._create_row(self.tab_company, "Maintains", "combo")
        w_maintains["values"] = ["Accounts With Inventory", "Accounts Only"]
        tk.Label(row_maintains, text=" ⓘ", bg=BG, font=("Segoe UI", 12)).pack(side="left", padx=5)

        v_phone, w_phone, _ = self._create_row(self.tab_company, "Phone Number")
        w_phone.configure(bg=YELLOW)

        v_email, w_email, row_email = self._create_row(self.tab_company, "Company Email Id")
        tk.Label(row_email, text="Verify", bg=BG, fg=BLUE_LINK, font=("Segoe UI", 9, "underline"), cursor="hand2").pack(side="left", padx=5)

        v_addr1, _, _ = self._create_row(self.tab_company, "Address Line1")
        v_addr2, _, _ = self._create_row(self.tab_company, "Address Line2")
        v_city, _, _ = self._create_row(self.tab_company, "City")
        v_state, _, _ = self._create_row(self.tab_company, "State")
        v_pin, _, _ = self._create_row(self.tab_company, "Pincode")

        self.widgets.update({
            "company_name": v_name, "country": v_country, "maintains": v_maintains,
            "phone": v_phone, "email": v_email, "address1": v_addr1, "address2": v_addr2,
            "city": v_city, "state": v_state, "pincode": v_pin
        })

    def _build_tax_tab(self):
        row_fy = tk.Frame(self.tab_tax, bg=BG)
        row_fy.pack(fill="x", pady=(20, 10))
        tk.Label(row_fy, text="Financial Year From", bg=BG, font=FONT, width=20, anchor="e").pack(side="left", padx=(0, 10))
        
        # FY Date Pickers (Month, Day, Year)
        v_fy_month = tk.StringVar()
        w_month = AutocompleteCombobox(row_fy, textvariable=v_fy_month, width=10, state="readonly")
        w_month["values"] = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
        w_month.pack(side="left")
        
        v_fy_day = tk.StringVar()
        w_day = AutocompleteCombobox(row_fy, textvariable=v_fy_day, width=3, state="readonly")
        w_day["values"] = [str(i) for i in range(1, 32)]
        w_day.pack(side="left", padx=5)
        
        v_fy_year = tk.StringVar()
        w_year = AutocompleteCombobox(row_fy, textvariable=v_fy_year, width=6, state="readonly")
        w_year["values"] = [str(i) for i in range(2020, 2035)]
        w_year.pack(side="left")



        v_gst_no, _, _ = self._create_row(self.tab_tax, "GST No")
        v_tax2, _, _ = self._create_row(self.tab_tax, "Tax No. 2")
        v_tax3, _, _ = self._create_row(self.tab_tax, "Tax No. 3")
        
        v_currency, _, row_curr = self._create_row(self.tab_tax, "Currency Symbol")
        lbl_ex = tk.Label(row_curr, text="Example: INR, Rs., $, £, €, Rp, GBP, PKR, NPR", bg=BG, font=("Segoe UI", 8))
        # Place below entry
        lbl_ex.place(x=175, y=25)

        self.widgets.update({
            "fy_month": v_fy_month, "fy_day": v_fy_day, "fy_year": v_fy_year,
            "gst_no": v_gst_no, "tax2": v_tax2, "tax3": v_tax3,
            "currency_symbol": v_currency
        })

    def _build_features_tab(self):
        tk.Frame(self.tab_features, bg=BG, height=30).pack() # Spacer

        v_audit = tk.IntVar()
        v_mfg = tk.IntVar()
        v_wh = tk.IntVar()

        for text, var in [("Enable Audit Trail", v_audit), 
                          ("Enable Manufacturing?", v_mfg), 
                          ("Enable Warehousing?", v_wh)]:
            row = tk.Frame(self.tab_features, bg=BG)
            row.pack(fill="x", pady=15, padx=80)
            tk.Checkbutton(row, text=text, variable=var, bg=BG, font=FONT).pack(side="left")

        self.widgets.update({
            "enable_audit": v_audit, "enable_mfg": v_mfg, "enable_wh": v_wh
        })

    def _build_password_tab(self):
        row_pwd = tk.Frame(self.tab_password, bg=BG)
        row_pwd.pack(fill="x", pady=(30, 10))
        tk.Label(row_pwd, width=12, bg=BG).pack(side="left") # Spacer

        v_enable_pwd = tk.IntVar()
        chk_pwd = tk.Checkbutton(row_pwd, text="Enable Company Level Password?", variable=v_enable_pwd, bg=YELLOW, font=FONT)
        chk_pwd.pack(side="left")
        tk.Label(row_pwd, text="Recommended", fg=RED, font=FONT_BOLD, bg=BG).pack(side="left", padx=10)

        v_user, w_user, row_user = self._create_row(self.tab_password, "Username")
        v_user.set("admin")

        v_new_pwd, w_new_pwd, row_new = self._create_row(self.tab_password, "New Password")
        w_new_pwd.configure(show="*")
        
        v_rep_pwd, w_rep_pwd, row_rep = self._create_row(self.tab_password, "Repeat Password")
        w_rep_pwd.configure(show="*")

        def toggle_pwd(*args):
            state = "normal" if v_enable_pwd.get() else "disabled"
            w_new_pwd.config(state=state)
            w_rep_pwd.config(state=state)

        chk_pwd.config(command=toggle_pwd)
        # We need to call toggle_pwd after load_data, so we bind a trace to v_enable_pwd
        v_enable_pwd.trace_add("write", toggle_pwd)
        toggle_pwd()

        tk.Label(self.tab_password, text="Forgetting your password will render your data inaccessible.", 
                 fg=RED, font=FONT, bg=BG).pack(pady=5)

        v_admin_device = tk.IntVar()
        tk.Checkbutton(self.tab_password, text="This Is My Admin Device", variable=v_admin_device, bg=BG, font=FONT).pack(pady=10)

        self.widgets.update({
            "enable_pwd": v_enable_pwd, "username": v_user, "password": v_new_pwd, "rep_pwd": v_rep_pwd, "admin_device": v_admin_device
        })

    def _build_logo_tab(self):
        row = tk.Frame(self.tab_logo, bg=BG)
        row.pack(fill="both", expand=True, pady=50)

        # Split into two columns
        left = tk.Frame(row, bg=BG)
        left.pack(side="left", expand=True, fill="both")
        
        tk.Frame(row, width=1, bg="#888888").pack(side="left", fill="y") # Divider

        right = tk.Frame(row, bg=BG)
        right.pack(side="left", expand=True, fill="both")

        self.logo_path = tk.StringVar()
        self.sig_path = tk.StringVar()
        self.widgets.update({"logo_path": self.logo_path, "sig_path": self.sig_path})

        tk.Label(left, text="Company Logo", font=FONT, bg=BG).pack(pady=10)
        self.c_logo = tk.Canvas(left, width=150, height=150, bg=BG, highlightthickness=1, highlightbackground="#000")
        self.c_logo.pack()

        tk.Label(right, text="Company Signature", font=FONT, bg=BG).pack(pady=10)
        self.c_sig = tk.Canvas(right, width=150, height=150, bg=BG, highlightthickness=1, highlightbackground="#000")
        self.c_sig.pack()

        # Actions
        def select_image(var, canvas):
            path = filedialog.askopenfilename(filetypes=[("Image Files", "*.png *.jpg *.jpeg *.gif *.bmp")])
            if path:
                var.set(path)
                _load_image(path, canvas)

        def clear_image(var, canvas):
            var.set("")
            canvas.delete("all")

        def _load_image(path, canvas):
            try:
                img = Image.open(path)
                img.thumbnail((150, 150))
                photo = ImageTk.PhotoImage(img)
                canvas.image = photo # Keep reference
                canvas.delete("all")
                canvas.create_image(75, 75, image=photo, anchor="center")
            except Exception as e:
                print(f"Error loading image {path}: {e}")

        # The images will be loaded properly after _load_data populates the paths
        # We can trace the paths
        def on_logo_change(*args):
            p = self.logo_path.get()
            if p: _load_image(p, self.c_logo)
            else: self.c_logo.delete("all")
        self.logo_path.trace_add("write", on_logo_change)

        def on_sig_change(*args):
            p = self.sig_path.get()
            if p: _load_image(p, self.c_sig)
            else: self.c_sig.delete("all")
        self.sig_path.trace_add("write", on_sig_change)

        # Buttons frame for Logo
        btn_frm_logo = tk.Frame(left, bg=BG)
        btn_frm_logo.pack(pady=10)
        tk.Label(btn_frm_logo, text="✎", font=("Segoe UI", 20), fg="#333", bg=BG, cursor="hand2").pack(side="left", padx=10)
        btn_frm_logo.winfo_children()[0].bind("<Button-1>", lambda e: select_image(self.logo_path, self.c_logo))
        tk.Label(btn_frm_logo, text="🗑", font=("Segoe UI", 20), fg="#333", bg=BG, cursor="hand2").pack(side="left", padx=10)
        btn_frm_logo.winfo_children()[1].bind("<Button-1>", lambda e: clear_image(self.logo_path, self.c_logo))

        # Buttons frame for Signature
        btn_frm_sig = tk.Frame(right, bg=BG)
        btn_frm_sig.pack(pady=10)
        tk.Label(btn_frm_sig, text="✎", font=("Segoe UI", 20), fg="#333", bg=BG, cursor="hand2").pack(side="left", padx=10)
        btn_frm_sig.winfo_children()[0].bind("<Button-1>", lambda e: select_image(self.sig_path, self.c_sig))
        tk.Label(btn_frm_sig, text="🗑", font=("Segoe UI", 20), fg="#333", bg=BG, cursor="hand2").pack(side="left", padx=10)
        btn_frm_sig.winfo_children()[1].bind("<Button-1>", lambda e: clear_image(self.sig_path, self.c_sig))

    # --- Data Handling ---

    def _load_data(self):
        if self.is_new:
            # Set default values for a brand new company
            defaults = {
                "company_name": "",
                "country": "Pakistan",
                "maintains": "Accounts With Inventory",
                "phone": "",
                "email": "",
                "address1": "",
                "address2": "",
                "city": "",
                "state": "",
                "pincode": "",
                "fy_month": "April",
                "fy_day": "1",
                "fy_year": str(datetime.datetime.now().year),
                "gst_no": "",
                "tax2": "",
                "tax3": "",
                "currency_symbol": "PKR",
                "enable_audit": 0,
                "enable_mfg": 0,
                "enable_wh": 0,
                "enable_pwd": 0,
                "username": "admin",
                "password": "",
                "rep_pwd": "",
                "admin_device": 1,
                "logo_path": "",
                "sig_path": ""
            }
            for key, default_val in defaults.items():
                if key in self.widgets:
                    var = self.widgets[key]
                    if isinstance(var, tk.IntVar):
                        var.set(int(default_val) if default_val else 0)
                    else:
                        var.set(str(default_val))
            return

        for key, var in self.widgets.items():
            val = db.get_setting(f"company_{key}", "")
            if key == "username" and not val:
                val = "admin"
            if isinstance(var, tk.IntVar):
                try:
                    var.set(int(val) if val else 0)
                except ValueError:
                    var.set(0)
            else:
                var.set(val)

    def save_data(self):
        c_name = self.widgets.get("company_name", tk.StringVar()).get().strip()
        if not c_name:
            messagebox.showerror("Validation Error", "Please enter a Company Name!", parent=self)
            self.notebook.select(0)
            return

        if self.widgets.get("enable_pwd") and self.widgets["enable_pwd"].get():
            pwd = self.widgets.get("password", tk.StringVar()).get()
            rep = self.widgets.get("rep_pwd", tk.StringVar()).get()
            if pwd != rep:
                messagebox.showerror("Validation Error", "Passwords do not match! Please check repeated password.", parent=self)
                self.notebook.select(3)
                return
            if not pwd:
                messagebox.showerror("Validation Error", "Password cannot be blank when Password Protection is enabled!", parent=self)
                self.notebook.select(3)
                return

        if self.is_new:
            import os, sys
            default_dir = os.path.join(os.path.expanduser("~"), "Desktop")
            onedrive_desktop = os.path.join(os.path.expanduser("~"), "OneDrive", "Desktop")
            if os.path.exists(onedrive_desktop):
                default_dir = onedrive_desktop
            elif not os.path.exists(default_dir):
                default_dir = os.path.dirname(os.path.abspath(sys.argv[0]))

            safe_name = "".join(c for c in c_name if c.isalnum() or c in (' ', '_', '-')).strip()
            if not safe_name:
                safe_name = "NewCompany"

            db_filename = f"{safe_name}.db"
            target_path = os.path.join(default_dir, db_filename)

            if os.path.exists(target_path):
                if not messagebox.askyesno("File Exists", f"'{db_filename}' already exists. Overwrite this database?", parent=self):
                    return
                try:
                    os.remove(target_path)
                except:
                    pass

            db.set_db_path(target_path)
            db.init_db()

            conn = db.get_conn()
            conn.execute("DELETE FROM company")
            conn.execute("INSERT INTO company (c_name) VALUES (?)", (c_name))
            conn.commit()
            conn.close()

            for key, var in self.widgets.items():
                if hasattr(var, "get"):
                    db.set_setting(f"company_{key}", var.get())

            # Update recent companies list
            try:
                import os
                appdata_dir = os.path.join(os.getenv('APPDATA'), 'BookKeeper')
                os.makedirs(appdata_dir, exist_ok=True)
                recent_file = os.path.join(appdata_dir, "recent_companies.json")
                recent = []
                if os.path.exists(recent_file):
                    with open(recent_file, "r") as ff:
                        recent = json.load(ff)
                if target_path in recent:
                    recent.remove(target_path)
                recent.insert(0, target_path)
                with open(recent_file, "w") as ff:
                    json.dump(recent, ff)
            except:
                pass

            messagebox.showinfo("Success", f"Company '{c_name}' created successfully!", parent=self)
            self.destroy()

            if self.app_ref:
                # Close selection window if open
                if hasattr(self.master, 'destroy') and self.master != self.app_ref:
                    try:
                        self.master.destroy()
                    except:
                        pass
                self.app_ref.load_company(target_path)
                self.app_ref.deiconify()
        else:
            conn = db.get_conn()
            conn.execute("UPDATE company SET c_name = ?", (c_name))
            conn.commit()
            conn.close()

            for key, var in self.widgets.items():
                if hasattr(var, "get"):
                    db.set_setting(f"company_{key}", var.get())

            messagebox.showinfo("Saved", "Company details saved successfully!", parent=self)
            self.destroy()
            if self.app_ref:
                self.app_ref.company_name = c_name
                if hasattr(self.app_ref, 'update_all_views'):
                    self.app_ref.update_all_views()

if __name__ == "__main__":
    # Test execution
    root = tk.Tk()
    root.withdraw()
    app = AlterCompanyWindow(root)
    root.mainloop()
