# -*- coding: utf-8 -*-
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import os
import datetime
import db
from autocomplete import AutocompleteCombobox

try:
    from tkcalendar import DateEntry
except ImportError:
    DateEntry = None

BG = "#f0f2f5"
BG_WHITE = "#ffffff"
YELLOW = "#ffff00"
RED = "#cc0000"
FONT = ("Segoe UI", 10)
FONT_BOLD = ("Segoe UI", 10, "bold")
FONT_TITLE = ("Segoe UI", 12, "bold")

class SelectVouchersWindow(tk.Toplevel):
    def __init__(self, master, supplier_name, callback):
        super().__init__(master)
        self.title("Select Vouchers")
        self.geometry("900x600")
        self.configure(bg=BG_WHITE)
        self.grab_set()
        self.transient(master)
        
        self.supplier_name = supplier_name
        self.callback = callback

        self.main_frame = tk.Frame(self, bg=BG_WHITE)
        self.main_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        self.main_frame.grid_rowconfigure(0, weight=1)
        self.main_frame.grid_columnconfigure(0, weight=1)
        
        # Grid container (Canvas + Scrollbar)
        self.canvas = tk.Canvas(self.main_frame, bg=BG_WHITE, highlightthickness=0)
        
        class AutoScrollbar(ttk.Scrollbar):
            def set(self, lo, hi):
                if float(lo) <= 0.0 and float(hi) >= 1.0:
                    self.grid_remove()
                else:
                    self.grid()
                super().set(lo, hi)
                
        self.scrollbar = AutoScrollbar(self.main_frame, orient="vertical", command=self.canvas.yview)
        self.scrollable_frame = tk.Frame(self.canvas, bg=BG_WHITE)
        
        self.scrollable_frame.bind(
            "<Configure>",
            lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        )
        
        self.canvas_window = self.canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        
        self.canvas.bind(
            "<Configure>",
            lambda e: self.canvas.itemconfig(self.canvas_window, width=e.width)
        )
        
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        
        self.canvas.grid(row=0, column=0, sticky="nsew")
        self.scrollbar.grid(row=0, column=1, sticky="ns")

        # Make the scrollable frame columns expand based on weight
        self.scrollable_frame.grid_columnconfigure(0, minsize=150)
        self.scrollable_frame.grid_columnconfigure(1, weight=1, minsize=250)
        self.scrollable_frame.grid_columnconfigure(2, minsize=100)
        self.scrollable_frame.grid_columnconfigure(3, minsize=120)
        self.scrollable_frame.grid_columnconfigure(4, minsize=100)
        self.scrollable_frame.grid_columnconfigure(5, minsize=60)
        
        # Headers
        headers = ["ACCOUNTS", "Description", "Total\nAmount", "Outstanding\nAmount", "Amount\nTo Pay", "Select"]
        for i, h in enumerate(headers):
            lbl = tk.Label(self.scrollable_frame, text=h, font=FONT_BOLD, bg="#e2e8f0", fg="black", anchor="w" if i<2 else "center", relief="solid", bd=1)
            lbl.grid(row=0, column=i, sticky="nsew")
            
        self.rows_frame = self.scrollable_frame
        
        # Bottom section
        bot = tk.Frame(self, bg=BG_WHITE)
        bot.pack(fill="x", side="bottom", padx=10, pady=10)
        
        bot.grid_columnconfigure(0, weight=1)
        bot.grid_columnconfigure(1, weight=1)
        bot.grid_columnconfigure(2, weight=1)
        
        tk.Button(bot, text="Ctrl+Q: Exit", font=FONT, bg="#e0e0e0", width=12, command=self.destroy).grid(row=0, column=0, sticky="sw")
        
        center_frame = tk.Frame(bot, bg=BG_WHITE)
        center_frame.grid(row=0, column=1)
        
        tk.Label(center_frame, text="F9: Advance Payment", font=FONT, bg=BG_WHITE).grid(row=0, column=0, sticky="e", pady=2)
        self.v_adv = tk.StringVar(value="0")
        self.adv_entry = tk.Entry(center_frame, textvariable=self.v_adv, font=FONT, justify="right", width=20, relief="solid", bd=1)
        self.adv_entry.grid(row=0, column=1, padx=5, pady=2)
        self.adv_entry.bind('<KeyRelease>', lambda e: self._update_total())
        
        tk.Label(center_frame, text="Against Opening Balance", font=FONT, bg=BG_WHITE).grid(row=1, column=0, sticky="e", pady=2)
        self.v_open = tk.StringVar(value="0")
        tk.Entry(center_frame, textvariable=self.v_open, font=FONT, justify="right", width=20, relief="solid", bd=1).grid(row=1, column=1, padx=5, pady=2)
        
        tk.Label(center_frame, text="Total Amount", font=FONT, bg=BG_WHITE).grid(row=2, column=0, sticky="e", pady=2)
        self.v_tot = tk.StringVar(value="0")
        tk.Entry(center_frame, textvariable=self.v_tot, font=FONT, justify="right", width=20, relief="solid", bd=1).grid(row=2, column=1, padx=5, pady=2)
        
        tk.Button(bot, text="F12: OK", font=FONT, bg="#e0e0e0", width=12, command=self.on_ok).grid(row=0, column=2, sticky="se")
        
        self.row_data = []
        self.entries = []
        
        self._load_data()
        
        self.bind("<Control-q>", lambda e: self.destroy())
        self.bind("<Control-Q>", lambda e: self.destroy())
        self.bind("<F9>", lambda e: self.adv_entry.focus_set())
        self.bind("<F12>", lambda e: self.on_ok())

        # Bind mouse wheel for scrolling
        self.canvas.bind_all("<MouseWheel>", self._on_mousewheel)

    def _on_mousewheel(self, event):
        # Handle scroll only if cursor is over window
        if getattr(event.widget, 'winfo_toplevel', lambda: None)() == self:
            self.canvas.yview_scroll(int(-1*(event.delta/120)), "units")

    def _load_data(self):
        conn = db.get_conn()
        rows = conn.execute(
            "SELECT * FROM vouchers WHERE v_type IN ('purchase', 'journal', 'debit_note') AND (debit=? OR credit=?) AND (amount - COALESCE(paid_amount,0)) > 0.01",
            (self.supplier_name, self.supplier_name)
        ).fetchall()
        conn.close()
        
        type_labels = {
            "purchase": "Purchase",
            "journal": "Journal",
            "debit_note": "Debit Note"
        }
        
        for i, r in enumerate(rows):
            v_type = r["v_type"]
            lbl = type_labels.get(v_type, v_type.capitalize())
            out = r["amount"] - (r["paid_amount"] if r["paid_amount"] else 0)
            desc = f"{lbl}\nVoucher No:{r['vch_no']}\nVoucher Date: {r['date']}\nVoucher Due Date: {r['date']}"
            if "sellers_estimate_reference" in r.keys() and r["sellers_estimate_reference"]:
                desc += f"\nSellers Estimate Reference: {r['sellers_estimate_reference']}"
                
            bg_color = BG_WHITE if i % 2 == 0 else "#f2f2f2"
            row_idx = i + 1
            
            # ACCOUNTS
            lbl1 = tk.Label(self.rows_frame, text=f"{self.supplier_name}\n{lbl}", font=FONT, bg=bg_color, fg="black", anchor="w", justify="left", relief="solid", bd=1)
            lbl1.grid(row=row_idx, column=0, sticky="nsew")
            
            # Description
            lbl2 = tk.Label(self.rows_frame, text=desc, font=FONT, bg=bg_color, fg="black", anchor="w", justify="left", relief="solid", bd=1)
            lbl2.grid(row=row_idx, column=1, sticky="nsew")
            
            # Total Amount
            lbl3 = tk.Label(self.rows_frame, text=f"{r['amount']:g}", font=FONT, bg=bg_color, fg="black", anchor="e", relief="solid", bd=1)
            lbl3.grid(row=row_idx, column=2, sticky="nsew")
            
            # Outstanding
            lbl4 = tk.Label(self.rows_frame, text=f"{out:g}", font=FONT, bg=bg_color, fg="black", anchor="e", relief="solid", bd=1)
            lbl4.grid(row=row_idx, column=3, sticky="nsew")
            
            # Amount To Pay (Entry)
            pay_var = tk.StringVar(value="0")
            pay_frame = tk.Frame(self.rows_frame, bg=bg_color, relief="solid", bd=1)
            pay_frame.grid(row=row_idx, column=4, sticky="nsew")
            pay_frame.grid_columnconfigure(0, weight=1)
            pay_frame.grid_rowconfigure(0, weight=1)
            pay_entry = tk.Entry(pay_frame, textvariable=pay_var, font=FONT, bg=bg_color, justify="right", bd=0, highlightthickness=0)
            pay_entry.grid(row=0, column=0, sticky="nsew", padx=2, pady=2)
            
            # Select (Checkbox)
            sel_var = tk.BooleanVar(value=False)
            sel_frame = tk.Frame(self.rows_frame, bg=bg_color, relief="solid", bd=1)
            sel_frame.grid(row=row_idx, column=5, sticky="nsew")
            sel_cb = tk.Checkbutton(sel_frame, variable=sel_var, bg=bg_color, activebackground=YELLOW)
            sel_cb.pack(expand=True)
            
            data = {
                "vch_no": r['vch_no'],
                "type": v_type,
                "out": out,
                "pay_var": pay_var,
                "sel_var": sel_var,
                "sel_frame": sel_frame,
                "sel_cb": sel_cb,
                "bg_color": bg_color
            }
            self.row_data.append(data)
            
            def on_focus_in(e, pf=pay_frame, pe=pay_entry):
                pf.config(bg=YELLOW)
                pe.config(bg=YELLOW)
                
            def on_focus_out(e, pf=pay_frame, pe=pay_entry, c=bg_color):
                pf.config(bg=c)
                pe.config(bg=c)
                
            def on_check_toggle(d=data, o=out):
                if d["sel_var"].get():
                    d["pay_var"].set(f"{o:g}")
                    d["sel_frame"].config(bg=YELLOW)
                    d["sel_cb"].config(bg=YELLOW)
                else:
                    d["pay_var"].set("0")
                    d["sel_frame"].config(bg=d["bg_color"])
                    d["sel_cb"].config(bg=d["bg_color"])
                self._update_total()
                
            sel_cb.config(command=on_check_toggle)

            pay_entry.bind("<FocusIn>", on_focus_in)
            pay_entry.bind("<FocusOut>", on_focus_out)
            pay_entry.bind("<KeyRelease>", lambda e: self._update_total())
            
            pay_entry.bind("<Up>", lambda e, idx=i: self._navigate(idx, -1))
            pay_entry.bind("<Down>", lambda e, idx=i: self._navigate(idx, 1))
            
            self.entries.append(pay_entry)
            
    def _navigate(self, current_idx, direction):
        new_idx = current_idx + direction
        if 0 <= new_idx < len(self.entries):
            self.entries[new_idx].focus_set()
            
    def _update_total(self):
        tot = 0
        for data in self.row_data:
            try:
                val = float(data["pay_var"].get() or 0)
                tot += val
                if val > 0 and not data["sel_var"].get():
                    data["sel_var"].set(True)
                    data["sel_frame"].config(bg=YELLOW)
                    data["sel_cb"].config(bg=YELLOW)
                elif val == 0 and data["sel_var"].get():
                    data["sel_var"].set(False)
                    data["sel_frame"].config(bg=data["bg_color"])
                    data["sel_cb"].config(bg=data["bg_color"])
            except ValueError:
                pass
                
        try:
            adv = float(self.v_adv.get() or 0)
        except ValueError:
            adv = 0
        self.v_tot.set(f"{tot + adv:.0f}")

    def on_ok(self):
        selected = []
        for data in self.row_data:
            try:
                val = float(data["pay_var"].get() or 0)
                if val > 0 or data["sel_var"].get():
                    selected.append((data["vch_no"], val, data["type"]))
            except ValueError:
                pass
        self.callback(self.v_tot.get(), selected)
        self.destroy()

class PaymentSupplierWindow(tk.Toplevel):
    def __init__(self, master, app=None):
        self.app = app
        super().__init__(master)
        self.title("Create Voucher")
        self.geometry("1100x650")
        self.configure(bg=BG_WHITE)
        self.grab_set()
        
        # Toolbar
        tb = tk.Frame(self, bg=BG_WHITE)
        tb.pack(fill="x", padx=10, pady=5)
        shortcuts = [
            ("Alt+A: New Account", lambda: self.app._account_form() if self.app else None, "<Alt-a>"), 
            ("Alt+C: New Customer", lambda: self.app._account_form() if self.app else None, "<Alt-c>"),
            ("Alt+S: New Supplier", lambda: self.app._account_form() if self.app else None, "<Alt-s>"), 
            ("Alt+T: New Tax Account", lambda: self.app._account_form() if self.app else None, "<Alt-t>"),
            ("Alt+I: New Inventory Item", lambda: self.app._item_form() if self.app else None, "<Alt-i>"), 
            ("Alt+E: New Service", lambda: self.app._item_form() if self.app else None, "<Alt-e>"),
            ("Ctrl+F: Search", lambda: self.app.show_invoices("payment") if self.app else None, "<Control-f>")
        ]
        for txt, cmd, key in shortcuts:
            lbl = tk.Label(tb, text=txt, font=FONT_BOLD, bg=BG_WHITE, cursor="hand2")
            lbl.pack(side="right" if "Search" in txt else "left", padx=10)
            if cmd:
                lbl.bind("<Button-1>", lambda e, c=cmd: c())
                self.bind(key, lambda e, c=cmd: c())
                self.bind(key[:-2] + key[-2:].upper(), lambda e, c=cmd: c())
                
        self.bind("<Control-q>", lambda e: self.destroy())
        self.bind("<Control-Q>", lambda e: self.destroy())
        self.bind("<F12>", lambda e: self.save())

        tk.Frame(self, bg="#cccccc", height=1).pack(fill="x")

        # Main Layout
        self.main = tk.Frame(self, bg=BG_WHITE)
        self.main.pack(fill="both", expand=True, padx=20, pady=10)

        # Header section
        hf = tk.Frame(self.main, bg=BG_WHITE)
        hf.pack(fill="x", pady=10)

        # Left Header
        hl = tk.Frame(hf, bg=BG_WHITE)
        hl.pack(side="left")

        def add_row(parent, label):
            f = tk.Frame(parent, bg=BG_WHITE)
            f.pack(fill="x", pady=5)
            tk.Label(f, text=label, font=FONT, width=15, anchor="e", bg=BG_WHITE).pack(side="left", padx=10)
            return f

        self.v_pay_no = tk.StringVar(value=self._get_next_pay_no())
        r1 = add_row(hl, "Payment No")
        tk.Entry(r1, textvariable=self.v_pay_no, font=FONT, width=40, relief="solid", bd=1).pack(side="left")
        tk.Label(r1, text="Press ENTER to move forward", fg=RED, font=("Segoe UI", 10, "bold", "italic"), bg=BG_WHITE).pack(side="left", padx=40)

        self.v_date = tk.StringVar(value=datetime.date.today().strftime("%B %d, %Y"))
        r2 = add_row(hl, "Voucher Date")
        if DateEntry:
            self.cal = DateEntry(r2, textvariable=self.v_date, width=38, font=FONT, background="darkblue", foreground="white", borderwidth=1)
            self.cal.pack(side="left")
        else:
            tk.Entry(r2, textvariable=self.v_date, font=FONT, width=40, relief="solid", bd=1).pack(side="left")

        r3 = add_row(hl, "Paid To")
        self.v_paid_to = tk.StringVar()
        suppliers = [acc["name"] for acc in db.get_all_accounts() if acc.get("account_group") == "Sundry Creditors" or acc.get("a_type") == "supplier"]
        
        cb1_frame = tk.Frame(r3, bg=BG_WHITE, relief="solid", bd=1)
        cb1_frame.pack(side="left")
        cb1 = AutocompleteCombobox(cb1_frame, textvariable=self.v_paid_to, values=suppliers, font=FONT, width=38)
        cb1.pack(fill="both", expand=True, padx=0, pady=0)
        
        self.lbl_paid_to_bal = tk.Label(r3, text="0.0", font=FONT, bg=BG_WHITE)
        self.lbl_paid_to_bal.pack(side="left", padx=10)
        cb1.bind("<<ComboboxSelected>>", lambda e: self.lbl_paid_to_bal.config(text=f"{db.get_account_balance(self.v_paid_to.get()):,.0f}"))

        r4 = add_row(hl, "Paid From")
        self.v_paid_from = tk.StringVar()
        cash_bank = [acc["name"] for acc in db.get_all_accounts() if acc.get("account_group") in ("cash", "bank", "Bank A/Cs", "Cash-in-hand")]
        
        cb2_frame = tk.Frame(r4, bg=BG_WHITE, relief="solid", bd=1)
        cb2_frame.pack(side="left")
        cb2 = AutocompleteCombobox(cb2_frame, textvariable=self.v_paid_from, values=cash_bank, font=FONT, width=38)
        cb2.pack(fill="both", expand=True, padx=0, pady=0)
        cb2.set("Cash-in-hand" if "Cash-in-hand" in cash_bank else (cash_bank[0] if cash_bank else ""))
        
        self.lbl_paid_from_bal = tk.Label(r4, text="0.0", font=FONT, bg=BG_WHITE)
        self.lbl_paid_from_bal.pack(side="left", padx=10)
        cb2.bind("<<ComboboxSelected>>", lambda e: self.lbl_paid_from_bal.config(text=f"{db.get_account_balance(self.v_paid_from.get()):,.0f}"))
        if self.v_paid_from.get(): self.lbl_paid_from_bal.config(text=f"{db.get_account_balance(self.v_paid_from.get()):,.0f}")

        # Middle sections
        mid = tk.Frame(self.main, bg=BG_WHITE)
        mid.pack(fill="both", expand=True, pady=30)

        ml = tk.Frame(mid, bg=BG_WHITE)
        ml.pack(side="left", anchor="n", fill="y")
        mr = tk.Frame(mid, bg=BG_WHITE)
        mr.pack(side="right", anchor="n")

        tk.Button(ml, text="Payment against purchases", font=FONT, relief="solid", bd=1, bg=BG_WHITE,
                  command=self.open_vouchers).pack(anchor="w", ipadx=10, ipady=5, pady=(20, 10))

        self.v_disc = tk.IntVar()
        tk.Checkbutton(ml, text="Discount", variable=self.v_disc, font=FONT, bg=BG_WHITE, command=self.toggle_discount).pack(anchor="w", pady=5)
        
        self.v_tax = tk.IntVar()
        tk.Checkbutton(ml, text="Tax Deducted", variable=self.v_tax, font=FONT, bg=BG_WHITE, command=self.toggle_tax).pack(anchor="w", pady=5)

        # Dynamic Frames for Discount / Tax
        self.f_dyn = tk.Frame(mid, bg=BG_WHITE)
        self.f_dyn.pack(side="left", padx=50, anchor="n", pady=50)

        self.r_disc = tk.Frame(self.f_dyn, bg=BG_WHITE)
        tk.Label(self.r_disc, text="Discount Received:", font=FONT, bg=BG_WHITE).pack(side="left")
        AutocompleteCombobox(self.r_disc, values=["Discount On Purchase"], font=FONT, width=20).pack(side="left", padx=5)
        tk.Label(self.r_disc, text="Discount %", font=FONT, bg=BG_WHITE).pack(side="left")
        self.v_disc_pct = tk.StringVar(value="0")
        tk.Entry(self.r_disc, textvariable=self.v_disc_pct, width=5, justify="right", font=FONT).pack(side="left", padx=5)
        tk.Button(self.r_disc, text="Calculate", bg=YELLOW, font=FONT, relief="flat", command=self.calc_disc).pack(side="left", padx=5)

        self.r_tax = tk.Frame(self.f_dyn, bg=BG_WHITE)
        tk.Label(self.r_tax, text="Tax Account", font=FONT, width=15, anchor="e", bg=BG_WHITE).pack(side="left")
        AutocompleteCombobox(self.r_tax, values=["Salary Payable"], font=FONT, width=20).pack(side="left", padx=5)
        tk.Label(self.r_tax, text="Tax %", font=FONT, width=9, anchor="e", bg=BG_WHITE).pack(side="left")
        self.v_tax_pct = tk.StringVar(value="0")
        tk.Entry(self.r_tax, textvariable=self.v_tax_pct, width=5, justify="right", font=FONT).pack(side="left", padx=5)
        tk.Button(self.r_tax, text="Calculate", bg=YELLOW, font=FONT, relief="flat", command=self.calc_tax).pack(side="left", padx=5)

        # Right side Totals
        def right_row(parent, label, var):
            f = tk.Frame(parent, bg=BG_WHITE)
            f.pack(fill="x", pady=5)
            tk.Label(f, text=label, font=FONT, bg=BG_WHITE).pack(side="left")
            tk.Entry(f, textvariable=var, font=FONT, justify="right", width=20).pack(side="right")
            return f

        self.v_subtot = tk.StringVar(value="0")
        right_row(mr, "Sub Total", self.v_subtot).pack(pady=(20, 5))
        
        self.v_disc_val = tk.StringVar(value="0")
        self.f_disc_val = right_row(mr, "Discount Value", self.v_disc_val)
        
        self.v_tax_val = tk.StringVar(value="0")
        self.f_tax_val = right_row(mr, "Amount Withheld", self.v_tax_val)

        # Initially hide dynamic parts
        self.f_disc_val.pack_forget()
        self.f_tax_val.pack_forget()

        # Bottom section
        bot = tk.Frame(self.main, bg=BG_WHITE)
        bot.pack(fill="x", side="bottom")
        
        btn_f = tk.Frame(bot, bg=BG_WHITE)
        btn_f.pack(fill="x", side="bottom")
        tk.Button(btn_f, text="Ctrl+Q: Exit", font=FONT, bg="#e0e0e0", width=12, command=self.destroy).pack(side="left")
        tk.Button(btn_f, text="F12:Save", font=FONT, bg="#e0e0e0", width=12, command=self.save).pack(side="right")

        n_f = tk.Frame(bot, bg=BG_WHITE)
        n_f.pack(fill="x", side="bottom", pady=20)
        
        # Total
        tf = tk.Frame(n_f, bg=BG_WHITE)
        tf.pack(side="right", anchor="s")
        t_row = right_row(tf, "Total Amount", tk.StringVar(value="0"))
        self.v_grand_tot = t_row.winfo_children()[1].cget("textvariable")
        
        ref_f = tk.LabelFrame(tf, text="Reference Document", bg=BG_WHITE, font=("Segoe UI", 9))
        ref_f.pack(fill="x", pady=5)
        self.v_ref_doc = tk.StringVar()
        tk.Entry(ref_f, textvariable=self.v_ref_doc, state="readonly", width=25).pack(pady=5, padx=5)
        bf = tk.Frame(ref_f, bg=BG_WHITE)
        bf.pack(pady=5)
        tk.Button(bf, text="Browse", width=8, bg="#e0e0e0", command=self.browse_doc).pack(side="left", padx=2)
        tk.Button(bf, text="View", width=8, bg="#e0e0e0", command=self.view_doc).pack(side="left", padx=2)
        tk.Button(bf, text="Delete", width=8, bg="#e0e0e0", command=lambda: self.v_ref_doc.set("")).pack(side="left", padx=2)

        # Narration
        tk.Label(n_f, text="Narration\\nCtrl+Enter for next line", font=("Segoe UI", 8, "italic"), bg=BG_WHITE, justify="left").pack(side="left", anchor="n")
        self.nar_text = tk.Text(n_f, height=3, width=70, bg=YELLOW, font=FONT)
        self.nar_text.pack(side="left", padx=10)

        # Bindings
        self.bind("<Control-q>", lambda e: self.destroy())
        self.bind("<Control-Q>", lambda e: self.destroy())
        self.bind("<F12>", lambda e: self.save())
        self.bind("<F9>", lambda e: self.cb_paid_from.focus_set() if hasattr(self, 'cb_paid_from') else None)

    def _get_next_pay_no(self):
        conn = db.get_conn()
        c = conn.execute("SELECT COUNT(*) as cnt FROM vouchers WHERE v_type='payment'").fetchone()
        conn.close()
        cnt = c['cnt'] if c else 0
        return f"PAY{cnt + 1}"

    def open_vouchers(self):
        sup = self.v_paid_to.get()
        if not sup:
            messagebox.showwarning("Warning", "Please select Paid To (Supplier) first.")
            return
        w = SelectVouchersWindow(self, sup, self.set_subtot)

    def set_subtot(self, val, selected=[]):
        self.selected_vouchers = selected
        self.v_subtot.set(val)
        self._calc_grand()

    def toggle_discount(self):
        if self.v_disc.get():
            self.r_disc.pack(fill="x", pady=5)
            self.f_disc_val.pack(fill="x", pady=5)
        else:
            self.r_disc.pack_forget()
            self.f_disc_val.pack_forget()
            self.v_disc_val.set("0")
            self._calc_grand()

    def toggle_tax(self):
        if self.v_tax.get():
            self.r_tax.pack(fill="x", pady=5)
            self.f_tax_val.pack(fill="x", pady=5)
        else:
            self.r_tax.pack_forget()
            self.f_tax_val.pack_forget()
            self.v_tax_val.set("0")
            self._calc_grand()

    def calc_disc(self):
        try:
            pct = float(self.v_disc_pct.get())
            st = float(self.v_subtot.get())
            self.v_disc_val.set(f"{st * (pct/100):.0f}")
            self._calc_grand()
        except ValueError:
            pass

    def calc_tax(self):
        try:
            pct = float(self.v_tax_pct.get())
            st = float(self.v_subtot.get())
            self.v_tax_val.set(f"{st * (pct/100):.0f}")
            self._calc_grand()
        except ValueError:
            pass

    def _calc_grand(self):
        try: st = float(self.v_subtot.get())
        except ValueError: st = 0
        try: dv = float(self.v_disc_val.get())
        except ValueError: dv = 0
        try: tv = float(self.v_tax_val.get())
        except ValueError: tv = 0
        
        gt = st - dv - tv
        self.setvar(self.v_grand_tot, f"{gt:.0f}")

    def browse_doc(self):
        filepath = filedialog.askopenfilename()
        if filepath:
            self.v_ref_doc.set(filepath)
            
    def view_doc(self):
        filepath = self.v_ref_doc.get()
        if filepath and os.path.exists(filepath):
            try: os.startfile(filepath)
            except: pass
            
    def save(self):
        if not self.v_paid_to.get() or not self.v_paid_from.get():
            messagebox.showerror("Error", "Please select Paid To and Paid From!")
            return
            
        date_str = self.v_date.get()
        # Convert date to standard YYYY-MM-DD if possible or just use string
        import datetime
        try:
            date_str = datetime.datetime.strptime(date_str, "%B %d, %Y").strftime("%Y-%m-%d")
        except:
            date_str = datetime.date.today().strftime("%Y-%m-%d")
            
        try: st = float(self.v_subtot.get())
        except: st = 0
        try: dv = float(self.v_disc_val.get())
        except: dv = 0
        try: tv = float(self.v_tax_val.get())
        except: tv = 0
        
        gt = st - dv - tv
        if gt <= 0:
            messagebox.showerror("Error", "Total Amount must be greater than zero!")
            return
            
        v_id = db.create_payment(
            payment_no=self.v_pay_no.get(),
            date=date_str,
            paid_to=self.v_paid_to.get(),
            paid_from=self.v_paid_from.get(),
            sub_total=st,
            discount=dv,
            tax=tv,
            grand_total=gt,
            narration=self.nar_text.get("1.0", "end").strip() if hasattr(self, 'nar_text') else "",
            selected_vouchers=getattr(self, 'selected_vouchers', [])
        )
        
        messagebox.showinfo("Saved", "Payment Voucher saved successfully!")
        self.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    root.withdraw()
    w = PaymentSupplierWindow(root)
    root.mainloop()
