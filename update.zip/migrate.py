import sqlite3

def migrate_db():
    conn = sqlite3.connect('bookkeeper.db')
    try:
        conn.execute("ALTER TABLE vouchers ADD COLUMN status TEXT")
        print("Added status column.")
    except Exception as e:
        print(f"Status column: {e}")
        
    try:
        conn.execute("ALTER TABLE vouchers ADD COLUMN terms TEXT")
        print("Added terms column.")
    except Exception as e:
        print(f"Terms column: {e}")
        
    try:
        conn.execute("ALTER TABLE vouchers ADD COLUMN linked_po_id INTEGER")
        print("Added linked_po_id column.")
    except Exception as e:
        print(f"linked_po_id column: {e}")
        
    conn.commit()
    conn.close()

if __name__ == '__main__':
    migrate_db()
