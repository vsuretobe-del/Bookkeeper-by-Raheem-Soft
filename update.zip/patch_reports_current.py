import re
import os

def fix_current_calls(filepath):
    if not os.path.exists(filepath):
        print(f"{filepath} not found!")
        return

    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()

    # Regex to find something like: self.cb_name.current(0)
    # and replace with: self.cb_name.set(self.cb_name['values'][0])
    
    def replacer(match):
        obj_name = match.group(1)
        return f"{obj_name}.set({obj_name}['values'][0])"
        
    new_content = re.sub(r'(\w+\.\w+)\.current\(0\)', replacer, content)

    if new_content != content:
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(new_content)
        print(f"Patched {filepath}")
    else:
        print(f"No changes needed in {filepath}")

fix_current_calls('report_ledger.py')
fix_current_calls('report_daybook.py')
