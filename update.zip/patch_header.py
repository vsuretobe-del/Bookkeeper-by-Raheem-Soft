with open('bookkeeper.py', 'r', encoding='utf-8') as f:
from autocomplete import AutocompleteCombobox
    content = f.read()

target = '''        def lbl(parent, text, row, col, **kw):
            tk.Label(parent, text=text, bg=WHITE, fg="#000",
                     font=FONT, anchor="w", **kw).grid(
                row=row, column=col, sticky="w", padx=4, pady=3)

        def entry_field(parent, row, col, width=22, default=""):
            var = tk.StringVar(value=default)
            e = tk.Entry(parent, textvariable=var, font=FONT,
                         width=width, relief="solid", bd=1, bg=WHITE)
            e.grid(row=row, column=col, padx=4, pady=3, sticky="w")
            return var, e

        # Left column
        lbl(hdr, "Purchase No" if v_type == "purchase" else "Invoice No", 0, 0)
        inv_no_var, _ = entry_field(hdr, 0, 1, 14, db.get_next_invoice_no())
        
        tk.Label(hdr, text="Press ENTER to move forward", bg=WHITE, fg="darkred",
                 font=("Tahoma", 9, "bold italic")).grid(row=0, column=2, sticky="w", padx=10)

        lbl(hdr, "Voucher Date", 1, 0)
        date_frame = tk.Frame(hdr, bg=WHITE)
        date_frame.grid(row=1, column=1, sticky="w", padx=4, pady=3)
        date_var = tk.StringVar(value=datetime.date.today().strftime("%B %d, %Y"))
        tk.Entry(date_frame, textvariable=date_var, font=FONT,
                 width=16, relief="solid", bd=1, bg=WHITE).pack(side="left")
        tk.Label(date_frame, text=" ??", bg=WHITE, fg="#333",
                 font=("Tahoma", 9), cursor="hand2").pack(side="left")

        lbl(hdr, "Customer/Cash", 2, 0)
        cust_frame = tk.Frame(hdr, bg=WHITE)
        cust_frame.grid(row=2, column=1, sticky="w", padx=4, pady=3)
        cust_var = tk.StringVar(value="Cash")
        tk.Entry(cust_frame, textvariable=cust_var, font=FONT,
                 width=20, relief="solid", bd=1, bg=WHITE).pack(side="left")
        tk.Label(cust_frame, text="balance", bg=WHITE, fg="#000",
                 font=("Tahoma", 8), padx=6).pack(side="left")

        lbl(hdr, "Sales Account", 3, 0)
        sales_frame = tk.Frame(hdr, bg=WHITE)
        sales_frame.grid(row=3, column=1, sticky="w", padx=4, pady=3)
        sales_var = tk.StringVar(value="Sales")
        tk.Entry(sales_frame, textvariable=sales_var, font=FONT,
                 width=20, relief="solid", bd=1, bg=WHITE).pack(side="left")
        tk.Label(sales_frame, text="balance", bg=WHITE, fg="#000",
                 font=("Tahoma", 8), padx=6).pack(side="left")'''

replacement = '''        def lbl(parent, text, row, col, **kw):
            tk.Label(parent, text=text, bg=WHITE, fg="#000",
                     font=FONT, anchor="w", **kw).grid(
                row=row, column=col, sticky="w", padx=4, pady=3)

        def entry_field(parent, row, col, width=22, default=""):
            var = tk.StringVar(value=default)
            e = tk.Entry(parent, textvariable=var, font=FONT,
                         width=width, relief="solid", bd=1, bg=WHITE)
            e.grid(row=row, column=col, padx=4, pady=3, sticky="w")
            return var, e

        # Left column
        lbl(hdr, "Purchase No" if v_type == "purchase" else "Invoice No", 0, 0)
        inv_no_var, _ = entry_field(hdr, 0, 1, 14, db.get_next_invoice_no())
        
        tk.Label(hdr, text="Press ENTER to move forward", bg=WHITE, fg="darkred",
                 font=("Tahoma", 9, "bold italic")).grid(row=0, column=2, sticky="w", padx=10)

        lbl(hdr, "Voucher Date", 1, 0)
        date_frame = tk.Frame(hdr, bg=WHITE)
        date_frame.grid(row=1, column=1, sticky="w", padx=4, pady=3)
        date_var = tk.StringVar(value=datetime.date.today().strftime("%B %d, %Y"))
        tk.Entry(date_frame, textvariable=date_var, font=FONT,
                 width=16, relief="solid", bd=1, bg=WHITE).pack(side="left")
        tk.Label(date_frame, text=" ??", bg=WHITE, fg="#333",
                 font=("Tahoma", 9), cursor="hand2").pack(side="left")

        # --- Dynamic Accounts ---
        if v_type == "purchase":
            party_type = "supplier"
            txn_type = "purchase"
        else:
            party_type = "customer"
            txn_type = "sales"
            
        party_accs = db.get_all_accounts(party_type)
        party_map = {a["name"]: a["balance"] for a in party_accs}
        party_map["Cash"] = 0.0 # Default fallback
        party_list = ["Cash"] + [a["name"] for a in party_accs]
        
        txn_accs = db.get_all_accounts(txn_type)
        txn_map = {a["name"]: a["balance"] for a in txn_accs}
        txn_default = "Purchase" if v_type == "purchase" else "Sales"
        if txn_default not in txn_map:
            txn_map[txn_default] = 0.0
        txn_list = [txn_default] + [a["name"] for a in txn_accs if a["name"] != txn_default]

        lbl(hdr, "Supplier/Cash" if v_type == "purchase" else "Customer/Cash", 2, 0)
        cust_frame = tk.Frame(hdr, bg=WHITE)
        cust_frame.grid(row=2, column=1, sticky="w", padx=4, pady=3)
        cust_var = tk.StringVar(value="Cash")
        cust_cb = AutocompleteCombobox(cust_frame, textvariable=cust_var, values=party_list, font=FONT, width=19)
        cust_cb.pack(side="left")
        cust_bal_lbl = tk.Label(cust_frame, text="0.00", bg=WHITE, fg="#000", font=("Tahoma", 8), padx=6)
        cust_bal_lbl.pack(side="left")
        
        def update_cust_bal(*args):
            bal = party_map.get(cust_var.get(), 0.0)
            cust_bal_lbl.config(text=f"{bal:,.2f}")
        cust_var.trace_add("write", update_cust_bal)
        update_cust_bal()

        lbl(hdr, "Purchase Account" if v_type == "purchase" else "Sales Account", 3, 0)
        sales_frame = tk.Frame(hdr, bg=WHITE)
        sales_frame.grid(row=3, column=1, sticky="w", padx=4, pady=3)
        sales_var = tk.StringVar(value=txn_default)
        sales_cb = AutocompleteCombobox(sales_frame, textvariable=sales_var, values=txn_list, font=FONT, width=19)
        sales_cb.pack(side="left")
        sales_bal_lbl = tk.Label(sales_frame, text="0.00", bg=WHITE, fg="#000", font=("Tahoma", 8), padx=6)
        sales_bal_lbl.pack(side="left")
        
        def update_sales_bal(*args):
            bal = txn_map.get(sales_var.get(), 0.0)
            sales_bal_lbl.config(text=f"{bal:,.2f}")
        sales_var.trace_add("write", update_sales_bal)
        update_sales_bal()'''

content = content.replace(target, replacement)

with open('bookkeeper.py', 'w', encoding='utf-8') as f:
    f.write(content)

print("Patch Applied!")
