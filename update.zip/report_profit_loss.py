import tkinter as tk
from tkinter import ttk, messagebox
import db
import datetime

BG_DARK = "#2B579A"
WHITE = "#FFFFFF"
GRAY = "#E0E0E0"
DARK_GRAY = "#666666"

FONT = ("Segoe UI", 10)
FONT_BOLD = ("Segoe UI", 10, "bold")
TITLE_FONT = ("Segoe UI", 14, "bold")
CELL_FONT = ("Segoe UI", 9)

class ReportProfitLoss(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent, bg=WHITE)
        self.app_ref = parent
        self.title("Profit and Loss")
        self.state("zoomed")
        self.geometry("1024x768")
        
        try:
            self.start_d = self.app_ref.reporting_from_dp.get_date().strftime("%Y-%m-%d")
            self.end_d = self.app_ref.reporting_to_dp.get_date().strftime("%Y-%m-%d")
        except:
            today = datetime.date.today()
            self.start_d = datetime.date(today.year if today.month >= 4 else today.year - 1, 4, 1).strftime("%Y-%m-%d")
            self.end_d = today.strftime("%Y-%m-%d")
            
        self.build_ui()
        self.load_data()
        
    def not_implemented(self, event=None):
        messagebox.showinfo("Coming Soon", "This feature is not implemented yet.")

    def build_ui(self):
        # Toolbar
        tb = tk.Frame(self, bg=WHITE)
        tb.pack(fill="x", padx=10, pady=5)
        
        btn_exit = tk.Button(tb, text="✖ Ctrl+Q: Exit", bg="black", fg="white", font=("Tahoma", 8, "bold"), padx=4, pady=2, relief="flat", cursor="hand2", command=self.destroy)
        btn_exit.pack(side="left", padx=2)
        
        btn_print = tk.Button(tb, text="🖨 Alt+P: Print", bg="white", fg="black", font=("Tahoma", 8), padx=4, pady=2, relief="flat", cursor="hand2", command=self.not_implemented)
        btn_print.pack(side="left", padx=2)
        
        btn_word = tk.Button(tb, text="📄 Ctrl+W: Open In MS Word", bg="#DCDCDC", fg="black", font=("Tahoma", 8), padx=4, pady=2, relief="flat", cursor="hand2", command=self.not_implemented)
        btn_word.pack(side="left", padx=2)
        
        btn_excel = tk.Button(tb, text="📊 Ctrl+E: Open In MS Excel", bg="#DCDCDC", fg="black", font=("Tahoma", 8), padx=4, pady=2, relief="flat", cursor="hand2", command=self.not_implemented)
        btn_excel.pack(side="left", padx=2)
        
        btn_pdf = tk.Button(tb, text="📄 Ctrl+V: Open In PDF", bg="white", fg="black", font=("Tahoma", 8), padx=4, pady=2, relief="flat", cursor="hand2", command=self.not_implemented)
        btn_pdf.pack(side="left", padx=2)
        
        btn_browser = tk.Button(tb, text="🌐 Ctrl+H: Open In Browser", bg="black", fg="white", font=("Tahoma", 8, "bold"), padx=4, pady=2, relief="flat", cursor="hand2", command=self.not_implemented)
        btn_browser.pack(side="left", padx=2)
        
        # Additional Toolbar (Alt+F1)
        tb2 = tk.Frame(self, bg="#F0F0F0")
        tb2.pack(fill="x")
        btn_f1 = tk.Button(tb2, text="Alt+F1: View Detailed/Condensed Report", bg="#F0F0F0", fg="black", font=("Tahoma", 8), relief="flat", cursor="hand2", command=self.not_implemented)
        btn_f1.pack(side="left", padx=10, pady=2)
        
        tk.Frame(self, bg="#bbb", height=1).pack(fill="x")
        
        # Header
        self.header_f = tk.Frame(self, bg=WHITE)
        self.header_f.pack(fill="x", padx=20, pady=(20, 10))
        
        lbl_co = tk.Label(self.header_f, text="ALHUMDULILLAH", font=FONT_BOLD, bg=WHITE, fg=BG_DARK)
        lbl_co.pack(anchor="w")
        
        lbl_report = tk.Label(self.header_f, text="Trading & P/L Account", font=TITLE_FONT, bg=WHITE, fg="black")
        lbl_report.pack(anchor="w")
        
        lbl_date_range = tk.Label(self.header_f, text=f"{self.start_d} To {self.end_d}", font=FONT_BOLD, bg=WHITE, fg="black")
        lbl_date_range.pack(anchor="w")
        
        # Treeview container
        self.tree_f = tk.Frame(self, bg=WHITE)
        self.tree_f.pack(fill="both", expand=True, padx=20, pady=10)
        
    def format_money(self, val, show_currency=False):
        if val is None or val == 0:
            return "0"
        prefix = "Rs" if show_currency else ""
        if val < 0:
            return f"-{prefix}{abs(val):,.0f}"
        return f"{prefix}{val:,.0f}"

    def build_treeview(self):
        for widget in self.tree_f.winfo_children():
            widget.destroy()
            
        cols = ["PARTICULARS", "E1", "DEBIT", "CREDIT"]
                
        self.tree = ttk.Treeview(self.tree_f, columns=cols, show="headings", height=25, selectmode="none")
        
        self.tree.heading("PARTICULARS", text="PARTICULARS")
        self.tree.column("PARTICULARS", width=400, minwidth=400, anchor="w", stretch=False)
        
        self.tree.heading("E1", text="")
        self.tree.column("E1", width=50, minwidth=50, anchor="c", stretch=False)
        
        self.tree.heading("DEBIT", text="DEBIT")
        self.tree.column("DEBIT", width=150, minwidth=150, anchor="e", stretch=False)
        
        self.tree.heading("CREDIT", text="CREDIT")
        self.tree.column("CREDIT", width=150, minwidth=150, anchor="e", stretch=False)
            
        def disable_resize(event):
            if self.tree.identify_region(event.x, event.y) == "separator":
                return "break"
        self.tree.bind('<Button-1>', disable_resize)
        self.tree.bind('<B1-Motion>', disable_resize)
        style = ttk.Style()
        style.configure("Treeview", font=CELL_FONT, rowheight=30)
        style.configure("Treeview.Heading", font=FONT_BOLD)
        
        self.tree.tag_configure("row", font=CELL_FONT)
        self.tree.tag_configure("underline", font=("Segoe UI", 9, "underline"))
        self.tree.tag_configure("bold_row", font=FONT_BOLD)
        self.tree.tag_configure("grand", font=FONT_BOLD, background="#f0f0f0")
        
        ysb = ttk.Scrollbar(self.tree_f, orient="vertical", command=self.tree.yview)
        xsb = ttk.Scrollbar(self.tree_f, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscroll=ysb.set, xscroll=xsb.set)
        
        ysb.pack(side="right", fill="y")
        xsb.pack(side="bottom", fill="x")
        self.tree.pack(fill="both", expand=True)

    def load_data(self):
        self.build_treeview()
        try:
            data = db.get_detailed_profit_loss(self.start_d, self.end_d)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to fetch data:\n{e}")
            return
            
        trading = data['trading']
        pl = data['pl']
        
        # 1. Trading Account
        dr_len = len(trading['dr'])
        cr_len = len(trading['cr'])
        max_len = max(dr_len, cr_len)
        
        for i in range(max_len):
            dr_item = trading['dr'][i] if i < dr_len else None
            cr_item = trading['cr'][i] if i < cr_len else None
            
            # Print Debit side
            if dr_item and dr_item['val'] > 0:
                tag = "underline" if "Inventory" in dr_item['name'] else "row"
                self.tree.insert("", "end", values=[dr_item['name'], "", self.format_money(dr_item['val']), ""], tags=(tag,))
            
            # Print Credit side
            if cr_item and cr_item['val'] > 0:
                tag = "underline" if "Inventory" in cr_item['name'] else "row"
                self.tree.insert("", "end", values=[cr_item['name'], "", "", self.format_money(cr_item['val'])], tags=(tag,))
        
        # Gross Profit/Loss row
        if trading['gp'] > 0:
            self.tree.insert("", "end", values=["Gross Profit c/o", "", self.format_money(trading['gp']), ""], tags=("row",))
        elif trading['gl'] > 0:
            self.tree.insert("", "end", values=["Gross Loss c/o", "", "", self.format_money(trading['gl'])], tags=("row",))
            
        # Trading Total
        t_tot = self.format_money(trading['total'], True)
        self.tree.insert("", "end", values=["TOTAL", "", t_tot, t_tot], tags=("grand",))
        
        # 2. P/L Account
        dr_len = len(pl['dr'])
        cr_len = len(pl['cr'])
        max_len = max(dr_len, cr_len)
        
        for i in range(max_len):
            dr_item = pl['dr'][i] if i < dr_len else None
            cr_item = pl['cr'][i] if i < cr_len else None
            
            if dr_item and dr_item['val'] > 0:
                self.tree.insert("", "end", values=[dr_item['name'], "", self.format_money(dr_item['val']), ""], tags=("row",))
            
            if cr_item and cr_item['val'] > 0:
                self.tree.insert("", "end", values=[cr_item['name'], "", "", self.format_money(cr_item['val'])], tags=("row",))
                
        # Net Profit/Loss row
        if pl['np'] > 0:
            self.tree.insert("", "end", values=["Net Profit", "", self.format_money(pl['np']), ""], tags=("row",))
        elif pl['nl'] > 0:
            self.tree.insert("", "end", values=["Net Loss", "", "", self.format_money(pl['nl'])], tags=("row",))
            
        # P/L Total
        pl_tot = self.format_money(pl['total'], True)
        self.tree.insert("", "end", values=["TOTAL", "", pl_tot, pl_tot], tags=("grand",))

if __name__ == "__main__":
    root = tk.Tk()
    root.withdraw()
    app = ReportProfitLoss(root)
    root.mainloop()
