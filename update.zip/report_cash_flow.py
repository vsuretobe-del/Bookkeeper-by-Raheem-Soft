import tkinter as tk
from tkinter import ttk, messagebox
import db
import datetime

BG_DARK = "#2B579A"
WHITE = "#FFFFFF"
GRAY = "#E0E0E0"
DARK_GRAY = "#666666"

FONT = ("Segoe UI", 10)
FONT_BOLD = ("Segoe UI", 10, "bold")
TITLE_FONT = ("Segoe UI", 14, "bold")
SECTION_FONT = ("Segoe UI", 10, "bold")
ITEM_FONT = ("Segoe UI", 10)

class ReportCashFlow(tk.Toplevel):
    def __init__(self, parent, start_date, end_date):
        super().__init__(parent, bg=WHITE)
        self.title("Cash Flow Statement")
        self.state("zoomed")
        self.geometry("1024x768")
        
        self.start_date = start_date
        self.end_date = end_date
        
        self.build_ui()
        self.load_data()
        
    def not_implemented(self, event=None):
        messagebox.showinfo("Coming Soon", "This feature is not implemented yet.")

    def build_ui(self):
        # Header Toolbar
        tb = tk.Frame(self, bg=WHITE)
        tb.pack(fill="x", padx=10, pady=5)

        btn_exit = tk.Button(tb, text="✖ Ctrl+Q: Exit", bg="black", fg="white", font=("Tahoma", 8, "bold"), padx=4, pady=2, relief="flat", cursor="hand2", command=self.destroy)
        btn_exit.pack(side="left", padx=2)
        
        btn_print = tk.Button(tb, text="🖨 Alt+P: Print", bg="white", fg="black", font=("Tahoma", 8), padx=4, pady=2, relief="flat", cursor="hand2", command=self.not_implemented)
        btn_print.pack(side="left", padx=2)
        
        btn_word = tk.Button(tb, text="📄 Ctrl+W: Open In MS Word", bg="#DCDCDC", fg="black", font=("Tahoma", 8), padx=4, pady=2, relief="flat", cursor="hand2", command=self.not_implemented)
        btn_word.pack(side="left", padx=2)
        
        btn_excel = tk.Button(tb, text="📊 Ctrl+E: Open In MS Excel", bg="#DCDCDC", fg="black", font=("Tahoma", 8), padx=4, pady=2, relief="flat", cursor="hand2", command=self.not_implemented)
        btn_excel.pack(side="left", padx=2)
        
        btn_pdf = tk.Button(tb, text="📄 Ctrl+V: Open In PDF", bg="white", fg="black", font=("Tahoma", 8), padx=4, pady=2, relief="flat", cursor="hand2", command=self.not_implemented)
        btn_pdf.pack(side="left", padx=2)
        
        btn_browser = tk.Button(tb, text="🌐 Ctrl+H: Open In Browser", bg="black", fg="white", font=("Tahoma", 8, "bold"), padx=4, pady=2, relief="flat", cursor="hand2", command=self.not_implemented)
        btn_browser.pack(side="left", padx=2)
        
        tk.Frame(self, bg="#bbb", height=1).pack(fill="x")
        
        # Report Header
        self.header_f = tk.Frame(self, bg=WHITE)
        self.header_f.pack(fill="x", padx=20, pady=(20, 10))
        
        lbl_co = tk.Label(self.header_f, text="ALHUMDULILLAH", font=FONT_BOLD, bg=WHITE, fg=BG_DARK)
        lbl_co.pack(anchor="w")
        
        lbl_report = tk.Label(self.header_f, text="Cash Flow Statement", font=TITLE_FONT, bg=WHITE, fg="black")
        lbl_report.pack(anchor="w")
        
        self.lbl_date_range = tk.Label(self.header_f, text=f"{self.start_date} to {self.end_date}", font=FONT, bg=WHITE, fg=DARK_GRAY)
        self.lbl_date_range.pack(anchor="w")
        
        # Treeview
        self.tree_f = tk.Frame(self, bg=WHITE)
        self.tree_f.pack(fill="both", expand=True, padx=20, pady=10)
        
        cols = ["ACCOUNT", "AMOUNT"]
        self.tree = ttk.Treeview(self.tree_f, columns=cols, show="headings", height=20, selectmode="none")
        
        self.tree.heading("ACCOUNT", text="ACCOUNT")
        self.tree.heading("AMOUNT", text="AMOUNT")
        
        self.tree.column("ACCOUNT", width=600, minwidth=600, anchor="w", stretch=False)
        self.tree.column("AMOUNT", width=150, minwidth=150, anchor="e", stretch=False)
                
        def disable_resize(event):
            if self.tree.identify_region(event.x, event.y) == "separator":
                return "break"
        self.tree.bind('<Button-1>', disable_resize)
        self.tree.bind('<B1-Motion>', disable_resize)
        style = ttk.Style()
        style.configure("Treeview", font=FONT, rowheight=25)
        style.configure("Treeview.Heading", font=FONT_BOLD)
        
        self.tree.tag_configure("section", font=SECTION_FONT, foreground="#888888")
        self.tree.tag_configure("item", font=ITEM_FONT)
        self.tree.tag_configure("subtotal", font=FONT_BOLD)
        self.tree.tag_configure("grand", font=FONT_BOLD, background="#DCDCDC")
        
        ysb = ttk.Scrollbar(self.tree_f, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscroll=ysb.set)
        
        ysb.pack(side="right", fill="y")
        self.tree.pack(fill="both", expand=True)

    def format_money(self, val):
        if val is None or val == 0:
            return "0"
        return f"{val:,.0f}"

    def insert_section(self, section_name):
        self.tree.insert("", "end", values=(section_name.upper(), ""), tags=("section",))

    def insert_item(self, item_name, amount):
        self.tree.insert("", "end", values=(f"  {item_name}", self.format_money(amount)), tags=("item",))

    def insert_subtotal(self, label, amount):
        self.tree.insert("", "end", values=(label, self.format_money(amount)), tags=("subtotal",))
        self.tree.insert("", "end", values=("", ""), tags=("item",))

    def load_data(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
            
        try:
            data = db.get_cash_flow_data(self.start_date, self.end_date)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to fetch data:\n{e}")
            return

        # OPERATIONS
        self.insert_section("Cash Flow From Operations")
        op_items = [
            ("Net Income", data["Net Income"]),
            ("Customers Balance", data["Customers Balance"]),
            ("Suppliers Balance", data["Suppliers Balance"]),
            ("Stock", data["Stock"]),
            ("Current Assets", data["Current Assets"]),
            ("Current Liability", data["Current Liability"]),
            ("Tax Payable", data["Tax Payable"]),
        ]
        op_total = 0
        for name, val in op_items:
            self.insert_item(name, val)
            op_total += val
        self.insert_subtotal("  Operations (total)", op_total)

        # INVESTING
        self.insert_section("Cash Flow From Investing")
        inv_items = [
            ("Fixed Assets", data["Fixed Assets"]),
        ]
        inv_total = 0
        for name, val in inv_items:
            self.insert_item(name, val)
            inv_total += val
        self.insert_subtotal("  Investing (total)", inv_total)

        # FINANCING
        self.insert_section("Cash Flow From Financing")
        fin_items = [
            ("Capital A/C", data["Capital A/C"]),
            ("Loans & Advances", data["Loans & Advances"]),
        ]
        fin_total = 0
        for name, val in fin_items:
            self.insert_item(name, val)
            fin_total += val
        self.insert_subtotal("  Financing (total)", fin_total)

        # GRAND TOTAL
        grand_total = op_total + inv_total + fin_total
        self.tree.insert("", "end", values=("TOTAL CASH FLOW", f"Rs{self.format_money(grand_total)}"), tags=("grand",))

if __name__ == "__main__":
    root = tk.Tk()
    root.withdraw()
    app = ReportCashFlow(root, "2026-04-01", "2026-07-31")
    root.mainloop()
