import re

with open('bookkeeper.py', 'r', encoding='utf-8') as f:
    content = f.read()

old_str = 'tk.Label(win, text="For credit balance of customers,\\nEnter amount in negative (-)", bg="#ffffff", fg="#000", justify="left").place(x=cx1, y=205)'
new_str = '''        bal_text = "For credit balance of customers,\\nEnter amount in negative (-)"
        if acc_type == "supplier":
            bal_text = "For debit balance of suppliers,\\nEnter amount in negative (-)"
        
        tk.Label(win, text=bal_text, bg="#ffffff", fg="#000", justify="left").place(x=cx1, y=205)'''

content = content.replace(old_str, new_str)

# Also let's fix the yellow background of Account Name to be dynamic if it was a focus thing, 
# but actually leaving it yellow for all or white for all is fine. I'll leave it as is for now.

with open('bookkeeper.py', 'w', encoding='utf-8') as f:
    f.write(content)
print("Updated successfully")
