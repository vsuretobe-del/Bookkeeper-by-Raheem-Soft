import tkinter as tk
from tkinter import ttk, messagebox
import db
import webbrowser
from autocomplete import AutocompleteCombobox

WHITE = "#ffffff"
BG = "#f2f2f2"
BLUE_DARK = "#005a9e"
FONT = ("Segoe UI", 10)
FONT_BOLD = ("Segoe UI", 10, "bold")
RED = "darkred"

class MessageSettingsWindow(tk.Toplevel):
    def __init__(self, master):
        super().__init__(master)
        self.title("Message Settings")
        self.geometry("900x650")
        self.configure(bg=WHITE)
        self.transient(master)
        self.grab_set()

        self.setup_ui()
        self.load_settings()
        self.bind_events()
        self.update_visibility()

    def setup_ui(self):
        # ── Top Frame ────────────────────────────────────────────────────────
        top_fr = tk.Frame(self, bg=WHITE)
        top_fr.pack(fill="x", padx=10, pady=5)
        
        tk.Label(top_fr, text="Message Settings", bg=WHITE, font=("Segoe UI", 11)).pack(anchor="w")
        tk.Label(top_fr, text="Press ENTER to move forward SHIFT+ENTER to move back.",
                 bg=WHITE, fg=RED, font=("Segoe UI", 10, "bold italic")).pack(anchor="w")

        # ── Configure Parameters ─────────────────────────────────────────────
        self.param_fr = tk.LabelFrame(self, text="Configure Parameters", bg=WHITE, font=FONT)
        self.param_fr.pack(fill="x", padx=10, pady=5)
        
        radio_fr = tk.Frame(self.param_fr, bg=WHITE)
        radio_fr.pack(fill="x", pady=5)
        
        self.config_mode = tk.StringVar(value="text")
        rb1 = tk.Radiobutton(radio_fr, text="Configure for text message", variable=self.config_mode, value="text", bg=WHITE, font=FONT, command=self.update_visibility)
        rb2 = tk.Radiobutton(radio_fr, text="Configure for WhatsApp", variable=self.config_mode, value="whatsapp", bg=WHITE, font=FONT, command=self.update_visibility)
        
        rb1.pack(side="left", padx=100)
        rb2.pack(side="left", padx=50)

        self.body_fr = tk.Frame(self.param_fr, bg=WHITE)
        self.body_fr.pack(fill="both", expand=True, padx=5, pady=5)

        self.text_fr = tk.Frame(self.body_fr, bg=WHITE)
        self.whatsapp_fr = tk.Frame(self.body_fr, bg=WHITE)

        # -- Text Config UI --
        left_text = tk.Frame(self.text_fr, bg=WHITE)
        left_text.pack(side="left", fill="both", expand=True)
        right_text = tk.Frame(self.text_fr, bg=WHITE)
        right_text.pack(side="right", fill="both", expand=True, padx=10)

        # Left Grid
        labels = ["Website URL", "apikey", "", "", "sender", "mobileno", "text", "Owner Phone Number", "", ""]
        self.text_vars = {}
        for i, lbl in enumerate(labels):
            if lbl:
                tk.Label(left_text, text=lbl, bg=WHITE, font=FONT).grid(row=i, column=0, sticky="e", padx=5, pady=2)
            var = tk.StringVar()
            self.text_vars[lbl if lbl else f"blank_{i}"] = var
            if lbl == "Website URL":
                cb = AutocompleteCombobox(left_text, textvariable=var, font=FONT, width=45)
                cb['values'] = ["http://www.smsalert.co.in/api/push.json?"]
                cb.grid(row=i, column=1, sticky="w", pady=2)
            else:
                entry = tk.Entry(left_text, textvariable=var, font=FONT, width=47, relief="solid", bd=1)
                entry.grid(row=i, column=1, sticky="w", pady=2)
                
            if lbl in ["sender", "Owner Phone Number"]:
                tk.Label(left_text, text="ⓘ", bg=WHITE, font=FONT_BOLD).grid(row=i, column=2, padx=2)

        # Right Grid (Text mode)
        chk_fr = tk.Frame(right_text, bg=WHITE)
        chk_fr.pack(anchor="w", pady=5)
        self.inc_country_var = tk.IntVar()
        tk.Checkbutton(chk_fr, text="Include Country Prefix In Phone Numbers", variable=self.inc_country_var, bg=WHITE, font=FONT).pack(side="left")
        self.country_prefix_txt_var = tk.StringVar()
        tk.Entry(chk_fr, textvariable=self.country_prefix_txt_var, font=FONT, width=4, relief="solid", bd=1).pack(side="left", padx=5)

        chk_fr2 = tk.Frame(right_text, bg=WHITE)
        chk_fr2.pack(anchor="w", pady=5)
        self.url_enc_var = tk.IntVar()
        tk.Checkbutton(chk_fr2, text="Use URL Encoder for message (Advance option)", variable=self.url_enc_var, bg=WHITE, font=FONT).pack(side="left")
        tk.Label(chk_fr2, text="ⓘ", bg=WHITE, font=FONT_BOLD).pack(side="left", padx=2)

        tk.Label(right_text, text="Preview URL", bg=WHITE, font=FONT).pack(anchor="w", pady=(15, 0))
        self.preview_txt = tk.Text(right_text, width=40, height=6, font=FONT, relief="solid", bd=1, bg=BG)
        self.preview_txt.pack(anchor="w")
        self.preview_txt.insert("1.0", "http://www.smsalert.co.in/api/push.json?\nsender=DEMO&mobileno=919999176746&text=This is\nsample message.")
        self.preview_txt.config(state="disabled")

        # -- WhatsApp Config UI --
        # Same right-aligned structure but only 3 fields
        chk_wa1 = tk.Frame(self.whatsapp_fr, bg=WHITE)
        chk_wa1.pack(anchor="e", pady=5, padx=20)
        tk.Label(chk_wa1, text="Country prefix in phone numbers", bg=WHITE, font=FONT).pack(side="left", padx=10)
        self.country_prefix_wa_var = tk.StringVar()
        tk.Entry(chk_wa1, textvariable=self.country_prefix_wa_var, font=FONT, width=5, relief="solid", bd=1).pack(side="left")

        chk_wa2 = tk.Frame(self.whatsapp_fr, bg=WHITE)
        chk_wa2.pack(anchor="e", pady=5, padx=20)
        self.url_enc_wa_var = tk.IntVar()
        tk.Checkbutton(chk_wa2, text="Use URL Encoder for message (Advance option)", variable=self.url_enc_wa_var, bg=WHITE, font=FONT).pack(side="left")
        tk.Label(chk_wa2, text="ⓘ", bg=WHITE, font=FONT_BOLD).pack(side="left", padx=2)

        wa_combo_fr = tk.Frame(self.whatsapp_fr, bg=WHITE)
        wa_combo_fr.pack(anchor="e", pady=5, padx=20)
        tk.Label(wa_combo_fr, text="Use WhatsApp On", bg=WHITE, font=FONT).pack(side="left", padx=10)
        self.wa_client_var = tk.StringVar()
        wa_cb = AutocompleteCombobox(wa_combo_fr, textvariable=self.wa_client_var, font=FONT, width=15, state="readonly")
        wa_cb['values'] = ["Old Application", "Web", "New Application"]
        wa_cb.pack(side="left")

        # ── Templates ────────────────────────────────────────────────────────
        tpl_fr = tk.LabelFrame(self, text="Templates", bg=WHITE, font=FONT)
        tpl_fr.pack(fill="both", expand=True, padx=10, pady=5)
        
        tpl_left = tk.Frame(tpl_fr, bg=WHITE)
        tpl_left.pack(side="left", fill="both", expand=True, padx=5)
        tpl_right = tk.Frame(tpl_fr, bg=WHITE)
        tpl_right.pack(side="right", fill="y", padx=5)

        tk.Label(tpl_left, text="Don't use special characters like & or = etc in templates.", bg=WHITE, fg=RED, font=("Segoe UI", 10, "bold italic")).grid(row=0, column=0, columnspan=2, pady=2)
        
        tpl_fields = [
            ("Estimate", "msg_tpl_estimate"),
            ("Invoice", "msg_tpl_invoice"),
            ("Receipt From Customer", "msg_tpl_receipt"),
            ("Purchase Order", "msg_tpl_po"),
            ("Purchase", "msg_tpl_purchase"),
            ("Payment To Supplier", "msg_tpl_payment"),
            ("Outstanding Amount", "msg_tpl_outstanding"),
        ]
        self.tpl_vars = {}
        for i, (lbl, key) in enumerate(tpl_fields, start=1):
            tk.Label(tpl_left, text=lbl, bg=WHITE, font=FONT).grid(row=i, column=0, sticky="w", padx=5, pady=2)
            var = tk.StringVar()
            self.tpl_vars[key] = var
            tk.Entry(tpl_left, textvariable=var, font=FONT, width=65, relief="solid", bd=1).grid(row=i, column=1, sticky="w", pady=2)

        help_text = (
            "%%name%%        - customer supplier name\n"
            "%%number%%      - voucher number\n"
            "%%amount%%      - voucher amount\n"
            "%%date%%        - voucher date\n"
            "%%narration%%   - narration\n"
            "%%outstanding%% - total outstanding\n"
            "%%company%%     - company name\n"
            "%%due%%         - due date\n"
            "%%item%%        - item details\n"
            "%%paymentlink%% - cashfree payment link\n"
            "%%invoices%%    - list of all the invoices\n"
            "                  purchases against which\n"
            "                  payment is received\n"
            "                  made"
        )
        tk.Label(tpl_right, text=help_text, bg=WHITE, fg=RED, font=("Segoe UI", 9), justify="left").pack(anchor="nw", pady=20)

        # ── Bottom Bar ───────────────────────────────────────────────────────
        bot_fr = tk.Frame(self, bg=BG)
        bot_fr.pack(fill="x", side="bottom")
        
        tk.Button(bot_fr, text="Ctrl+Q: Exit", font=FONT, command=self.destroy).pack(side="left", padx=10, pady=5)
        
        link_fr = tk.Frame(bot_fr, bg=BG)
        link_fr.pack(side="left", expand=True)
        lbl_v1 = tk.Label(link_fr, text="How to send SMS from Book Keeper Windows?", bg=BG, fg="blue", font=("Segoe UI", 9, "underline"), cursor="hand2")
        lbl_v1.pack(side="left", padx=10)
        lbl_v2 = tk.Label(link_fr, text="How to use custom website for sending SMS?", bg=BG, fg="blue", font=("Segoe UI", 9, "underline"), cursor="hand2")
        lbl_v2.pack(side="left", padx=10)
        
        tk.Button(bot_fr, text="Enter: Save", font=FONT, command=self.save_settings).pack(side="right", padx=10, pady=5)

    def bind_events(self):
        self.bind("<Control-q>", lambda e: self.destroy())
        self.bind("<Control-Q>", lambda e: self.destroy())
        self.bind("<Return>", lambda e: self.save_settings())

    def update_visibility(self):
        mode = self.config_mode.get()
        if mode == "text":
            self.whatsapp_fr.pack_forget()
            self.text_fr.pack(fill="both", expand=True)
        else:
            self.text_fr.pack_forget()
            self.whatsapp_fr.pack(fill="both", expand=True)

    def load_settings(self):
        self.config_mode.set(db.get_setting("msg_config_type", "whatsapp"))
        self.update_visibility()

        # Text vars
        self.text_vars["Website URL"].set(db.get_setting("msg_text_url", "http://www.smsalert.co.in/api/push.json?"))
        self.text_vars["apikey"].set(db.get_setting("msg_text_apikey", ""))
        self.text_vars["sender"].set(db.get_setting("msg_text_sender", "DEMO"))
        self.text_vars["mobileno"].set(db.get_setting("msg_text_mobileno", "CUSTOMER_PHONE_NUMBER (AUTOFILLED)"))
        self.text_vars["text"].set(db.get_setting("msg_text_text", "MESSAGE_TO_BE_SENT (AUTOFILLED)"))
        self.text_vars["Owner Phone Number"].set(db.get_setting("msg_text_owner_num", ""))
        self.text_vars["blank_2"].set(db.get_setting("msg_text_b2", ""))
        self.text_vars["blank_3"].set(db.get_setting("msg_text_b3", ""))
        self.text_vars["blank_8"].set(db.get_setting("msg_text_b8", ""))
        self.text_vars["blank_9"].set(db.get_setting("msg_text_b9", ""))

        self.inc_country_var.set(int(db.get_setting("msg_inc_country", "1")))
        self.country_prefix_txt_var.set(db.get_setting("msg_country_prefix_txt", "91"))
        self.url_enc_var.set(int(db.get_setting("msg_url_enc_txt", "0")))

        # WhatsApp vars
        self.country_prefix_wa_var.set(db.get_setting("msg_country_prefix_wa", "+92"))
        self.url_enc_wa_var.set(int(db.get_setting("msg_url_enc_wa", "0")))
        self.wa_client_var.set(db.get_setting("msg_wa_client", "Web"))

        # Templates
        def_templates = {
            "msg_tpl_estimate": "Hi, This is %%company%%. Estimate %%number%% has been generated on %%date%% for %%amount%%",
            "msg_tpl_invoice": "Hi %%name%%, This is %%company%%. Invoice %%number%% has been generated on %%date%% for %%amount%%",
            "msg_tpl_receipt": "Hi, This is %%company%%. We confirm the receipt (%%number%%) of %%amount%% on %%date%%",
            "msg_tpl_po": "Hi, This is %%company%%. Purchase Order %%number%% has been generated on %%date%% for %%amount%%",
            "msg_tpl_purchase": "Hi, This is %%company%%. Purchase %%number%% has been generated on %%date%% for %%amount%%",
            "msg_tpl_payment": "Hi, This is %%company%%. We confirm the payment (%%number%%) of %%amount%% on %%date%%",
            "msg_tpl_outstanding": "Hi %%name%%, this is %%company%%. Outstanding amount is %%amount%%",
        }
        for k, v in self.tpl_vars.items():
            v.set(db.get_setting(k, def_templates[k]))

    def save_settings(self):
        db.set_setting("msg_config_type", self.config_mode.get())
        
        # Text vars
        db.set_setting("msg_text_url", self.text_vars["Website URL"].get())
        db.set_setting("msg_text_apikey", self.text_vars["apikey"].get())
        db.set_setting("msg_text_sender", self.text_vars["sender"].get())
        db.set_setting("msg_text_mobileno", self.text_vars["mobileno"].get())
        db.set_setting("msg_text_text", self.text_vars["text"].get())
        db.set_setting("msg_text_owner_num", self.text_vars["Owner Phone Number"].get())
        db.set_setting("msg_text_b2", self.text_vars["blank_2"].get())
        db.set_setting("msg_text_b3", self.text_vars["blank_3"].get())
        db.set_setting("msg_text_b8", self.text_vars["blank_8"].get())
        db.set_setting("msg_text_b9", self.text_vars["blank_9"].get())

        db.set_setting("msg_inc_country", str(self.inc_country_var.get()))
        db.set_setting("msg_country_prefix_txt", self.country_prefix_txt_var.get())
        db.set_setting("msg_url_enc_txt", str(self.url_enc_var.get()))

        # WhatsApp vars
        db.set_setting("msg_country_prefix_wa", self.country_prefix_wa_var.get())
        db.set_setting("msg_url_enc_wa", str(self.url_enc_wa_var.get()))
        db.set_setting("msg_wa_client", self.wa_client_var.get())

        # Templates
        for k, v in self.tpl_vars.items():
            db.set_setting(k, v.get())

        messagebox.showinfo("Success", "Message settings saved successfully.", parent=self)
        self.destroy()
