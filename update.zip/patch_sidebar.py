with open('bookkeeper.py', 'r', encoding='utf-8') as f:
    content = f.read()

start_marker = '        row_link("Alt+E:", "Expense")'
end_marker = '        sep()'

start_idx = content.find(start_marker)
end_idx = content.find(end_marker)

if start_idx == -1 or end_idx == -1:
    print("Markers not found!")
    exit(1)

new_code = '''        def create_dropdown_link(key, label, create_cmd, view_cmd):
            state = {"expanded": False, "sub_frame": None}

            outer = tk.Frame(inner, bg=BG)
            outer.pack(fill="x")
            tk.Frame(outer, bg="#bbb", height=1).pack(fill="x")
            row = tk.Frame(outer, bg=BG)
            row.pack(fill="x", padx=3, pady=2)
            lbl = tk.Label(row, text=f"{key} {label}", bg=BG, fg="#003399",
                           font=("Tahoma", 8, "bold"), anchor="w", cursor="hand2")
            lbl.pack(side="left", fill="x", expand=True)
            arrow = tk.Label(row, text="?", bg=BG, fg="#555", font=("Tahoma", 8))
            arrow.pack(side="right")

            def toggle(e=None):
                if state["sub_frame"] and state["sub_frame"].winfo_exists():
                    state["sub_frame"].destroy()
                    state["sub_frame"] = None
                    arrow.config(text="?")
                else:
                    sub = tk.Frame(inner, bg="#e8eef8", relief="flat", bd=0)
                    sub.pack(fill="x", after=outer)
                    state["sub_frame"] = sub
                    arrow.config(text="?")

                    def make_sub_row(sub_label, cmd):
                        sr = tk.Frame(sub, bg="#e8eef8")
                        sr.pack(fill="x")
                        tk.Frame(sr, bg="#ccd", height=1).pack(fill="x")
                        r2 = tk.Frame(sr, bg="#e8eef8")
                        r2.pack(fill="x", padx=6, pady=3)
                        lbl2 = tk.Label(r2, text=sub_label, bg="#e8eef8", fg="#003399",
                                        font=("Tahoma", 8), anchor="w", cursor="hand2")
                        lbl2.pack(side="left", fill="x", expand=True)
                        for w2 in (sr, r2, lbl2):
                            w2.bind("<Button-1>", lambda ev, c=cmd: c())
                            w2.bind("<Enter>", lambda ev, x=sr: x.config(bg="#aabbdd"))
                            w2.bind("<Leave>", lambda ev, x=sr: x.config(bg="#e8eef8"))

                    make_sub_row("Create", create_cmd)
                    make_sub_row("View",   view_cmd)

            for w in (outer, row, lbl, arrow):
                w.bind("<Button-1>", toggle)
                w.bind("<Enter>", lambda e, x=outer: x.config(bg="#b8c0d0"))
                w.bind("<Leave>", lambda e, x=outer: x.config(bg=BG))

        def coming_soon():
            messagebox.showinfo("Coming Soon", "This feature is coming soon!", parent=self)

        create_dropdown_link("Alt+E:", "Expense", coming_soon, coming_soon)
        create_dropdown_link("Alt+I:", "Income", coming_soon, coming_soon)
        create_dropdown_link("F4:", "Contra", coming_soon, coming_soon)
        create_dropdown_link("F5:", "Payment To Supplier", coming_soon, coming_soon)
        create_dropdown_link("F6:", "Receipt From Customer", coming_soon, coming_soon)
        create_dropdown_link("F7:", "Journal", coming_soon, coming_soon)
        create_dropdown_link("F8:", "Sale/Invoice/Bill", self._open_create_voucher, self.show_invoices)
        create_dropdown_link("F9:", "Purchase", coming_soon, coming_soon)
        create_dropdown_link("Alt+F4:", "Purchase Order", coming_soon, coming_soon)
        create_dropdown_link("Alt+F5:", "Estimate", coming_soon, coming_soon)
        create_dropdown_link("Alt+F8:", "Credit Note/Sales Return", coming_soon, coming_soon)
        create_dropdown_link("Alt+F9:", "Debit Note/Purchase Return", coming_soon, coming_soon)
'''

content = content[:start_idx] + new_code + content[end_idx:]

with open('bookkeeper.py', 'w', encoding='utf-8') as f:
    f.write(content)

print("Patch applied successfully.")
