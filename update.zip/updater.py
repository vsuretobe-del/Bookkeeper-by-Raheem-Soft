import os
import sys
import time
import urllib.request
import zipfile
import shutil
from tkinter import Tk, messagebox

# Replace this with the RAW GitHub URL of the update.zip
# For example: "https://raw.githubusercontent.com/USERNAME/REPO_NAME/main/update.zip"
GITHUB_ZIP_URL = "https://raw.githubusercontent.com/vsuretobe-del/Bookkeeper-by-Raheem-Soft/main/update.zip"

def main():
    root = Tk()
    root.withdraw()
    
    if "YOUR_GITHUB_USERNAME" in GITHUB_ZIP_URL:
        messagebox.showerror("Updater Error", "Developer has not configured the GitHub URL yet.")
        return

    messagebox.showinfo("Updating", "Downloading latest update... Please wait.", parent=root)
    
    zip_path = "update.zip"
    extract_folder = "update_extracted"
    
    try:
        # Download the zip
        urllib.request.urlretrieve(GITHUB_ZIP_URL, zip_path)
        
        # Extract the zip
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(extract_folder)
            
        # The zip created by ReleaseManager.py extracts directly into the folder without a repo root
        # Copy all files from extract_folder to current directory
        for root_dir, dirs, files in os.walk(extract_folder):
            rel_path = os.path.relpath(root_dir, extract_folder)
            target_dir = os.path.join(os.getcwd(), rel_path if rel_path != "." else "")
            
            if not os.path.exists(target_dir):
                os.makedirs(target_dir)
                
            for file in files:
                if file not in ["updater.py", "bookkeeper.db", "company.db", "bk.db"]: # Protect DBs and updater
                    s = os.path.join(root_dir, file)
                    d = os.path.join(target_dir, file)
                    
                    copied = False
                    for i in range(10):
                        try:
                            shutil.copy2(s, d)
                            copied = True
                            break
                        except PermissionError:
                            time.sleep(1)
                    
                    if not copied:
                        raise Exception(f"File {file} is locked by another program. Please close any running instances of Book Keeper completely and try again.")
                        
        messagebox.showinfo("Success", "Update completed successfully! Restarting software...", parent=root)
    except Exception as e:
        messagebox.showerror("Update Failed", f"An error occurred during update:\n{e}", parent=root)
    finally:
        # Cleanup
        if os.path.exists(zip_path):
            os.remove(zip_path)
        if os.path.exists(extract_folder):
            shutil.rmtree(extract_folder)
            
        # Restart bookkeeper
        os.startfile("bookkeeper.py")

if __name__ == "__main__":
    # Wait for the main app to close completely
    time.sleep(2)
    main()
