with open('bookkeeper.py', 'r', encoding='utf-8') as f:
    content = f.read()

# 1. show_invoices signature
t1 = '''    def show_invoices(self):
        win = tk.Toplevel(self)
        win.title("Accounts/Transactions - View Sales Invoice")'''
r1 = '''    def show_invoices(self, v_type="sale"):
        win = tk.Toplevel(self)
        win.title("Accounts/Transactions - View Purchase" if v_type == "purchase" else "Accounts/Transactions - View Sales Invoice")'''
content = content.replace(t1, r1)

# 2. Context Menu
t2 = '''        # Right Click Context Menu
        ctx_menu = tk.Menu(win, tearoff=0, font=("Segoe UI", 9))
        ctx_menu.add_command(label="Edit")
        ctx_menu.add_command(label="Delete", accelerator="Alt+D")
        ctx_menu.add_command(label="Cancel", accelerator="Alt+X")
        ctx_menu.add_separator()
        ctx_menu.add_command(label="Create Credit Note")
        ctx_menu.add_command(label="Create Duplicate", accelerator="Alt+2")
        
        rec_menu = tk.Menu(ctx_menu, tearoff=0, font=("Segoe UI", 9))
        rec_menu.add_command(label="Monthly")
        rec_menu.add_command(label="Yearly")
        ctx_menu.add_cascade(label="Make Recurring", menu=rec_menu)
        
        ctx_menu.add_separator()
        ctx_menu.add_command(label="e-Way Bill")
        ctx_menu.add_command(label="View Delivery Note")
        ctx_menu.add_command(label="View Invoice")'''

r2 = '''        # Right Click Context Menu
        ctx_menu = tk.Menu(win, tearoff=0, font=("Segoe UI", 9))
        ctx_menu.add_command(label="Edit")
        ctx_menu.add_command(label="Delete", accelerator="Alt+D")
        ctx_menu.add_command(label="Cancel", accelerator="Alt+X")
        ctx_menu.add_separator()
        
        if v_type == "purchase":
            ctx_menu.add_command(label="Payment to Supplier")
            ctx_menu.add_command(label="Create Debit Note")
            ctx_menu.add_command(label="Create Duplicate", accelerator="Alt+2")
            ctx_menu.add_command(label="Convert Purchase to Sale")
            
            rec_menu = tk.Menu(ctx_menu, tearoff=0, font=("Segoe UI", 9))
            rec_menu.add_command(label="Monthly")
            rec_menu.add_command(label="Yearly")
            ctx_menu.add_cascade(label="Make Recurring", menu=rec_menu)
            
            ctx_menu.add_separator()
            ctx_menu.add_command(label="Mark Paid")
            ctx_menu.add_command(label="View Purchase", command=lambda: invoice_preview.show_invoice_preview(self, v_type="purchase"))
        else:
            ctx_menu.add_command(label="Create Credit Note")
            ctx_menu.add_command(label="Create Duplicate", accelerator="Alt+2")
            
            rec_menu = tk.Menu(ctx_menu, tearoff=0, font=("Segoe UI", 9))
            rec_menu.add_command(label="Monthly")
            rec_menu.add_command(label="Yearly")
            ctx_menu.add_cascade(label="Make Recurring", menu=rec_menu)
            
            ctx_menu.add_separator()
            ctx_menu.add_command(label="e-Way Bill")
            ctx_menu.add_command(label="View Delivery Note")
            ctx_menu.add_command(label="View Invoice", command=lambda: invoice_preview.show_invoice_preview(self, v_type="sale"))'''
content = content.replace(t2, r2)

with open('bookkeeper.py', 'w', encoding='utf-8') as f:
    f.write(content)

with open('invoice_preview.py', 'r', encoding='utf-8') as f:
    inv = f.read()

t_inv = '''def show_invoice_preview(parent):'''
r_inv = '''def show_invoice_preview(parent, v_type="sale"):'''
inv = inv.replace(t_inv, r_inv)

t_inv2 = '''    # --- Top Header ---
    header_fr = tk.Frame(container, bg="white")
    header_fr.pack(fill="x", pady=(0, 20))

    tk.Label(header_fr, text="SALES INVOICE", font=("Arial", 16, "bold"), fg="#333", bg="white").pack(side="right", anchor="n")'''
r_inv2 = '''    # --- Top Header ---
    header_fr = tk.Frame(container, bg="white")
    header_fr.pack(fill="x", pady=(0, 20))

    title_text = "PURCHASE" if v_type == "purchase" else "SALES INVOICE"
    tk.Label(header_fr, text=title_text, font=("Arial", 16, "bold"), fg="#333", bg="white").pack(side="right", anchor="n")'''
inv = inv.replace(t_inv2, r_inv2)

t_inv3 = '''    tk.Label(bill_to_fr, text="Bill To:", font=("Arial", 10, "bold"), bg="white").pack(anchor="w")'''
r_inv3 = '''    tk.Label(bill_to_fr, text="Bill From:" if v_type == "purchase" else "Bill To:", font=("Arial", 10, "bold"), bg="white").pack(anchor="w")'''
inv = inv.replace(t_inv3, r_inv3)

t_inv4 = '''    tk.Label(details_fr, text="Invoice No", font=("Arial", 9, "bold"), bg="white", width=12, anchor="w").grid(row=0, column=0, sticky="w", pady=2)'''
r_inv4 = '''    tk.Label(details_fr, text="Purchase No" if v_type == "purchase" else "Invoice No", font=("Arial", 9, "bold"), bg="white", width=12, anchor="w").grid(row=0, column=0, sticky="w", pady=2)'''
inv = inv.replace(t_inv4, r_inv4)

t_inv5 = '''    tk.Label(details_fr, text="Supplier Invoice No", font=("Arial", 9, "bold"), bg="white", width=15, anchor="w").grid(row=2, column=0, sticky="w", pady=2)'''
r_inv5 = '''    if v_type == "purchase":
        tk.Label(details_fr, text="Supplier Invoice No", font=("Arial", 9, "bold"), bg="white", width=15, anchor="w").grid(row=2, column=0, sticky="w", pady=2)
        tk.Label(details_fr, text=" ", font=("Arial", 9), bg="white").grid(row=2, column=1, sticky="w")'''
inv = inv.replace(t_inv5, r_inv5)

with open('invoice_preview.py', 'w', encoding='utf-8') as f:
    f.write(inv)

print("Phase 3 Patch Applied!")
