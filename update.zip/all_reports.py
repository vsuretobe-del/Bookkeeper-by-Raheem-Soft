import tkinter as tk
from tkinter import ttk, messagebox
from autocomplete import AutocompleteCombobox

BG = "#e1e4dc"  # A greenish gray similar to the image
WHITE = "#ffffff"
RED = "#b20000"
FONT = ("Segoe UI", 10)
FONT_BOLD = ("Segoe UI", 10, "bold")
FONT_TITLE = ("Segoe UI", 14, "bold")

class AllReportsView(tk.Frame):
    def __init__(self, master, app_ref):
        super().__init__(master, bg=BG)
        self.app_ref = app_ref
        
        self.pack(fill="both", expand=True)
        self.setup_ui()
        
    def setup_ui(self):
        # 1. Top Bar (Exit Button)
        top_bar = tk.Frame(self, bg=WHITE)
        top_bar.pack(fill="x")
        
        btn_exit = tk.Button(top_bar, text="✖ Ctrl+Q: Exit", font=("Segoe UI", 9, "bold"), 
                             bg=WHITE, fg="black", relief="flat", cursor="hand2",
                             command=self.app_ref.show_dashboard)
        btn_exit.pack(side="left", padx=5, pady=2)
        
        # Main content container to center everything slightly or add padding
        content_fr = tk.Frame(self, bg=BG)
        content_fr.pack(fill="both", expand=True, padx=20, pady=10)
        
        # 2. Header
        tk.Label(content_fr, text="Reports", font=("Segoe UI", 16, "bold"), bg=BG, fg="black").pack()
        tk.Label(content_fr, text="You can change the Reporting Period from TOP RIGHT corner.", 
                 font=("Segoe UI", 10, "bold", "italic"), bg=BG, fg=RED).pack(pady=(5, 15))
        
        # 3. Search Bar
        search_fr = tk.Frame(content_fr, bg=BG)
        search_fr.pack(fill="x", pady=(0, 20))
        
        search_inner = tk.Frame(search_fr, bg=BG)
        search_inner.pack(anchor="center")
        
        tk.Label(search_inner, text="F3: Search:", font=FONT, bg=BG).grid(row=0, column=0, padx=5)
        
        self.cb_search = AutocompleteCombobox(search_inner, font=FONT, width=40, state="readonly")
        self.cb_search['values'] = [
            "Trial Balance", "Ledger", "Aged Payable", "Aged Receivable",
            "Customer Supplier List", "Outstanding Payable", "Outstanding Receivable",
            "Inventory Item Details", "Service Details", "Inventory Summary",
            "Day Book", "Post Dated", "Cash Flow Statement", "Purchase Register",
            "Sales Register", "Monthly Breakdown", "Best Customer", "Top Supplier"
        ]
        self.cb_search.set(self.cb_search['values'][0])
        self.cb_search.grid(row=0, column=1, padx=5)
        
        def on_search_display():
            v = self.cb_search.get()
            if v == "Trial Balance": self.app_ref.show_trial_balance()
            elif v == "Ledger": self.app_ref.show_ledger()
            elif v == "Aged Payable": self.app_ref.show_aged_payable()
            elif v == "Aged Receivable": self.app_ref.show_aged_receivable()
            elif v == "Inventory Summary": self.app_ref.show_inventory_summary()
            elif v == "Day Book": self.app_ref.show_daybook()
            elif v == "Post Dated": self.app_ref.show_post_dated_vouchers()
            elif v == "Cash Flow Statement": self.app_ref.show_cash_flow()
            elif v == "Sales Register": self.app_ref.show_sales_register()
            elif v == "Purchase Register": self.app_ref.show_purchase_register()
            elif v == "Monthly Breakdown": self.app_ref.show_monthly_breakdown()
            elif v == "Best Customer": self.app_ref.show_best_customer()
            elif v == "Top Supplier": self.app_ref.show_top_supplier()
            else: self.not_implemented()

        btn_display = tk.Button(search_inner, text="Display Report", font=FONT, bg="#f0f0f0", 
                                relief="raised", command=on_search_display, width=30)
        btn_display.grid(row=1, column=1, pady=10)
        
        # Helper to create sections
        def create_section(parent, title):
            fr = tk.Frame(parent, bg=BG)
            fr.pack(fill="x", pady=(10, 0))
            tk.Label(fr, text=title, font=FONT_BOLD, bg=BG).pack(anchor="w", pady=(0, 5))
            grid_fr = tk.Frame(fr, bg=BG)
            grid_fr.pack(fill="x")
            return grid_fr
            
        def create_btn(parent, text, row, col, rowspan=1, colspan=1):
            btn = tk.Button(parent, text=text, font=FONT, bg="#f0f0f0", relief="raised", 
                            command=self.not_implemented, wraplength=100)
            btn.grid(row=row, column=col, rowspan=rowspan, columnspan=colspan, sticky="nsew", padx=2, pady=2)
            return btn

        # 4. Accounting Reports
        acc_fr = create_section(content_fr, "Accounting Reports")
        for i in range(4): acc_fr.columnconfigure(i, weight=1, uniform="acc")
        for i in range(2): acc_fr.rowconfigure(i, weight=1, minsize=40)
        
        btn_ledger = create_btn(acc_fr, "Ledger", 0, 0, rowspan=2)
        btn_ledger.config(command=self.app_ref.show_ledger)
        
        btn_aged_pay = create_btn(acc_fr, "Aged Payable", 0, 1)
        btn_aged_pay.config(command=self.app_ref.show_aged_payable)
        
        btn_aged_rec = create_btn(acc_fr, "Aged Receivable", 1, 1)
        btn_aged_rec.config(command=self.app_ref.show_aged_receivable)
        
        btn_cust_supp = create_btn(acc_fr, "Customer\nSupplier\nList", 0, 2, rowspan=2)
        btn_cust_supp.config(command=self.app_ref.show_customer_supplier_list)
        
        btn_out_pay = create_btn(acc_fr, "Outstanding\nPayable", 0, 3)
        btn_out_pay.config(command=self.app_ref.show_outstanding_payable)
        
        btn_out_rec = create_btn(acc_fr, "Outstanding\nReceivable", 1, 3)
        btn_out_rec.config(command=self.app_ref.show_outstanding_receivable)
        
        # 5. Inventory Reports
        inv_fr = create_section(content_fr, "Inventory Reports")
        for i in range(2): inv_fr.columnconfigure(i, weight=1, uniform="inv")
        for i in range(2): inv_fr.rowconfigure(i, weight=1, minsize=40)
        
        btn_inv_det = create_btn(inv_fr, "Inventory Item Details", 0, 0)
        btn_inv_det.config(command=self.app_ref.show_inventory_item_details)
        create_btn(inv_fr, "Service Details", 0, 1)
        btn_inv_sum = create_btn(inv_fr, "Inventory Summary", 1, 0, colspan=2)
        btn_inv_sum.config(command=self.app_ref.show_inventory_summary)
        
        # 6. Summary Reports
        sum_fr = create_section(content_fr, "Summary Reports")
        for i in range(5): sum_fr.columnconfigure(i, weight=1, uniform="sum")
        for i in range(2): sum_fr.rowconfigure(i, weight=1, minsize=40)
        
        btn_daybook = create_btn(sum_fr, "Day Book", 0, 0)
        btn_daybook.config(command=self.app_ref.show_daybook)
        
        btn_post_dated = create_btn(sum_fr, "Post\nDated", 1, 0)
        btn_post_dated.config(command=self.app_ref.show_post_dated_vouchers)
        btn_cash_flow = create_btn(sum_fr, "Cash Flow\nStatement", 0, 1, rowspan=2)
        btn_cash_flow.config(command=self.app_ref.show_cash_flow)
        btn_purchase = create_btn(sum_fr, "Purchase\nRegister", 0, 2)
        btn_purchase.config(command=self.app_ref.show_purchase_register)
        btn_sales = create_btn(sum_fr, "Sales\nRegister", 1, 2)
        btn_sales.config(command=self.app_ref.show_sales_register)
        btn_monthly = create_btn(sum_fr, "Monthly\nBreakdown", 0, 3, rowspan=2)
        btn_monthly.config(command=self.app_ref.show_monthly_breakdown)
        btn_best_cust = create_btn(sum_fr, "Best\nCustomer", 0, 4)
        btn_best_cust.config(command=self.app_ref.show_best_customer)
        btn_top_supp = create_btn(sum_fr, "Top\nSupplier", 1, 4)
        btn_top_supp.config(command=self.app_ref.show_top_supplier)

    def not_implemented(self):
        messagebox.showinfo("Coming Soon", "This report is currently under development.")
