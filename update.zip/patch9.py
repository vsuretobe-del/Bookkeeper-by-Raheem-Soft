import re

with open('bookkeeper.py', 'r', encoding='utf-8') as f:
    content = f.read()

new_func = '''    def _unit_form(self, parent_win=None):
        win = tk.Toplevel(parent_win if parent_win else self)
        win.title("Create Units Of Measure")
        win.geometry("500x350")
        win.resizable(False, False)
        win.configure(bg="#ffffff")
        win.grab_set()

        tk.Label(win, text="Press ENTER to move forward  SHIFT+ENTER to move back.", 
                 fg="darkred", bg="#ffffff", font=(FONT[0], 10, "italic", "bold")).place(x=80, y=10)

        widgets = []
        def register_widget(w):
            widgets.append(w)
            w.bind("<Return>", lambda e: focus_next(w))
            w.bind("<Shift-Return>", lambda e: focus_prev(w))
            return w

        def focus_next(current):
            try:
                idx = widgets.index(current)
                widgets[(idx + 1) % len(widgets)].focus_set()
            except: pass
            return "break"

        def focus_prev(current):
            try:
                idx = widgets.index(current)
                widgets[(idx - 1) % len(widgets)].focus_set()
            except: pass
            return "break"

        tk.Label(win, text="Units Name", bg="#ffffff", fg="#000", font=FONT).place(x=70, y=50)
        u_name = tk.Entry(win, font=FONT, width=30, relief="solid", bd=1, bg="#ffff00")
        u_name.place(x=180, y=50)
        register_widget(u_name)

        tk.Label(win, text="Symbol", bg="#ffffff", fg="#000", font=FONT).place(x=70, y=85)
        u_symb = tk.Entry(win, font=FONT, width=30, relief="solid", bd=1, bg="#ffffff")
        u_symb.place(x=180, y=85)
        register_widget(u_symb)

        compound_var = tk.IntVar()
        cb = tk.Checkbutton(win, text="Is Compound Unit ?", variable=compound_var, bg="#ffffff", fg="#000", font=FONT)
        cb.place(x=180, y=130)

        def save(event=None):
            name = u_name.get().strip()
            symb = u_symb.get().strip()
            
            if not name:
                messagebox.showerror("Error", "Units Name is required!", parent=win)
                u_name.focus_set()
                return

            try:
                db.add_unit({
                    "units_name": name,
                    "symbol": symb,
                    "isSimpleUnit": 0 if compound_var.get() else 1
                })
                win.destroy()
                # If we are called from _item_form, we could theoretically update its dropdown, 
                # but for simplicity, we just destroy the window.
            except Exception as e:
                messagebox.showerror("Database Error", str(e), parent=win)

        win.bind('<Control-q>', lambda e: win.destroy())
        win.bind('<Return>', lambda e: save() if win.focus_get() not in widgets else None)
        
        bot_frame = tk.Frame(win, bg="#e0e0e0", height=45)
        bot_frame.pack(fill="x", side="bottom")
        tk.Button(bot_frame, text="Ctrl+Q: Exit", bg="#e0e0e0", font=FONT, command=win.destroy, relief="solid", bd=1).place(x=10, y=5, width=100, height=35)
        tk.Label(bot_frame, text="Video: How To Create Compound Unit Of Measure", fg="blue", bg="#e0e0e0", font=(FONT[0], 9, "underline")).place(x=130, y=12)
        tk.Button(bot_frame, text="Enter: Save", bg="#e0e0e0", font=FONT, command=save, relief="solid", bd=1).place(x=390, y=5, width=100, height=35)

        u_name.focus_set()
'''

# append right after _item_form finishes
content = content.replace("    def _edit_selected_item(self, tree):", new_func + "\n    def _edit_selected_item(self, tree):")

# Now hook up Alt+U inside _item_form
old_bind = "win.bind('<F12>', save)"
new_bind = "win.bind('<F12>', save)\n        win.bind('<Alt-u>', lambda e: self._unit_form(win))"
content = content.replace(old_bind, new_bind)

# Wait, win.bind('<F12>', save) might appear multiple times! We should replace it only in _item_form.
# Let's do a more precise replacement using regex.
