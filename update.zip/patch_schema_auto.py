import re

with open('db.py', 'r', encoding='utf-8') as f:
    text = f.read()

# Find the end of init_db()
# It ends around line 190 with conn.commit() or similar.
# Wait, let's search for the whole init_db() body.

auto_migrate_logic = '''
    # Auto-patch schema for newly added features
    try:
        c.execute("PRAGMA table_info(vouchers)")
        columns = [row[1] for row in c.fetchall()]
        if 'is_template' not in columns:
            c.execute("ALTER TABLE vouchers ADD COLUMN is_template INTEGER DEFAULT 0")
    except Exception:
        pass
        
    try:
        c.execute("PRAGMA table_info(purchases)")
        columns = [row[1] for row in c.fetchall()]
        if 'extra_costs' not in columns:
            c.execute("ALTER TABLE purchases ADD COLUMN extra_costs TEXT")
    except Exception:
        pass

    conn.commit()
    conn.close()
'''

def replace_init_db(m):
    original_code = m.group(0)
    # the original_code probably ends with conn.commit() and maybe conn.close()
    # we will inject auto_migrate_logic before conn.commit()
    if 'conn.commit()' in original_code:
        return original_code.replace('conn.commit()', auto_migrate_logic.replace('conn.commit()\n    conn.close()', 'conn.commit()'))
    return original_code

text = re.sub(r'def init_db\(\).*?conn\.commit\(\)', replace_init_db, text, flags=re.DOTALL)

with open('db.py', 'w', encoding='utf-8') as f:
    f.write(text)

print("db.py patched with auto-migration logic")
