import tkinter as tk
from tkinter import ttk, messagebox
import db
from custom_calendar import DateEntry
from datetime import datetime
from autocomplete import AutocompleteCombobox

BG_BLUE = "#2b579a"
BG_WHITE = "#ffffff"
BG_YELLOW = "#ffff00"
FONT = ("Segoe UI", 10)
FONT_BOLD = ("Segoe UI", 10, "bold")

class CustomerSupplierListView:
    def __init__(self, master, app_ref):
        self.master = tk.Toplevel(master)
        self.app_ref = app_ref
        
        self.master.title("Customer Supplier List")
        self.master.geometry("1100x700")
        self.master.configure(bg=BG_WHITE)
        self.master.grab_set()
        
        self._build_ui()
        
    def _build_ui(self):
        # 1. Top Toolbar
        top_bar = tk.Frame(self.master, bg=BG_WHITE)
        top_bar.pack(fill="x", side="top")
        
        buttons = [
            ("✖ Ctrl+Q: Exit", self.master.destroy),
            ("🖨️ Alt+P: Print", self.not_implemented),
            ("📝 Ctrl+W: Open In MS Word", self.not_implemented),
            ("📊 Ctrl+E: Open In MS Excel", self.not_implemented),
            ("📄 Ctrl+V: Open In PDF", self.not_implemented),
            ("🌐 Ctrl+H: Open In Browser", self.not_implemented)
        ]
        for text, cmd in buttons:
            btn = tk.Button(top_bar, text=text, font=("Segoe UI", 9), relief="flat", bg=BG_WHITE, cursor="hand2", command=cmd)
            btn.pack(side="left", padx=2, pady=2)
            
        tk.Frame(self.master, bg="#cccccc", height=1).pack(fill="x")
        
        # 2. Main Content
        content_fr = tk.Frame(self.master, bg=BG_WHITE)
        content_fr.pack(fill="both", expand=True)
        
        # Left Panel
        left_fr = tk.Frame(content_fr, bg=BG_BLUE, width=320)
        left_fr.pack(side="left", fill="y")
        left_fr.pack_propagate(False)
        
        # Right Panel
        self.right_fr = tk.Frame(content_fr, bg=BG_WHITE)
        self.right_fr.pack(side="left", fill="both", expand=True)
        
        # --- Left Panel Content ---
        tk.Label(left_fr, text="F2: Change Date:", bg=BG_BLUE, fg="white", font=FONT).pack(anchor="w", padx=10, pady=(10, 2))
        self.change_date = DateEntry(left_fr, date_pattern="Month DD, YYYY")
        self.change_date.pack(fill="x", padx=20, pady=5)
        
        self.list_type = tk.StringVar(value="customer")
        
        fr_radios = tk.Frame(left_fr, bg=BG_BLUE)
        fr_radios.pack(fill="x", padx=10, pady=5)
        
        rb_cust = tk.Radiobutton(fr_radios, text="Customers", variable=self.list_type, value="customer", 
                                  bg=BG_BLUE, fg="white", font=FONT, selectcolor=BG_BLUE, activebackground=BG_BLUE, activeforeground="white", command=self.on_type_change)
        rb_cust.pack(side="left")
        
        rb_supp = tk.Radiobutton(fr_radios, text="Suppliers", variable=self.list_type, value="supplier", 
                                  bg=BG_BLUE, fg="white", font=FONT, selectcolor=BG_BLUE, activebackground=BG_BLUE, activeforeground="white", command=self.on_type_change)
        rb_supp.pack(side="left", padx=10)
        
        rb_group = tk.Radiobutton(left_fr, text="Groupwise List", variable=self.list_type, value="group", 
                                  bg=BG_BLUE, fg="white", font=FONT, selectcolor=BG_BLUE, activebackground=BG_BLUE, activeforeground="white", command=self.on_type_change)
        rb_group.pack(anchor="w", padx=10)
        
        self.cb_group = AutocompleteCombobox(left_fr, font=FONT, state="disabled")
        self.cb_group.pack(fill="x", padx=20, pady=5)
        
        self.chk_vars = {}
        chk_options = [
            ("Display Zero Balance Accounts", False),
            ("Display Buyer Details (From Cash\nTransactions)", False),
            ("Email id", False),
            ("Phone Number", False),
            ("Address", False),
            ("GST No", False),
            ("Outstanding Balance", True),
            ("Display Monthly Sale", False),
            ("Tax No. 2", False),
            ("Tax No. 3", False),
            ("Credit Period/Limit", False),
            ("Remarks", False),
            ("Show Display Name", False),
            ("Display Inactive Customers", False) # or Suppliers dynamically
        ]
        
        # Create a frame for checkboxes to easily change text later
        self.chk_frame = tk.Frame(left_fr, bg=BG_BLUE)
        self.chk_frame.pack(fill="x", padx=10, pady=10)
        
        for text, default in chk_options:
            var = tk.BooleanVar(value=default)
            self.chk_vars[text] = var
            chk = tk.Checkbutton(self.chk_frame, text=text, variable=var, bg=BG_BLUE, fg="white", font=("Segoe UI", 9), 
                                 selectcolor=BG_BLUE, activebackground=BG_BLUE, activeforeground="white", justify="left")
            chk.pack(anchor="w", pady=1)
            if "Monthly Sale" in text:
                self.chk_monthly = chk
            if "Inactive Customers" in text:
                self.chk_inactive = chk
                
        btn_display = tk.Button(left_fr, text="Display", bg="#2b579a", fg="white", font=FONT, relief="raised", bd=2, command=self.display_report)
        btn_display.pack(fill="x", padx=20, pady=20)
        
        # --- Right Panel Content ---
        self.report_header = tk.Frame(self.right_fr, bg=BG_WHITE)
        self.report_header.pack(fill="x", pady=10, padx=10)
        
        self.lbl_company = tk.Label(self.report_header, text=db.get_company_name().upper() if db.get_company_name() else "ALHUMDULILLAH", 
                                    font=("Segoe UI", 16, "bold"), bg=BG_WHITE, fg="#2b579a")
        self.lbl_company.pack(anchor="w")
        
        self.lbl_title = tk.Label(self.report_header, text="", font=("Segoe UI", 14, "bold"), bg=BG_WHITE, fg="black")
        self.lbl_title.pack(anchor="w")
        
        self.tree_fr = tk.Frame(self.right_fr, bg=BG_WHITE)
        self.tree_fr.pack(fill="both", expand=True, padx=10, pady=10)
        
        self.tree = None
        self.scrollbar = None
        
        self.on_type_change()
        
    def on_type_change(self):
        val = self.list_type.get()
        if val == "group":
            self.cb_group.config(state="readonly")
        else:
            self.cb_group.config(state="disabled")
            
        if val == "supplier":
            self.chk_monthly.config(text="Display Monthly Purchase")
            self.chk_inactive.config(text="Display Inactive Supplier")
        else:
            self.chk_monthly.config(text="Display Monthly Sale")
            self.chk_inactive.config(text="Display Inactive Customers")
            
    def build_tree(self):
        if self.tree:
            self.tree.destroy()
            self.scrollbar.destroy()
            
        cols = ["name"]
        if self.chk_vars["Email id"].get(): cols.append("email")
        if self.chk_vars["Phone Number"].get(): cols.append("phone")
        if self.chk_vars["Address"].get(): cols.append("address")
        if self.chk_vars["GST No"].get(): cols.append("gst")
        if self.chk_vars["Credit Period/Limit"].get(): cols.append("credit_limit")
        if self.chk_vars["Remarks"].get(): cols.append("remarks")
        if self.chk_vars["Show Display Name"].get(): cols.append("display_name")
        if self.chk_vars["Outstanding Balance"].get(): cols.append("outstanding")
        
        self.tree = ttk.Treeview(self.tree_fr, columns=cols, show="headings", selectmode="none")
        
        self.tree.heading("name", text="NAME")
        self.tree.column("name", width=200, minwidth=200, anchor="w", stretch=False)
        
        if "email" in cols: self.tree.heading("email", text="EMAIL ID"); self.tree.column("email", width=150)
        if "phone" in cols: self.tree.heading("phone", text="PHONE NO"); self.tree.column("phone", width=120)
        if "address" in cols: self.tree.heading("address", text="ADDRESS"); self.tree.column("address", width=200)
        if "gst" in cols: self.tree.heading("gst", text="GST NO"); self.tree.column("gst", width=120)
        if "credit_limit" in cols: self.tree.heading("credit_limit", text="CREDIT LIMIT"); self.tree.column("credit_limit", width=100)
        if "remarks" in cols: self.tree.heading("remarks", text="REMARKS"); self.tree.column("remarks", width=150)
        if "display_name" in cols: self.tree.heading("display_name", text="DISPLAY NAME"); self.tree.column("display_name", width=150)
        if "outstanding" in cols: self.tree.heading("outstanding", text="OUTSTANDING AMOUNT"); self.tree.column("outstanding", width=150, minwidth=150, anchor="e", stretch=False)
        
        self.scrollbar = ttk.Scrollbar(self.tree_fr, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=self.scrollbar.set)
        self.tree.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")
        
        self.tree.tag_configure("even", background="#f9f9f9")
        self.tree.tag_configure("odd", background="#ffffff")
        self.tree.tag_configure("bold", font=("Segoe UI", 10, "bold"), background="#f0f0f0")
        self.tree.tag_configure("link", foreground="blue", font=("Segoe UI", 10, "underline"))

    def display_report(self):
        self.build_tree()
        
        dt = self.change_date.get_date()
        as_on = dt.strftime("%Y-%m-%d")
        is_customer = (self.list_type.get() != "supplier")
        
        title = "Customer/Debtor" if is_customer else "Supplier/Creditor"
        self.lbl_title.config(text=f"{title} As On {as_on}")
        
        data = db.get_customer_supplier_list(is_customer, as_on)
        
        show_zero = self.chk_vars["Display Zero Balance Accounts"].get()
        cols = self.tree["columns"]
        
        total_outstanding = 0
        count = 0
        
        for i, row in enumerate(data):
            out = row['calculated_balance']
            if not show_zero and out == 0:
                continue
                
            total_outstanding += out
            count += 1
            
            vals = []
            for col in cols:
                if col == "name": vals.append(row['aname'])
                elif col == "email": vals.append(row.get('email_id', ''))
                elif col == "phone": vals.append(row.get('phone', ''))
                elif col == "address": vals.append(row.get('address', ''))
                elif col == "gst": vals.append(row.get('tax_regn', ''))
                elif col == "credit_limit": vals.append(row.get('credit_limit', ''))
                elif col == "remarks": vals.append(row.get('remarks', ''))
                elif col == "display_name": vals.append(row.get('display_name', ''))
                elif col == "outstanding": 
                    vals.append(f"{out:,.0f}" if out > 0 else "0")
            
            tag = "even" if count % 2 == 0 else "odd"
            item = self.tree.insert("", "end", values=vals, tags=(tag))
            # Optional: if we want first column to be blue link, we could handle it via tags but ttk.Treeview tags apply to whole row.
            
        if "outstanding" in cols:
            summary = [""] * len(cols)
            summary[0] = f"TOTAL ({count})"
            summary[-1] = f"RS{total_outstanding:,.0f}"
            self.tree.insert("", "end", values=summary, tags=("bold"))
            
    def not_implemented(self):
        messagebox.showinfo("Coming Soon", "This feature is currently under development.")
