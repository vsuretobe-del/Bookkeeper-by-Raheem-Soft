import tkinter as tk
from tkinter import ttk

WHITE = "#ffffff"
LEFT_BG = "#ededed"
RIGHT_BG = "#e1e6e1"
FONT_NORMAL = ("Segoe UI", 9)
FONT_BOLD = ("Segoe UI", 11, "bold")

class TransactionsWindow(tk.Toplevel):
    def __init__(self, master):
        super().__init__(master)
        self.title("Transactions")
        self.geometry("1100x650")
        try:
            self.state("zoomed")
        except:
            pass
        self.configure(bg=WHITE)
        self.transient(master)
        self.grab_set()
        
        self.master_app = master

        self.setup_ui()
        self.bind_events()

    def setup_ui(self):
        # Main layout: Left sidebar, Center content (empty), Right sidebar
        self.left_sidebar = tk.Frame(self, bg=LEFT_BG, width=250)
        self.left_sidebar.pack(side="left", fill="y")
        self.left_sidebar.pack_propagate(False)

        self.right_sidebar = tk.Frame(self, bg=RIGHT_BG, width=250)
        self.right_sidebar.pack(side="right", fill="y")
        self.right_sidebar.pack_propagate(False)

        self.center_frame = tk.Frame(self, bg=WHITE)
        self.center_frame.pack(side="left", fill="both", expand=True)

        self.build_left_sidebar()
        self.build_right_sidebar()

    def build_left_sidebar(self):
        # Exit Button
        exit_fr = tk.Frame(self.left_sidebar, bg=LEFT_BG)
        exit_fr.pack(fill="x", pady=10, padx=10)
        
        # Black square with cross
        btn_x = tk.Label(exit_fr, text="✕", bg="black", fg="white", font=("Segoe UI", 8, "bold"), width=2)
        btn_x.pack(side="left")
        lbl_exit = tk.Label(exit_fr, text=" Ctrl+Q: Exit", bg=LEFT_BG, fg="black", font=FONT_NORMAL, cursor="hand2")
        lbl_exit.pack(side="left")
        
        def exit_win(e=None):
            self.destroy()
        
        btn_x.bind("<Button-1>", exit_win)
        lbl_exit.bind("<Button-1>", exit_win)

        # Helper to add section headers and items
        def add_header(text):
            tk.Label(self.left_sidebar, text=text, bg=LEFT_BG, fg="#555555", font=FONT_BOLD, anchor="w").pack(fill="x", padx=10, pady=(10, 2))

        def add_item(text, cmd=None):
            lbl = tk.Label(self.left_sidebar, text=text, bg=LEFT_BG, fg="#000000", font=FONT_NORMAL, anchor="w", cursor="hand2")
            lbl.pack(fill="x", padx=10, pady=1)
            lbl.bind("<Enter>", lambda e, l=lbl: l.config(fg="blue", font=("Segoe UI", 9, "underline")))
            lbl.bind("<Leave>", lambda e, l=lbl: l.config(fg="#000000", font=FONT_NORMAL))
            if cmd:
                lbl.bind("<Button-1>", lambda e, c=cmd: c())

        # Sales
        add_header("Sales")
        add_item("Estimate", lambda: self.master_app._open_create_voucher("estimate"))
        add_item("Delivery Challan", lambda: self.master_app._open_create_voucher("delivery_challan"))
        add_item("Sales/Invoice/Bill", lambda: self.master_app._open_create_voucher("sales_invoice"))
        add_item("Receipt From Customer", lambda: self.master_app._open_receipt_customer())
        add_item("Credit Note/Sales Return", lambda: self.master_app._open_create_voucher("credit_note"))

        # Purchase
        add_header("Purchase")
        add_item("Purchase Order", lambda: self.master_app._open_create_voucher("purchase_order"))
        add_item("Purchase", lambda: self.master_app._open_create_voucher("purchase"))
        add_item("Payment To Supplier", lambda: self.master_app._open_payment_supplier())
        add_item("Debit Note/Purchases Return", lambda: self.master_app._open_create_voucher("debit_note"))

        # Inventory Transaction
        add_header("Inventory Transaction")
        def show_inv_menu():
            menu = tk.Menu(self, tearoff=0, font=("Segoe UI", 10), bg="#ffffff")
            menu.add_command(label="Create", command=lambda: self.master_app._open_create_voucher("inventory_adjustment"))
            menu.add_command(label="View", command=lambda: self.master_app.show_invoices("inventory_adjustment"))
            x = self.winfo_pointerx()
            y = self.winfo_pointery()
            menu.post(x, y)
        add_item("Inventory Adjustment", show_inv_menu)

        # Expenses/Income
        add_header("Expenses/Income")
        add_item("Expense", lambda: self.master_app._open_expense_voucher())
        add_item("Income", lambda: self.master_app._open_income_voucher())

        # Banking
        add_header("Banking")
        add_item("Withdraw Cash", lambda: self.master_app._open_contra_voucher(default_to="Cash-in-hand", default_from="Bank A/Cs"))
        add_item("Deposit Cash", lambda: self.master_app._open_contra_voucher(default_to="Bank A/Cs", default_from="Cash-in-hand"))
        add_item("Transfer Money", lambda: self.master_app._open_contra_voucher())
        add_item("View All", lambda: self.master_app.show_invoices("contra"))

        # Miscellaneous
        add_header("Miscellaneous")
        add_item("Journal", lambda: self.master_app._open_journal_voucher())
        add_item("View All Transactions", lambda: self.master_app.show_invoices("all"))
        add_item("View All Recurring Transactions")

    def build_right_sidebar(self):
        def add_shortcut(text, cmd=None):
            lbl = tk.Label(self.right_sidebar, text=text, bg=RIGHT_BG, fg="#000000", font=FONT_NORMAL, anchor="w")
            lbl.pack(fill="x", padx=10, pady=4)
            if cmd:
                lbl.config(cursor="hand2")
                lbl.bind("<Enter>", lambda e, l=lbl: l.config(fg="blue", font=("Segoe UI", 9, "underline")))
                lbl.bind("<Leave>", lambda e, l=lbl: l.config(fg="#000000", font=FONT_NORMAL))
                lbl.bind("<Button-1>", lambda e, c=cmd: c())
            
        def add_separator():
            tk.Frame(self.right_sidebar, bg="#cccccc", height=1).pack(fill="x", padx=5, pady=2)

        # Padding at top
        tk.Frame(self.right_sidebar, bg=RIGHT_BG, height=20).pack(fill="x")

        # Group 1
        add_shortcut("Alt+E: Expense", lambda: self.master_app._open_expense_voucher())
        add_shortcut("Alt+I: Income", lambda: self.master_app._open_income_voucher())
        add_separator()

        # Group 2
        add_shortcut("F4: Contra", lambda: self.master_app._open_contra_voucher())
        add_shortcut("F5: Payment To Supplier", lambda: self.master_app._open_payment_supplier())
        add_shortcut("F6: Receipt From Customer", lambda: self.master_app._open_receipt_customer())
        add_shortcut("F7: Journal", lambda: self.master_app._open_journal_voucher())
        add_shortcut("F8: Sale/Invoice/Bill", lambda: self.master_app._open_create_voucher("sales_invoice"))
        add_shortcut("F9: Purchase", lambda: self.master_app._open_create_voucher("purchase"))
        add_separator()

        # Group 3
        add_shortcut("Alt+F4: Purchase Order", lambda: self.master_app._open_create_voucher("purchase_order"))
        add_shortcut("Alt+F5: Estimate", lambda: self.master_app._open_create_voucher("estimate"))
        add_shortcut("Alt+F7: Manufacturing Journal")
        add_shortcut("Alt+F8: Credit Note/Sales Return", lambda: self.master_app._open_create_voucher("credit_note"))
        add_shortcut("Alt+F9: Debit Note/Purchase Return", lambda: self.master_app._open_create_voucher("debit_note"))
        add_separator()

        # Group 4
        add_shortcut("Alt+R: View All Recurring Transactions")
        add_shortcut("Alt+T: View All Transactions", lambda: self.master_app.show_invoices("all"))
        add_separator()

        # Group 5
        def open_calc():
            import subprocess
            try:
                subprocess.Popen("calc")
            except:
                pass
        add_shortcut("Ctrl+N: Calculator", open_calc)

    def bind_events(self):
        self.bind("<Control-q>", lambda e: self.destroy())
        self.bind("<Control-Q>", lambda e: self.destroy())
