with open('bookkeeper.py', 'r', encoding='utf-8') as f:
    lines = f.readlines()

new_lines = []
for line in lines:
    if "tk.Entry(ref_box, bg=WHITE, width=28, relief=\"solid\", bd=1).pack(padx=4, pady=2)" in line: continue
    new_lines.append(line)

with open('bookkeeper.py', 'w', encoding='utf-8') as f:
    f.writelines(new_lines)
print("Removed ref_box usage")
