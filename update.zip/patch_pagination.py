with open('bookkeeper.py', 'r', encoding='utf-8') as f:
    lines = f.readlines()

import re

for i, line in enumerate(lines):
    if line.strip().startswith('def prev_page(*args):'):
        # Fix prev_page
        if lines[i+1].strip() == 'current_page[0] -= 1':
            lines[i+1] = '            if current_page[0] > 1:\n                current_page[0] -= 1\n'

for i, line in enumerate(lines):
    if line.strip().startswith('def apply_search(*args):'):
        # Replace the end of apply_search
        for j in range(i, i+100):
            if lines[j].strip() == 'r.pack(fill="x")':
                # Re-write the rest of apply_search
                lines[j] = '                    matched_rows.append(r)\n'
            elif lines[j].strip() == 'r.pack_forget()':
                pass
            elif lines[j].strip() == 'search_var.trace_add("write", apply_search)':
                # Found the end of apply_search
                new_logic = '''
            items_per_page = 20
            total_pages = max(1, (len(matched_rows) + items_per_page - 1) // items_per_page)
            if current_page[0] > total_pages:
                current_page[0] = total_pages
            if current_page[0] < 1:
                current_page[0] = 1
                
            start_idx = (current_page[0] - 1) * items_per_page
            end_idx = start_idx + items_per_page
            
            for k, r in enumerate(matched_rows):
                if start_idx <= k < end_idx:
                    r.pack(fill="x")
                else:
                    r.pack_forget()
                    
            page_lbl.config(text=f"Displaying page: {current_page[0]} of {total_pages}")
'''
                lines.insert(j, new_logic)
                break
        break

with open('bookkeeper.py', 'w', encoding='utf-8') as f:
    f.writelines(lines)
