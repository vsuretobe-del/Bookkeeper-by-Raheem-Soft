import re

with open('bookkeeper.py', 'r', encoding='utf-8') as f:
    text = f.read()

# 1. Modify col_defs dynamically
old_cols = '''        col_defs = [
            ("Item",         22), ("QTY", 6), ("Units", 7),
            ("Rate",          9), ("Per", 5), ("Discount(%)", 9),
            ("Tax",           7), ("Value", 10), ("Description", 14),
        ]
        COL_WIDTHS = [d[1] for d in col_defs]
        COL_WEIGHTS = [5, 1, 1, 2, 1, 2, 1, 2, 3]'''

new_cols = '''        col_defs = [
            ("Item",         22), ("QTY", 6), ("Units", 7),
            ("Rate",          9), ("Per", 5), ("Discount(%)", 9),
            ("Tax",           7), ("Value", 10), ("Description", 14),
        ]
        COL_WEIGHTS = [5, 1, 1, 2, 1, 2, 1, 2, 3]
        if v_type in ["purchase", "purchase_order"]:
            col_defs.append(("+Costs", 8))
            COL_WEIGHTS.append(1)
            col_defs.append(("S.Price", 8))
            COL_WEIGHTS.append(2)
        COL_WIDTHS = [d[1] for d in col_defs]'''

text = text.replace(old_cols, new_cols)

# 1.5 Fix hardcoded range(9)
text = text.replace('for j in range(9):', 'for j in range(len(col_defs)):')

# 2. Modify add_grid_row signature and row_dict
def replace_add_grid_row(m):
    return 'def add_grid_row(item_name="", qty="1", unit="Nos", rate="0", per="", disc="0", tax="0", extra_costs="[]", sp="0"):'
text = re.sub(r'def add_grid_row\(item_name="", qty="1", unit="Nos",\s*rate="0", per="", disc="0", tax="0"\):', replace_add_grid_row, text, flags=re.DOTALL)

old_row_dict = '''            row_dict = {
                "item_v": item_v, "qty_v": qty_v, "unit_v": unit_v,
                "rate_v": rate_v, "per_v": per_v, "disc_v": disc_v,
                "tax_v": tax_v, "value_v": value_v, "desc_v": desc_v,
                "item_w": item_cb, "qty_w": qty_e, "unit_w": unit_cb,
                "rate_w": rate_e, "per_w": per_cb, "disc_w": disc_e, "tax_w": tax_cb, "desc_w": desc_e
            }'''
new_row_dict = '''            row_dict = {
                "item_v": item_v, "qty_v": qty_v, "unit_v": unit_v,
                "rate_v": rate_v, "per_v": per_v, "disc_v": disc_v,
                "tax_v": tax_v, "value_v": value_v, "desc_v": desc_v,
                "item_w": item_cb, "qty_w": qty_e, "unit_w": unit_cb,
                "rate_w": rate_e, "per_w": per_cb, "disc_w": disc_e, "tax_w": tax_cb, "desc_w": desc_e
            }
            if v_type in ["purchase", "purchase_order"]:
                row_dict["extra_costs_v"] = extra_costs_var
                row_dict["sp_v"] = sp_var'''
text = text.replace(old_row_dict, new_row_dict)

old_vars = '''            tax_v   = tk.StringVar(value=tax)
            value_v = tk.StringVar(value="0.00")
            desc_v  = tk.StringVar()'''
new_vars = '''            tax_v   = tk.StringVar(value=tax)
            value_v = tk.StringVar(value="0.00")
            desc_v  = tk.StringVar()
            extra_costs_var = tk.StringVar(value=extra_costs)
            sp_var = tk.StringVar(value=sp)'''
text = text.replace(old_vars, new_vars)

old_grid = '''            desc_e.grid(row=ri, column=8, sticky="nsew", padx=(0, 1), pady=(0, 1))'''
new_grid = '''            desc_e.grid(row=ri, column=8, sticky="nsew", padx=(0, 1), pady=(0, 1))

            def open_costs_popup():
                import json
                popup = tk.Toplevel(win)
                popup.title("Extra Costs")
                popup.geometry("350x400")
                popup.grab_set()
                tk.Label(popup, text="Enter extra costs (per unit):", font=FONT_BOLD).pack(pady=5)
                
                f = tk.Frame(popup)
                f.pack(fill="both", expand=True, padx=10, pady=5)
                
                rows = []
                try:
                    existing = json.loads(extra_costs_var.get())
                except:
                    existing = []
                
                def add_row(name="", amt="0"):
                    fr = tk.Frame(f)
                    fr.pack(fill="x", pady=2)
                    n_v = tk.StringVar(value=name)
                    a_v = tk.StringVar(value=amt)
                    tk.Entry(fr, textvariable=n_v, width=20).pack(side="left", padx=2)
                    tk.Entry(fr, textvariable=a_v, width=10).pack(side="left", padx=2)
                    rows.append((n_v, a_v))
                
                for ex in existing:
                    add_row(ex.get("name", ""), str(ex.get("amount", 0)))
                if not rows:
                    add_row("Glass Cost", "0")
                    add_row("Rubber Cost", "0")
                    add_row("Supplier Cost", "0")
                
                tk.Button(popup, text="+ Add Cost", command=add_row).pack(pady=5)
                
                def save_costs():
                    data = []
                    for n, a in rows:
                        if n.get().strip():
                            data.append({"name": n.get().strip(), "amount": float(a.get() or 0)})
                    extra_costs_var.set(json.dumps(data))
                    recalc()
                    popup.destroy()
                
                tk.Button(popup, text="Save", command=save_costs, bg="#4CAF50", fg="white").pack(pady=10)

            if v_type in ["purchase", "purchase_order"]:
                tk.Button(grid_inner, text="Costs", command=open_costs_popup, font=FONT).grid(row=ri, column=9, sticky="nsew", padx=(0, 1), pady=(0, 1))
                tk.Entry(grid_inner, textvariable=sp_var, font=FONT, justify="right").grid(row=ri, column=10, sticky="nsew", padx=(0, 1), pady=(0, 1))
'''
text = text.replace(old_grid, new_grid)

# 4. Modify recalc to add extra costs
def modify_recalc(m):
    orig = m.group(0)
    old = 'r_ = safe_num(rate_v.get())'
    new = '''r_ = safe_num(rate_v.get())
                    import json
                    try:
                        ex_costs = sum(float(c.get("amount", 0)) for c in json.loads(extra_costs_var.get()))
                        r_ += ex_costs
                    except:
                        pass'''
    return orig.replace(old, new)
text = re.sub(r'def recalc\(e=None\):.*?(?:recalc_total\(\)|except Exception)', modify_recalc, text, flags=re.DOTALL)

with open('bookkeeper.py', 'w', encoding='utf-8') as f:
    f.write(text)
print("Patch for Purchase Items Costs generated successfully!")
