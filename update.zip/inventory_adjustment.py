import tkinter as tk
from tkinter import ttk, messagebox
import db
from datetime import datetime

WHITE = "#ffffff"
BG = "#f2f2f2"
BLUE_DARK = "#005a9e"
RED = "darkred"
FONT = ("Segoe UI", 10)
FONT_BOLD = ("Segoe UI", 10, "bold")

class InventoryAdjustmentWindow(tk.Toplevel):
    def __init__(self, master):
        super().__init__(master)
        self.title("Stock Journal")
        self.geometry("1000x600")
        self.update_idletasks()
        w = self.winfo_width()
        h = self.winfo_height()
        x = (self.winfo_screenwidth() // 2) - (w // 2)
        y = max(0, (self.winfo_screenheight() // 2) - (h // 2) - 50)
        self.geometry(f"{w}x{h}+{x}+{y}")
        self.configure(bg=WHITE)
        self.transient(master)
        self.grab_set()
        self.focus_force()

        self.master_app = master
        
        self.items = db.get_all_items()
        self.item_names = [item['name'] for item in self.items]
        
        self.setup_ui()
        self.bind_events()

    def setup_ui(self):
        # Top Section
        top_frame = tk.Frame(self, bg=WHITE)
        top_frame.pack(fill="x", padx=10, pady=10)

        # Left of top section
        top_left = tk.Frame(top_frame, bg=WHITE)
        top_left.pack(side="left", fill="y")

        tk.Label(top_left, text="Press ENTER to move forward  SHIFT+ENTER to move", bg=WHITE, fg=RED, font=("Segoe UI", 10, "bold italic")).grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 5))
        
        tk.Label(top_left, text="Voucher No", bg=WHITE, font=FONT).grid(row=1, column=0, sticky="w", padx=(0, 10))
        self.txt_voucher_no = tk.Entry(top_left, font=FONT, bg="yellow", width=35)
        self.txt_voucher_no.grid(row=1, column=1, sticky="w", pady=2)
        # Generate dummy voucher no for now
        self.txt_voucher_no.insert(0, f"ADJ{datetime.now().strftime('%M%S')}")

        tk.Label(top_left, text="Voucher Date", bg=WHITE, font=FONT).grid(row=2, column=0, sticky="w", padx=(0, 10))
        
        try:
            from tkcalendar import DateEntry
            self.txt_date = DateEntry(top_left, width=32, background='darkblue',
                                      foreground='white', borderwidth=2)
        except ImportError:
            self.txt_date = tk.Entry(top_left, font=FONT, width=35)
            self.txt_date.insert(0, datetime.now().strftime('%B %d, %Y'))
            
        self.txt_date.grid(row=2, column=1, sticky="w", pady=2)

        # Right of top section
        top_right = tk.Frame(top_frame, bg=WHITE)
        top_right.pack(side="right", fill="y", padx=50)

        self.adj_type = tk.StringVar(value="Add Stock")
        
        lf = tk.LabelFrame(top_right, text="Adjustment Type", bg=WHITE, font=FONT, padx=10, pady=5)
        lf.pack(fill="both", expand=True)

        rb_frame1 = tk.Frame(lf, bg=WHITE)
        rb_frame1.pack(fill="x")
        self.rb_add = tk.Radiobutton(rb_frame1, text="Add Stock", variable=self.adj_type, value="Add Stock", bg=WHITE, font=FONT, command=self.on_adj_type_change)
        self.rb_add.pack(side="left", padx=(0, 20))
        self.rb_reduce = tk.Radiobutton(rb_frame1, text="Reduce Stock", variable=self.adj_type, value="Reduce Stock", bg=WHITE, font=FONT, command=self.on_adj_type_change)
        self.rb_reduce.pack(side="left")

        self.rb_manual = tk.Radiobutton(lf, text="Enter Physical Stock Manually To Adjust", variable=self.adj_type, value="Enter Physical Stock Manually To Adjust", bg=WHITE, font=FONT, command=self.on_adj_type_change)
        self.rb_manual.pack(anchor="w", pady=(5, 0))

        # Middle Item Section
        mid_frame = tk.Frame(self, bg=WHITE)
        mid_frame.pack(fill="x", padx=10, pady=5)

        tk.Label(mid_frame, text="Press DELETE key to remove item row.", bg=WHITE, fg=RED, font=("Segoe UI", 10, "bold italic")).pack(side="left", anchor="s")

        item_input_frame = tk.Frame(mid_frame, bg=WHITE)
        item_input_frame.pack(side="right", anchor="se")

        tk.Label(item_input_frame, text="Press ENTER key to add. ESCAPE to leave.", bg=WHITE, fg=RED, font=("Segoe UI", 9, "bold italic")).pack(anchor="e")

        item_row = tk.Frame(item_input_frame, bg=WHITE)
        item_row.pack(fill="x")
        tk.Label(item_row, text="F9: Item", bg=WHITE, font=FONT).pack(side="left")
        
        self.item_entry = tk.Entry(item_row, font=FONT, width=40)
        self.item_entry.pack(side="left", padx=5)
        self.item_entry.bind("<KeyRelease>", self.check_autocomplete)
        self.item_entry.bind("<Return>", self.add_item_to_grid)
        self.item_entry.bind("<FocusIn>", lambda e: self.item_entry.config(bg="yellow"))
        self.item_entry.bind("<FocusOut>", lambda e: self.item_entry.config(bg="white"))

        self.units_left_lbl = tk.Label(item_input_frame, text="Units Left: 0 nos", bg="red", fg="white", font=FONT, anchor="w")
        
        self.listbox = tk.Listbox(self, font=FONT)
        self.listbox.bind("<<ListboxSelect>>", self.on_listbox_select)
        self.listbox.bind("<Return>", self.on_listbox_return)

        # Action Bar (Bottom - Pack first so it stays at very bottom)
        action_bar = tk.Frame(self, bg=WHITE)
        action_bar.pack(fill="x", side="bottom", padx=10, pady=5)
        
        # Bottom Section (Narration and Total - Pack above action bar)
        bot_frame = tk.Frame(self, bg=WHITE)
        bot_frame.pack(fill="x", side="bottom", padx=10, pady=(5, 10))
        
        # Left (Narration)
        nar_fr = tk.Frame(bot_frame, bg=WHITE)
        nar_fr.pack(side="left")
        tk.Label(nar_fr, text="Narration\nUse Ctrl+Enter for next line", bg=WHITE, font=("Segoe UI", 8), justify="right").pack(side="left", anchor="n", padx=(0, 5))
        self.txt_narration = tk.Text(nar_fr, height=4, width=50, font=FONT)
        self.txt_narration.pack(side="left")
        
        # Right (Total Value)
        tot_fr = tk.Frame(bot_frame, bg=WHITE)
        tot_fr.pack(side="right", anchor="n")
        tk.Label(tot_fr, text="Total Value", bg=WHITE, font=FONT).pack(side="left")
        self.txt_total = tk.Entry(tot_fr, font=FONT, width=20, justify="right", bg="#e0e0e0")
        self.txt_total.pack(side="left", padx=5)
        self.txt_total.insert(0, "0.0")
        self.txt_total.config(state="readonly")

        # Data Grid (Treeview - Pack last so it fills remaining space)
        grid_frame = tk.Frame(self, bg=WHITE)
        grid_frame.pack(fill="both", expand=True, padx=10, pady=5)

        cols = ("Item", "Quantity", "Rate/Unit", "Amount")
        self.tree = ttk.Treeview(grid_frame, columns=cols, show="headings", height=10)
        for col in cols:
            self.tree.heading(col, text=col)
            if col == "Item":
                self.tree.column(col, width=400, anchor="w")
            else:
                self.tree.column(col, width=150, anchor="e")
        self.tree.pack(fill="both", expand=True)
        
        self.tree.bind("<Double-1>", self.on_double_click)
        self.tree.bind("<Delete>", self.delete_row)
        
        btn_exit = tk.Button(action_bar, text="Ctrl+Q: Exit", font=FONT, bg="#e0e0e0", command=self.destroy)
        btn_exit.pack(side="left")
        
        btn_save = tk.Button(action_bar, text="F12:Save", font=FONT, bg="#e0e0e0", command=self.save_adjustment)
        btn_save.pack(side="right")
        
        link = tk.Label(action_bar, text="Video: Inventory Adjustment: Add/Reduce Stock", fg="blue", bg=WHITE, font=("Segoe UI", 9, "underline"), cursor="hand2")
        link.pack(side="bottom")
        link.bind("<Button-1>", lambda e: self.open_video())

    def on_adj_type_change(self):
        val = self.adj_type.get()
        if val == "Enter Physical Stock Manually To Adjust" or "Manually" in val:
            self.tree.heading("Quantity", text="Available Physical Qty")
        else:
            self.tree.heading("Quantity", text="Quantity")

    def check_autocomplete(self, event):
        if event.keysym in ("Up", "Down", "Return", "Escape"):
            return
            
        typed = self.item_entry.get()
        if typed == "":
            self.listbox.place_forget()
            self.units_left_lbl.pack_forget()
            return
            
        matches = [i['name'] for i in self.items if typed.lower() in i['name'].lower()]
        if matches:
            self.listbox.delete(0, tk.END)
            for m in matches:
                self.listbox.insert(tk.END, m)
            
            # Place listbox under entry
            x = self.item_entry.winfo_rootx() - self.winfo_rootx()
            y = self.item_entry.winfo_rooty() - self.winfo_rooty() + self.item_entry.winfo_height()
            self.listbox.place(x=x, y=y, width=self.item_entry.winfo_width())
            self.listbox.lift()
        else:
            self.listbox.place_forget()

    def on_listbox_select(self, event):
        if not self.listbox.curselection():
            return
        idx = self.listbox.curselection()[0]
        selected = self.listbox.get(idx)
        self.item_entry.delete(0, tk.END)
        self.item_entry.insert(0, selected)
        self.listbox.place_forget()
        
        # Show units left
        item_data = next((i for i in self.items if i['name'] == selected), None)
        if item_data:
            stock = item_data['stock']
            self.units_left_lbl.config(text=f"Units Left: {stock} nos")
            self.units_left_lbl.pack(fill="x", pady=2)
            self.item_entry.focus()

    def on_listbox_return(self, event):
        self.on_listbox_select(event)
        self.add_item_to_grid()

    def add_item_to_grid(self, event=None):
        selected = self.item_entry.get().strip()
        if not selected:
            return
            
        item_data = next((i for i in self.items if i['name'] == selected), None)
        rate = item_data['purchase_price'] if item_data else 0.0
        
        item_id = self.tree.insert("", "end", values=(selected, "", rate, "0.0"))
        
        self.item_entry.delete(0, tk.END)
        self.listbox.place_forget()
        self.units_left_lbl.pack_forget()
        self.update_total()
        
        # Auto-open quantity edit box
        self.tree.selection_set(item_id)
        # Create a dummy event to trigger double click
        class DummyEvent:
            pass
        e = DummyEvent()
        # Find cell coordinates
        bbox = self.tree.bbox(item_id, "#2")
        if bbox:
            e.x = bbox[0] + 5
            e.y = bbox[1] + 5
            self.on_double_click(e)

    def delete_row(self, event):
        selected_item = self.tree.selection()
        if selected_item:
            self.tree.delete(selected_item)
            self.update_total()

    def on_double_click(self, event):
        region = self.tree.identify("region", event.x, event.y)
        if region != "cell": return

        col = self.tree.identify_column(event.x)
        row = self.tree.identify_row(event.y)
        if not row: return
        
        col_idx = int(col[1:]) - 1
        if col_idx not in (1, 2): return # Only qty and rate are editable
        
        x, y, w, h = self.tree.bbox(row, col)
        val = self.tree.item(row, "values")[col_idx]
        
        entry = tk.Entry(self.tree, font=FONT, bg="yellow")
        entry.place(x=x, y=y, width=w, height=h)
        entry.insert(0, val)
        entry.focus_set()
        entry.select_range(0, tk.END)
        
        def save_edit(e):
            new_val = entry.get()
            try:
                new_val_float = float(new_val)
            except ValueError:
                new_val_float = 0.0
                
            vals = list(self.tree.item(row, "values"))
            vals[col_idx] = str(new_val_float)
            
            # Recalculate amount
            qty = float(vals[1]) if vals[1] else 0.0
            rate = float(vals[2]) if vals[2] else 0.0
            vals[3] = str(qty * rate)
            
            self.tree.item(row, values=vals)
            entry.destroy()
            self.update_total()
            
        entry.bind("<Return>", save_edit)
        entry.bind("<FocusOut>", lambda e: entry.destroy())

    def update_total(self):
        total = 0.0
        for child in self.tree.get_children():
            amt = float(self.tree.item(child, "values")[3])
            total += amt
        self.txt_total.config(state="normal")
        self.txt_total.delete(0, tk.END)
        self.txt_total.insert(0, str(total))
        self.txt_total.config(state="readonly")

    def open_video(self):
        import webbrowser
        webbrowser.open("https://www.youtube.com/watch?v=dQw4w9WgXcQ") # Dummy link

    def save_adjustment(self):
        vch_no = self.txt_voucher_no.get()
        date = self.txt_date.get()
        adj_type = self.adj_type.get()
        narration = self.txt_narration.get("1.0", tk.END).strip()
        
        items_to_adjust = []
        for child in self.tree.get_children():
            vals = self.tree.item(child, "values")
            if not vals[1]: continue # Skip if no qty
            qty = float(vals[1])
            items_to_adjust.append({
                'name': vals[0],
                'qty': qty,
                'rate': float(vals[2])
            })
            
        if not items_to_adjust:
            messagebox.showerror("Error", "Please add at least one item with a valid quantity.")
            return
            
        total_amount = float(self.txt_total.get())
        
        conn = db.get_conn()
        c = conn.cursor()
        
        # Insert voucher record
        voucher_narration = f"Stock Adjustment\nVoucher No:{vch_no}"
        if narration:
            voucher_narration += f"\n{narration}"
            
        c.execute(
            "INSERT INTO vouchers (vch_no, v_type, date, amount, narration, paid_amount, debit, credit) VALUES (?,?,?,?,?,?,?,?)",
            (vch_no, 'inventory_adjustment', date, total_amount, voucher_narration, 0.0, '', '')
        )
        
        for item in items_to_adjust:
            # Get current stock
            curr_stock_row = c.execute("SELECT cl_bal FROM stock WHERE stock_name=?", (item['name'],)).fetchone()
            curr_stock = curr_stock_row['cl_bal'] if curr_stock_row else 0.0
            
            new_stock = curr_stock
            if adj_type == "Add Stock":
                new_stock += item['qty']
            elif adj_type == "Reduce Stock":
                new_stock -= item['qty']
            else: # Manual
                new_stock = item['qty']
                
            # Update stock
            if curr_stock_row:
                c.execute("UPDATE stock SET cl_bal=?, date=? WHERE stock_name=?", (new_stock, date, item['name']))
            else:
                c.execute("INSERT INTO stock (stock_name, cl_bal, date) VALUES (?, ?, ?)", (item['name'], new_stock, date))
                
        conn.commit()
        conn.close()
        
        self.master_app.update_all_views()
        messagebox.showinfo("Success", "Inventory Adjustment saved successfully!")
        self.destroy()

    def bind_events(self):
        self.bind("<Control-q>", lambda e: self.destroy())
        self.bind("<Control-Q>", lambda e: self.destroy())
        self.bind("<F12>", lambda e: self.save_adjustment())
        
        def handle_f9(e):
            self.item_entry.focus()
            
        self.bind("<F9>", handle_f9)
