import os
import json
import base64
import urllib.request
import urllib.error
import zipfile
import tkinter as tk
from tkinter import messagebox

CONFIG_FILE = ".releasemanager.json"

class ReleaseManager(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Book Keeper - Release Manager")
        self.geometry("500x350")
        self.configure(padx=20, pady=20)
        
        self.config_data = {"username": "", "repo": "", "token": ""}
        self.load_config()
        
        tk.Label(self, text="GitHub Settings", font=("Arial", 14, "bold")).pack(anchor="w", pady=(0, 10))
        
        f1 = tk.Frame(self)
        f1.pack(fill="x", pady=5)
        tk.Label(f1, text="GitHub Username:", width=20, anchor="w").pack(side="left")
        self.user_var = tk.StringVar(value=self.config_data.get("username", ""))
        tk.Entry(f1, textvariable=self.user_var, width=30).pack(side="left", expand=True, fill="x")
        
        f2 = tk.Frame(self)
        f2.pack(fill="x", pady=5)
        tk.Label(f2, text="Repository Name:", width=20, anchor="w").pack(side="left")
        self.repo_var = tk.StringVar(value=self.config_data.get("repo", "BookKeeper-Updates"))
        tk.Entry(f2, textvariable=self.repo_var, width=30).pack(side="left", expand=True, fill="x")
        
        f3 = tk.Frame(self)
        f3.pack(fill="x", pady=5)
        tk.Label(f3, text="Personal Access Token:", width=20, anchor="w").pack(side="left")
        self.token_var = tk.StringVar(value=self.config_data.get("token", ""))
        tk.Entry(f3, textvariable=self.token_var, width=30, show="*").pack(side="left", expand=True, fill="x")
        
        tk.Button(self, text="Save Settings", command=self.save_config).pack(pady=10)
        
        tk.Frame(self, height=2, bg="gray").pack(fill="x", pady=10)
        
        self.btn_release = tk.Button(self, text="🚀 Build & Release Update", font=("Arial", 14, "bold"), 
                                     bg="#4CAF50", fg="white", command=self.release_update)
        self.btn_release.pack(pady=10, fill="x", ipady=10)
        
    def load_config(self):
        if os.path.exists(CONFIG_FILE):
            try:
                with open(CONFIG_FILE, "r") as f:
                    self.config_data = json.load(f)
            except:
                pass
                
    def save_config(self):
        self.config_data = {
            "username": self.user_var.get().strip(),
            "repo": self.repo_var.get().strip(),
            "token": self.token_var.get().strip()
        }
        with open(CONFIG_FILE, "w") as f:
            json.dump(self.config_data, f)
        messagebox.showinfo("Saved", "Settings saved successfully.")
        
    def get_file_sha(self, path):
        user = self.user_var.get().strip()
        repo = self.repo_var.get().strip()
        token = self.token_var.get().strip()
        url = f"https://api.github.com/repos/{user}/{repo}/contents/{path}"
        
        req = urllib.request.Request(url, headers={
            "Authorization": f"token {token}",
            "Accept": "application/vnd.github.v3+json",
            "User-Agent": "BookKeeper-ReleaseManager"
        })
        try:
            with urllib.request.urlopen(req, timeout=10) as response:
                data = json.loads(response.read().decode())
                return data.get("sha")
        except urllib.error.HTTPError as e:
            if e.code == 404:
                return None
            raise e
            
    def upload_file(self, file_path, repo_path, commit_msg):
        user = self.user_var.get().strip()
        repo = self.repo_var.get().strip()
        token = self.token_var.get().strip()
        
        with open(file_path, "rb") as f:
            content = f.read()
        encoded_content = base64.b64encode(content).decode("utf-8")
        
        sha = self.get_file_sha(repo_path)
        
        url = f"https://api.github.com/repos/{user}/{repo}/contents/{repo_path}"
        data = {
            "message": commit_msg,
            "content": encoded_content
        }
        if sha:
            data["sha"] = sha
            
        json_data = json.dumps(data).encode("utf-8")
        
        req = urllib.request.Request(url, data=json_data, headers={
            "Authorization": f"token {token}",
            "Accept": "application/vnd.github.v3+json",
            "Content-Type": "application/json",
            "User-Agent": "BookKeeper-ReleaseManager"
        }, method="PUT")
        
        with urllib.request.urlopen(req, timeout=300) as response:
            return response.status in [200, 201]

    def release_update(self):
        if not self.user_var.get() or not self.repo_var.get() or not self.token_var.get():
            messagebox.showerror("Error", "Please fill in all GitHub settings and save them first.")
            return
            
        self.btn_release.config(state="disabled", text="Working...")
        self.update()
        
        try:
            # 1. Update version.txt
            ver = "1.0.0"
            if os.path.exists("version.txt"):
                with open("version.txt", "r") as f:
                    ver = f.read().strip()
            
            parts = ver.split('.')
            if len(parts) == 3 and parts[-1].isdigit():
                parts[-1] = str(int(parts[-1]) + 1)
                new_ver = ".".join(parts)
            else:
                new_ver = ver + ".1"
                
            with open("version.txt", "w") as f:
                f.write(new_ver)
                
            # 2. Zip files
            zip_name = "update.zip"
            excluded_dirs = [".git", "__pycache__", "node_modules", "build", "dist", ".next", "Output", ".tempmediaStorage", ".user_uploaded"]
            with zipfile.ZipFile(zip_name, 'w', zipfile.ZIP_DEFLATED) as zf:
                for root, dirs, files in os.walk("."):
                    # modify dirs in-place to skip excluded directories entirely
                    dirs[:] = [d for d in dirs if d not in excluded_dirs]
                    
                    for file in files:
                        if file.endswith(".db") or file == zip_name or file == CONFIG_FILE or file.endswith(".sqlite") or file.endswith(".json") or file.endswith(".log") or file.endswith(".exe"):
                            continue
                        file_path = os.path.join(root, file)
                        arcname = os.path.relpath(file_path, ".")
                        zf.write(file_path, arcname)
                        
            # 3. Upload version.txt
            self.upload_file("version.txt", "version.txt", f"Release version {new_ver}")
            
            # 4. Upload update.zip
            self.upload_file(zip_name, "update.zip", f"Update package for {new_ver}")
            
            os.remove(zip_name)
            
            messagebox.showinfo("Success", f"Version {new_ver} has been successfully released to clients!")
            
        except Exception as e:
            messagebox.showerror("Upload Error", f"An error occurred:\n{e}")
        finally:
            self.btn_release.config(state="normal", text="🚀 Build & Release Update")

if __name__ == "__main__":
    app = ReleaseManager()
    app.mainloop()
