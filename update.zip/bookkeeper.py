# -*- coding: utf-8 -*-
"""
# Book Keeper Clone - Main Application
# Classic Windows XP style using Python Tkinter (built-in)
"""
try:
    from tkcalendar import DateEntry
except ImportError:
    DateEntry = None

try:
    from tkcalendar import DateEntry
except ImportError:
    DateEntry = None

import tkinter as tk
from tkinter import ttk, messagebox
import datetime
import invoice_preview
import db
import payment_supplier
import receipt_customer
import journal_voucher
import credit_note
import debit_note
import category
import inventory_stock
import excel_import
from autocomplete import AutocompleteCombobox

# ── Colors & Fonts (Windows XP Classic) ─────────────────────────────────────
BG         = "#f0f2f5"
BG_DARK    = "#e1e4e8"
WHITE      = "#ffffff"
BLUE_SEL   = "#d0e2f5"
BLUE_SEL_FG= "#111827"
YELLOW     = "#ffff00"
RED        = "#cc0000"
GREEN_DARK = "#007700"
ORANGE     = "#f0ad4e"
GREEN_BAR  = "#5cb85c"
GREEN_BAR2 = "#4cae4c"
RED_BOX    = "#d9534f"

FONT       = ("Segoe UI", 11)
FONT_BOLD  = ("Segoe UI", 11, "bold")
FONT_LG    = ("Segoe UI", 14, "bold")
FONT_XL    = ("Segoe UI", 20, "bold")



# Formatting Helper
def format_amt(amount, show_symbol=True):
    try:
        amt = float(amount or 0)
    except:
        amt = 0.0
    
    currency_symbol = db.get_setting("currency_symbol", "Rs ")
    currency_format = db.get_setting("currency_format", "1,234,567.89")
    decimals_str = db.get_setting("decimal_amount", "2")
    try:
        decimals = int(decimals_str)
    except:
        decimals = 2
        
    is_negative = amt < 0
    amt = abs(amt)
    
    if currency_format == "12,34,567.89":
        # South Asian Format
        s = f"{amt:.{decimals}f}"
        if "." in s:
            whole, frac = s.split(".")
        else:
            whole, frac = s, ""
            
        res = ""
        if len(whole) > 3:
            res = "," + whole[-3:]
            whole = whole[:-3]
            while len(whole) > 2:
                res = "," + whole[-2:] + res
                whole = whole[:-2]
            res = whole + res
        else:
            res = whole
            
        if frac:
            formatted = res + "." + frac
        else:
            formatted = res
    else:
        # International Format
        formatted = f"{amt:,.{decimals}f}"
        
    if is_negative:
        formatted = "-" + formatted
        
    if show_symbol:
        return f"{currency_symbol.strip()} {formatted}".strip()
    return formatted

def format_qty(qty):
    try:
        q = float(qty or 0)
    except:
        q = 0.0
    decimals_str = db.get_setting("decimal_quantity", "2")
    try:
        decimals = int(decimals_str)
    except:
        decimals = 2
    return f"{q:,.{decimals}f}"

def make_button(parent, text, command=None, **kw):
    return tk.Button(
        parent, text=text, command=command,
        relief="raised", bd=2, bg=BG,
        activebackground=BG_DARK, font=FONT, cursor="hand2", **kw
    )

# ── Windows XP style icons (text-based) ─────────────────────────────────────
ICONS = {
    "customer":  "👤",
    "supplier":  "👥",
    "accounts":  "💰",
    "inventory": "🛒",
    "unit":      "⚖",
    "service": "iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAMAAAAoLQ9TAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAVZQTFRFR3BMVFRUEhISPj4+Tk5OUlJSNDQ0AAAAAAAARUVFLy8vAAAAIiIiAAAAFRUVAQEBAAAACgoKFhYWS0tLXFxgh4eP1tbmUFBQbm5y19forq66ra261NTlysrOt7fFuLjIxMTEAAAA4eHziYmJUFBQAAAAAQEB9PT0AQEBAQEBAQEBm5ubAQEBAQEBAQEB4uLiAQEBAQEBXV1dAAAAsbGx2NjY5eXl7+/vRkZGaWlpZ2dntLS0ZmZmysrb5eX21tbnoKCsu7u71dXmqam7kZGaxsbHv7/Oc3Nz0dHiiIiOtLTCkJCbUlJSzs7gs7PCnZ2nqqqrjY2VlpajSUlJqKi5oqKwuLjIbGxsampqTk5O5OTkkpKenJysmpqcREREl5em0NDSeHh4qKitysrKra2tUVFRioqKYGBgkJCQtra2goKC2NjY09PTYmJiubm5WVlZ0dHRVVVVV9Z9TgAAADd0Uk5TAEhmQ00bZhrHBR8KVxd1WpyGw0CLnvVmgvXNxvDs/OzIyP6SQsO9+rexrairsKz1tbyLws3w/hG47D4AAACvSURBVBjTY2AgErCIs6AKsNmxIXNZGZkcmRhZYVxOFWUFWTl5aQlhTogAs7a6uauDs62YKDOYz2Wkbx4V4Oni5SQpwgUS4DHJTraODfT2d7OX4gEJ8JnmWKckRAeF+nnI8IEEBM0K8jKT4mNCwnyVBIF8fqH8XJv0VIs4i+BIHyF+BgaOQqusjLRESxsry4hwdw4GBgEOY0MDXT0dLU0NNVVFAQYGbl52BODlxvQmABKyG3UUSSzwAAAAAElFTkSuQmCC",
    "balance":   "📈",
    "profit":    "%",
    "ledger":    "📋",
    "daybook":   "📖",
    "sales":     "≈",
    "invdet":    "🛒",
    "invsum":    "📊",
    "tax":       "💰",
    "allrep":    "📊",
}

# ════════════════════════════════════════════════════════════════════════════



class BookKeeperApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.withdraw() # Hide immediately
        
        self.active_company_path = None
        self.company_name = "Company"
        self.current_user = None

        self.title("Book Keeper Windows [v7.3.9]")
        self.geometry("1280x800")
        self.configure(bg=BG)

        # Apply ttk style
        style = ttk.Style(self)
        style.theme_use("clam")
        self._apply_styles(style)

        self.init_icons()

        def open_company_settings(e=None, is_new=False, parent_win=None):
            try:
                from company_settings import AlterCompanyWindow
                p = parent_win if parent_win else self
                AlterCompanyWindow(p, is_new=is_new, app_ref=self)
            except Exception as e:
                import traceback
                print(traceback.format_exc())
                messagebox.showerror("Error", f"Could not open Company Settings: {e}")
        self.open_company_settings = open_company_settings
        self.bind_all("<Alt-F3>", open_company_settings)

        def open_user_management(e=None):
            enable_pwd = db.get_setting("company_enable_pwd", "0")
            pwd = db.get_setting("company_password", "").strip()
            if str(enable_pwd) != "1" or not pwd:
                messagebox.showwarning(
                    "operation failed",
                    "You need to first setup company password.\nGo to Settings > Company Settings & enable Company Level Password.\n\nERRCODE: [v7.3.9][BKW10301289]",
                    parent=self
                )
                return
            try:
                import user_management
                user_management.UserManagementWindow(self)
            except Exception as e:
                import traceback
                print(traceback.format_exc())
        self.open_user_management = open_user_management

        def open_message_settings(e=None):
            try:
                import message_settings
                message_settings.MessageSettingsWindow(self)
            except Exception as e:
                import traceback
                print(traceback.format_exc())
        self.open_message_settings = open_message_settings

        def open_inventory_stock_level(e=None):
            try:
                import inventory_stock
                inventory_stock.InventoryStockLevelWindow(self, app=self)
            except Exception as ex:
                import traceback
                print(traceback.format_exc())
        self.open_inventory_stock_level = open_inventory_stock_level

        def open_template_settings(e=None):
            try:
                import template_settings
                template_settings.TemplateSettingsWindow(self)
            except Exception as ex:
                import traceback
                print(traceback.format_exc())
        self.open_template_settings = open_template_settings

        def open_transaction_settings(e=None):
            try:
                import transaction_settings
                transaction_settings.TransactionSettingsWindow(self)
            except Exception as ex:
                import traceback
                messagebox.showerror("Error", str(ex))
                print(traceback.format_exc())
        self.open_transaction_settings = open_transaction_settings

        self._build_ui()
        self._bind_shortcuts()
        
    # =========================================================================
    # SETTINGS HELPERS (Fix 1-5)
    # =========================================================================

    def get_default_date(self):
        """Fix 5: Return the default date string based on date_mode setting."""
        import datetime
        mode = db.get_setting("date_mode", "current")
        if mode == "last_voucher":
            try:
                conn = db.get_conn()
                row = conn.execute(
                    "SELECT date FROM vouchers ORDER BY rowid DESC LIMIT 1"
                ).fetchone()
                conn.close()
                if row and row[0]:
                    # Parse and reformat to match existing format
                    d = row[0]
                    try:
                        parsed = datetime.datetime.strptime(d, "%B %d, %Y")
                    except:
                        try:
                            parsed = datetime.datetime.strptime(d, "%Y-%m-%d")
                        except:
                            return datetime.date.today().strftime("%B %d, %Y")
                    return parsed.strftime("%B %d, %Y")
            except:
                pass
        elif mode == "custom":
            custom = db.get_setting("date_custom_value", "")
            if custom:
                return custom
        return datetime.date.today().strftime("%B %d, %Y")

    def apply_roundoff(self, amount):
        """Fix 4: Auto round-off amount if setting enabled."""
        if db.get_setting("misc_auto_roundoff", "1") == "1":
            return round(amount)
        return amount

    def confirm_delete_voucher(self, voucher_id, invoice_no, parent_win, after_delete):
        """Fix 2: Confirm delete with optional password, then execute after_delete callback."""
        # Step 1: Confirmation message
        if db.get_setting("warn_confirm_delete", "0") == "1":
            if not messagebox.askyesno(
                "Confirm Delete",
                f"Are you sure you want to delete {invoice_no}?",
                parent=parent_win
            ):
                return

        # Step 2: Password check
        if db.get_setting("warn_del_password_enabled", "0") == "1":
            stored_pwd = db.get_setting("warn_del_password", "")
            if stored_pwd:
                pwd_win = tk.Toplevel(parent_win)
                pwd_win.title("Enter Password")
                pwd_win.geometry("320x130")
                pwd_win.configure(bg="#f0f0f0")
                pwd_win.grab_set()
                tk.Label(pwd_win, text="Enter delete password:", bg="#f0f0f0",
                         font=FONT).place(x=20, y=20)
                pwd_var = tk.StringVar()
                pwd_entry = tk.Entry(pwd_win, textvariable=pwd_var, show="*",
                                     font=FONT, width=22, relief="solid", bd=1)
                pwd_entry.place(x=20, y=50)
                pwd_entry.focus_set()

                def check_pwd(event=None):
                    if pwd_var.get() == stored_pwd:
                        pwd_win.destroy()
                        db.delete_voucher(voucher_id)
                        after_delete()
                    else:
                        messagebox.showerror("Wrong Password",
                                             "Incorrect password!", parent=pwd_win)

                tk.Button(pwd_win, text="OK", command=check_pwd, font=FONT,
                          bg="#e0e0e0", relief="solid", bd=1,
                          width=10).place(x=20, y=85)
                pwd_win.bind("<Return>", check_pwd)
                return  # execution continues in callback

        # No password required — delete directly
        db.delete_voucher(voucher_id)
        after_delete()

    def check_negative_inventory(self, line_items, parent_win):
        """Fix 3: Warn if any sale item would cause negative stock."""
        if db.get_setting("warn_neg_inventory", "0") != "1":
            return True  # no check needed
        try:
            conn = db.get_conn()
            for item in line_items:
                name = item.get("name", "")
                qty = float(item.get("qty", 0))
                row = conn.execute(
                    "SELECT cl_bal FROM stock WHERE stock_name=?", (name)
                ).fetchone()
                if row:
                    available = float(row[0] or 0)
                    if qty > available:
                        conn.close()
                        return messagebox.askyesno(
                            "Negative Inventory Warning",
                            f"Item '{name}' has only {available} in stock but you are entering {qty}.\n"
                            f"This will result in negative stock. Continue anyway?",
                            parent=parent_win
                        )
            conn.close()
        except Exception as ex:
            print("Inventory check error:", ex)
        return True

    def _bind_shortcuts(self):
        # Global Application Shortcuts
        self.bind_all('<Control-q>', lambda e: self.destroy() if getattr(e.widget, 'winfo_toplevel', lambda: None)() == self else None)
        self.bind_all('<Control-Q>', lambda e: self.destroy() if getattr(e.widget, 'winfo_toplevel', lambda: None)() == self else None)

        def _safe_action(action):
            def handler(e):
                focused = self.focus_get()
                if focused and isinstance(focused.winfo_toplevel(), tk.Toplevel):
                    return
                if self.active_company_path:
                    action()
            return handler

        self.bind('<Control-n>', _safe_action(lambda: self.open_company_settings(is_new=True)))
        self.bind('<Control-N>', _safe_action(lambda: self.open_company_settings(is_new=True)))
        self.bind('<Control-o>', lambda e: self.show_standalone_selection())
        self.bind('<Control-O>', lambda e: self.show_standalone_selection())
        self.bind('<Control-f>', _safe_action(lambda: self.show_invoices('all')))
        self.bind('<Control-F>', _safe_action(lambda: self.show_invoices('all')))
        self.bind('<Control-r>', _safe_action(lambda: self.update_all_views()))
        self.bind('<Control-R>', _safe_action(lambda: self.update_all_views()))

        self.bind('<Alt-F1>', _safe_action(lambda: self.close_company()))
        self.bind('<Alt-F3>', lambda e: self.open_company_settings())
        self.bind('<F4>', _safe_action(lambda: self._open_contra_voucher()))
        self.bind('<F5>', _safe_action(lambda: self._open_payment_supplier()))
        self.bind('<F6>', _safe_action(lambda: self._open_receipt_customer()))
        self.bind('<F7>', _safe_action(lambda: self._open_journal_voucher()))
        self.bind('<F8>', _safe_action(lambda: self._open_create_voucher("sale")))
        self.bind('<F9>', _safe_action(lambda: self._open_create_voucher("purchase")))
        self.bind('<Alt-F4>', _safe_action(lambda: self._open_create_voucher("purchase_order")))
        self.bind('<Alt-F5>', _safe_action(lambda: self._open_create_voucher("estimate")))
        self.bind('<Alt-F8>', _safe_action(lambda: self._open_credit_note_window()))
        self.bind('<Alt-F9>', _safe_action(lambda: self._open_debit_note_window()))

        self.bind('<Alt-e>', _safe_action(lambda: self._open_expense_voucher()))
        self.bind('<Alt-E>', _safe_action(lambda: self._open_expense_voucher()))
        self.bind('<Alt-i>', _safe_action(lambda: self._open_income_voucher()))
        self.bind('<Alt-I>', _safe_action(lambda: self._open_income_voucher()))
        self.bind('<Alt-a>', _safe_action(lambda: self._generic_account_form()))
        self.bind('<Alt-A>', _safe_action(lambda: self._generic_account_form()))
        self.bind('<Alt-c>', _safe_action(lambda: self._account_form('customer')))
        self.bind('<Alt-C>', _safe_action(lambda: self._account_form('customer')))
        self.bind('<Alt-s>', _safe_action(lambda: self.open_inventory_stock_level()))
        self.bind('<Alt-S>', _safe_action(lambda: self.open_inventory_stock_level()))
        self.bind('<Alt-t>', _safe_action(lambda: self.show_invoices('all')))
        self.bind('<Alt-T>', _safe_action(lambda: self.show_invoices('all')))
        self.bind('<Alt-m>', _safe_action(lambda: category.CategorySubcategoryWindow(self, app=self)))
        self.bind('<Alt-M>', _safe_action(lambda: category.CategorySubcategoryWindow(self, app=self)))
        self.bind('<Alt-u>', _safe_action(lambda: self._unit_form()))
        self.bind('<Alt-U>', _safe_action(lambda: self._unit_form()))
        self.bind('<Alt-v>', _safe_action(lambda: self._item_form()))
        self.bind('<Alt-V>', _safe_action(lambda: self._item_form()))


    def update_all_views(self):
        # Refresh dashboard if currently open
        if hasattr(self, 'current_view') and self.current_view == 'dashboard':
            self.show_dashboard()
        elif hasattr(self, 'current_view') and self.current_view == 'balance_sheet':
            self.show_balance_sheet()
        elif hasattr(self, 'current_view') and self.current_view == 'profit_loss':
            self.show_profit_loss()

    def _apply_styles(self, style):
        style.configure(".", background=BG, foreground="#000", font=FONT)
        style.configure("Treeview",
                        background=WHITE, foreground="#111827",
                        fieldbackground=WHITE, font=FONT, rowheight=30)
        style.configure("Treeview.Heading",
                        background=BG, foreground="#000",
                        font=FONT_BOLD, relief="raised")
        style.map("Treeview",
                  background=[("selected", "#d0e2f5")],
                  foreground=[("selected", "#111827")])
        style.configure("TScrollbar", background=BG, troughcolor="#c0c0c0",
                        arrowcolor="#000", relief="raised")

    # ── Build UI ─────────────────────────────────────────────────────────────
    def check_startup(self):
        import json, os
        import os
        appdata_dir = os.path.join(os.getenv('APPDATA'), 'BookKeeper')
        os.makedirs(appdata_dir, exist_ok=True)
        recent_file = os.path.join(appdata_dir, "recent_companies.json")
        last_company = None
        if os.path.exists(recent_file):
            try:
                with open(recent_file, "r") as ff:
                    recent = json.load(ff)
                    if recent:
                        last_company = recent[0]
            except: pass
            
        import company_selection
        if last_company and os.path.exists(last_company):
            # We want to check login directly
            company_selection.check_pwd_and_login(self, last_company)
        else:
            self.show_standalone_selection()

    def show_standalone_selection(self):
        import company_selection
        sel_win = tk.Toplevel(self)
        sel_win.title("Open Company From Dropbox")
        sel_win.geometry("820x560")
        sel_win.minsize(750, 480)
        
        # Center the window
        sel_win.update_idletasks()
        x = max(0, (sel_win.winfo_screenwidth() // 2) - 410)
        y = max(0, (sel_win.winfo_screenheight() // 2) - 280)
        sel_win.geometry(f"+{x}+{y}")
        
        company_selection.CompanySelectionView(sel_win, self)
        
        def on_close():
            sel_win.destroy()
            if not self.active_company_path:
                self.destroy()
                
        sel_win.protocol("WM_DELETE_WINDOW", on_close)

    def _build_ui(self):
        # Clear existing widgets except menubars (if any)
        for widget in self.winfo_children():
            widget.destroy()

        if not self.active_company_path:
            self.check_startup()
            return
            
        self.state("zoomed")
        self.deiconify()

        self._build_topbar()

        # Main body
        self.body = tk.Frame(self, bg=BG)
        self.body.pack(fill="both", expand=True)
        
        if not self.active_company_path:
            import company_selection
            self.selection_view = company_selection.CompanySelectionView(self.body, self)
        else:
            # Sidebar (left)
            self.sidebar_frame = tk.Frame(self.body, bg=BG, width=220,
                                          relief="groove", bd=1)
            self.sidebar_frame.pack(side="left", fill="y")
            self.sidebar_frame.pack_propagate(False)
            self._build_sidebar()
    
            # Right shortcuts panel
            self.right_frame = tk.Frame(self.body, bg=BG, width=220,
                                        relief="groove", bd=1)
            self.right_frame.pack(side="right", fill="y")
            self.right_frame.pack_propagate(False)
            self._build_right_panel()
    
            # Main content
            self.main_frame = tk.Frame(self.body, bg=BG, relief="flat")
            self.main_frame.pack(side="left", fill="both", expand=True)

    def has_permission(self, perm_key):
        if not getattr(self, 'current_user', None):
            return True
        if self.current_user.get("is_admin"):
            return True
        val = self.current_user.get(perm_key, 1)
        try:
            return int(val) == 1
        except:
            return bool(val)

    def check_permission(self, perm_key, action_name="perform this action"):
        if not self.has_permission(perm_key):
            from tkinter import messagebox
            messagebox.showwarning(
                "Permission Denied",
                f"You do not have permission to {action_name}.",
                parent=self
            )
            return False
        return True

    def get_user_voucher_prefix(self):
        if getattr(self, 'current_user', None) and not self.current_user.get("is_admin"):
            init = self.current_user.get("initials", "").strip()
            if init:
                return f"{init}-"
        return ""

    def load_company(self, filepath):
        self.active_company_path = filepath
        db.set_db_path(filepath)
        db.init_db()
        self.company_name = db.get_company_name()
        self._build_ui()
        self.show_dashboard()

    def close_company(self):
        from tkinter import messagebox
        if messagebox.askyesno("Close Company", "Close the current company?"):
            self.active_company_path = None
            self.current_user = None
            self.company_name = "Company"
            self.withdraw()
            self.show_standalone_selection()

    def _build_topbar(self):
        # ── Row 1: Menu bar ──────────────────────────────────────────────────
        bar1 = tk.Frame(self, bg=BG, relief="flat")
        bar1.pack(fill="x", side="top")

        # Exit
        ef = tk.Frame(bar1, bg=RED)
        ef.pack(side="left", padx=(4, 0), pady=2)
        tk.Label(ef, text="✕", bg=RED, fg=WHITE,
                 font=("Segoe UI", 10, "bold"), padx=2).pack()

        tk.Label(bar1, text=" Ctrl+Q: Exit", bg=BG, fg=RED,
                 font=FONT_BOLD, cursor="hand2").pack(side="left")

        def show_company_menu(event):
            menu = tk.Menu(self, tearoff=0, font=FONT, bg=WHITE, fg="#000", activebackground=BLUE_SEL, activeforeground=WHITE)
            menu.add_command(label=" Backup Company On Email")
            menu.add_command(label=" Create Duplicate")
            menu.add_command(label=" Split Company")
            
            adv_menu = tk.Menu(menu, tearoff=0, font=FONT, bg=WHITE, fg="#000", activebackground=BLUE_SEL, activeforeground=WHITE)
            adv_menu.add_command(label=" Optimize Company File")
            adv_menu.add_command(label=" Verify Accounts")
            adv_menu.add_command(label=" Verify Transactions")
            adv_menu.add_command(label=" Book Keeper Language")
            adv_menu.add_command(label=" Get Unrelated Transactions")
            
            menu.add_cascade(label=" Advance", menu=adv_menu)
            menu.add_separator()
            menu.add_command(label=" Close Company", accelerator="Alt+F1", command=self.close_company)
            
            menu.post(event.widget.winfo_rootx(), event.widget.winfo_rooty() + event.widget.winfo_height())

        # Company icon + name
        tk.Label(bar1, text="   🏢", bg=BG,
                 font=("Segoe UI", 11)).pack(side="left")
        lbl_text = f" {self.company_name.upper()} " if self.active_company_path else " Company "
        comp_lbl = tk.Label(bar1, text=lbl_text, bg=BG, fg="green",
                 font=("Segoe UI", 11, "bold"), cursor="hand2" if self.active_company_path else "")
        comp_lbl.pack(side="left")
        if self.active_company_path:
            comp_lbl.bind("<Button-1>", show_company_menu)

        # Menu items
        def show_settings_menu(event):
            menu = tk.Menu(self, tearoff=0, font=FONT, bg=WHITE, fg="#000", activebackground=BLUE_SEL, activeforeground=WHITE)
            
            def set_and_refresh(key, value):
                db.set_setting(key, value)
                self.update_all_views()
                
            def toggle_setting(key, default="1"):
                cur = db.get_setting(key, default)
                new_val = "0" if cur == "1" else "1"
                set_and_refresh(key, new_val)
                
            def prompt_setting(title, prompt, key, default=""):
                import tkinter.simpledialog as sd
                cur = db.get_setting(key, default)
                val = sd.askstring(title, prompt, initialvalue=cur, parent=self)
                if val is not None:
                    set_and_refresh(key, val)

            gen_menu = tk.Menu(menu, tearoff=0, font=FONT, bg=WHITE, activebackground=BLUE_SEL, activeforeground=WHITE)
            
            # Financial Year
            gen_menu.add_command(label="Financial Year", command=lambda: prompt_setting("Financial Year", "Enter Financial Year:", "financial_year", "2026-2027"))
            
            # Date Format
            date_menu = tk.Menu(gen_menu, tearoff=0, font=FONT, bg=WHITE, activebackground=BLUE_SEL, activeforeground=WHITE)
            date_menu.add_command(label="DD/MM/YYYY", command=lambda: set_and_refresh("date_format", "DD/MM/YYYY"))
            date_menu.add_command(label="MM/DD/YYYY", command=lambda: set_and_refresh("date_format", "MM/DD/YYYY"))
            date_menu.add_command(label="YYYY-MM-DD", command=lambda: set_and_refresh("date_format", "YYYY-MM-DD"))
            gen_menu.add_cascade(label="Date Format", menu=date_menu)
            
            # Decimal Place (Amount)
            gen_menu.add_command(label="Decimal Place (Amount)", command=lambda: prompt_setting("Decimals", "Number of decimals for amount:", "decimal_amount", "2"))
            
            # Decimal Place (Quantity)
            gen_menu.add_command(label="Decimal Place (Quantity)", command=lambda: prompt_setting("Decimals", "Number of decimals for quantity:", "decimal_quantity", "2"))
            
            # Currency Format
            cur_fmt_menu = tk.Menu(gen_menu, tearoff=0, font=FONT, bg=WHITE, activebackground=BLUE_SEL, activeforeground=WHITE)
            cur_fmt_menu.add_command(label="1,234,567.89", command=lambda: set_and_refresh("currency_format", "1,234,567.89"))
            cur_fmt_menu.add_command(label="12,34,567.89", command=lambda: set_and_refresh("currency_format", "12,34,567.89"))
            gen_menu.add_cascade(label="Currency Format", menu=cur_fmt_menu)
            
            # Currency Symbol
            gen_menu.add_command(label="Currency Symbol", command=lambda: prompt_setting("Currency Symbol", "Enter currency symbol:", "currency_symbol", "Rs "))
            
            # Country
            gen_menu.add_command(label="Country", command=lambda: prompt_setting("Country", "Enter Country:", "country", "Pakistan"))
            
            # Inventory Valuation
            inv_menu = tk.Menu(gen_menu, tearoff=0, font=FONT, bg=WHITE, activebackground=BLUE_SEL, activeforeground=WHITE)
            inv_menu.add_command(label="FIFO", command=lambda: set_and_refresh("inventory_valuation", "FIFO"))
            inv_menu.add_command(label="LIFO", command=lambda: set_and_refresh("inventory_valuation", "LIFO"))
            inv_menu.add_command(label="Average", command=lambda: set_and_refresh("inventory_valuation", "Average"))
            gen_menu.add_cascade(label="Inventory Valuation Method", menu=inv_menu)
            
            gen_menu.add_separator()
            
            # Toggles
            chk1 = "☑ " if db.get_setting("display_zero_bal", "1") == "1" else "☐ "
            gen_menu.add_command(label=chk1 + "Display Zero Balance Accounts", command=lambda: toggle_setting("display_zero_bal", "1"))
            
            chk2 = "☑ " if db.get_setting("include_opening_bal", "1") == "1" else "☐ "
            gen_menu.add_command(label=chk2 + "Include Opening Balance Of Expense/Income Accounts In Reports", command=lambda: toggle_setting("include_opening_bal", "1"))
            
            chk3 = "☑ " if db.get_setting("alt_color_rows", "1") == "1" else "☐ "
            gen_menu.add_command(label=chk3 + "Display Reports With Alternating Color Rows", command=lambda: toggle_setting("alt_color_rows", "1"))

            menu.add_cascade(label=" General Settings", menu=gen_menu)
            menu.add_separator()
            
            menu.add_command(label=" Company Settings", accelerator="Alt+F3", command=self.open_company_settings)
            menu.add_separator()
            
            menu.add_command(label=" User Management", command=self.open_user_management)
            menu.add_separator()
            
            menu.add_command(label=" Template Settings", command=self.open_template_settings)
            menu.add_separator()
            
            menu.add_command(label=" Transactions Settings", command=self.open_transaction_settings)
            menu.add_separator()
            
            win_menu = tk.Menu(menu, tearoff=0, font=FONT, bg=WHITE, activebackground=BLUE_SEL, activeforeground=WHITE)
            menu.add_cascade(label=" Windows Specific Settings", menu=win_menu)
            
            # Keep variables in scope
            self._win_vars = {}
            def add_win_toggle(lbl_text, key, default_val="1"):
                cur_val = db.get_setting(key, default_val)
                var = tk.StringVar(value=cur_val)
                self._win_vars[key] = var
                def on_toggle():
                    db.set_setting(key, var.get())
                    self.update_all_views()
                win_menu.add_checkbutton(label=lbl_text, variable=var, onvalue="1", offvalue="0", command=on_toggle)

            add_win_toggle("Show Notification In Taskbar", "win_show_notification", "1")
            add_win_toggle("Enable AutoBackup", "win_auto_backup", "1")
            
            # Number Of Transactions Per Page (cascade)
            tx_page_menu = tk.Menu(win_menu, tearoff=0, font=FONT, bg=WHITE, activebackground=BLUE_SEL, activeforeground=WHITE)
            win_menu.add_cascade(label="Number Of Transactions Per Page", menu=tx_page_menu)
            cur_tx_page = db.get_setting("win_tx_per_page", "50")
            tx_page_var = tk.StringVar(value=cur_tx_page)
            self._win_vars["win_tx_per_page"] = tx_page_var
            for val in ["10", "25", "50", "100", "200"]:
                def make_tx_page_cmd(v):
                    return lambda: [db.set_setting("win_tx_per_page", v), self.update_all_views()]
                tx_page_menu.add_radiobutton(label=val, variable=tx_page_var, value=val, command=make_tx_page_cmd(val))

            add_win_toggle("Display Narration & Buyer Details In Transactions", "win_show_narration_buyer", "0")
            add_win_toggle("Display Item/Service Details In Transactions", "win_show_item_service_details", "0")
            add_win_toggle("Display Mark Paid/Unpaid Option In Transactions", "win_show_mark_paid", "1")
            add_win_toggle("Open All Weblinks In Internet Explorer", "win_open_ie", "0")

            # Path For Opening Local Company (cascade)
            path_menu = tk.Menu(win_menu, tearoff=0, font=FONT, bg=WHITE, activebackground=BLUE_SEL, activeforeground=WHITE)
            win_menu.add_cascade(label="Path For Opening Local Company", menu=path_menu)
            
            def set_path():
                from tkinter import filedialog
                p = filedialog.askdirectory(title="Select Local Company Directory", parent=self)
                if p:
                    db.set_setting("win_local_company_path", p)
                    messagebox.showinfo("Success", f"Path set to:\n{p}", parent=self)
            def clear_path():
                db.set_setting("win_local_company_path", "")
                messagebox.showinfo("Success", "Path cleared.", parent=self)
            path_menu.add_command(label="Select Path...", command=set_path)
            path_menu.add_command(label="Clear Path", command=clear_path)

            add_win_toggle("Mandate Place Of Supply", "win_mandate_place_of_supply", "1")
            add_win_toggle("Display Item Detail While Creating Voucher", "win_show_item_detail_creation", "1")

            def create_defaults():
                if messagebox.askyesno("Confirm", "Are you sure you want to create default accounts?", parent=self):
                    conn = db.get_conn()
                    defaults = [
                        ("Cash-in-hand", "cash"),
                        ("Bank A/Cs", "bank"),
                        ("Sales Account", "sales"),
                        ("Purchase Account", "purchase"),
                        ("Sundry Debtors", "customer"),
                        ("Sundry Creditors", "supplier")
                    ]
                    created = 0
                    for name, grp in defaults:
                        row = conn.execute("SELECT aname FROM account_detail WHERE aname=?", (name)).fetchone()
                        if not row:
                            conn.execute("INSERT INTO account_detail (aname, account_group, cl_bal) VALUES (?, ?, 0.0)", (name, grp))
                            created += 1
                    conn.commit()
                    conn.close()
                    self.update_all_views()
                    messagebox.showinfo("Success", f"Created {created} default accounts successfully!", parent=self)

            win_menu.add_command(label="Create Default Accounts", command=create_defaults)
            menu.add_separator()
            
            msg_menu = tk.Menu(menu, tearoff=0, font=FONT, bg=WHITE, activebackground=BLUE_SEL, activeforeground=WHITE)
            
            chk_sms = "☑ " if db.get_setting("msg_auto_sms", "0") == "1" else "☐ "
            msg_menu.add_command(label=chk_sms + "Send Automatic Message", command=lambda: toggle_setting("msg_auto_sms", "0"))
            
            chk_wa = "☑ " if db.get_setting("msg_auto_whatsapp", "0") == "1" else "☐ "
            msg_menu.add_command(label=chk_wa + "Send Automatic WhatsApp", command=lambda: toggle_setting("msg_auto_whatsapp", "0"))
            
            msg_menu.add_command(label="Configure", command=self.open_message_settings)
            
            menu.add_cascade(label=" Message Settings", menu=msg_menu)
            menu.add_separator()
            
            menu.add_command(label=" Email Settings")
            menu.add_separator()
            
            dbg_menu = tk.Menu(menu, tearoff=0, font=FONT, bg=WHITE, activebackground=BLUE_SEL, activeforeground=WHITE)
            menu.add_cascade(label=" Debugging", menu=dbg_menu)
            
            menu.post(event.widget.winfo_rootx(), event.widget.winfo_rooty() + event.widget.winfo_height())

        def show_tools_menu(event):
            menu = tk.Menu(self, tearoff=0, font=FONT, bg=WHITE, activebackground=BLUE_SEL, activeforeground=WHITE)
            menu.add_command(label=" Bank Reconciliation")
            menu.add_command(label=" Payroll")
            menu.add_separator()
            menu.add_command(label=" Import Item/Service From Excel", command=lambda: excel_import.open_import_items_dialog(self))
            menu.add_command(label=" Import Customer/Supplier From Excel", command=lambda: excel_import.open_import_accounts_dialog(self))
            menu.add_command(label=" Import Transactions From Excel", command=lambda: excel_import.open_import_items_dialog(self))
            menu.add_separator()
            menu.add_command(label=" Cheque Printing")
            menu.add_command(label=" Cheque Manager")
            menu.add_separator()
            menu.add_command(label=" Item Barcode Printing")
            menu.add_command(label=" Envelope Printing")
            menu.post(event.widget.winfo_rootx(), event.widget.winfo_rooty() + event.widget.winfo_height())

        for m in ["Settings", "Tools", "Addons", "Help"]:
            lbl = tk.Label(bar1, text=f"  {m}  ", bg=BG, fg="#000",
                           font=FONT, cursor="hand2", padx=2)
            lbl.pack(side="left")
            lbl.bind("<Leave>", lambda e, l=lbl: l.config(bg=BG))
            if m == "Settings":
                lbl.bind("<Enter>", lambda e, l=lbl: [l.config(bg=BG_DARK), show_settings_menu(e)])
                lbl.bind("<Button-1>", show_settings_menu)
            elif m == "Tools":
                lbl.bind("<Enter>", lambda e, l=lbl: [l.config(bg=BG_DARK), show_tools_menu(e)])
                lbl.bind("<Button-1>", show_tools_menu)
            else:
                lbl.bind("<Enter>", lambda e, l=lbl: l.config(bg=BG_DARK))
        # Right: Universal Search
        tk.Label(bar1, text="🔍 Ctrl+F: Universal Search",
                 bg=BG, fg="#333", font=FONT).pack(side="right", padx=6)

        # Separator line
        tk.Frame(self, bg="#808080", height=1).pack(fill="x")

        # ── Row 2: Status bar ─────────────────────────────────────────────────
        bar2 = tk.Frame(self, bg=BG)
        bar2.pack(fill="x", side="top")

        if not self.active_company_path:
            tk.Label(bar2, text="Ctrl+N: New Company | Ctrl+O: Open Company",
                     bg=BG, fg="#000", font=FONT).pack(side="left", padx=5)
        else:
            ef2 = tk.Frame(bar2, bg=RED)
            ef2.pack(side="left", padx=(4, 0), pady=1)
            tk.Label(ef2, text="✕", bg=RED, fg=WHITE,
                     font=("Tahoma", 7), padx=1).pack()
            
            tk.Label(bar2, text=" Company File Is Local, Not Syncing",
                     bg=BG, fg="#000", font=FONT).pack(side="left")
            user_display_name = getattr(self, 'current_user', {}).get('username', 'Admin') if getattr(self, 'current_user', None) else 'Admin'
            tk.Label(bar2, text=f"   \u263A Logged In As {user_display_name}",
                     bg=BG, fg="#000", font=FONT).pack(side="left")
            tk.Label(bar2, text="↻ Shift+F5: Import User Data ▼",
                     bg=BG, fg="#333", font=FONT).pack(side="right", padx=6)

        # Final separator (thicker)
        tk.Frame(self, bg="#808080", height=2).pack(fill="x")

    def _build_sidebar(self):
        f = self.sidebar_frame

        canvas = tk.Canvas(f, bg=BG, highlightthickness=0)
        canvas.pack(fill="both", expand=True)

        inner = tk.Frame(canvas, bg=BG)
        cw = canvas.create_window((0, 0), window=inner, anchor="nw")

        def _on_inner_configure(e):
            canvas.configure(scrollregion=canvas.bbox("all"))

        def _on_canvas_configure(e):
            canvas.itemconfig(cw, width=e.width)

        inner.bind("<Configure>", _on_inner_configure)
        canvas.bind("<Configure>", _on_canvas_configure)

        def _on_mousewheel(e):
            canvas.yview_scroll(-1 * (e.delta // 120), "units")

        canvas.bind("<MouseWheel>", _on_mousewheel)
        inner.bind("<MouseWheel>", _on_mousewheel)

        def add_section(title, bold=True, italic=False, cmd=None):
            font = ("Segoe UI", 8, "bold italic" if italic else "bold") if bold else ("Segoe UI", 8)
            lbl = tk.Label(inner, text=title, bg=BG, fg="#555555",
                           font=font, anchor="w", padx=10)
            lbl.pack(fill="x", pady=(6, 2))
            lbl.bind("<MouseWheel>", _on_mousewheel)
            if cmd:
                lbl.config(cursor="hand2")
                lbl.bind("<Button-1>", lambda e, c=cmd: c())
                lbl.bind("<Enter>", lambda e, l=lbl: l.config(bg="#dbe5f1"))
                lbl.bind("<Leave>", lambda e, l=lbl: l.config(bg=BG))

        def add_item(icon_key, label, cmd):
            row = tk.Frame(inner, bg=BG, cursor="hand2")
            row.pack(fill="x", pady=0)
            img = self.icons_cache.get(icon_key) if hasattr(self, 'icons_cache') else None
            if img:
                lbl_img = tk.Label(row, image=img, bg=BG, cursor="hand2")
                lbl_img.image = img
                lbl_img.pack(side="left", padx=(8, 6), pady=1)
            else:
                lbl_img = tk.Label(row, text="", bg=BG, width=3)
                lbl_img.pack(side="left", padx=(8, 6), pady=1)
                
            lbl = tk.Label(row, text=label, bg=BG, fg="#2a2a2a",
                           font=("Segoe UI", 10), anchor="w", cursor="hand2")
            lbl.pack(side="left", fill="x", expand=True, pady=1)

            for w in (row, lbl_img, lbl):
                w.bind("<Button-1>", lambda e, c=cmd: c())
                w.bind("<Enter>", lambda e, r=row, li=lbl_img, l=lbl: (r.config(bg="#dbe5f1"), li.config(bg="#dbe5f1"), l.config(bg="#dbe5f1")))
                w.bind("<Leave>", lambda e, r=row, li=lbl_img, l=lbl: (r.config(bg=BG), li.config(bg=BG), l.config(bg=BG)))
                w.bind("<MouseWheel>", _on_mousewheel)

        add_section("HOME")
        add_item("dashboard", "Dashboard", self.show_dashboard)
        
        add_section("ACCOUNTS")
        add_item("customer", "Customers/Debtors",   self.show_customers)
        add_item("supplier", "Suppliers/Creditors", self.show_suppliers)
        add_item("accounts", "All Accounts",        self.show_all_accounts)

        def open_transactions_window():
            try:
                import transactions_window
                transactions_window.TransactionsWindow(self)
            except Exception as e:
                import traceback
                print(traceback.format_exc())

        add_section("TRANSACTIONS", cmd=open_transactions_window)

        add_section("INVENTORY")
        add_item("inventory", "Inventory Item",      self.show_inventory)
        add_item("unit",  "Unit Of Measure",    self.show_units)
        add_item("service", "Service",             self.show_service)

        add_section("REPORTS", bold=True, italic=False)
        rpt_items = [
            ("balance", "Balance Sheet",             self.show_balance_sheet),
            ("profit", "Profit and Loss",           self.show_profit_loss),
            ("ledger", "Account Statement/Ledger",  self.show_ledger),
            ("daybook", "Day Book",                  self.show_daybook),
            ("sales", "Sales Register",            self.show_sales_register),
            ("invdet", "Inventory Item Details",    self.show_inventory_details),
            ("invsum", "Inventory Summary",         self.show_inventory_summary),
            ("tax", "Tax Register",              self.show_tax_register),
            ("allrep", "All Reports",               self.show_all_reports),
        ]
        for icon_key, label, cmd in rpt_items:
            add_item(icon_key, label, cmd)

    def _build_right_panel(self):
        f = self.right_frame

        canvas = tk.Canvas(f, bg=BG, highlightthickness=0)
        canvas.pack(fill="both", expand=True)

        inner = tk.Frame(canvas, bg=BG)
        cw = canvas.create_window((0, 0), window=inner, anchor="nw")
        inner.bind("<Configure>",
                   lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>",
                    lambda e: canvas.itemconfig(cw, width=e.width))
        canvas.bind("<MouseWheel>",
                    lambda e: canvas.yview_scroll(-1*(e.delta//120), "units"))
        inner.bind("<MouseWheel>",
                   lambda e: canvas.yview_scroll(-1*(e.delta//120), "units"))

        def row_link(key, label, bold=False, arrow=True, command=None):
            fr = tk.Frame(inner, bg=BG)
            fr.pack(fill="x")
            tk.Frame(fr, bg="#bbb", height=1).pack(fill="x")
            r = tk.Frame(fr, bg=BG)
            r.pack(fill="x", padx=3, pady=2)
            txt = f"{key} {label}"
            lbl = tk.Label(r, text=txt, bg=BG, fg="#000000",
                           font=("Tahoma", 8, "bold") if bold else ("Tahoma", 8),
                           anchor="w", cursor="hand2",
                           wraplength=175, justify="left")
            lbl.pack(side="left", fill="x", expand=True)
            arr_lbl = None
            if arrow:
                arr_lbl = tk.Label(r, text="▶", bg=BG, fg="#555",
                                   font=("Segoe UI", 10), cursor="hand2")
                arr_lbl.pack(side="right")
            widgets_to_bind = [fr, r, lbl]
            if arr_lbl:
                widgets_to_bind.append(arr_lbl)
            for w in widgets_to_bind:
                w.bind("<Enter>", lambda e, x=fr: x.config(bg="#b8c0d0"))
                w.bind("<Leave>", lambda e, x=fr: x.config(bg=BG))
                if command:
                    w.bind("<Button-1>", lambda e, c=command: c())

        def sep():
            tk.Frame(inner, bg="#999", height=10).pack(fill="x", pady=0)

        row_link("Alt+F1:", "Switch Company/New Company", arrow=False, command=self.close_company)

        # ── Reporting Period ─────────────────────────────────────────────────
        pf = tk.Frame(inner, bg="#e0e0f0")
        pf.pack(fill="x")
        tk.Frame(pf, bg="#bbb", height=1).pack(fill="x")
        tk.Label(pf, text="Alt+F2: Reporting Period",
                 bg="#e0e0f0", fg="#000",
                 font=("Tahoma", 8, "bold"), anchor="w",
                 padx=4).pack(fill="x", pady=(4, 2))

        today = datetime.date.today()
        fy_start = datetime.date(
            today.year if today.month >= 4 else today.year - 1, 4, 1)

        from custom_calendar import DateEntry
        
        # From Date
        rr1 = tk.Frame(pf, bg="#e0e0f0")
        rr1.pack(fill="x", padx=4, pady=1)
        tk.Label(rr1, text="From", bg="#e0e0f0", fg="#000",
                 font=("Segoe UI", 10), width=5, anchor="w").pack(side="left")
        self.reporting_from_dp = DateEntry(rr1)
        self.reporting_from_dp.set_date(fy_start)
        self.reporting_from_dp.pack(side="left", fill="x", expand=True)

        # To Date
        rr2 = tk.Frame(pf, bg="#e0e0f0")
        rr2.pack(fill="x", padx=4, pady=1)
        tk.Label(rr2, text="To", bg="#e0e0f0", fg="#000",
                 font=("Segoe UI", 10), width=5, anchor="w").pack(side="left")
        self.reporting_to_dp = DateEntry(rr2)
        self.reporting_to_dp.set_date(today)
        self.reporting_to_dp.pack(side="left", fill="x", expand=True)
        
        tk.Frame(pf, bg="#e0e0f0", height=4).pack()

        active_dropdowns = []

        def create_dropdown_link(key, label, create_cmd, view_cmd):
            state = {"expanded": False, "sub_frame": None}

            outer = tk.Frame(inner, bg=BG)
            outer.pack(fill="x")
            tk.Frame(outer, bg="#bbb", height=1).pack(fill="x")
            row = tk.Frame(outer, bg=BG)
            row.pack(fill="x", padx=3, pady=2)
            lbl = tk.Label(row, text=f"{key} {label}", bg=BG, fg="#000000",
                           font=("Tahoma", 8, "bold"), anchor="w", cursor="hand2")
            lbl.pack(side="left", fill="x", expand=True)
            arrow = tk.Label(row, text="▶", bg=BG, fg="#555", font=("Segoe UI", 10))
            arrow.pack(side="right")

            def close_dropdown():
                if state["sub_frame"] and state["sub_frame"].winfo_exists():
                    state["sub_frame"].destroy()
                    state["sub_frame"] = None
                    arrow.config(text="▶")

            def toggle(e=None):
                if state["sub_frame"] and state["sub_frame"].winfo_exists():
                    close_dropdown()
                else:
                    # Close all other dropdowns
                    for other_close in active_dropdowns:
                        other_close()
                    
                    sub = tk.Frame(inner, bg="#e8eef8", relief="flat", bd=0)
                    sub.pack(fill="x", after=outer)
                    state["sub_frame"] = sub
                    arrow.config(text="▼")

                    def make_sub_row(sub_label, cmd):
                        sr = tk.Frame(sub, bg="#e8eef8")
                        sr.pack(fill="x")
                        tk.Frame(sr, bg="#ccd", height=1).pack(fill="x")
                        r2 = tk.Frame(sr, bg="#e8eef8")
                        r2.pack(fill="x", padx=6, pady=3)
                        lbl2 = tk.Label(r2, text=sub_label, bg="#e8eef8", fg="#000000",
                                        font=("Segoe UI", 10), anchor="w", cursor="hand2")
                        lbl2.pack(side="left", fill="x", expand=True)
                        for w2 in (sr, r2, lbl2):
                            w2.bind("<Button-1>", lambda ev, c=cmd: [close_dropdown(), c()])
                            w2.bind("<Enter>", lambda ev, x=sr: x.config(bg="#aabbdd"))
                            w2.bind("<Leave>", lambda ev, x=sr: x.config(bg="#e8eef8"))

                    make_sub_row("Create", create_cmd)
                    make_sub_row("View",   view_cmd)

            active_dropdowns.append(close_dropdown)

            for w in (outer, row, lbl, arrow):
                w.bind("<Button-1>", toggle)
                w.bind("<Enter>", lambda e, x=outer: x.config(bg="#b8c0d0"))
                w.bind("<Leave>", lambda e, x=outer: x.config(bg=BG))

        def coming_soon():
            messagebox.showinfo("Coming Soon", "This feature is coming soon!", parent=self)

        create_dropdown_link("Alt+E:", "Expense", self._open_expense_voucher, lambda: self.show_invoices("expense"))
        create_dropdown_link("Alt+I:", "Income", self._open_income_voucher, lambda: self.show_invoices("income"))
        create_dropdown_link("F4:", "Contra", self._open_contra_voucher, lambda: self.show_invoices("contra"))
        create_dropdown_link("F5:", "Payment To Supplier", self._open_payment_supplier, lambda: self.show_invoices("payment"))
        create_dropdown_link("F6:", "Receipt From Customer", self._open_receipt_customer, lambda: self.show_invoices("receipt"))
        create_dropdown_link("F7:", "Journal", self._open_journal_voucher, lambda: self.show_invoices("journal"))
        create_dropdown_link("F8:", "Sale/Invoice/Bill", lambda: self._open_create_voucher("sale"), lambda: self.show_invoices("sale"))
        create_dropdown_link("F9:", "Purchase", lambda: self._open_create_voucher("purchase"), lambda: self.show_invoices("purchase"))
        create_dropdown_link("Alt+F4:", "Purchase Order", lambda: self._open_create_voucher("purchase_order"), lambda: self.show_invoices("purchase_order"))
        create_dropdown_link("Alt+F5:", "Estimate", lambda: self._open_create_voucher("estimate"), lambda: self.show_invoices("estimate"))
        row_link("Alt+V:", "Estimate Templates", arrow=False, command=self.show_estimate_templates)
        create_dropdown_link("Alt+F8:", "Credit Note/Sales Return", self._open_credit_note_window, lambda: self.show_invoices("credit_note"))
        create_dropdown_link("Alt+F9:", "Debit Note/Purchase Return", self._open_debit_note_window, lambda: self.show_invoices("debit_note"))
        sep()
        row_link("Alt+T:", "View All Transactions", arrow=False, command=lambda: self.show_invoices("all"))
        row_link("Alt+M:", "Manage Category/Subcategory", arrow=False, command=lambda: category.CategorySubcategoryWindow(self, app=self))
        row_link("Alt+S:", "Item Stock Level Enquiry", arrow=False, command=self.open_inventory_stock_level)

    # ── Page helpers ──────────────────────────────────────────────────────────
    def _clear_main(self):
        for w in self.main_frame.winfo_children():
            w.destroy()

    def _make_tab_header(self, title):
        # Tab strip
        strip = tk.Frame(self.main_frame, bg=BG)
        strip.pack(fill="x")
        tk.Frame(strip, bg=BG, width=4).pack(side="left")
        tab = tk.Frame(strip, bg=WHITE, relief="raised", bd=1)
        tab.pack(side="left", pady=(3, 0))
        tk.Label(tab, text=title, bg=WHITE, fg="#000",
                 font=FONT_BOLD, padx=12, pady=3).pack()
        tk.Frame(self.main_frame, bg="#808080", height=1).pack(fill="x")

        # Mini toolbar
        tb = tk.Frame(self.main_frame, bg=BG)
        tb.pack(fill="x")
        ef = tk.Frame(tb, bg=RED)
        ef.pack(side="left", padx=4, pady=2)
        tk.Label(ef, text="✕", bg=RED, fg=WHITE,
                 font=("Tahoma", 7, "bold"), padx=2).pack()
        tk.Label(tb, text=" Ctrl+Q: Exit", bg=BG, fg=RED,
                 font=("Tahoma", 8, "bold"), cursor="hand2").pack(side="left")
        tk.Label(tb, text="    ⚡ Ctrl+R: Reload/Refresh", bg=BG,
                 fg="#007700", font=("Tahoma", 8, "bold"),
                 cursor="hand2").pack(side="left")
        tk.Frame(self.main_frame, bg="#aaa", height=1).pack(fill="x")

    def _make_scrollable(self):
        """Returns (outer_frame, inner_frame, canvas) — inner is where you add widgets."""
        outer = tk.Frame(self.main_frame, bg=WHITE, relief="sunken", bd=1)
        outer.pack(fill="both", expand=True)

        canvas = tk.Canvas(outer, bg=WHITE, highlightthickness=0)
        vsb = ttk.Scrollbar(outer, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)

        inner = tk.Frame(canvas, bg=WHITE)
        cw = canvas.create_window((0, 0), window=inner, anchor="nw")

        def _on_frame_configure(e):
            canvas.configure(scrollregion=canvas.bbox("all"))

        def _on_canvas_configure(e):
            canvas.itemconfig(cw, width=e.width)

        inner.bind("<Configure>", _on_frame_configure)
        canvas.bind("<Configure>", _on_canvas_configure)
        canvas.bind("<MouseWheel>",
                    lambda e: canvas.yview_scroll(-1*(e.delta//120), "units"))
        return outer, inner, canvas

    # ═════════════════════════════════════════════════════════════════════════
    #  DASHBOARD
    # ════════════════════════════════════════════════════
    def init_icons(self):
        self.icons_cache = {}
        from PIL import Image, ImageTk
        import os
        import sys
        if getattr(sys, 'frozen', False) and hasattr(sys, '_MEIPASS'):
            base_dir = sys._MEIPASS
        else:
            base_dir = os.path.dirname(os.path.abspath(__file__))
        icons_dir = os.path.join(base_dir, "icons")
        if os.path.exists(icons_dir):
            for file in os.listdir(icons_dir):
                if file.endswith(".png"):
                    key = file.replace(".png", "")
                    try:
                        img = Image.open(os.path.join(icons_dir, file)).resize((24, 24), Image.Resampling.LANCZOS)
                        self.icons_cache[key] = ImageTk.PhotoImage(img)
                    except Exception as e:
                        print(f"Error loading icon {file}: {e}")

    def show_daybook(self):
        import report_daybook
        import importlib
        importlib.reload(report_daybook)
        report_daybook.ReportDaybook(self, is_post_dated=False)

    def show_post_dated_vouchers(self):
        import report_daybook
        import importlib
        importlib.reload(report_daybook)
        report_daybook.ReportDaybook(self, is_post_dated=True)
        
    def show_cash_flow(self):
        try:
            start_d = self.reporting_from_dp.get_date().strftime("%Y-%m-%d")
            end_d = self.reporting_to_dp.get_date().strftime("%Y-%m-%d")
        except:
            import datetime
            start_d = datetime.date(datetime.date.today().year, 4, 1).strftime("%Y-%m-%d")
            end_d = datetime.date.today().strftime("%Y-%m-%d")
            
        import report_cash_flow
        import importlib
        importlib.reload(report_cash_flow)
        report_cash_flow.ReportCashFlow(self, start_d, end_d)

    # ═════════════════════
    def show_dashboard(self):
        self._clear_main()
        self._make_tab_header("Today")
        _, inner, canvas = self._make_scrollable()

        # ── Heading row ──────────────────────────────────────────────────────
        heading = tk.Frame(inner, bg=WHITE)
        heading.pack(fill="x", padx=14, pady=(12, 8))
        tk.Label(heading, text=self.company_name, bg=WHITE, fg="#000",
                 font=("Tahoma", 16, "bold")).pack(side="left")
        tk.Label(heading, text="Today", bg=WHITE, fg=GREEN_DARK,
                 font=("Tahoma", 16, "bold")).pack(side="right", padx=14)

        # ── Top row: boxes + table ────────────────────────────────────────────
        top = tk.Frame(inner, bg=WHITE)
        top.pack(fill="x", padx=14)

        # Left column: invoice boxes + bars
        left = tk.Frame(top, bg=WHITE)
        left.pack(side="left", anchor="n")

        boxes = tk.Frame(left, bg=WHITE)
        boxes.pack()

        overdue = db.get_overdue_invoices_count()
        overdue_amt = db.get_overdue_invoices_sum()
        unpaid  = db.get_unpaid_invoices_count()
        unpaid_amt = db.get_unpaid_invoices_sum()
        
        self._invoice_box(boxes, "Overdue Invoices", overdue, format_amt(overdue_amt, show_symbol=False).replace("Rs ", "").replace("Rs", ""), "#c0504d")
        tk.Frame(boxes, bg=WHITE, width=10).pack(side="left")
        self._invoice_box(boxes, "Unpaid Invoices", unpaid, format_amt(unpaid_amt, show_symbol=False).replace("Rs ", "").replace("Rs", ""), "#f79646")

        cash_c = db.get_today_cash_collection()
        bank_c = db.get_today_bank_collection()
        tk.Frame(left, bg=WHITE, height=6).pack()
        self._bar(left, "Today's Cash Collection:", format_amt(cash_c), "#3cb371")
        tk.Frame(left, bg=WHITE, height=4).pack()
        self._bar(left, "Today's Bank Collection:", format_amt(bank_c), "#2e8b57")

        # Right column: account table
        right = tk.Frame(top, bg=WHITE)
        right.pack(side="left", padx=28, anchor="n")
        self._account_table(right)

        # ── Daily Cash Flow Chart ─────────────────────────────────────────────
        chart_card = tk.Frame(inner, bg=WHITE, relief="solid", bd=1, highlightbackground="#cbd5e1", highlightthickness=1)
        chart_card.pack(fill="x", padx=14, pady=(16, 20))

        # Header: Title + Legend
        chart_header = tk.Frame(chart_card, bg=WHITE)
        chart_header.pack(fill="x", padx=16, pady=(14, 6))

        # Title: "Daily Cash Flow"
        tk.Label(chart_header, text="Daily Cash Flow", bg=WHITE, fg="#0f172a",
                 font=("Segoe UI", 13, "bold")).pack(anchor="center")

        # Legend: Cash (light blue) and Bank (light green)
        legend_fr = tk.Frame(chart_header, bg=WHITE)
        legend_fr.pack(anchor="center", pady=(6, 2))

        c_box = tk.Frame(legend_fr, bg="#93c5fd", relief="solid", bd=1, highlightbackground="#3b82f6", highlightthickness=1, width=24, height=12)
        c_box.pack(side="left", padx=(0, 6))
        c_box.pack_propagate(False)
        tk.Label(legend_fr, text="Cash", bg=WHITE, fg="#334155", font=("Segoe UI", 9, "bold")).pack(side="left", padx=(0, 20))

        b_box = tk.Frame(legend_fr, bg="#86efac", relief="solid", bd=1, highlightbackground="#22c55e", highlightthickness=1, width=24, height=12)
        b_box.pack(side="left", padx=(0, 6))
        b_box.pack_propagate(False)
        tk.Label(legend_fr, text="Bank", bg=WHITE, fg="#334155", font=("Segoe UI", 9, "bold")).pack(side="left")

        # Canvas
        self._chart_canvas = tk.Canvas(chart_card, bg=WHITE,
                                       height=340,
                                       highlightthickness=0)
        self._chart_canvas.pack(fill="x", expand=True, padx=12, pady=(4, 14))

        # Chart state
        self._chart_hover_idx = None
        self._chart_data = []
        self._chart_plot_meta = {}

        # Draw chart on resize / configure & interactive hover events
        self._chart_canvas.bind("<Configure>", self._draw_chart)
        self._chart_canvas.bind("<Motion>", self._on_chart_hover)
        self._chart_canvas.bind("<Leave>", self._on_chart_leave)

    def _invoice_box(self, parent, label, count, amount, color):
        box = tk.Frame(parent, bg=color, width=160, height=160)
        box.pack(side="left")
        box.pack_propagate(False)
        tk.Label(box, text=str(count), bg=color, fg=WHITE,
                 font=("Segoe UI", 36)).pack(pady=(10, 0))
        tk.Label(box, text=label, bg=color, fg=WHITE,
                 font=("Segoe UI", 12)).pack()
        tk.Label(box, text=amount, bg=color, fg=WHITE,
                 font=("Segoe UI", 12)).pack(pady=(10, 0))

    def _bar(self, parent, label, value, color):
        bar = tk.Frame(parent, bg=color, width=330, height=35)
        bar.pack(anchor="w")
        bar.pack_propagate(False)
        r = tk.Frame(bar, bg=color)
        r.pack(fill="x", padx=10, pady=5)
        tk.Label(r, text=label, bg=color, fg=WHITE, font=("Segoe UI", 11)).pack(side="left")
        tk.Label(r, text=value, bg=color, fg=WHITE, font=("Segoe UI", 11)).pack(side="right")

    def _account_table(self, parent):
        # Header
        hdr = tk.Frame(parent, bg="#e0e0e0", relief="raised", bd=1)
        hdr.pack(fill="x")
        tk.Label(hdr, text="Account", bg="#e0e0e0", fg="#000",
                 font=FONT_BOLD, width=22, anchor="w",
                 padx=6, pady=4).pack(side="left")
        tk.Label(hdr, text="Amount", bg="#e0e0e0", fg="#000",
                 font=FONT_BOLD, width=12, anchor="e",
                 padx=6, pady=4).pack(side="right")

        rows = db.get_dashboard_accounts()
        for i, row in enumerate(rows):
            name = row[0]; amt = row[1]
            is_first = (i == 0)
            bg_r = BLUE_SEL if is_first else (WHITE if i % 2 == 0 else "#f8f9fa")
            fg_r = BLUE_SEL_FG if is_first else (RED if amt < 0 else GREEN_DARK if amt > 0 else "#111827")

            r = tk.Frame(parent, bg=bg_r)
            r.pack(fill="x")
            tk.Label(r, text=name, bg=bg_r, fg=fg_r,
                     font=FONT, width=22, anchor="w",
                     padx=8, pady=6).pack(side="left")
            tk.Label(r, text=f"{amt:,.0f}", bg=bg_r, fg=fg_r,
                     font=FONT, width=12, anchor="e",
                     padx=8, pady=6).pack(side="right")
            tk.Frame(parent, bg="#e2e8f0", height=1).pack(fill="x")

    def _calc_nice_ticks(self, min_val, max_val, max_ticks=5):
        import math
        if min_val > 0:
            min_val = 0.0
        if max_val < 0:
            max_val = 0.0
        if min_val == max_val:
            return [-1000.0, 0.0, 1000.0], -1000.0, 1000.0

        span = max_val - min_val
        raw_step = span / max_ticks
        magnitude = 10 ** math.floor(math.log10(raw_step)) if raw_step > 0 else 1.0
        fraction = raw_step / magnitude if magnitude > 0 else 1.0

        if fraction <= 1.5:
            step = 1.0 * magnitude
        elif fraction <= 3.0:
            step = 2.0 * magnitude
        elif fraction <= 7.0:
            step = 5.0 * magnitude
        else:
            step = 10.0 * magnitude

        low = math.floor(min_val / step) * step
        high = math.ceil(max_val / step) * step

        ticks = []
        curr = low
        while curr <= high + (step * 0.01):
            ticks.append(round(curr, 2))
            curr += step

        if 0.0 not in [round(t, 2) for t in ticks] and low < 0 and high > 0:
            ticks.append(0.0)
            ticks = sorted(set(ticks))

        return ticks, low, high

    def _format_date_pk(self, d_str):
        """Converts date string to standard Pakistani format DD/MM/YYYY."""
        if not d_str:
            return ""
        import datetime
        d_clean = str(d_str).strip()
        for fmt in ('%Y-%m-%d', '%B %d, %Y', '%b %d, %Y', '%d-%m-%Y', '%d/%m/%Y', '%Y/%m/%d'):
            try:
                dt = datetime.datetime.strptime(d_clean, fmt)
                return dt.strftime('%d/%m/%Y')
            except Exception:
                pass
        return d_clean

    def _draw_chart(self, event=None):
        c = self._chart_canvas
        c.delete("all")
        c.update_idletasks()
        W = c.winfo_width()
        H = c.winfo_height()
        if W < 80 or H < 80:
            return

        padL, padR, padT, padB = 115, 30, 25, 90
        cW = W - padL - padR
        cH = H - padT - padB

        data = db.get_daily_cash_flow(limit=25)
        self._chart_data = data or []
        if not data:
            c.create_text(W / 2, H / 2, text="No daily cash flow transactions found",
                          font=("Segoe UI", 11), fill="#64748b")
            return

        n = len(data)
        all_vals = [d['cash'] for d in data] + [d['bank'] for d in data]
        min_v_raw = min(all_vals) if all_vals else 0.0
        max_v_raw = max(all_vals) if all_vals else 1000.0

        ticks, min_v, max_v = self._calc_nice_ticks(min_v_raw, max_v_raw, 5)
        rng = max_v - min_v if max_v != min_v else 1.0

        # Inset margin so first & last points have breathing room and dates never collide with Y-axis
        x_inset = max(24, min(42, int(cW / n * 0.45)))
        plot_w = cW - (2 * x_inset)

        def px(i):
            return padL + x_inset + (i / (n - 1)) * plot_w if n > 1 else padL + cW / 2

        def py(v):
            return padT + ((max_v - v) / rng) * cH

        bar_w = max(6, min(18, int(plot_w / n * 0.32)))

        self._chart_plot_meta = {
            'W': W, 'H': H, 'padL': padL, 'padR': padR, 'padT': padT, 'padB': padB,
            'cW': cW, 'cH': cH, 'n': n, 'px': px, 'py': py, 'y_base': py(0.0),
            'bar_w': bar_w, 'x_inset': x_inset, 'plot_w': plot_w
        }

        # 1. Gridlines & Y-Axis Labels
        for tick in ticks:
            y = py(tick)
            if abs(tick) < 0.001:
                # 0 baseline
                c.create_line(padL, y, padL + cW, y, fill="#94a3b8", width=1.5)
            else:
                c.create_line(padL, y, padL + cW, y, fill="#f1f5f9", width=1)

            txt = f"Rs {tick:,.0f}" if abs(tick) >= 1000 else f"Rs {tick:,.2f}"
            c.create_text(padL - 10, y, text=txt, anchor="e",
                          font=("Segoe UI", 8, "bold" if abs(tick) < 0.001 else "normal"),
                          fill="#1e293b" if abs(tick) < 0.001 else "#64748b")

        # 2. X-Axis Pakistani Date Labels (DD/MM/YYYY) & Ticks
        for i, item in enumerate(data):
            x = px(i)
            raw_d = item.get('date', '')
            lbl = self._format_date_pk(raw_d)
            c.create_text(x + 2, padT + cH + 8, text=lbl,
                          anchor="ne", font=("Segoe UI", 8), angle=315, fill="#334155")
            c.create_line(x, padT + cH - 3, x, padT + cH + 4, fill="#94a3b8", width=1)

        # 3. Draw Combination Bars (Cash & Bank)
        y_base = py(0.0)
        for i, item in enumerate(data):
            x = px(i)
            v_cash = item['cash']
            v_bank = item['bank']

            # Cash Bar (left half)
            y_c = py(v_cash)
            if v_cash >= 0:
                c.create_rectangle(x - bar_w, y_c, x, y_base,
                                   fill="#93c5fd", outline="#3b82f6", width=1)
            else:
                c.create_rectangle(x - bar_w, y_base, x, y_c,
                                   fill="#fca5a5", outline="#ef4444", width=1)

            # Bank Bar (right half)
            y_b = py(v_bank)
            if v_bank >= 0:
                c.create_rectangle(x, y_b, x + bar_w, y_base,
                                   fill="#86efac", outline="#22c55e", width=1)
            else:
                c.create_rectangle(x, y_base, x + bar_w, y_b,
                                   fill="#fca5a5", outline="#ef4444", width=1)

        # 4. Connecting Lines
        cash_pts = []
        for i, item in enumerate(data):
            cash_pts.extend([px(i) - bar_w / 2, py(item['cash'])])
        if len(cash_pts) >= 4:
            c.create_line(cash_pts, fill="#2563eb", width=2)

        bank_pts = []
        for i, item in enumerate(data):
            bank_pts.extend([px(i) + bar_w / 2, py(item['bank'])])
        if len(bank_pts) >= 4:
            c.create_line(bank_pts, fill="#16a34a", width=2)

        # 5. Circular Data Points
        for i, item in enumerate(data):
            # Cash marker
            x_c = px(i) - bar_w / 2
            y_c = py(item['cash'])
            col_c = "#ef4444" if item['cash'] < 0 else "#1d4ed8"
            c.create_oval(x_c - 4, y_c - 4, x_c + 4, y_c + 4,
                          fill=col_c, outline="#ffffff", width=1.5)

            # Bank marker
            x_b = px(i) + bar_w / 2
            y_b = py(item['bank'])
            col_b = "#ef4444" if item['bank'] < 0 else "#15803d"
            c.create_oval(x_b - 4, y_b - 4, x_b + 4, y_b + 4,
                          fill=col_b, outline="#ffffff", width=1.5)

        # 6. Border lines
        c.create_line(padL, padT, padL, padT + cH, fill="#e2e8f0")
        c.create_line(padL, padT + cH, padL + cW, padT + cH, fill="#e2e8f0")

    def _on_chart_hover(self, event):
        if not hasattr(self, '_chart_data') or not self._chart_data or not hasattr(self, '_chart_plot_meta') or not self._chart_plot_meta:
            return

        c = self._chart_canvas
        padL = self._chart_plot_meta['padL']
        cW = self._chart_plot_meta['cW']
        n = self._chart_plot_meta['n']
        px = self._chart_plot_meta['px']
        H = self._chart_plot_meta['H']
        padT = self._chart_plot_meta['padT']
        padB = self._chart_plot_meta['padB']

        if not (padL - 25 <= event.x <= padL + cW + 25 and padT - 10 <= event.y <= H - padB + 30):
            self._on_chart_leave(event)
            return

        closest_idx = 0
        min_dist = float('inf')
        for i in range(n):
            dist = abs(event.x - px(i))
            if dist < min_dist:
                min_dist = dist
                closest_idx = i

        if closest_idx != getattr(self, '_chart_hover_idx', None) or not c.find_withtag("hover_elem"):
            self._chart_hover_idx = closest_idx
            c.delete("hover_elem")

            item = self._chart_data[closest_idx]
            cx = px(closest_idx)

            # Draw vertical guide line
            c.create_line(cx, padT, cx, H - padB, fill="#64748b", dash=(3, 3), width=1.2, tags="hover_elem")

            # Data
            raw_d = item.get('date', '')
            d_str = self._format_date_pk(raw_d)
            cash_val = item.get('cash', 0.0)
            bank_val = item.get('bank', 0.0)
            net_val = item.get('total', cash_val + bank_val)

            # Tooltip dimensions & location
            tw, th = 185, 90
            tx = cx + 14 if cx + tw + 20 < self._chart_plot_meta['W'] else cx - tw - 14
            ty = max(padT + 5, min(event.y - th / 2, H - padB - th - 5))

            # Shadow & Card
            c.create_rectangle(tx + 2, ty + 2, tx + tw + 2, ty + th + 2,
                               fill="#0f172a", outline="", tags="hover_elem")
            c.create_rectangle(tx, ty, tx + tw, ty + th,
                               fill="#1e293b", outline="#475569", width=1.5, tags="hover_elem")

            # Content inside Tooltip
            c.create_text(tx + 10, ty + 13, text=f"📅 {d_str}", anchor="w",
                          font=("Segoe UI", 9, "bold"), fill="#f8fafc", tags="hover_elem")
            c.create_line(tx + 8, ty + 25, tx + tw - 8, ty + 25, fill="#334155", tags="hover_elem")

            c.create_text(tx + 10, ty + 38, text=f"● Cash: Rs {cash_val:,.2f}", anchor="w",
                          font=("Segoe UI", 8, "bold"), fill="#93c5fd", tags="hover_elem")
            c.create_text(tx + 10, ty + 54, text=f"● Bank: Rs {bank_val:,.2f}", anchor="w",
                          font=("Segoe UI", 8, "bold"), fill="#86efac", tags="hover_elem")
            c.create_text(tx + 10, ty + 70, text=f"● Net:  Rs {net_val:,.2f}", anchor="w",
                          font=("Segoe UI", 8, "bold"), fill="#fde047", tags="hover_elem")

    def _on_chart_leave(self, event=None):
        self._chart_hover_idx = None
        if hasattr(self, '_chart_canvas'):
            self._chart_canvas.delete("hover_elem")

    # ═════════════════════════════════════════════════════════════════════════
    #  ACCOUNTS
    # ═════════════════════════════════════════════════════════════════════════
    def show_customers(self):
        if not self.check_permission("acc_view", "view customers"):
            return
        import accounts_transactions
        accounts_transactions.AccountsTransactionsWindow(self, "customer")

    def show_suppliers(self):
        if not self.check_permission("acc_view", "view suppliers"):
            return
        import accounts_transactions
        accounts_transactions.AccountsTransactionsWindow(self, "supplier")

    def show_all_accounts(self):
        if not self.check_permission("acc_view", "view all accounts"):
            return
        import accounts_transactions
        accounts_transactions.AccountsTransactionsWindow(self, None)

    def _account_list(self, acc_type, title):
        self._clear_main()
        self._make_tab_header(title)
        _, inner, _ = self._make_scrollable()

        tb = tk.Frame(inner, bg=WHITE)
        tb.pack(fill="x", padx=6, pady=6)
        make_button(tb, "  ➕ Add New  ",
                    command=lambda: self._account_form(acc_type or "customer")
                    ).pack(side="left", padx=2)
        make_button(tb, "  ✏ Edit  ",
                    command=lambda: self._edit_selected_account(tree, acc_type)
                    ).pack(side="left", padx=2)
        make_button(tb, "  🗑 Delete  ",
                    command=lambda: self._delete_account(tree)
                    ).pack(side="left", padx=2)

        cols = ("ID", "Name", "Type", "Phone", "Balance")
        tree = ttk.Treeview(inner, columns=cols, show="headings", height=25)
        tree.column("ID", width=40, stretch=False)
        tree.column("Name", width=200)
        tree.column("Type", width=100)
        tree.column("Phone", width=130)
        tree.column("Balance", width=120)
        for col in cols:
            tree.heading(col, text=col)
        vsb = ttk.Scrollbar(inner, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        tree.pack(fill="both", expand=True, padx=6)

        for r in db.get_all_accounts(acc_type):
            tree.insert("", "end", iid=str(r["id"]),
                        values=(r["id"], r["name"], r["type"],
                                r["phone"] or "", format_amt(r['balance'], show_symbol=False)))

        tree.bind("<Double-1>",
                  lambda e: self._edit_selected_account(tree, acc_type))

    def _account_form(self, acc_type=None, existing=None, callback=None):
        ACCOUNT_TYPES = [
            "Cash-in-hand", "Bank A/Cs", "Sundry Debtors", "Sundry Creditors", 
            "Purchases A/C", "Purchases Return", "Sales A/C", "Sales Return", 
            "Capital A/C", "Direct Expenses", "Indirect Expenses", "Direct Income", 
            "Indirect Income", "Current Assets", "Current Liabilities", "Misc. Expenses", 
            "Misc. Income", "Loans (Liability)", "Loans & Advances", "Fixed Assets", 
            "Investments", "Bank OD A/C", "Deposits (Assets)", "Provisions", "Reserves & Surplus"
        ]

        win = tk.Toplevel(self)
        win.resizable(False, False)
        win.configure(bg="#ffffff")
        win.grab_set()

        tk.Label(win, text="Press ENTER to move forward  SHIFT+ENTER to move back.", 
                 fg="darkred", bg="#ffffff", font=(FONT[0], 10, "italic", "bold")).place(x=10, y=5)

        fields = {}
        widgets = []
        party_widgets = []

        def register_widget(w):
            widgets.append(w)
            w.bind("<Return>", lambda e: focus_next(w))
            w.bind("<Shift-Return>", lambda e: focus_prev(w))
            return w

        def focus_next(current):
            try:
                idx = widgets.index(current)
                widgets[(idx + 1) % len(widgets)].focus_set()
            except: pass
            return "break"

        def focus_prev(current):
            try:
                idx = widgets.index(current)
                widgets[(idx - 1) % len(widgets)].focus_set()
            except: pass
            return "break"

        def create_lbl(x, y, text, is_party=False):
            lbl = tk.Label(win, text=text, bg="#ffffff", fg="#000", font=FONT)
            if is_party:
                party_widgets.append((lbl, {'x': x, 'y': y}))
            else:
                lbl.place(x=x, y=y)
            return lbl

        def create_entry(x, y, w, bg="#ffffff", is_party=False):
            e = tk.Entry(win, font=FONT, width=w, relief="solid", bd=1, bg=bg)
            if is_party:
                party_widgets.append((e, {'x': x, 'y': y}))
            else:
                e.place(x=x, y=y)
            return register_widget(e)
            
        def create_combo(x, y, w, vals, is_party=False):
            c = AutocompleteCombobox(win, font=FONT, width=w-2, values=vals)
            if is_party:
                party_widgets.append((c, {'x': x, 'y': y}))
            else:
                c.place(x=x, y=y)
            return register_widget(c)

        cx1, cx2, cx3 = 15, 310, 570

        # --- Column 1 (Common) ---
        create_lbl(cx1, 35, "Account Name")
        fields['aname'] = create_entry(cx1, 55, 28, bg="#ffff00")
        
        lbl_video = tk.Label(win, text="Video: How to Create Group/Subgroup?", fg="blue", bg="#ffffff", font=(FONT[0], 9, "underline"))
        lbl_video.place(x=cx1, y=85)
        
        create_lbl(cx1, 110, "Account Type")
        fields['account_group'] = create_combo(cx1, 130, 28, ACCOUNT_TYPES)
        
        create_lbl(cx1, 160, "Opening balance")
        fields['op_bal'] = create_entry(cx1, 180, 28)
        fields['op_bal'].insert(0, "0")
        
        lbl_bal_hint = tk.Label(win, text="For credit balance of customers,\nEnter amount in negative (-)", bg="#ffffff", fg="#000", justify="left")
        lbl_bal_hint.place(x=cx1, y=205)

        # --- Bank Details (Yellow Banner & collapsible fields) ---
        bank_banner = tk.Frame(win, bg="#ffff00", bd=1, relief="solid")
        bank_var = tk.IntVar(value=0)
        cb_bank = tk.Checkbutton(
            bank_banner, text=" Bank Details", variable=bank_var,
            bg="#ffff00", fg="#000000", activebackground="#ffff00",
            font=(FONT[0], 10, "bold"), selectcolor="#ffffff",
            command=lambda: update_bank_visibility()
        )
        cb_bank.pack(side="left", padx=4, pady=2, fill="both", expand=True)

        lbl_acc_no = tk.Label(win, text="Account Number", bg="#ffffff", fg="#000", font=FONT)
        ent_acc_no = tk.Entry(win, font=FONT, width=13, relief="solid", bd=1, bg="#ffffff")
        fields['acc_number'] = register_widget(ent_acc_no)

        lbl_ifsc = tk.Label(win, text="IFSC Code", bg="#ffffff", fg="#000", font=FONT)
        ent_ifsc = tk.Entry(win, font=FONT, width=13, relief="solid", bd=1, bg="#ffffff")
        fields['ifsc_code'] = register_widget(ent_ifsc)

        lbl_bank_name = tk.Label(win, text="Bank Name  Branch", bg="#ffffff", fg="#000", font=FONT)
        try:
            bank_rows = db.get_all_accounts('bank')
            bank_list = list(set([r['aname'] for r in bank_rows if r.get('aname')]))
        except Exception:
            bank_list = []
        cmb_bank_name = AutocompleteCombobox(win, font=FONT, width=28, values=bank_list)
        fields['bank_name'] = register_widget(cmb_bank_name)

        def update_bank_visibility(*args):
            grp = fields['account_group'].get().strip()
            is_party = (grp in ["Sundry Debtors", "Sundry Creditors"])
            if is_party and bank_var.get() == 1:
                lbl_acc_no.place(x=cx1, y=282)
                ent_acc_no.place(x=cx1, y=302)
                lbl_ifsc.place(x=cx1+135, y=282)
                ent_ifsc.place(x=cx1+135, y=302)
                lbl_bank_name.place(x=cx1, y=332)
                cmb_bank_name.place(x=cx1, y=352)
            else:
                hide_bank_fields()

        def hide_bank_fields():
            lbl_acc_no.place_forget()
            ent_acc_no.place_forget()
            lbl_ifsc.place_forget()
            ent_ifsc.place_forget()
            lbl_bank_name.place_forget()
            cmb_bank_name.place_forget()

        # --- Column 2 (Common) ---
        create_lbl(cx2, 35, "Display Name")
        fields['display_name'] = create_entry(cx2, 55, 25)
        
        create_lbl(cx2, 160, "Account Creation Date")
        if DateEntry:
            de = DateEntry(win, width=23, background='darkblue', foreground='white', borderwidth=2, font=FONT)
            de.place(x=cx2, y=180)
            fields['date_created'] = register_widget(de)
        else:
            fields['date_created'] = create_entry(cx2, 180, 25)
            fields['date_created'].insert(0, datetime.datetime.now().strftime("%B %d, %Y"))

        # --- Column 3 (Party Details: GST, Country, Address, Phone, Email, etc.) ---
        create_lbl(cx3, 10, "GST No", is_party=True)
        fields['tax_regn'] = create_entry(cx3, 30, 18, is_party=True)
        
        create_lbl(cx3, 60, "Country", is_party=True)
        fields['country'] = create_combo(cx3, 80, 30, ["Pakistan", "India", "USA", "UK"], is_party=True)
        fields['country'].set("Pakistan")
        
        create_lbl(cx3, 110, "ZIP Code", is_party=True)
        fields['pincode'] = create_entry(cx3, 130, 30, is_party=True)
        
        create_lbl(cx3, 160, "Address", is_party=True)
        fields['address'] = create_entry(cx3, 180, 30, is_party=True)
        fields['address2'] = create_entry(cx3, 205, 30, is_party=True)
        
        lbl_ship = create_lbl(cx3, 235, "Shipping Address", is_party=True)
        same_var = tk.IntVar(value=0)
        def toggle_same_addr(*args):
            if same_var.get() == 1:
                fields['ship_addr_1'].delete(0, "end")
                fields['ship_addr_1'].insert(0, fields['address'].get())
                fields['ship_addr_2'].delete(0, "end")
                fields['ship_addr_2'].insert(0, fields['address2'].get())

        cb_same = tk.Checkbutton(win, text="Same As Above", variable=same_var, bg="#ffffff", fg="#000", command=toggle_same_addr)
        party_widgets.append((cb_same, {'x': cx3+120, 'y': 235}))
        register_widget(cb_same)

        fields['ship_addr_1'] = create_entry(cx3, 255, 30, is_party=True)
        fields['ship_addr_2'] = create_entry(cx3, 280, 30, is_party=True)
        
        create_lbl(cx3, 310, "Credit Period", is_party=True)
        sb = ttk.Spinbox(win, from_=0, to=365, width=8, font=FONT)
        sb.set("0")
        party_widgets.append((sb, {'x': cx3, 'y': 330}))
        fields['credit_period'] = register_widget(sb)
        
        create_lbl(cx3+120, 310, "Credit Limit", is_party=True)
        fields['credit_limit'] = create_entry(cx3+120, 330, 16, is_party=True)
        
        create_lbl(cx3, 360, "Discount Type", is_party=True)
        fields['discount_type'] = create_combo(cx3, 380, 30, ["Item Default Discount", "Percentage", "Amount"], is_party=True)
        fields['discount_type'].set("Item Default Discount")
        
        create_lbl(cx3, 410, "Phone Number", is_party=True)
        fields['phone'] = create_entry(cx3, 430, 30, is_party=True)
        
        create_lbl(cx3, 460, "Email id", is_party=True)
        fields['email_id'] = create_entry(cx3, 480, 30, is_party=True)
        
        create_lbl(cx3, 510, "Tax No. 2", is_party=True)
        fields['tax_regn2'] = create_entry(cx3, 530, 13, is_party=True)
        
        create_lbl(cx3+140, 510, "Tax No. 3", is_party=True)
        fields['tax_regn3'] = create_entry(cx3+140, 530, 13, is_party=True)
        
        create_lbl(cx3, 560, "Remarks", is_party=True)
        fields['remarks'] = create_entry(cx3, 580, 30, is_party=True)
        
        lbl_template_info = tk.Label(win, text="You can change address/tax labels in Settings >\nTemplate Settings.", bg="#ffffff", fg="#000", justify="left", font=(FONT[0], 8))
        party_widgets.append((lbl_template_info, {'x': cx3, 'y': 608}))

        # --- Generic Info Text (for non-party accounts) ---
        info_text = (
            "Sundry Debtor : Customers/Clients\n"
            "# Sundry Creditor : Suppliers/Vendors\n\n"
            "Loans(Liability) : Loans that company has borrowed\n"
            "# Loans & Advances : All loans & advances given by the company\n\n"
            "# Bank OD : Bank Overdraft\n"
            "Deposits(Assets): Any deposit made by the company."
        )
        lbl_generic_info = tk.Label(win, text=info_text, bg="#ffffff", fg="darkred", font=(FONT[0], 10), justify="left")

        # --- Buttons ---
        btn_exit = tk.Button(win, text="Ctrl+Q: Exit", bg="#e0e0e0", font=FONT, command=win.destroy, relief="solid", bd=1)
        btn_save = tk.Button(win, text="F12:Save", bg="#e0e0e0", font=FONT, command=lambda: save(), relief="solid", bd=1)

        def update_layout(*args):
            grp = fields['account_group'].get().strip()
            is_party = (grp in ["Sundry Debtors", "Sundry Creditors"])

            if is_party:
                win.geometry("920x660")
                if grp == "Sundry Debtors":
                    win.title("Create Customer" if not existing else "Edit Customer")
                    lbl_bal_hint.config(text="For credit balance of customers,\nEnter amount in negative (-)")
                else:
                    win.title("Create Supplier" if not existing else "Edit Supplier")
                    lbl_bal_hint.config(text="For debit balance of suppliers,\nEnter amount in negative (-)")

                lbl_generic_info.place_forget()

                for w, pos in party_widgets:
                    w.place(**pos)

                bank_banner.place(x=cx1, y=248, width=270, height=28)
                update_bank_visibility()

                btn_exit.place(x=15, y=615, width=120, height=30)
                btn_save.place(x=310, y=615, width=120, height=30)
            else:
                win.geometry("600x580")
                win.title("Create Account" if not existing else "Edit Account")
                lbl_bal_hint.config(text="For credit balance of customers,\nEnter amount in negative (-)")

                for w, _ in party_widgets:
                    w.place_forget()

                bank_banner.place_forget()
                hide_bank_fields()

                lbl_generic_info.place(x=cx1, y=260)

                btn_exit.place(x=15, y=520, width=120, height=30)
                btn_save.place(x=450, y=520, width=120, height=30)

        fields['account_group'].bind("<<ComboboxSelected>>", update_layout)
        fields['account_group'].bind("<KeyRelease>", update_layout)

        # Set default group selection
        default_grp = "Cash-in-hand"
        if existing:
            default_grp = existing.get('account_group') or existing.get('type') or "Cash-in-hand"
        elif acc_type == 'customer':
            default_grp = "Sundry Debtors"
        elif acc_type == 'supplier':
            default_grp = "Sundry Creditors"
        elif acc_type == 'expense':
            default_grp = "Direct Expenses"
        elif acc_type == 'income':
            default_grp = "Direct Income"
        elif acc_type == 'cash':
            default_grp = "Cash-in-hand"
        elif acc_type == 'bank':
            default_grp = "Bank A/Cs"
        elif acc_type in ['tax', 'tax_group']:
            default_grp = "Duties & Taxes" if "Duties & Taxes" in ACCOUNT_TYPES else "Current Liabilities"

        fields['account_group'].set(default_grp)

        # Populate existing data if any
        if existing:
            for k, w in fields.items():
                if k in existing and existing[k] is not None:
                    if hasattr(w, 'set'):
                        w.set(existing[k])
                    elif hasattr(w, 'insert'):
                        w.delete(0, "end")
                        w.insert(0, str(existing[k]))
                    elif hasattr(w, 'delete'):
                        w.delete("1.0", "end")
                        w.insert("1.0", str(existing[k]))

            has_bank = existing.get('has_bank_details') or (
                existing.get('acc_number') or existing.get('ifsc_code') or existing.get('bank_name') or
                existing.get('detail1') or existing.get('detail2') or existing.get('detail3')
            )
            if has_bank:
                bank_var.set(1)
                if existing.get('acc_number'):
                    fields['acc_number'].delete(0, "end")
                    fields['acc_number'].insert(0, str(existing['acc_number']))
                elif existing.get('detail1'):
                    fields['acc_number'].delete(0, "end")
                    fields['acc_number'].insert(0, str(existing['detail1']))
                    
                if existing.get('ifsc_code'):
                    fields['ifsc_code'].delete(0, "end")
                    fields['ifsc_code'].insert(0, str(existing['ifsc_code']))
                elif existing.get('detail2'):
                    fields['ifsc_code'].delete(0, "end")
                    fields['ifsc_code'].insert(0, str(existing['detail2']))
                    
                if existing.get('bank_name'):
                    fields['bank_name'].set(str(existing['bank_name']))
                elif existing.get('detail3'):
                    fields['bank_name'].set(str(existing['detail3']))

        update_layout()

        def save(e=None):
            data = {}
            for k, var in fields.items():
                if hasattr(var, 'get'):
                    val = var.get()
                else:
                    val = ""
                if isinstance(val, str):
                    val = val.strip()
                data[k] = val
                
            name = data.get('aname', '').strip()
            if not name:
                messagebox.showerror("Error", "Account Name is required!", parent=win)
                if 'aname' in fields:
                    fields['aname'].focus_set()
                return
                
            try:
                if data.get("op_bal"):
                    data["op_bal"] = float(data["op_bal"])
                else:
                    data["op_bal"] = 0.0
            except ValueError:
                messagebox.showerror("Error", "Opening Balance must be a number!", parent=win)
                return

            grp = data.get('account_group') or 'Cash-in-hand'
            data['account_group'] = grp
            data['a_type'] = 'Account'

            if grp in ["Sundry Debtors", "Sundry Creditors"]:
                data['has_bank_details'] = bank_var.get()
                if bank_var.get() == 1:
                    data['acc_number'] = fields['acc_number'].get().strip()
                    data['ifsc_code'] = fields['ifsc_code'].get().strip()
                    data['bank_name'] = fields['bank_name'].get().strip()
                    data['detail1'] = data['acc_number']
                    data['detail2'] = data['ifsc_code']
                    data['detail3'] = data['bank_name']
                else:
                    data['acc_number'] = ""
                    data['ifsc_code'] = ""
                    data['bank_name'] = ""
                    data['detail1'] = ""
                    data['detail2'] = ""
                    data['detail3'] = ""
            else:
                data['has_bank_details'] = 0

            try:
                if existing:
                    db.update_account(existing["id"], data)
                else:
                    db.add_account(data)
                win.destroy()
                if callback:
                    callback()
                if hasattr(self, 'update_all_views'):
                    self.update_all_views()
                if hasattr(self, '_account_list') and acc_type:
                    self._account_list(acc_type, "Accounts")
            except Exception as ex:
                if "UNIQUE constraint failed" in str(ex):
                    messagebox.showerror("Error", f"An account with the name '{name}' already exists!", parent=win)
                else:
                    messagebox.showerror("Database Error", str(ex), parent=win)

        win.bind("<Control-q>", lambda e: win.destroy())
        win.bind("<F12>", save)
        if 'aname' in fields:
            fields["aname"].focus_set()

    def _generic_account_form(self, existing=None, callback=None):
        self._account_form(None, existing=existing, callback=callback)

    def _edit_selected_account(self, tree, acc_type):
        sel = tree.selection()
        if not sel:
            return
        acc_id = sel[0]
        rows = db.get_all_accounts()
        acc = next((dict(r) for r in rows if r["id"] == acc_id), None)
        if acc:
            self._account_form(acc_type, existing=acc)

    def _delete_account(self, tree):
        sel = tree.selection()
        if not sel:
            messagebox.showwarning("Select", "Please select an account.")
            return
        if messagebox.askyesno("Confirm Delete", "Delete this account?"):
            db.delete_account(sel[0])
            tree.delete(sel[0])

    # ═════════════════════════════════════════════════════════════════════════
    #  INVENTORY
    # ═════════════════════════════════════════════════════════════════════════
    def show_inventory(self):
        if not self.check_permission("inv_view", "view inventory"):
            return
        self._clear_main()

        # ── 1. Top Navigation Bar ─────────────────────────────────────────────
        nav_frame = tk.Frame(self.main_frame, bg=WHITE, height=32)
        nav_frame.pack(fill="x", side="top")

        # Left grip ⋮
        tk.Label(nav_frame, text="⋮", font=("Segoe UI", 11, "bold"), fg="#888888", bg=WHITE).pack(side="left", padx=(6, 2))

        # [✕] Ctrl+Q: Exit
        exit_frame = tk.Frame(nav_frame, bg=WHITE, cursor="hand2")
        exit_frame.pack(side="left", padx=(2, 4), pady=4)
        lbl_x = tk.Label(exit_frame, text="✕", font=("Segoe UI", 8, "bold"), fg=WHITE, bg="#000000", width=2)
        lbl_x.pack(side="left")
        lbl_x.bind("<Button-1>", lambda e: self.show_dashboard())
        btn_exit = tk.Button(exit_frame, text="Ctrl+Q: Exit", font=("Segoe UI", 9), bg=WHITE, activebackground="#e8e8e8",
                             relief="flat", bd=0, command=self.show_dashboard, cursor="hand2")
        btn_exit.pack(side="left", padx=(2, 0))

        # Divider |
        tk.Frame(nav_frame, bg="#cccccc", width=1, height=18).pack(side="left", padx=4, pady=6)

        # 🛒 F2: New Inventory Item
        btn_new = tk.Button(nav_frame, text="🛒 F2: New Inventory Item", font=("Segoe UI", 9), bg=WHITE,
                            activebackground="#e8e8e8", relief="flat", bd=0, cursor="hand2",
                            command=lambda: self._item_form(callback=self.show_inventory))
        btn_new.pack(side="left", padx=4, pady=4)

        # Divider |
        tk.Frame(nav_frame, bg="#cccccc", width=1, height=18).pack(side="left", padx=4, pady=6)

        # Status Filter Combobox
        status_var = tk.StringVar(value="Active Items")
        cb_status = AutocompleteCombobox(nav_frame, textvariable=status_var,
                                 values=["Active Items", "Inactive Items", "ALL"],
                                 state="readonly", width=14, font=("Segoe UI", 9))
        cb_status.pack(side="left", padx=4, pady=4)

        # 🔄 Reload/Refresh
        btn_refresh = tk.Button(nav_frame, text="🔄 Reload/Refresh", font=("Segoe UI", 9), bg=WHITE,
                                activebackground="#e8e8e8", relief="flat", bd=0, cursor="hand2",
                                command=self.show_inventory)
        btn_refresh.pack(side="left", padx=6, pady=4)

        # ── 2. Header & Search Frame ──────────────────────────────────────────
        BG_HEADER = "#d6ded9"
        header_frame = tk.Frame(self.main_frame, bg=BG_HEADER, padx=12, pady=4)
        header_frame.pack(fill="x")

        lbl_title = tk.Label(header_frame, text="Inventory Items", font=("Segoe UI", 11, "bold"), bg=BG_HEADER, fg="#000000")
        lbl_title.pack(anchor="center", pady=(1, 2))

        search_row = tk.Frame(header_frame, bg=BG_HEADER)
        search_row.pack(fill="x", pady=2)

        lbl_search = tk.Label(search_row, text="F3: Search:", font=("Segoe UI", 10), bg=BG_HEADER, fg="#000000")
        lbl_search.pack(side="left", padx=(0, 4))

        search_var = tk.StringVar()
        search_entry = tk.Entry(search_row, textvariable=search_var, font=FONT, bg=WHITE, relief="solid", bd=1)
        search_entry.pack(side="left", fill="x", expand=True, padx=(0, 4))

        lbl_notice = tk.Label(header_frame, text="Press ENTER to edit and DELETE to delete",
                              font=("Segoe UI", 9, "italic", "bold"), fg="#800000", bg=BG_HEADER)
        lbl_notice.pack(anchor="w", pady=(2, 1))

        # ── 3. Table / Treeview Frame ─────────────────────────────────────────
        table_frame = tk.Frame(self.main_frame, bg=WHITE)
        table_frame.pack(fill="both", expand=True)

        cols = ("name", "purchase_price", "sale_price", "units_left", "desc")
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("InvList.Treeview.Heading", font=("Segoe UI", 9, "bold"), background="#f0f0f0", foreground="#000000")
        style.configure("InvList.Treeview", font=FONT, rowheight=30)
        style.map("InvList.Treeview",
                  background=[("selected", "#d0e2f5")],
                  foreground=[("selected", "#111827")])

        tree = ttk.Treeview(table_frame, columns=cols, show="headings", style="InvList.Treeview", selectmode="browse")
        tree.heading("name", text="Item Name", anchor="w")
        tree.heading("purchase_price", text="Purchase Price", anchor="e")
        tree.heading("sale_price", text="Sales Price", anchor="e")
        tree.heading("units_left", text="Units Left", anchor="center")
        tree.heading("desc", text="Item Description", anchor="w")

        tree.column("name", width=220, anchor="w", stretch=True)
        tree.column("purchase_price", width=120, anchor="e", stretch=False)
        tree.column("sale_price", width=120, anchor="e", stretch=False)
        tree.column("units_left", width=130, anchor="center", stretch=False)
        tree.column("desc", width=240, anchor="w", stretch=True)

        vsb = ttk.Scrollbar(table_frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        tree.pack(fill="both", expand=True)

        all_items = []
        try:
            raw_items = db.get_all_items()
            all_items = [dict(r) for r in raw_items]
        except Exception as e:
            print("Error loading items:", e)

        def apply_filter(*args):
            status_filter = status_var.get()
            query = search_var.get().strip().lower()

            for item in tree.get_children():
                tree.delete(item)

            for r in all_items:
                st = r.get("status")
                is_active = (st is None or st == 1 or str(st).lower() in ["active", "1"])
                if status_filter == "Active Items" and not is_active:
                    continue
                elif status_filter == "Inactive Items" and is_active:
                    continue

                name = str(r.get("name") or r.get("item") or "")
                desc = str(r.get("item_desc") or "")
                code = str(r.get("code") or r.get("sku") or "")
                barcode = str(r.get("barcode") or "")
                unit = str(r.get("unit") or r.get("units_name") or "")

                if query:
                    if not (query in name.lower() or query in desc.lower() or query in code.lower() or query in barcode.lower() or query in unit.lower()):
                        continue

                p_price_val = r.get("purchase_price")
                if p_price_val is not None:
                    try:
                        p_float = float(p_price_val)
                        p_str = f"{p_float:,.2f}" if not p_float.is_integer() else f"{p_float:,.0f}"
                    except:
                        p_str = str(p_price_val)
                else:
                    p_str = "0.00"

                s_price_val = r.get("sale_price")
                if s_price_val is not None:
                    try:
                        s_float = float(s_price_val)
                        s_price_str = f"{s_float:,.2f}" if not s_float.is_integer() else f"{s_float:,.0f}"
                    except:
                        s_price_str = str(s_price_val)
                else:
                    s_price_str = "0.00"

                stock_val = r.get("stock")
                if stock_val is not None:
                    try:
                        s_float = float(stock_val)
                        s_str = f"{s_float:,.2f}" if not s_float.is_integer() else f"{s_float:.0f}"
                    except:
                        s_str = str(stock_val)
                    units_left_str = f"{s_str} {unit}".strip() if unit else s_str
                else:
                    units_left_str = f"0 {unit}".strip() if unit else "0"

                tree.insert("", "end", iid=str(r.get("id") or r.get("item")),
                            values=(name, p_str, s_price_str, units_left_str, desc))

        cb_status.bind("<<ComboboxSelected>>", apply_filter)
        search_entry.bind("<KeyRelease>", apply_filter)

        apply_filter()

        def edit_item(e=None):
            sel = tree.selection()
            if not sel: return
            item_id = sel[0]
            item = next((r for r in all_items if str(r.get("id") or r.get("item")) == str(item_id) or str(r.get("item")) == str(item_id)), None)
            if item:
                self._item_form(existing=item, callback=self.show_inventory)

        def delete_item(e=None):
            sel = tree.selection()
            if not sel:
                messagebox.showwarning("Select", "Select an item first.")
                return
            item_id = sel[0]
            item = next((r for r in all_items if str(r.get("id") or r.get("item")) == str(item_id) or str(r.get("item")) == str(item_id)), None)
            item_name = item.get("name") or item.get("item") if item else item_id
            if messagebox.askyesno("Confirm Delete", f"Delete this item '{item_name}'?"):
                db.delete_item(item_id)
                self.show_inventory()

        tree.bind("<Double-1>", edit_item)
        tree.bind("<Return>", edit_item)
        tree.bind("<KP_Enter>", edit_item)
        tree.bind("<Delete>", delete_item)

        self.bind("<Control-q>", lambda e: self.show_dashboard())
        self.bind("<Control-Q>", lambda e: self.show_dashboard())
        self.bind("<F2>", lambda e: self._item_form(callback=self.show_inventory))
        self.bind("<F3>", lambda e: [search_entry.focus_set(), search_entry.select_range(0, 'end')])
        self.bind("<Control-r>", lambda e: self.show_inventory())
        self.bind("<Control-R>", lambda e: self.show_inventory())
        self.bind("<F5>", lambda e: self.show_inventory())

    def _item_form(self, existing=None, callback=None, initial_name="", parent=None):
        import re, datetime
        try:
            import category
        except Exception:
            category = None

        parent_win = parent or self
        win = tk.Toplevel(parent_win)
        win.title("Create Inventory Item" if not existing else "Edit Inventory Item")
        win.geometry("980x660")
        win.resizable(False, False)
        win.configure(bg="#ffffff")
        win.transient(parent_win)
        win.grab_set()

        # Top Bar
        top_frame = tk.Frame(win, bg="#f0f0f0", height=32)
        top_frame.pack(fill="x", side="top")
        tk.Label(top_frame, text="Alt+M: Category/Subcategory    Alt+U: New Unit Of Measure", bg="#f0f0f0", fg="#333", font=(FONT[0], 9)).place(x=15, y=6)

        main_frame = tk.Frame(win, bg="#ffffff")
        main_frame.pack(fill="both", expand=True)

        tk.Label(main_frame, text="Press ENTER to move forward  SHIFT+ENTER to move back.", 
                 fg="darkred", bg="#ffffff", font=(FONT[0], 10, "italic", "bold")).place(x=15, y=6)

        fields = {}
        widgets = []
        image_path_var = tk.StringVar(value="")

        def register_widget(w):
            widgets.append(w)
            w.bind("<Return>", lambda e: focus_next(w))
            w.bind("<Shift-Return>", lambda e: focus_prev(w))
            return w

        def focus_next(current):
            try:
                idx = widgets.index(current)
                widgets[(idx + 1) % len(widgets)].focus_set()
            except Exception: pass
            return "break"

        def focus_prev(current):
            try:
                idx = widgets.index(current)
                widgets[(idx - 1) % len(widgets)].focus_set()
            except Exception: pass
            return "break"

        def create_lbl(x, y, text, align="right", width=22):
            lbl = tk.Label(main_frame, text=text, bg="#ffffff", fg="#000", font=FONT, anchor="e" if align=="right" else "w", width=width)
            lbl.place(x=x, y=y)
            return lbl

        def create_entry(x, y, w, bg="#ffffff"):
            e = tk.Entry(main_frame, font=FONT, width=w, relief="solid", bd=1, bg=bg)
            e.place(x=x, y=y)
            return register_widget(e)
            
        def create_combo(x, y, w, vals):
            c = AutocompleteCombobox(main_frame, font=FONT, width=w-2, values=vals)
            c.place(x=x, y=y)
            return register_widget(c)

        # ── LEFT COLUMN ──────────────────────────────────────────────────────
        lbl_x = 10
        ent_x = 195
        
        create_lbl(lbl_x, 35, "Item Name", width=20)
        fields['item'] = create_entry(ent_x, 35, 30, bg="#ffff99")
        if initial_name and not existing:
            fields['item'].delete(0, 'end')
            fields['item'].insert(0, str(initial_name).strip())
            fields['item'].focus_set()
            fields['item'].select_range(0, 'end')
        
        create_lbl(lbl_x, 65, "Item Code/SKU/HSN", width=20)
        fields['sku'] = create_entry(ent_x, 65, 30)
        
        create_lbl(lbl_x, 95, "Barcode", width=20)
        fields['barcode'] = create_entry(ent_x, 95, 30)
        
        create_lbl(lbl_x, 125, "Units Of Measure", width=20)
        
        def load_units():
            try:
                units = db.get_all_units()
                return [u['units_name'] for u in units] if units else ["Numbers", "Kgs", "Liters", "Boxes", "Pieces"]
            except Exception:
                return ["Numbers", "Kgs", "Liters", "Boxes", "Pieces"]
                
        fields['units_name'] = create_combo(ent_x, 125, 30, load_units())
        fields['units_name'].set("Numbers")
        
        def on_unit_focus(event):
            curr = fields['units_name'].get()
            vals = load_units()
            fields['units_name']['values'] = vals
            if curr not in vals and vals:
                fields['units_name'].set(vals[0])
        fields['units_name'].bind("<FocusIn>", on_unit_focus)
        
        tk.Label(main_frame, text="(i)", bg="#ffffff", fg="#333", font=(FONT[0], 9, "bold")).place(x=ent_x+250, y=125)
        
        create_lbl(lbl_x, 155, "Item Description", width=20)
        desc_box = tk.Text(main_frame, width=30, height=3, font=FONT, relief="solid", bd=1)
        desc_box.place(x=ent_x, y=155)
        fields['item_desc'] = desc_box
        tk.Label(main_frame, text="(i)", bg="#ffffff", fg="#333", font=(FONT[0], 9, "bold")).place(x=ent_x+250, y=155)
        tk.Label(main_frame, text="Ctrl+Enter for next line", bg="#ffffff", fg="#666", font=(FONT[0], 8)).place(x=ent_x+120, y=218)
        
        create_lbl(lbl_x, 240, "Initial Quantity On Hand", width=20)
        fields['stock'] = create_entry(ent_x, 240, 30)
        fields['stock'].insert(0, "0")
        
        create_lbl(lbl_x, 270, "As Of Date", width=20)
        if DateEntry:
            de = DateEntry(main_frame, width=28, background='darkblue', foreground='white', borderwidth=2, font=FONT)
            de.place(x=ent_x, y=270)
            fields['date_created'] = register_widget(de)
        else:
            fields['date_created'] = create_entry(ent_x, 270, 30)
            fields['date_created'].insert(0, datetime.datetime.now().strftime("%B %d, %Y"))
        tk.Label(main_frame, text="You can't pass voucher entries before this date.", bg="#ffffff", fg="#666", font=(FONT[0], 8)).place(x=ent_x, y=295)
        
        create_lbl(lbl_x, 318, "Initial Cost/Unit", width=20)
        fields['rate1'] = create_entry(ent_x, 318, 30)
        fields['rate1'].insert(0, "0")
        
        create_lbl(lbl_x, 348, "Value", width=20)
        fields['rate2'] = create_entry(ent_x, 348, 30)
        fields['rate2'].insert(0, "0")

        def calc_val(*args):
            try:
                q = float(fields['stock'].get() or 0)
                c = float(fields['rate1'].get() or 0)
                v = q * c
                fields['rate2'].delete(0, 'end')
                fields['rate2'].insert(0, f"{v:,.2f}" if not v.is_integer() else f"{v:.0f}")
            except Exception: pass

        fields['stock'].bind("<KeyRelease>", calc_val)
        fields['rate1'].bind("<KeyRelease>", calc_val)
        
        create_lbl(lbl_x, 388, "Minimum Order Quantity", width=20)
        fields['reorder_qty'] = create_entry(ent_x, 388, 30)
        fields['reorder_qty'].insert(0, "50")
        tk.Label(main_frame, text="(i)", bg="#ffffff", fg="#333", font=(FONT[0], 9, "bold")).place(x=ent_x+250, y=388)
        
        # Dynamically load categories and subcategories from DB
        categories_list = db.get_all_categories()
        cat_names = [c["name"] for c in categories_list]

        create_lbl(lbl_x, 422, "Item Category", width=20)
        fields['category'] = create_combo(ent_x, 422, 30, cat_names)
        
        create_lbl(lbl_x, 454, "Item Subcategory", width=20)
        fields['subcategory'] = create_combo(ent_x, 454, 30, [])
        
        def update_sub_options(event=None):
            cat_val = fields['category'].get()
            cat_obj = next((c for c in categories_list if c["name"] == cat_val), None)
            if cat_obj:
                sub_list = db.get_subcategories_by_category(cat_obj["id"])
                sub_names = [s["name"] for s in sub_list]
                fields['subcategory']['values'] = sub_names
                if sub_names:
                    fields['subcategory'].set(sub_names[0])
                else:
                    fields['subcategory'].set("")
            else:
                fields['subcategory']['values'] = []
                fields['subcategory'].set("")
                
        fields['category'].bind("<<ComboboxSelected>>", update_sub_options)
        
        if cat_names:
            fields['category'].set(cat_names[0])
            update_sub_options()
        
        create_lbl(lbl_x, 492, "Remarks", width=20)
        fields['remarks'] = create_entry(ent_x, 492, 30)
        tk.Label(main_frame, text="Remarks are for internal use only, it won't be displayed anywhere.", bg="#ffffff", fg="#666", font=(FONT[0], 8), justify="left").place(x=ent_x, y=518)

        # ── RIGHT COLUMN ─────────────────────────────────────────────────────
        rx = 490
        
        create_lbl(rx, 40, "Item Image", width=18)
        img_box_frame = tk.Frame(main_frame, bg="#ffffff", relief="solid", bd=1, width=110, height=95)
        img_box_frame.place(x=rx+160, y=25)
        img_box_frame.pack_propagate(False)

        img_lbl = tk.Label(img_box_frame, text="No Image\nSelected", bg="#ffffff", fg="#888", font=(FONT[0], 9), justify="center")
        img_lbl.pack(fill="both", expand=True)
        
        def choose_image():
            from tkinter import filedialog
            import shutil, os
            try:
                from PIL import Image, ImageTk
                file_path = filedialog.askopenfilename(title="Select Image", filetypes=[("Image Files", "*.png;*.jpg;*.jpeg;*.bmp")])
                if file_path:
                    if not os.path.exists('images'): os.makedirs('images')
                    filename = os.path.basename(file_path)
                    dest = os.path.join('images', filename)
                    shutil.copy(file_path, dest)
                    image_path_var.set(dest)
                    
                    img = Image.open(dest)
                    img.thumbnail((105, 90))
                    photo = ImageTk.PhotoImage(img)
                    img_lbl.config(image=photo, text="")
                    img_lbl.image = photo
            except Exception as e:
                messagebox.showerror("Error", str(e), parent=win)

        def clear_image():
            image_path_var.set("")
            img_lbl.config(image="", text="No Image\nSelected")
            img_lbl.image = None

        tk.Button(main_frame, text="📁 Choose...", bg="#f0f0f0", font=(FONT[0], 9), relief="solid", bd=1, cursor="hand2", command=choose_image).place(x=rx+280, y=35, width=95, height=28)
        tk.Button(main_frame, text="✕ Remove", bg="#f0f0f0", font=(FONT[0], 9), relief="solid", bd=1, cursor="hand2", command=clear_image).place(x=rx+280, y=75, width=95, height=28)
        
        tax_info = "For nil rated items, select 0% tax\nFor exempted items, don't select tax account."
        tk.Label(main_frame, text=tax_info, bg="#ffffff", fg="#444", font=(FONT[0], 8), justify="right").place(x=rx+110, y=130)
        
        create_lbl(rx, 175, "Default Tax Account", width=18)
        fields['tax_regn'] = create_combo(rx+160, 175, 27, ["None", "VAT 0%", "VAT 5%", "VAT 15%"])
        fields['tax_regn'].set("None")

        create_lbl(rx, 207, "Additional Cess", width=18)
        fields['additional_cess'] = create_entry(rx+160, 207, 27)
        fields['additional_cess'].insert(0, "0")

        # Tax pricing headers
        tk.Label(main_frame, text="Exclusive Tax", bg="#ffffff", fg="#000", font=(FONT[0], 9, "bold"), width=14, anchor="center").place(x=rx+160, y=245)
        tk.Label(main_frame, text="Inclusive Tax", bg="#ffffff", fg="#000", font=(FONT[0], 9, "bold"), width=14, anchor="center").place(x=rx+280, y=245)

        def get_tax_rate():
            tax_str = fields['tax_regn'].get()
            m = re.search(r'(\d+(?:\.\d+)?)%', tax_str)
            if m:
                return float(m.group(1)) / 100.0
            return 0.0

        create_lbl(rx, 275, "Default Purchase Price", width=18)
        fields['defaultpurchaseprice'] = create_entry(rx+160, 275, 14)
        fields['defaultpurchaseprice'].insert(0, "0")
        inc_pur = create_entry(rx+280, 275, 14)
        inc_pur.insert(0, "0")

        create_lbl(rx, 307, "Default Sale Price", width=18)
        fields['defaultsellingprice'] = create_entry(rx+160, 307, 14)
        fields['defaultsellingprice'].insert(0, "0")
        inc_sal = create_entry(rx+280, 307, 14)
        inc_sal.insert(0, "0")

        create_lbl(rx, 339, "Default Discount %", width=18)
        fields['defaultdiscountpercent'] = create_entry(rx+160, 339, 14)
        fields['defaultdiscountpercent'].insert(0, "0")
        inc_dis = create_entry(rx+280, 339, 14)
        inc_dis.insert(0, "0")

        def sync_prices(*args):
            r = get_tax_rate()
            try:
                pur_ex = float(fields['defaultpurchaseprice'].get() or 0)
                pur_inc = pur_ex * (1.0 + r)
                inc_pur.delete(0, 'end')
                inc_pur.insert(0, f"{pur_inc:,.2f}" if not pur_inc.is_integer() else f"{pur_inc:.0f}")
            except Exception: pass

            try:
                sal_ex = float(fields['defaultsellingprice'].get() or 0)
                sal_inc = sal_ex * (1.0 + r)
                inc_sal.delete(0, 'end')
                inc_sal.insert(0, f"{sal_inc:,.2f}" if not sal_inc.is_integer() else f"{sal_inc:.0f}")
            except Exception: pass

            try:
                dis_ex = float(fields['defaultdiscountpercent'].get() or 0)
                inc_dis.delete(0, 'end')
                inc_dis.insert(0, f"{dis_ex:,.2f}" if not dis_ex.is_integer() else f"{dis_ex:.0f}")
            except Exception: pass

        def sync_pur_from_inc(*args):
            r = get_tax_rate()
            try:
                p_inc = float(inc_pur.get() or 0)
                p_ex = p_inc / (1.0 + r) if (1.0 + r) > 0 else p_inc
                fields['defaultpurchaseprice'].delete(0, 'end')
                fields['defaultpurchaseprice'].insert(0, f"{p_ex:,.2f}" if not p_ex.is_integer() else f"{p_ex:.0f}")
            except Exception: pass

        def sync_sal_from_inc(*args):
            r = get_tax_rate()
            try:
                s_inc = float(inc_sal.get() or 0)
                s_ex = s_inc / (1.0 + r) if (1.0 + r) > 0 else s_inc
                fields['defaultsellingprice'].delete(0, 'end')
                fields['defaultsellingprice'].insert(0, f"{s_ex:,.2f}" if not s_ex.is_integer() else f"{s_ex:.0f}")
            except Exception: pass

        fields['defaultpurchaseprice'].bind("<KeyRelease>", sync_prices)
        fields['defaultsellingprice'].bind("<KeyRelease>", sync_prices)
        fields['defaultdiscountpercent'].bind("<KeyRelease>", sync_prices)
        fields['tax_regn'].bind("<<ComboboxSelected>>", sync_prices)
        inc_pur.bind("<KeyRelease>", sync_pur_from_inc)
        inc_sal.bind("<KeyRelease>", sync_sal_from_inc)

        if existing and existing.get('item_subcategory_id'):
            try:
                conn = db.get_conn()
                info = conn.execute("""
                    SELECT s.subcategory_name, c.category_name 
                    FROM item_subcategory s
                    JOIN item_category c ON s.category_id = c.category_id
                    WHERE s.subcategory_id = ?
                """, (existing['item_subcategory_id'])).fetchone()
                conn.close()
                if info:
                    fields['category'].set(info['category_name'])
                    update_sub_options()
                    fields['subcategory'].set(info['subcategory_name'])
            except Exception as e:
                print("Error loading category info:", e)

        if existing:
            for k, w in fields.items():
                if k in existing and existing[k] is not None:
                    val_str = str(existing[k])
                    if isinstance(w, tk.Entry):
                        w.delete(0, 'end')
                        w.insert(0, val_str)
                    elif isinstance(w, AutocompleteCombobox):
                        w.set(val_str)
                    elif isinstance(w, tk.Text):
                        w.delete("1.0", "end")
                        w.insert("1.0", val_str)
            if existing.get('detail1'):
                image_path_var.set(existing['detail1'])
                try:
                    from PIL import Image, ImageTk
                    img = Image.open(existing['detail1'])
                    img.thumbnail((105, 90))
                    photo = ImageTk.PhotoImage(img)
                    img_lbl.config(image=photo, text="")
                    img_lbl.image = photo
                except Exception: pass
            sync_prices()

        def save(event=None):
            data = {}
            for k, w in fields.items():
                if k in ['category', 'subcategory']: continue
                if isinstance(w, tk.Text):
                    val = w.get("1.0", "end").strip()
                else:
                    val = w.get() if hasattr(w, 'get') else ''
                if isinstance(val, str): val = val.strip()
                data[k] = val

            data['detail1'] = image_path_var.get()
            data.pop('date_created', None)
            data.pop('tax_regn', None)

            if not data.get('item'):
                messagebox.showerror("Error", "Item Name is required!", parent=win)
                fields['item'].focus_set()
                return

            if fields['category'].get() and fields['subcategory'].get():
                cat_obj = next((c for c in categories_list if c["name"] == fields['category'].get()), None)
                if cat_obj:
                    sub_list = db.get_subcategories_by_category(cat_obj["id"])
                    sub_obj = next((s for s in sub_list if s["name"] == fields['subcategory'].get()), None)
                    if sub_obj:
                        data['item_subcategory_id'] = sub_obj["id"]

            try:
                for k in ['stock', 'defaultpurchaseprice', 'defaultsellingprice', 'reorder_qty', 'additional_cess', 'defaultdiscountpercent', 'rate1', 'rate2']:
                    if data.get(k): data[k] = float(data[k])
            except ValueError:
                pass 

            try:
                if existing:
                    db.update_item(existing["id"] if "id" in existing else existing["item"], data)
                else:
                    db.add_item(data)
                win.destroy()
                if callback:
                    try:
                        callback(data.get('item', initial_name))
                    except TypeError:
                        callback()
            except Exception as e:
                messagebox.showerror("Database Error", str(e), parent=win)

        def open_cat_manager(e=None):
            if category:
                category.CategorySubcategoryWindow(win, app=self)

        win.bind('<Control-q>', lambda e: win.destroy())
        win.bind('<Control-Q>', lambda e: win.destroy())
        win.bind('<F12>', save)
        win.bind('<Alt-u>', lambda e: self._unit_form())
        win.bind('<Alt-U>', lambda e: self._unit_form())
        win.bind('<Alt-m>', open_cat_manager)
        win.bind('<Alt-M>', open_cat_manager)

        bot_frame = tk.Frame(win, bg="#f0f0f0", height=42)
        bot_frame.pack(fill="x", side="bottom")
        tk.Button(bot_frame, text="Ctrl+Q: Exit", bg="#e0e0e0", font=FONT, command=win.destroy, relief="solid", bd=1).place(x=15, y=6, width=110, height=30)
        tk.Label(bot_frame, text="Video: Inventory Management", fg="blue", bg="#f0f0f0", font=(FONT[0], 9, "underline"), cursor="hand2").place(x=400, y=10)
        tk.Button(bot_frame, text="F12:Save", bg="#e0e0e0", font=(FONT[0], 10, "bold"), command=save, relief="solid", bd=1).place(x=850, y=6, width=110, height=30)
        
        fields['item'].focus_set()

    def _edit_selected_item(self, tree):
        sel = tree.selection()
        if not sel:
            return
        item_id = sel[0]
        item = next((dict(r) for r in db.get_all_items() if r["id"] == item_id), None)
        if item:
            self._item_form(existing=item)

    def _delete_item(self, tree):
        sel = tree.selection()
        if not sel:
            messagebox.showwarning("Select", "Select an item first.")
            return
        if messagebox.askyesno("Confirm Delete", "Delete this item?"):
            db.delete_item(sel[0])
            tree.delete(sel[0])

    # ═════════════════════════════════════════════════════════════════════════
    #  INVOICES
    # ═════════════════════════════════════════════════════════════════════════
    def show_estimate_templates(self):
        self._clear_main()
        self._make_tab_header("Estimate Templates")
        
        main_fr = tk.Frame(self.main_frame, bg=WHITE)
        main_fr.pack(fill="both", expand=True)
        
        top_fr = tk.Frame(main_fr, bg=WHITE)
        top_fr.pack(fill="x", padx=10, pady=10)
        
        tk.Label(top_fr, text="Estimate Templates", font=FONT_BOLD, bg=WHITE).pack(side="left")
        tk.Button(top_fr, text="New Template", command=lambda: self._open_create_voucher("estimate"), bg="#4CAF50", fg="white", font=FONT).pack(side="right")
        
        tv_fr = tk.Frame(main_fr, bg=WHITE)
        tv_fr.pack(fill="both", expand=True, padx=10, pady=(0, 10))
        
        cols = ("Template No", "Description", "Total Amount")
        tv = ttk.Treeview(tv_fr, columns=cols, show="headings", height=15)
        for c in cols:
            tv.heading(c, text=c)
            tv.column(c, width=150, anchor="w")
        tv.pack(side="left", fill="both", expand=True)
        
        sb = ttk.Scrollbar(tv_fr, orient="vertical", command=tv.yview)
        sb.pack(side="right", fill="y")
        tv.configure(yscrollcommand=sb.set)
        
        import db
        templates = db.get_estimate_templates()
        for t in templates:
            tv.insert("", "end", iid=str(t['id']), values=(t['invoice_no'], t['notes'], t['total']))
            
        def on_generate_estimate(e=None):
            sel = tv.selection()
            if not sel: return
            t_id = int(sel[0])
            t_data = next((t for t in templates if t['id'] == t_id), None)
            if not t_data: return
            
            # Use duplicate feature to load into a new estimate window!
            self._open_create_voucher("estimate", edit_inv=t_data, is_duplicate=True)
            
        tv.bind("<Double-1>", on_generate_estimate)
        
        tk.Label(main_fr, text="Double-click a template to generate a new Estimate for a customer.", font=("Segoe UI", 9, "italic"), bg=WHITE).pack(pady=5)

    def show_invoices(self, v_type="sale"):
        if v_type in ("sale", "estimate", "delivery_challan", "sales_invoice", "credit_note", "receipt"):
            if not self.check_permission("sales_view", "view sales"):
                return
        elif v_type in ("purchase", "purchase_order", "debit_note", "payment"):
            if not self.check_permission("purchase_view", "view purchases"):
                return
        elif v_type == "inventory_adjustment":
            if not self.check_permission("inv_view", "view inventory"):
                return
        elif v_type in ("expense", "income"):
            if not self.check_permission("exp_inc_view", "view expenses/incomes"):
                return
        elif v_type == "journal":
            if not self.check_permission("journal_view_all", "view journals"):
                return
                
        win = tk.Toplevel(self)
        if v_type == "purchase_order":
            win.title("Purchase Order")
        elif v_type == "estimate":
            win.title("Estimate")
        elif v_type == "expense":
            win.title("Accounts/Transactions - View Expense" if v_type == "expense" else "Accounts/Transactions - View Income" if v_type == "income" else "Accounts/Transactions - View Contra" if v_type == "contra" else "Accounts/Transactions")
        elif v_type == "payment":
            win.title("Accounts/Transactions - View Payment To Supplier")
        elif v_type == "receipt":
            win.title("Accounts/Transactions - View Receipt From Customer")
        elif v_type == "journal":
            win.title("Accounts/Transactions - View Journal")
        elif v_type == "credit_note":
            win.title("Accounts/Transactions - View Credit Note")
        elif v_type == "debit_note":
            win.title("Accounts/Transactions - View Debit Note")
        elif v_type == "inventory_adjustment":
            win.title("Accounts/Transactions - View Stock Journal")
        else:
            win.title("Accounts/Transactions - View Purchase" if v_type == "purchase" else "Accounts/Transactions - View Sales Invoice")
        win.geometry("1000x650")
        try:
            win.state("zoomed")
        except tk.TclError:
            pass
        win.configure(bg=BG)
        win.grab_set()

        # Tab header style inside popup
        strip = tk.Frame(win, bg=BG)
        strip.pack(fill="x")
        tk.Frame(strip, bg=BG, width=4).pack(side="left")
        tab = tk.Frame(strip, bg=WHITE, relief="raised", bd=1)
        tab.pack(side="left", pady=(3, 0))
        tk.Label(tab, text="Accounts/Transactions", bg=WHITE, fg="#000",
                 font=FONT_BOLD, padx=12, pady=3).pack()
        tk.Frame(win, bg="#808080", height=1).pack(fill="x")
        
        # 1. Toolbar Frame
        toolbar = tk.Frame(win, bg=WHITE)
        toolbar.pack(fill="x", pady=(0, 2))
        
        btn_close = tk.Button(toolbar, text="X", bg="black", fg="white", font=FONT_BOLD, relief="flat", bd=0, width=2, command=win.destroy)
        btn_close.pack(side="left", padx=4)
        
        if v_type in ["purchase_order", "estimate"]:
            tb_actions = [
                ("Ctrl+Q: Exit", win.destroy),
                ("Alt+F4: Purchase Order", lambda: [win.destroy(), self.show_invoices("purchase_order")]),
                ("Alt+F5: Estimate", lambda: [win.destroy(), self.show_invoices("estimate")]),
            ]
        else:
            tb_actions = [
                ("Ctrl+Q: Exit", win.destroy),
                ("F5: Payment To Supplier", lambda: [win.destroy(), self._open_payment_supplier()]),
                ("F6: Receipt From Customer", lambda: [win.destroy(), self._open_receipt_customer()]),
                ("F7: Journal", lambda: [win.destroy(), self._open_journal_voucher()]),
                ("F8: Sale/Invoice/Bill", lambda: [win.destroy(), self._open_create_voucher("sale")]),
                ("F9: Purchase", lambda: [win.destroy(), self._open_create_voucher("purchase")]),
                ("Alt+E: Expense", lambda: [win.destroy(), self._open_expense_voucher()]),
                ("Alt+I: Income", lambda: [win.destroy(), self._open_income_voucher()]),
                ("F4: Contra", lambda: [win.destroy(), self._open_contra_voucher()]),
            ]
        
        for txt, cmd in tb_actions:
            tk.Button(toolbar, text=txt, bg=WHITE, relief="flat", bd=0, font=("Segoe UI", 10), cursor="hand2", command=cmd).pack(side="left", padx=2)

        # 2. Search Frame
        search_fr = tk.Frame(win, bg=WHITE, relief="sunken", bd=1)
        search_fr.pack(fill="x", padx=4, pady=2)
        tk.Label(search_fr, text="F3: Search:", bg=WHITE, font=FONT).pack(side="left", padx=4, pady=2)
        search_var = tk.StringVar()
        search_entry = tk.Entry(search_fr, textvariable=search_var, font=FONT, relief="flat", bd=0)
        search_entry.pack(side="left", padx=4, fill="x", expand=True)
        tk.Button(search_fr, text="Search All Vouchers", bg="#f0f0f0", relief="solid", bd=1, font=("Segoe UI", 11)).pack(side="right", fill="y")
        
        tk.Label(win, text="Press ENTER for more options. Use ARROW KEYS to move left/right.", fg="darkred", bg=BG, font=("Segoe UI", 10, "bold italic"), anchor="w").pack(fill="x", padx=4)

        # 3. Main Split (Left: Transactions, Right: Filters)
        main_split = tk.Frame(win, bg=BG)
        main_split.pack(fill="both", expand=True, padx=4, pady=2)

        right_pane = tk.Frame(main_split, bg=WHITE, width=120)
        right_pane.pack(side="right", fill="y", padx=(4, 0))
        right_pane.pack_propagate(False)

        left_pane = tk.Frame(main_split, bg=WHITE, relief="solid", bd=1)
        left_pane.pack(side="left", fill="both", expand=True)

        # 4. Filters (Right Pane)
        fin_year = AutocompleteCombobox(right_pane, values=["2024-2025", "2025-2026", "2026-2027", "2027-2028"], state="readonly", font=("Segoe UI", 10))
        fin_year.pack(fill="x", pady=2)
        import datetime
        curr_y = datetime.date.today().year
        curr_m = datetime.date.today().month
        default_fy = f"{curr_y-1}-{curr_y}" if curr_m < 4 else f"{curr_y}-{curr_y+1}"
        fin_year.set(default_fy if default_fy in ["2024-2025", "2025-2026", "2026-2027", "2027-2028"] else "2025-2026")
        
        months_lb = tk.Listbox(right_pane, font=("Segoe UI", 10), selectbackground="#3399ff", relief="solid", bd=1, highlightthickness=0)
        months_lb.pack(fill="both", expand=True)
        
        def populate_months():
            sel_fy = fin_year.get()
            try:
                y1, y2 = sel_fy.split("-")
            except Exception:
                y1, y2 = "2025", "2026"
            months_lb.delete(0, "end")
            m_list = ["All", f"Apr-{y1}", f"May-{y1}", f"Jun-{y1}", f"Jul-{y1}", f"Aug-{y1}", f"Sep-{y1}", f"Oct-{y1}", f"Nov-{y1}", f"Dec-{y1}", f"Jan-{y2}", f"Feb-{y2}", f"Mar-{y2}"]
            for m in m_list:
                months_lb.insert("end", m)
            months_lb.selection_set(0)

        populate_months()

        current_page = [1]
        
        # 5. Pagination (Left Pane Header)
        page_fr = tk.Frame(left_pane, bg=BG)
        page_fr.pack(fill="x")
        
        def prev_page(*args):
            if current_page[0] > 1:
                current_page[0] -= 1
            apply_search()
            
        def next_page(*args):
            current_page[0] += 1
            apply_search()
        
        tk.Button(page_fr, text="< Alt+P: Previous Page\n(Newer Transactions)", justify="left", bg="#e0e0e0", relief="flat", bd=1, font=("Segoe UI", 10), command=prev_page).pack(side="left", padx=2, pady=2)
        page_lbl = tk.Label(page_fr, text="Displaying page: 1", bg=BG, font=FONT_BOLD)
        page_lbl.pack(side="left", expand=True)
        tk.Button(page_fr, text="Alt+N: Next Page >\n(Older Transactions)", justify="right", bg="#e0e0e0", relief="flat", bd=1, font=("Segoe UI", 10), command=next_page).pack(side="right", padx=2, pady=2)

        # 6. Transactions Header
        if v_type in ["purchase_order", "estimate"]:
            col_defs = [("Date", 11, "w"), ("Accounts", 22, "w"), ("Description", 24, "w"), ("Amount", 14, "e"), ("Narration", 18, "w"), ("Status", 15, "center")]
        else:
            col_defs = [("Date", 12, "w"), ("Accounts", 26, "w"), ("Description", 28, "w"), ("Amount", 16, "e"), ("Status", 18, "center")]

        hdr_fr = tk.Frame(left_pane, bg="#d0d0d0")
        hdr_fr.pack(fill="x")
        
        dummy_sb_space = tk.Frame(hdr_fr, bg=WHITE, width=0)
        dummy_sb_space.pack(side="right", fill="y")
        
        hdr_inner = tk.Frame(hdr_fr, bg="#d0d0d0")
        hdr_inner.pack(side="left", fill="x", expand=True)

        for j, (htext, w_weight, align) in enumerate(col_defs):
            hdr_inner.columnconfigure(j, weight=w_weight, uniform="cols")
            cell_h = tk.Frame(hdr_inner, bg=WHITE, height=32)
            cell_h.grid(row=0, column=j, sticky="nsew", padx=(1 if j == 0 else 0, 1), pady=(1, 1))
            cell_h.pack_propagate(False)
            lbl = tk.Label(cell_h, text=htext, font=FONT_BOLD, bg=WHITE, fg="#000000",
                           anchor=align, justify="left" if align == "w" else ("right" if align == "e" else "center"))
            lbl.pack(fill="both", expand=True, padx=6, pady=4)

        # 7. Transactions Canvas
        list_canvas = tk.Canvas(left_pane, bg=WHITE, highlightthickness=0, bd=0)
        scrollbar = ttk.Scrollbar(left_pane, orient="vertical", command=list_canvas.yview)
        list_canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        list_canvas.pack(side="left", fill="both", expand=True)

        def sync_sb_width(e):
            if dummy_sb_space.winfo_width() != e.width:
                dummy_sb_space.config(width=e.width)
        scrollbar.bind("<Configure>", sync_sb_width)

        list_inner = tk.Frame(list_canvas, bg="#d0d0d0")
        list_cw = list_canvas.create_window((0, 0), window=list_inner, anchor="nw")

        list_inner.bind("<Configure>", lambda e: list_canvas.configure(scrollregion=list_canvas.bbox("all")))
        list_canvas.bind("<Configure>", lambda e: list_canvas.itemconfig(list_cw, width=e.width))
        list_canvas.bind("<MouseWheel>", lambda e: list_canvas.yview_scroll(-1 * (e.delta // 120), "units"))

        # 8. Render Rows
        invoices = db.get_all_invoices(v_type)
        if not invoices:
            invoices = []
        invoices.sort(key=lambda x: (db.parse_date_for_sort(x.get('date')), x.get('id') or 0), reverse=True)

        rows = []
        
        # Right Click Context Menu
        ctx_menu = tk.Menu(win, tearoff=0, font=("Segoe UI", 11))
        
        # Store selected row data
        selected_po_data = {}
        
        def set_selected_data(po_data):
            selected_po_data.clear()
            selected_po_data.update(po_data)
            
        def cmd_make_purchase():
            if selected_po_data:
                win.destroy()
                self._open_create_voucher("purchase", linked_po=selected_po_data)
                
        def cmd_make_invoice():
            if selected_po_data:
                win.destroy()
                self._open_create_voucher("sale", linked_po=selected_po_data)
                
        def cmd_mark_closed():
            if selected_po_data and selected_po_data.get("id"):
                db.update_po_status(selected_po_data["id"], "CLOSED")
                win.destroy()
                self.show_invoices(v_type)
        
        def not_implemented():
            messagebox.showinfo("Coming Soon", "This feature is coming soon!", parent=win)

        def cmd_delete():
            if selected_po_data and selected_po_data.get("id"):
                vid = selected_po_data["id"]
                inv_no = selected_po_data.get("invoice_no", "this voucher")
                def after_delete():
                    win.destroy()
                    self.show_invoices(v_type)
                self.confirm_delete_voucher(vid, inv_no, win, after_delete)

        def cmd_cancel():
            if selected_po_data and selected_po_data.get("id"):
                if messagebox.askyesno("Confirm Cancel", f"Are you sure you want to cancel {selected_po_data.get('invoice_no')}?", parent=win):
                    db.cancel_voucher(selected_po_data["id"])
                    win.destroy()
                    self.show_invoices(v_type)
                    
        def cmd_edit():
            if selected_po_data:
                win.destroy()
                t = selected_po_data.get("type") or v_type
                if t == "expense":
                    self._open_expense_voucher(edit_inv=selected_po_data)
                elif t == "income":
                    self._open_income_voucher(edit_inv=selected_po_data)
                elif t == "contra":
                    self._open_contra_voucher(edit_inv=selected_po_data)
                elif t == "journal":
                    self._open_journal_voucher(edit_inv=selected_po_data)
                elif t == "credit_note":
                    self._open_credit_note_window(edit_inv=selected_po_data)
                elif t == "debit_note":
                    self._open_debit_note_window(edit_inv=selected_po_data)
                else:
                    self._open_create_voucher(t, edit_inv=selected_po_data)
                
        def cmd_duplicate():
            if selected_po_data:
                win.destroy()
                t = selected_po_data.get("type") or v_type
                if t == "expense":
                    self._open_expense_voucher(edit_inv=selected_po_data, is_duplicate=True)
                elif t == "income":
                    self._open_income_voucher(edit_inv=selected_po_data, is_duplicate=True)
                elif t == "contra":
                    self._open_contra_voucher(edit_inv=selected_po_data, is_duplicate=True)
                elif t == "journal":
                    self._open_journal_voucher(edit_inv=selected_po_data, is_duplicate=True)
                elif t == "credit_note":
                    self._open_credit_note_window(edit_inv=selected_po_data, is_duplicate=True)
                elif t == "debit_note":
                    self._open_debit_note_window(edit_inv=selected_po_data, is_duplicate=True)
                else:
                    self._open_create_voucher(t, edit_inv=selected_po_data, is_duplicate=True)
                
        def cmd_credit_note():
            if selected_po_data:
                win.destroy()
                self._open_create_voucher("credit_note", edit_inv=selected_po_data)
                
        def cmd_recurring(days):
            if selected_po_data and selected_po_data.get("id"):
                conn = db.get_conn()
                import datetime
                next_date = (datetime.date.today() + datetime.timedelta(days=days)).isoformat()
                conn.execute("INSERT INTO recurring_vouchers (v_id, repeat_period, next_date) VALUES (?,?,?)", (selected_po_data["id"], days, next_date))
                conn.commit()
                conn.close()
                messagebox.showinfo("Success", f"Invoice set to recur every {days} days.", parent=win)

        ctx_menu.add_command(label="Edit", command=cmd_edit)
        ctx_menu.add_command(label="Delete", accelerator="Alt+D", command=cmd_delete)
        ctx_menu.add_command(label="Cancel", accelerator="Alt+X", command=cmd_cancel)
        ctx_menu.add_separator()
        
        if v_type == "purchase_order":
            ctx_menu.add_command(label="Create Duplicate", accelerator="Alt+2", command=cmd_duplicate)
            ctx_menu.add_command(label="Mark Closed", command=cmd_mark_closed)
            ctx_menu.add_command(label="Make Purchase", command=cmd_make_purchase)
            ctx_menu.add_command(label="View Purchase Order", command=lambda: invoice_preview.show_invoice_preview(win, selected_po_data, doc_type="purchase_order"))
        elif v_type == "estimate":
            ctx_menu.add_command(label="Create Duplicate", accelerator="Alt+2", command=cmd_duplicate)
            ctx_menu.add_command(label="Mark Closed", command=cmd_mark_closed)
            ctx_menu.add_command(label="Make Invoice", command=cmd_make_invoice)
            ctx_menu.add_command(label="View Estimate", command=lambda: invoice_preview.show_invoice_preview(win, selected_po_data, doc_type="estimate"))
        elif v_type == "purchase":
            ctx_menu.add_command(label="Payment to Supplier", command=not_implemented)
            ctx_menu.add_command(label="Create Debit Note", command=not_implemented)
            ctx_menu.add_command(label="Create Duplicate", accelerator="Alt+2", command=cmd_duplicate)
            ctx_menu.add_command(label="Convert Purchase to Sale", command=not_implemented)
            
            rec_menu = tk.Menu(ctx_menu, tearoff=0, font=("Segoe UI", 11))
            rec_menu.add_command(label="Monthly", command=lambda: cmd_recurring(30))
            rec_menu.add_command(label="Yearly", command=lambda: cmd_recurring(365))
            ctx_menu.add_cascade(label="Make Recurring", menu=rec_menu)
            
            ctx_menu.add_separator()
            ctx_menu.add_command(label="Mark Paid", command=not_implemented)
            ctx_menu.add_command(label="View Purchase", command=lambda: invoice_preview.show_invoice_preview(win, selected_po_data, doc_type="purchase"))
        elif v_type == "expense":
            ctx_menu.add_command(label="Create Duplicate", accelerator="Alt+2", command=cmd_duplicate)
            
            rec_menu = tk.Menu(ctx_menu, tearoff=0, font=("Segoe UI", 11))
            rec_menu.add_command(label="Monthly", command=lambda: cmd_recurring(30))
            rec_menu.add_command(label="Yearly", command=lambda: cmd_recurring(365))
            ctx_menu.add_cascade(label="Make Recurring", menu=rec_menu)
            
            ctx_menu.add_separator()
            ctx_menu.add_command(label="View Expense", command=lambda: invoice_preview.show_invoice_preview(win, selected_po_data, doc_type="expense"))
        elif v_type == "income":
            ctx_menu.add_command(label="Create Duplicate", accelerator="Alt+2", command=cmd_duplicate)
            
            rec_menu = tk.Menu(ctx_menu, tearoff=0, font=("Segoe UI", 11))
            rec_menu.add_command(label="Monthly", command=lambda: cmd_recurring(30))
            rec_menu.add_command(label="Yearly", command=lambda: cmd_recurring(365))
            ctx_menu.add_cascade(label="Make Recurring", menu=rec_menu)
            
            ctx_menu.add_separator()
            ctx_menu.add_command(label="View Income", command=lambda: invoice_preview.show_invoice_preview(win, selected_po_data, doc_type="income"))
        elif v_type == "contra":
            ctx_menu.add_command(label="Create Duplicate", accelerator="Alt+2", command=cmd_duplicate)
            
            rec_menu = tk.Menu(ctx_menu, tearoff=0, font=("Segoe UI", 11))
            rec_menu.add_command(label="Monthly", command=lambda: cmd_recurring(30))
            rec_menu.add_command(label="Yearly", command=lambda: cmd_recurring(365))
            ctx_menu.add_cascade(label="Make Recurring", menu=rec_menu)
            
            ctx_menu.add_separator()
            ctx_menu.add_command(label="View Banking Transaction", command=lambda: invoice_preview.show_invoice_preview(win, selected_po_data, doc_type="contra"))
        elif v_type == "journal":
            ctx_menu.add_command(label="Create Duplicate", accelerator="Alt+2", command=cmd_duplicate)
            
            rec_menu = tk.Menu(ctx_menu, tearoff=0, font=("Segoe UI", 11))
            rec_menu.add_command(label="Monthly", command=lambda: cmd_recurring(30))
            rec_menu.add_command(label="Yearly", command=lambda: cmd_recurring(365))
            ctx_menu.add_cascade(label="Make Recurring", menu=rec_menu)
            
            ctx_menu.add_command(label="Mark Paid", command=not_implemented)
            ctx_menu.add_separator()
            ctx_menu.add_command(label="View Journal", command=lambda: invoice_preview.show_invoice_preview(win, selected_po_data, doc_type="journal"))
        elif v_type == "debit_note":
            ctx_menu.add_command(label="Create Duplicate", accelerator="Alt+2", command=cmd_duplicate)
            
            rec_menu = tk.Menu(ctx_menu, tearoff=0, font=("Segoe UI", 11))
            rec_menu.add_command(label="Monthly", command=lambda: cmd_recurring(30))
            rec_menu.add_command(label="Yearly", command=lambda: cmd_recurring(365))
            ctx_menu.add_cascade(label="Make Recurring", menu=rec_menu)
            
            ctx_menu.add_command(label="Mark Paid", command=not_implemented)
            ctx_menu.add_separator()
            ctx_menu.add_command(label="View Debit Note", command=lambda: invoice_preview.show_invoice_preview(win, selected_po_data, doc_type="debit_note"))
        elif v_type == "credit_note":
            ctx_menu.add_command(label="Create Duplicate", accelerator="Alt+2", command=cmd_duplicate)
            
            rec_menu = tk.Menu(ctx_menu, tearoff=0, font=("Segoe UI", 11))
            rec_menu.add_command(label="Monthly", command=lambda: cmd_recurring(30))
            rec_menu.add_command(label="Yearly", command=lambda: cmd_recurring(365))
            ctx_menu.add_cascade(label="Make Recurring", menu=rec_menu)
            
            ctx_menu.add_command(label="Mark Paid", command=not_implemented)
            ctx_menu.add_separator()
            ctx_menu.add_command(label="View Credit Note", command=lambda: invoice_preview.show_invoice_preview(win, selected_po_data, doc_type="credit_note"))
        else:
            ctx_menu.add_command(label="Create Credit Note", command=cmd_credit_note)
            ctx_menu.add_command(label="Create Duplicate", accelerator="Alt+2", command=cmd_duplicate)
            
            rec_menu = tk.Menu(ctx_menu, tearoff=0, font=("Segoe UI", 11))
            rec_menu.add_command(label="Monthly", command=lambda: cmd_recurring(30))
            rec_menu.add_command(label="Yearly", command=lambda: cmd_recurring(365))
            ctx_menu.add_cascade(label="Make Recurring", menu=rec_menu)
            
            ctx_menu.add_separator()
            ctx_menu.add_command(label="e-Way Bill", command=not_implemented)
            ctx_menu.add_command(label="View Delivery Note", command=lambda: invoice_preview.show_invoice_preview(win, selected_po_data, doc_type="delivery_note"))
            ctx_menu.add_command(label="View Invoice", command=lambda: invoice_preview.show_invoice_preview(win, selected_po_data, doc_type="sale"))

        def show_ctx_menu(event, row_fr, inv_data):
            on_row_click(event, row_fr)
            set_selected_data(inv_data)
            
            # Rebuild context menu dynamically based on row's transaction type
            ctx_menu.delete(0, "end")
            ctx_menu.add_command(label="Edit", command=cmd_edit)
            ctx_menu.add_command(label="Delete", accelerator="Alt+D", command=cmd_delete)
            ctx_menu.add_command(label="Cancel", accelerator="Alt+X", command=cmd_cancel)
            ctx_menu.add_separator()
            
            t = inv_data.get("type") or v_type
            if t == "purchase_order":
                ctx_menu.add_command(label="Create Duplicate", accelerator="Alt+2", command=cmd_duplicate)
                ctx_menu.add_command(label="Mark Closed", command=cmd_mark_closed)
                ctx_menu.add_command(label="Make Purchase", command=cmd_make_purchase)
                ctx_menu.add_command(label="View Purchase Order", command=lambda: invoice_preview.show_invoice_preview(win, selected_po_data, doc_type="purchase_order"))
            elif t == "estimate":
                ctx_menu.add_command(label="Create Duplicate", accelerator="Alt+2", command=cmd_duplicate)
                ctx_menu.add_command(label="Mark Closed", command=cmd_mark_closed)
                ctx_menu.add_command(label="Make Invoice", command=cmd_make_invoice)
                ctx_menu.add_command(label="View Estimate", command=lambda: invoice_preview.show_invoice_preview(win, selected_po_data, doc_type="estimate"))
            elif t == "purchase":
                ctx_menu.add_command(label="Payment to Supplier", command=not_implemented)
                ctx_menu.add_command(label="Create Debit Note", command=not_implemented)
                ctx_menu.add_command(label="Create Duplicate", accelerator="Alt+2", command=cmd_duplicate)
                ctx_menu.add_command(label="Convert Purchase to Sale", command=not_implemented)
                
                rec_menu = tk.Menu(ctx_menu, tearoff=0, font=("Segoe UI", 11))
                rec_menu.add_command(label="Monthly", command=lambda: cmd_recurring(30))
                rec_menu.add_command(label="Yearly", command=lambda: cmd_recurring(365))
                ctx_menu.add_cascade(label="Make Recurring", menu=rec_menu)
                
                ctx_menu.add_separator()
                ctx_menu.add_command(label="Mark Paid", command=not_implemented)
                ctx_menu.add_command(label="View Purchase", command=lambda: invoice_preview.show_invoice_preview(win, selected_po_data, doc_type="purchase"))
            elif t == "expense":
                ctx_menu.add_command(label="Create Duplicate", accelerator="Alt+2", command=cmd_duplicate)
                rec_menu = tk.Menu(ctx_menu, tearoff=0, font=("Segoe UI", 11))
                rec_menu.add_command(label="Monthly", command=lambda: cmd_recurring(30))
                rec_menu.add_command(label="Yearly", command=lambda: cmd_recurring(365))
                ctx_menu.add_cascade(label="Make Recurring", menu=rec_menu)
                ctx_menu.add_separator()
                ctx_menu.add_command(label="View Expense", command=lambda: invoice_preview.show_invoice_preview(win, selected_po_data, doc_type="expense"))
            elif t == "income":
                ctx_menu.add_command(label="Create Duplicate", accelerator="Alt+2", command=cmd_duplicate)
                rec_menu = tk.Menu(ctx_menu, tearoff=0, font=("Segoe UI", 11))
                rec_menu.add_command(label="Monthly", command=lambda: cmd_recurring(30))
                rec_menu.add_command(label="Yearly", command=lambda: cmd_recurring(365))
                ctx_menu.add_cascade(label="Make Recurring", menu=rec_menu)
                ctx_menu.add_separator()
                ctx_menu.add_command(label="View Income", command=lambda: invoice_preview.show_invoice_preview(win, selected_po_data, doc_type="income"))
            elif t == "contra":
                ctx_menu.add_command(label="Create Duplicate", accelerator="Alt+2", command=cmd_duplicate)
                rec_menu = tk.Menu(ctx_menu, tearoff=0, font=("Segoe UI", 11))
                rec_menu.add_command(label="Monthly", command=lambda: cmd_recurring(30))
                rec_menu.add_command(label="Yearly", command=lambda: cmd_recurring(365))
                ctx_menu.add_cascade(label="Make Recurring", menu=rec_menu)
                ctx_menu.add_separator()
                ctx_menu.add_command(label="View Banking Transaction", command=lambda: invoice_preview.show_invoice_preview(win, selected_po_data, doc_type="contra"))
            elif t == "journal":
                ctx_menu.add_command(label="Create Duplicate", accelerator="Alt+2", command=cmd_duplicate)
                rec_menu = tk.Menu(ctx_menu, tearoff=0, font=("Segoe UI", 11))
                rec_menu.add_command(label="Monthly", command=lambda: cmd_recurring(30))
                rec_menu.add_command(label="Yearly", command=lambda: cmd_recurring(365))
                ctx_menu.add_cascade(label="Make Recurring", menu=rec_menu)
                ctx_menu.add_command(label="Mark Paid", command=not_implemented)
                ctx_menu.add_separator()
                ctx_menu.add_command(label="View Journal", command=lambda: invoice_preview.show_invoice_preview(win, selected_po_data, doc_type="journal"))
            elif t == "debit_note":
                ctx_menu.add_command(label="Create Duplicate", accelerator="Alt+2", command=cmd_duplicate)
                rec_menu = tk.Menu(ctx_menu, tearoff=0, font=("Segoe UI", 11))
                rec_menu.add_command(label="Monthly", command=lambda: cmd_recurring(30))
                rec_menu.add_command(label="Yearly", command=lambda: cmd_recurring(365))
                ctx_menu.add_cascade(label="Make Recurring", menu=rec_menu)
                ctx_menu.add_command(label="Mark Paid", command=not_implemented)
                ctx_menu.add_separator()
                ctx_menu.add_command(label="View Debit Note", command=lambda: invoice_preview.show_invoice_preview(win, selected_po_data, doc_type="debit_note"))
            elif t == "credit_note":
                ctx_menu.add_command(label="Create Duplicate", accelerator="Alt+2", command=cmd_duplicate)
                rec_menu = tk.Menu(ctx_menu, tearoff=0, font=("Segoe UI", 11))
                rec_menu.add_command(label="Monthly", command=lambda: cmd_recurring(30))
                rec_menu.add_command(label="Yearly", command=lambda: cmd_recurring(365))
                ctx_menu.add_cascade(label="Make Recurring", menu=rec_menu)
                ctx_menu.add_command(label="Mark Paid", command=not_implemented)
                ctx_menu.add_separator()
                ctx_menu.add_command(label="View Credit Note", command=lambda: invoice_preview.show_invoice_preview(win, selected_po_data, doc_type="credit_note"))
            elif t == "inventory_adjustment":
                ctx_menu.add_command(label="Create Duplicate", accelerator="Alt+2", command=cmd_duplicate)
                rec_menu = tk.Menu(ctx_menu, tearoff=0, font=("Segoe UI", 11))
                rec_menu.add_command(label="Monthly", command=lambda: cmd_recurring(30))
                rec_menu.add_command(label="Yearly", command=lambda: cmd_recurring(365))
                ctx_menu.add_cascade(label="Make Recurring", menu=rec_menu)
                ctx_menu.add_separator()
                ctx_menu.add_command(label="View Stock Journal", command=not_implemented)
            else:
                ctx_menu.add_command(label="Create Credit Note", command=cmd_credit_note)
                ctx_menu.add_command(label="Create Duplicate", accelerator="Alt+2", command=cmd_duplicate)
                rec_menu = tk.Menu(ctx_menu, tearoff=0, font=("Segoe UI", 11))
                rec_menu.add_command(label="Monthly", command=lambda: cmd_recurring(30))
                rec_menu.add_command(label="Yearly", command=lambda: cmd_recurring(365))
                ctx_menu.add_cascade(label="Make Recurring", menu=rec_menu)
                ctx_menu.add_separator()
                ctx_menu.add_command(label="e-Way Bill", command=not_implemented)
                ctx_menu.add_command(label="View Delivery Note", command=lambda: invoice_preview.show_invoice_preview(win, selected_po_data, doc_type="delivery_note"))
                ctx_menu.add_command(label="View Invoice", command=lambda: invoice_preview.show_invoice_preview(win, selected_po_data, doc_type="sale"))
            
            ctx_menu.tk_popup(event.x_root, event.y_root)

        def on_row_click(event, clicked_row_fr):
            for r in rows:
                base_bg = "#f7f9fa" if r.row_idx % 2 == 1 else WHITE
                for cell in r.winfo_children():
                    cell.configure(bg=base_bg)
                    for w in cell.winfo_children():
                        if not getattr(w, '_is_status_badge', False):
                            w.configure(bg=base_bg)
            for cell in clicked_row_fr.winfo_children():
                cell.configure(bg="#ffffa0")
                for w in cell.winfo_children():
                    if not getattr(w, '_is_status_badge', False):
                        w.configure(bg="#ffffa0")

        def get_row_status_details(inv, type_str, bg_col):
            amt_val = float(inv.get("total") or 0)
            paid_val = float(inv.get("paid") or 0)
            is_paid = paid_val >= amt_val and amt_val > 0
            
            text = ""
            bg = bg_col
            fg = "black"
            
            if type_str in ["purchase_order", "estimate"]:
                raw_st = str(inv.get("status") or "OPEN").strip().upper()
                text = raw_st if raw_st else "OPEN"
                if text == "CLOSED":
                    bg = "#d4edda" # soft green background
                    fg = "#155724" # dark green text
                else:
                    bg = "#e0e0e0"
                    fg = "#000000"
            elif is_paid:
                text = "Paid"
                bg = "#8fed8f" # green
            elif type_str in ["sale", "purchase", "journal", "credit_note", "debit_note"]:
                v_date_str = inv.get("date")
                if v_date_str:
                    try:
                        import datetime
                        v_date = datetime.datetime.strptime(v_date_str, "%Y-%m-%d").date()
                        today = datetime.date.today()
                        delta = (today - v_date).days
                        if delta > 0:
                            text = f"Overdue by\n{delta} days"
                            if type_str in ["sale", "journal", "credit_note"]:
                                bg = "#ffff33" # yellow
                            else:
                                bg = "#ff6666" # red
                                fg = "white"
                    except Exception:
                        pass
            return text, bg, fg

        for idx, inv in enumerate(invoices):
            bg_col = "#f7f9fa" if idx % 2 == 1 else WHITE
            row_fr = tk.Frame(list_inner, bg="#d0d0d0")
            row_fr.pack(fill="x", pady=(0, 1))
            row_fr.row_idx = idx
            row_fr.inv_data = inv
            rows.append(row_fr)

            for j, (htext, w_weight, align) in enumerate(col_defs):
                row_fr.columnconfigure(j, weight=w_weight, uniform="cols")

            # Column 0: Date
            d_fr = tk.Frame(row_fr, bg=bg_col, height=44)
            d_fr.grid(row=0, column=0, sticky="nsew", padx=(1, 1), pady=0)
            d_fr.pack_propagate(False)
            tk.Label(d_fr, text=inv.get("date", ""), font=FONT, bg=bg_col, anchor="w").pack(side="top", anchor="nw", padx=6, pady=4)

            # Column 1: Accounts
            a_fr = tk.Frame(row_fr, bg=bg_col, height=44)
            a_fr.grid(row=0, column=1, sticky="nsew", padx=(0, 1), pady=0)
            a_fr.pack_propagate(False)
            tk.Label(a_fr, text=inv.get("account_name", ""), font=FONT, bg=bg_col, anchor="w", justify="left").pack(anchor="w", padx=6, pady=(2, 0))

            # Column 2: Description
            desc_fr = tk.Frame(row_fr, bg=bg_col, height=44)
            desc_fr.grid(row=0, column=2, sticky="nsew", padx=(0, 1), pady=0)
            desc_fr.pack_propagate(False)
            
            curr_type = inv.get("type") or v_type
            type_labels = {
                "sale": "Sales",
                "purchase": "Purchase",
                "payment": "Payment",
                "receipt": "Receipt",
                "journal": "Journal",
                "contra": "Contra",
                "expense": "Expense",
                "income": "Income",
                "credit_note": "Credit Note",
                "debit_note": "Debit Note",
                "purchase_order": "Purchase Order",
                "estimate": "Estimate"
            }
            lbl_type = type_labels.get(curr_type, curr_type.capitalize())

            if curr_type in ["purchase_order", "estimate"]:
                label_text = f"Purchase Order No: {inv['invoice_no']}" if curr_type == "purchase_order" else f"Estimate No: {inv['invoice_no']}"
                tk.Label(desc_fr, text=label_text, font=FONT, bg=bg_col, anchor="w").pack(anchor="w", padx=6, pady=(2, 0))
                tk.Label(desc_fr, text=inv.get("desc", ""), font=FONT, bg=bg_col, anchor="w").pack(anchor="w", padx=6)
            else:
                tk.Label(desc_fr, text=lbl_type, font=FONT, bg=bg_col, anchor="w").pack(anchor="w", padx=6, pady=(2, 0))
                tk.Label(desc_fr, text=f"Voucher No:{inv['invoice_no']}", font=FONT, bg=bg_col, anchor="w").pack(anchor="w", padx=6)

            # Column 3: Amount
            amt_val = float(inv.get("total") or 0)
            amt_fr = tk.Frame(row_fr, bg=bg_col, height=44)
            amt_fr.grid(row=0, column=3, sticky="nsew", padx=(0, 1), pady=0)
            amt_fr.pack_propagate(False)
            amt_str = f"{amt_val:,.0f}" if amt_val.is_integer() else format_amt(amt_val, show_symbol=False)
            tk.Label(amt_fr, text=amt_str, font=FONT, bg=bg_col, anchor="e").pack(side="top", fill="x", padx=8, pady=4)

            # Column 4: Narration (only for PO / Estimate)
            nar_fr = None
            if v_type in ["purchase_order", "estimate"]:
                nar_fr = tk.Frame(row_fr, bg=bg_col, height=44)
                nar_fr.grid(row=0, column=4, sticky="nsew", padx=(0, 1), pady=0)
                nar_fr.pack_propagate(False)
                tk.Label(nar_fr, text=inv.get("notes", ""), font=FONT, bg=bg_col, anchor="w").pack(side="top", fill="x", padx=6, pady=4)

            # Column 4 (or 5): Status
            s_col_idx = 5 if v_type in ["purchase_order", "estimate"] else 4
            s_fr = tk.Frame(row_fr, bg=bg_col, height=44)
            s_fr.grid(row=0, column=s_col_idx, sticky="nsew", padx=(0, 1), pady=0)
            s_fr.pack_propagate(False)
            
            status_text, status_bg, status_fg = get_row_status_details(inv, curr_type, bg_col)
            stat_lbl = None
            if status_text:
                stat_lbl = tk.Label(s_fr, text=status_text, bg=status_bg, fg=status_fg, font=FONT_BOLD if "Paid" in status_text or "Overdue" in status_text else FONT, padx=6, pady=2, justify="center")
                stat_lbl._is_status_badge = True
                stat_lbl.pack(anchor="center", expand=True)

            click_widgets = [row_fr, d_fr, a_fr, desc_fr, amt_fr, s_fr]
            for cell_frame in (d_fr, a_fr, desc_fr, amt_fr, s_fr):
                click_widgets.extend(cell_frame.winfo_children())
            if nar_fr:
                click_widgets.append(nar_fr)
                click_widgets.extend(nar_fr.winfo_children())
                
            for widget in click_widgets:
                widget.bind("<Button-1>", lambda e, r=row_fr, i=inv: [on_row_click(e, r), set_selected_data(i)])
                widget.bind("<Double-Button-1>", lambda e, r=row_fr, i=inv: [on_row_click(e, r), set_selected_data(i), cmd_edit()])
                widget.bind("<Button-3>", lambda e, r=row_fr, i=inv: show_ctx_menu(e, r, i))

        # Search functionality
        def apply_search(*args):
            query = search_var.get().lower()
            try:
                selected_month = months_lb.get(months_lb.curselection()[0])
            except:
                selected_month = "All"
                
            m_map = {"Jan":"01", "Feb":"02", "Mar":"03", "Apr":"04", "May":"05", "Jun":"06",
                     "Jul":"07", "Aug":"08", "Sep":"09", "Oct":"10", "Nov":"11", "Dec":"12"}
            
            filter_date_prefix = ""
            if selected_month != "All":
                parts = selected_month.split("-")
                if len(parts) == 2:
                    filter_date_prefix = f"{parts[1]}-{m_map.get(parts[0], '')}"
                    
            matched_rows = []
            for r in rows:
                inv = r.inv_data
                match = (query in inv.get("invoice_no", "").lower() or 
                         query in inv.get("account_name", "").lower() or
                         query in str(inv.get("total", "")))
                         
                if filter_date_prefix:
                    d_iso = db.parse_date_to_iso(inv.get("date", ""))
                    if not (d_iso.startswith(filter_date_prefix) or inv.get("date", "").startswith(filter_date_prefix)):
                        match = False
                    
                if match:
                    matched_rows.append(r)
                else:
                    r.pack_forget()


            items_per_page = 20
            total_pages = max(1, (len(matched_rows) + items_per_page - 1) // items_per_page)
            if current_page[0] > total_pages:
                current_page[0] = total_pages
            if current_page[0] < 1:
                current_page[0] = 1
                
            start_idx = (current_page[0] - 1) * items_per_page
            end_idx = start_idx + items_per_page
            
            for k, r in enumerate(matched_rows):
                if start_idx <= k < end_idx:
                    r.pack(fill="x")
                else:
                    r.pack_forget()
                    
            page_lbl.config(text=f"Displaying page: {current_page[0]} of {total_pages}")
        search_var.trace_add("write", apply_search)
        months_lb.bind("<<ListboxSelect>>", apply_search)
        fin_year.bind("<<ComboboxSelected>>", apply_search)
        
        # Window key bindings
        win.bind("<Control-q>", lambda e: win.destroy())
        win.bind("<Control-Q>", lambda e: win.destroy())
        win.bind("<F3>", lambda e: search_entry.focus_set())
        if v_type in ["purchase_order", "estimate"]:
            win.bind("<Alt-F4>", lambda e: [win.destroy(), self.show_invoices("purchase_order")])
            win.bind("<Alt-F5>", lambda e: [win.destroy(), self.show_invoices("estimate")])
        else:
            win.bind("<F5>", lambda e: [win.destroy(), self._open_payment_supplier()])
            win.bind("<F6>", lambda e: [win.destroy(), self._open_receipt_customer()])
            win.bind("<F7>", lambda e: [win.destroy(), self._open_journal_voucher()])
            win.bind("<F8>", lambda e: [win.destroy(), self._open_create_voucher("sale")])
            win.bind("<F9>", lambda e: [win.destroy(), self._open_create_voucher("purchase")])
            win.bind("<Alt-e>", lambda e: [win.destroy(), self._open_expense_voucher()])
            win.bind("<Alt-E>", lambda e: [win.destroy(), self._open_expense_voucher()])
            win.bind("<Alt-i>", lambda e: [win.destroy(), self._open_income_voucher()])
            win.bind("<Alt-I>", lambda e: [win.destroy(), self._open_income_voucher()])
            win.bind("<F4>", lambda e: [win.destroy(), self._open_contra_voucher()])
        win.bind("<Alt-p>", lambda e: prev_page())
        win.bind("<Alt-P>", lambda e: prev_page())
        win.bind("<Alt-n>", lambda e: next_page())
        win.bind("<Alt-N>", lambda e: next_page())
        
        apply_search()

    def _new_invoice_form(self):
        win = tk.Toplevel(self)
        win.title("New Sale Invoice")
        win.geometry("750x560")
        win.configure(bg=BG)
        win.grab_set()

        # Header fields
        hdr = tk.Frame(win, bg=BG)
        hdr.pack(fill="x", padx=12, pady=8)

        tk.Label(hdr, text="Invoice No:", bg=BG, font=FONT).grid(row=0, column=0, sticky="w", pady=3)
        inv_no = tk.StringVar(value=db.get_next_invoice_no())
        tk.Entry(hdr, textvariable=inv_no, font=FONT, width=14,
                 relief="sunken", bd=2).grid(row=0, column=1, padx=6, pady=3)

        tk.Label(hdr, text="Date:", bg=BG, font=FONT).grid(row=0, column=2, sticky="w", padx=(12,0))
        date_v = tk.StringVar(value=datetime.date.today().isoformat())
        tk.Entry(hdr, textvariable=date_v, font=FONT, width=12,
                 relief="sunken", bd=2).grid(row=0, column=3, padx=6)

        tk.Label(hdr, text="Customer:", bg=BG, font=FONT).grid(row=1, column=0, sticky="w", pady=3)
        customers = db.get_all_accounts("customer")
        cnames = [r["name"] for r in customers]
        cids   = [r["id"]   for r in customers]
        cust_v = tk.StringVar()
        AutocompleteCombobox(hdr, textvariable=cust_v, values=cnames,
                     width=30, font=FONT).grid(row=1, column=1, columnspan=3,
                                               padx=6, pady=3, sticky="w")

        # Items grid
        tk.Label(win, text="Line Items:", bg=BG, font=FONT_BOLD,
                 anchor="w").pack(fill="x", padx=12)
        item_fr = tk.Frame(win, bg=WHITE, relief="sunken", bd=1)
        item_fr.pack(fill="both", expand=True, padx=12, pady=4)

        headers = ["Item Name", "Qty", "Unit", "Price", "Tax%", "Amount"]
        widths  = [25, 6, 7, 10, 6, 10]
        for j, (h, w) in enumerate(zip(headers, widths)):
            tk.Label(item_fr, text=h, bg="#e0e0e0", fg="#000",
                     font=FONT_BOLD, width=w, relief="raised", bd=1,
                     anchor="w", padx=4, pady=3).grid(row=0, column=j, sticky="ew")

        line_rows = []

        def add_line():
            ri = len(line_rows) + 1
            all_items = db.get_all_items()
            item_names = [r["name"] for r in all_items]

            item_v  = tk.StringVar()
            qty_v   = tk.StringVar(value="1")
            unit_v  = tk.StringVar(value="Nos")
            price_v = tk.StringVar(value="0")
            tax_v   = tk.StringVar(value="0")
            total_v = tk.StringVar(value="0.00")

            def autofill(e=None):
                name = item_v.get()
                for it in all_items:
                    if it["name"] == name:
                        price_v.set(str(it["sale_price"]))
                        unit_v.set(it["unit"])
                        recalc()
                        break

            def recalc(e=None):
                try:
                    t = float(qty_v.get() or 0) * float(price_v.get() or 0) * (1 + float(tax_v.get() or 0)/100)
                    total_v.set(format_amt(t, show_symbol=False))
                    update_grand()
                except:
                    pass

            cb = AutocompleteCombobox(item_fr, textvariable=item_v,
                              values=item_names, width=23, font=FONT)
            cb.grid(row=ri, column=0, padx=1, pady=1, sticky="ew")
            cb.bind("<<ComboboxSelected>>", autofill)

            for ci, (var, w) in enumerate(zip(
                [qty_v, unit_v, price_v, tax_v], [5, 6, 9, 5]), start=1
            ):
                e = tk.Entry(item_fr, textvariable=var, font=FONT, width=w,
                             relief="sunken", bd=1)
                e.grid(row=ri, column=ci, padx=1, pady=1)
                e.bind("<FocusOut>", recalc)
                e.bind("<Return>", recalc)

            tk.Label(item_fr, textvariable=total_v, bg=WHITE, font=FONT,
                     anchor="e", width=11).grid(row=ri, column=5, padx=2)

            line_rows.append({"item_v": item_v, "qty_v": qty_v, "unit_v": unit_v,
                               "price_v": price_v, "tax_v": tax_v, "total_v": total_v,
                               "all_items": all_items})

        grand_v = tk.StringVar(value="Grand Total:  Rs 0.00")

        def update_grand():
            tot = sum(float(r["total_v"].get() or 0) for r in line_rows)
            grand_v.set(f"Grand Total:  {format_amt(tot)}")

        def save_inv():
            line_items = []
            all_db = db.get_all_items()
            for r in line_rows:
                name = r["item_v"].get().strip()
                if not name:
                    continue
                item_id = next((it["id"] for it in all_db if it["name"] == name), None)
                try:
                    qty   = float(r["qty_v"].get() or 1)
                    price = float(r["price_v"].get() or 0)
                    tax   = float(r["tax_v"].get() or 0)
                    total = float(r["total_v"].get() or 0)
                except:
                    continue
                line_items.append({"item_id": item_id, "name": name,
                                   "qty": qty, "unit": r["unit_v"].get(),
                                   "price": price, "tax_pct": tax, "total": total})
            if not line_items:
                messagebox.showerror("Error", "Add at least one item!", parent=win)
                return

            # Fix 3: Check negative inventory
            if not self.check_negative_inventory(line_items, win):
                return

            # Fix 4: Apply roundoff to grand total
            grand_total = sum(it["total"] for it in line_items)
            rounded = self.apply_roundoff(grand_total)
            if rounded != grand_total and line_items:
                line_items[-1]["total"] += (rounded - grand_total)

            acc_id = None
            cn = cust_v.get()
            if cn in cnames:
                acc_id = cids[cnames.index(cn)]
            db.create_invoice(inv_no.get().strip(), "sale",
                              acc_id, date_v.get().strip(), line_items)
            messagebox.showinfo("Saved", f"Invoice {inv_no.get()} saved!")
            win.destroy()
            self.show_invoices()

        ftr = tk.Frame(win, bg=BG)
        ftr.pack(fill="x", padx=12, pady=6)
        make_button(ftr, "  ➕ Add Line  ", command=add_line).pack(side="left", padx=2)
        tk.Label(ftr, textvariable=grand_v, bg=BG,
                 font=FONT_BOLD, fg=GREEN_DARK).pack(side="right", padx=12)
        make_button(ftr, "  ✕ Cancel  ", command=win.destroy).pack(side="right", padx=2)
        make_button(ftr, "  💾 Save Invoice  ", command=save_inv).pack(side="right", padx=2)

        add_line()

    # ═════════════════════════════════════════════════════════════════════════
    #  REPORTS
    # ═════════════════════════════════════════════════════════════════════════
    def show_profit_loss(self):
        import report_profit_loss
        import importlib
        importlib.reload(report_profit_loss)
        report_profit_loss.ReportProfitLoss(self)

    def show_trial_balance(self):
        import report_trial_balance
        import importlib
        importlib.reload(report_trial_balance)
        report_trial_balance.ReportTrialBalance(self)

    def show_balance_sheet(self):
        import report_balance_sheet
        import importlib
        importlib.reload(report_balance_sheet)
        report_balance_sheet.ReportBalanceSheet(self)

    def show_ledger(self):
        import report_ledger
        win = tk.Toplevel(self)
        win.title("Ledger")
        win.geometry("1100x700")
        win.configure(bg="#ffffff")
        win.grab_set() # Make it modal if desired, or let it float
        report_ledger.LedgerReportView(win, win)
        
    def show_aged_payable(self):
        import report_aging
        report_aging.AgingReportView(self, self, is_receivable=False)
        
    def show_aged_receivable(self):
        import report_aging
        report_aging.AgingReportView(self, self, is_receivable=True)
        
    def show_customer_supplier_list(self):
        import report_cust_supp
        report_cust_supp.CustomerSupplierListView(self, self)
        
    def show_outstanding_payable(self):
        import report_outstanding
        report_outstanding.OutstandingReportView(self, self, is_receivable=False)
        
    def show_outstanding_receivable(self):
        import report_outstanding
        report_outstanding.OutstandingReportView(self, self, is_receivable=True)


    def show_sales_register(self):
        if not self.check_permission("sales_view", "view sales register"):
            return
        import report_sales_register
        import importlib
        importlib.reload(report_sales_register)
        report_sales_register.ReportSalesRegister(self)

    def show_purchase_register(self):
        if not self.check_permission("purchase_view", "view purchase register"):
            return
        import report_purchase_register
        import importlib
        importlib.reload(report_purchase_register)
        report_purchase_register.ReportPurchaseRegister(self)

    def show_monthly_breakdown(self):
        import report_monthly_breakdown
        import importlib
        importlib.reload(report_monthly_breakdown)
        report_monthly_breakdown.ReportMonthlyBreakdown(self)

    def show_best_customer(self):
        import report_best_customer
        import importlib
        importlib.reload(report_best_customer)
        report_best_customer.ReportBestCustomer(self)

    def show_top_supplier(self):
        import report_top_supplier
        import importlib
        importlib.reload(report_top_supplier)
        report_top_supplier.ReportTopSupplier(self)

    def show_inventory_details(self): self.show_inventory()

    def show_inventory_summary(self):
        self._clear_main()
        self._make_tab_header("Inventory Summary")
        _, inner, _ = self._make_scrollable()
        cols = ("Name", "Code", "Unit", "Stock", "Sale Price", "Value")
        tree = ttk.Treeview(inner, columns=cols, show="headings", height=25)
        for col in cols:
            tree.heading(col, text=col)
            tree.column(col, width=140)
        vsb = ttk.Scrollbar(inner, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        tree.pack(fill="both", expand=True, padx=6)
        for item in db.get_all_items():
            val = item["stock"] * item["sale_price"]
            tree.insert("", "end", values=(
                item["name"], item["code"] or "", item["unit"],
                format_amt(item['stock'], show_symbol=False), format_amt(item['sale_price'], show_symbol=False), format_amt(val, show_symbol=False)))

    def show_tax_register(self):
        self._clear_main()
        self._make_tab_header("Tax Register")
        _, inner, _ = self._make_scrollable()
        tk.Label(inner, text="Tax Register — Coming Soon",
                 bg=WHITE, font=FONT_LG, padx=20, pady=20).pack(anchor="w")

    def show_inventory_item_details(self):
        try:
            from report_inventory_details import InventoryItemDetailsView
            InventoryItemDetailsView(self)
        except Exception as e:
            import traceback
            traceback.print_exc()

    def show_inventory_summary(self):
        try:
            from report_inventory_summary import InventorySummaryView
            InventorySummaryView(self)
        except Exception as e:
            import traceback
            traceback.print_exc()

    def show_all_reports(self):
        self._clear_main()
        import all_reports
        self.current_view = 'all_reports'
        all_reports.AllReportsView(self.main_frame, self)

    def _unit_form(self, existing=None):
        win = tk.Toplevel(self)
        win.title("Unit Of Measure")
        win.geometry("400x150")
        win.configure(bg="#ffffff")
        win.grab_set()

        tk.Label(win, text="Unit Name", bg="#ffffff", fg="#000", font=FONT).place(x=20, y=30)
        e = tk.Entry(win, font=FONT, width=20, relief="solid", bd=1)
        e.place(x=120, y=30)
        
        if existing:
            e.insert(0, existing['units_name'])
        
        def save(event=None):
            val = e.get().strip()
            if not val:
                messagebox.showerror("Error", "Unit Name is required!", parent=win)
                return
            try:
                if existing:
                    db.update_unit(existing['units_name'], {"units_name": val})
                else:
                    db.add_unit({"units_name": val})
                win.destroy()
                if hasattr(self, 'current_view') and self.current_view == "units":
                    self.show_units()
            except Exception as ex:
                messagebox.showerror("Database Error", str(ex), parent=win)
                
        tk.Button(win, text="Save", bg="#e0e0e0", font=FONT, command=save, relief="solid", bd=1).place(x=120, y=80, width=80)
        win.bind("<Return>", save)
        win.bind("<Escape>", lambda ev: win.destroy())

    def show_units(self):
        self._clear_main()
        
        tb = tk.Frame(self.main_frame, bg="#ffffff")
        tb.pack(fill="x")
        
        btn_exit = tk.Button(tb, text="[X] Ctrl+Q: Exit", bg="#ffffff", relief="flat", font=(FONT[0], 9), command=self.quit)
        btn_exit.pack(side="left", padx=2)
        
        btn_new = tk.Button(tb, text="[+] F2: New Unit Of Measure", bg="#ffffff", relief="flat", font=(FONT[0], 9), command=lambda: self._unit_form())
        btn_new.pack(side="left", padx=2)
        
        self.bind("<F2>", lambda e: self._unit_form())
        
        title_lbl = tk.Label(self.main_frame, text="Unit Of Measure", bg="#d3d3d3", font=(FONT[0], 11, "bold"))
        title_lbl.pack(fill="x")
        
        search_frame = tk.Frame(self.main_frame, bg="#d3d3d3")
        search_frame.pack(fill="x")
        tk.Label(search_frame, text="F3: Search:", bg="#d3d3d3", font=FONT).pack(side="left", padx=5, pady=5)
        search_var = tk.StringVar()
        search_entry = tk.Entry(search_frame, textvariable=search_var, font=FONT, width=40)
        search_entry.pack(side="left", pady=5)
        
        self.bind("<F3>", lambda e: search_entry.focus_set())
        
        tk.Label(self.main_frame, text="Press ENTER to edit and DELETE to delete", fg="darkred", bg="#d3d3d3", font=(FONT[0], 9, "italic", "bold"), anchor="w").pack(fill="x", padx=5)
        
        tree_frame = tk.Frame(self.main_frame, bg="#d3d3d3")
        tree_frame.pack(fill="both", expand=True, padx=5, pady=5)
        
        cols = ("Unit Name", "Symbol")
        tree = ttk.Treeview(tree_frame, columns=cols, show="headings", height=20)
        tree.heading("Unit Name", text="Unit Name")
        tree.heading("Symbol", text="Symbol")
        tree.column("Unit Name", width=200, anchor="w")
        tree.column("Symbol", width=200, anchor="w")
        
        tree.bind("<Return>", lambda e: self._edit_selected_unit(tree))
        tree.bind("<Delete>", lambda e: self._delete_selected_unit(tree))
        
        vsb = ttk.Scrollbar(tree_frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        tree.pack(fill="both", expand=True)
        
        self.main_frame.configure(bg="#d3d3d3")
        
        def load_units(*args):
            q = search_var.get().lower()
            for item in tree.get_children():
                tree.delete(item)
            for u in db.get_all_units():
                u_name = str(u.get('units_name', ''))
                symb = str(u.get('symbol', ''))
                if q in u_name.lower() or q in symb.lower():
                    tree.insert("", "end", iid=u_name, values=(u_name, symb))
        
        search_var.trace_add("write", load_units)
        load_units()
        
        self.current_list_refresh = load_units

    def _edit_selected_unit(self, tree):
        sel = tree.selection()
        if not sel: return
        unit_name = sel[0]
        u = next((u for u in db.get_all_units() if u["units_name"] == unit_name), None)
        if u:
            self._unit_form(existing=u)

    def _delete_selected_unit(self, tree):
        sel = tree.selection()
        if not sel: return
        if messagebox.askyesno("Confirm", "Delete selected unit?", parent=self):
            try:
                db.delete_unit(sel[0])
                if hasattr(self, 'current_list_refresh'):
                    self.current_list_refresh()
            except Exception as e:
                messagebox.showerror("Error", str(e), parent=self)


    def show_service(self):
        self.current_view = "service"
        self._clear_main()
        
        BG_PAGE = "#d2d9d4"
        
        # 1. Top Action Bar
        tb = tk.Frame(self.main_frame, bg="#ffffff")
        tb.pack(fill="x")
        
        btn_exit = tk.Button(tb, text="✖ Ctrl+Q: Exit", bg="#ffffff", relief="flat",
                             font=(FONT[0], 9), command=self.show_dashboard, cursor="hand2")
        btn_exit.pack(side="left", padx=2)
        
        btn_new = tk.Button(tb, text="⏱️ F2: Add Service", bg="#ffffff", relief="flat",
                            font=(FONT[0], 9), command=lambda: self._service_form(), cursor="hand2")
        btn_new.pack(side="left", padx=2)
        
        self.bind("<F2>", lambda e: self._service_form())
        self.bind("<Control-q>", lambda e: self.show_dashboard())
        self.bind("<Control-Q>", lambda e: self.show_dashboard())
        
        # 2. Main Page Header
        title_lbl = tk.Label(self.main_frame, text="Service", bg=BG_PAGE, fg="black",
                             font=(FONT[0], 12, "bold"))
        title_lbl.pack(fill="x", pady=(4, 2))
        
        # 3. Search Bar
        search_frame = tk.Frame(self.main_frame, bg=BG_PAGE)
        search_frame.pack(fill="x", padx=10)
        tk.Label(search_frame, text="F3: Search:", bg=BG_PAGE, font=FONT).pack(side="left", padx=(0, 5), pady=4)
        
        search_var = tk.StringVar()
        search_entry = tk.Entry(search_frame, textvariable=search_var, font=FONT, width=42, relief="solid", bd=1)
        search_entry.pack(side="left", pady=4)
        
        self.bind("<F3>", lambda e: search_entry.focus_set())
        
        # 4. Instruction Label
        tk.Label(self.main_frame, text="Press ENTER to edit and DELETE to delete",
                 fg="#800000", bg=BG_PAGE, font=(FONT[0], 9, "italic", "bold"),
                 anchor="w").pack(fill="x", padx=10, pady=(2, 4))
        
        # 5. Treeview Table Container
        tree_frame = tk.Frame(self.main_frame, bg=BG_PAGE)
        tree_frame.pack(fill="both", expand=True, padx=10, pady=(0, 10))
        
        cols = ("Service Name", "Service Description")
        tree = ttk.Treeview(tree_frame, columns=cols, show="headings", height=22, selectmode="browse")
        
        tree.heading("Service Name", text="Service Name", anchor="w")
        tree.heading("Service Description", text="Service Description", anchor="w")
        
        tree.column("Service Name", width=280, anchor="w")
        tree.column("Service Description", width=420, anchor="w")
        
        # Style treeview with soft blue-grey highlight for selection
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("Service.Treeview", font=FONT, rowheight=30, background="#ffffff", fieldbackground="#ffffff")
        style.configure("Service.Treeview.Heading", font=(FONT[0], 9, "bold"), background="#ffffff", foreground="black")
        style.map("Service.Treeview",
                  background=[("selected", "#d0e2f5")],
                  foreground=[("selected", "#111827")])
        tree.configure(style="Service.Treeview")
        
        tree.bind("<Double-1>", lambda e: self._edit_selected_service(tree))
        tree.bind("<Return>", lambda e: self._edit_selected_service(tree))
        tree.bind("<Delete>", lambda e: self._delete_selected_service(tree))
        
        vsb = ttk.Scrollbar(tree_frame, orient="vertical", command=tree.yview)
        hsb = ttk.Scrollbar(tree_frame, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        
        vsb.pack(side="right", fill="y")
        hsb.pack(side="bottom", fill="x")
        tree.pack(fill="both", expand=True)
        
        self.main_frame.configure(bg=BG_PAGE)
        
        def load_services(*args):
            q = search_var.get().lower().strip()
            for item in tree.get_children():
                tree.delete(item)
            services = db.get_all_services()
            for s in services:
                s_name = str(s.get("service_name", "") or "")
                s_desc = str(s.get("service_desc", "") or "")
                if not q or q in s_name.lower() or q in s_desc.lower():
                    tree.insert("", "end", iid=s_name, values=(s_name, s_desc))
            
            # Select first item if available
            children = tree.get_children()
            if children:
                tree.selection_set(children[0])
                tree.focus(children[0])
        
        search_var.trace_add("write", load_services)
        load_services()
        self.current_list_refresh = load_services

    def _edit_selected_service(self, tree):
        sel = tree.selection()
        if not sel: return
        service_name = sel[0]
        s = db.get_service(service_name)
        if s:
            self._service_form(existing=s)

    def _delete_selected_service(self, tree):
        sel = tree.selection()
        if not sel: return
        service_name = sel[0]
        if messagebox.askyesno("Confirm Delete", f"Are you sure you want to delete service '{service_name}'?", parent=self):
            try:
                db.delete_service(service_name)
                if hasattr(self, 'current_list_refresh'):
                    self.current_list_refresh()
            except Exception as e:
                messagebox.showerror("Error", str(e), parent=self)

    def _unit_form_from_service(self, cb_uom):
        def on_saved():
            units = [u['units_name'] for u in db.get_all_units()]
            if not units:
                units = ["Kilogram", "nos", "hours", "days"]
            cb_uom['values'] = units
            if units:
                cb_uom.set(units[-1])
        
        win = tk.Toplevel(self)
        win.title("Unit Of Measure")
        win.geometry("400x150")
        win.configure(bg="#ffffff")
        win.grab_set()

        tk.Label(win, text="Unit Name", bg="#ffffff", fg="#000", font=FONT).place(x=20, y=30)
        e = tk.Entry(win, font=FONT, width=20, relief="solid", bd=1)
        e.place(x=120, y=30)
        e.focus_set()
        
        def save(event=None):
            val = e.get().strip()
            if not val:
                messagebox.showerror("Error", "Unit Name is required!", parent=win)
                return
            try:
                db.add_unit({"units_name": val})
                win.destroy()
                on_saved()
            except Exception as ex:
                messagebox.showerror("Database Error", str(ex), parent=win)
                
        tk.Button(win, text="Save", bg="#e0e0e0", font=FONT, command=save, relief="solid", bd=1).place(x=120, y=80, width=80)
        win.bind("<Return>", save)
        win.bind("<Escape>", lambda ev: win.destroy())

    def _service_form(self, existing=None):
        win = tk.Toplevel(self)
        win.title("Create Service" if not existing else "Edit Service")
        win.geometry("530x490")
        win.configure(bg="#ffffff")
        win.resizable(False, False)
        win.grab_set()

        # Center on screen
        win.update_idletasks()
        try:
            x = self.winfo_x() + (self.winfo_width() - 530) // 2
            y = self.winfo_y() + (self.winfo_height() - 490) // 2
            win.geometry(f"+{max(0, x)}+{max(0, y)}")
        except Exception:
            pass

        # Top Bar with Alt+U: New Unit Of Measure
        top_bar = tk.Frame(win, bg="#ffffff")
        top_bar.pack(fill="x", padx=10, pady=(6, 2))

        btn_new_uom = tk.Button(top_bar, text="⏱️ Alt+U: New Unit Of Measure", bg="#ffffff",
                                relief="flat", font=(FONT[0], 9), cursor="hand2",
                                command=lambda: self._unit_form_from_service(cb_uom))
        btn_new_uom.pack(side="left")

        tk.Frame(win, bg="#e0e0e0", height=1).pack(fill="x", padx=10, pady=2)

        # Header Instruction
        tk.Label(win, text="Press ENTER to move forward  SHIFT+ENTER to move back.",
                 fg="#800000", bg="#ffffff", font=(FONT[0], 9, "bold", "italic"),
                 anchor="w").pack(fill="x", padx=20, pady=(4, 8))

        # Main Form Container
        form_fr = tk.Frame(win, bg="#ffffff")
        form_fr.pack(fill="both", expand=True, padx=20, pady=4)

        # Field Helper Function for Yellow Focus Highlight
        def set_yellow_focus(widget):
            def on_in(e):
                widget.config(bg="#ffff00")
            def on_out(e):
                widget.config(bg="#ffffff")
            widget.bind("<FocusIn>", on_in)
            widget.bind("<FocusOut>", on_out)

        # 1. Service Name
        tk.Label(form_fr, text="Service Name", font=FONT, bg="#ffffff", fg="#000000",
                 anchor="e", width=18).grid(row=0, column=0, padx=(0, 10), pady=4, sticky="e")
        e_name = tk.Entry(form_fr, font=FONT, width=32, relief="solid", bd=1)
        e_name.grid(row=0, column=1, pady=4, sticky="w")
        set_yellow_focus(e_name)

        # 2. SKU/SAC
        tk.Label(form_fr, text="SKU/SAC", font=FONT, bg="#ffffff", fg="#000000",
                 anchor="e", width=18).grid(row=1, column=0, padx=(0, 10), pady=4, sticky="e")
        e_sku = tk.Entry(form_fr, font=FONT, width=32, relief="solid", bd=1)
        e_sku.grid(row=1, column=1, pady=4, sticky="w")
        set_yellow_focus(e_sku)

        # 3. Service Description
        tk.Label(form_fr, text="Service Description", font=FONT, bg="#ffffff", fg="#000000",
                 anchor="ne", width=18).grid(row=2, column=0, padx=(0, 10), pady=4, sticky="ne")
        txt_desc = tk.Text(form_fr, font=FONT, width=32, height=3, relief="solid", bd=1)
        txt_desc.grid(row=2, column=1, pady=(4, 0), sticky="w")
        
        lbl_desc_sub = tk.Label(form_fr, text="Ctrl+Enter for next line", font=(FONT[0], 8),
                                bg="#ffffff", fg="#666666", anchor="e")
        lbl_desc_sub.grid(row=3, column=1, sticky="e", pady=(0, 4))

        # 4. Unit Of Measure
        tk.Label(form_fr, text="Unit Of Measure", font=FONT, bg="#ffffff", fg="#000000",
                 anchor="e", width=18).grid(row=4, column=0, padx=(0, 10), pady=4, sticky="e")
        
        units_list = [u['units_name'] for u in db.get_all_units()]
        if not units_list:
            units_list = ["Kilogram", "nos", "hours", "days"]
        cb_uom = AutocompleteCombobox(form_fr, values=units_list, font=FONT, width=30, state="readonly")
        cb_uom.grid(row=4, column=1, pady=(4, 0), sticky="w")
        if units_list:
            cb_uom.current(0)
            
        lbl_uom_sub = tk.Label(form_fr, text="Service will be measured in terms of this unit (ex: hours, days).",
                               font=(FONT[0], 8), bg="#ffffff", fg="#666666", anchor="w")
        lbl_uom_sub.grid(row=5, column=1, sticky="w", pady=(0, 4))

        # 5. Default Tax Account
        tk.Label(form_fr, text="Default Tax Account", font=FONT, bg="#ffffff", fg="#000000",
                 anchor="e", width=18).grid(row=6, column=0, padx=(0, 10), pady=4, sticky="e")
        
        tax_list = [""] + [t.get('scheme_name', '') for t in db.get_all_taxes()]
        cb_tax = AutocompleteCombobox(form_fr, values=tax_list, font=FONT, width=30, state="readonly")
        cb_tax.grid(row=6, column=1, pady=(4, 0), sticky="w")
        if tax_list:
            cb_tax.current(0)
            
        lbl_tax_sub = tk.Label(form_fr, text="For nil rated items, select 0% tax\nFor exempted items, don't select tax account.",
                               font=(FONT[0], 8), bg="#ffffff", fg="#666666", justify="left", anchor="w")
        lbl_tax_sub.grid(row=7, column=1, sticky="w", pady=(0, 4))

        # 6. Remarks
        tk.Label(form_fr, text="Remarks", font=FONT, bg="#ffffff", fg="#000000",
                 anchor="e", width=18).grid(row=8, column=0, padx=(0, 10), pady=4, sticky="e")
        e_remarks = tk.Entry(form_fr, font=FONT, width=32, relief="solid", bd=1)
        e_remarks.grid(row=8, column=1, pady=(4, 0), sticky="w")
        set_yellow_focus(e_remarks)
        
        lbl_rem_sub = tk.Label(form_fr, text="Remarks are for internal use only, it won't be displayed anywhere.",
                               font=(FONT[0], 8), bg="#ffffff", fg="#666666", anchor="w")
        lbl_rem_sub.grid(row=9, column=1, sticky="w", pady=(0, 4))

        # Populate if editing
        if existing:
            e_name.insert(0, existing.get("service_name", "") or "")
            e_sku.insert(0, existing.get("sku", "") or "")
            txt_desc.insert("1.0", existing.get("service_desc", "") or "")
            if existing.get("units_name") and existing["units_name"] in units_list:
                cb_uom.set(existing["units_name"])
            if existing.get("scheme_name") and existing["scheme_name"] in tax_list:
                cb_tax.set(existing["scheme_name"])
            e_remarks.insert(0, existing.get("remarks", "") or "")

        # 7. Bottom Action Buttons
        bot_bar = tk.Frame(win, bg="#ffffff")
        bot_bar.pack(fill="x", side="bottom", padx=20, pady=(10, 15))

        btn_cancel = tk.Button(bot_bar, text="Ctrl+Q: Exit", font=FONT, bg="#ffffff",
                               relief="solid", bd=1, padx=14, pady=3, command=win.destroy, cursor="hand2")
        btn_cancel.pack(side="left")

        def save_service(event=None):
            name_val = e_name.get().strip()
            if not name_val:
                messagebox.showerror("Validation Error", "Service Name is required!", parent=win)
                e_name.focus_set()
                return

            sku_val = e_sku.get().strip()
            desc_val = txt_desc.get("1.0", "end-1c").strip()
            uom_val = cb_uom.get().strip()
            tax_val = cb_tax.get().strip()
            rem_val = e_remarks.get().strip()

            data = {
                "service_name": name_val,
                "sku": sku_val,
                "service_desc": desc_val,
                "units_name": uom_val,
                "scheme_name": tax_val,
                "remarks": rem_val
            }

            try:
                if existing:
                    db.update_service(existing["service_name"], data)
                else:
                    # Check duplicate
                    if db.get_service(name_val):
                        messagebox.showerror("Error", f"A service with name '{name_val}' already exists!", parent=win)
                        return
                    db.add_service(data)

                win.destroy()
                if hasattr(self, 'current_list_refresh'):
                    self.current_list_refresh()
            except Exception as ex:
                messagebox.showerror("Database Error", str(ex), parent=win)

        btn_save = tk.Button(bot_bar, text="F12:Save", font=(FONT[0], 9, "bold"), bg="#e8e8e8",
                             relief="solid", bd=1, padx=18, pady=3, command=save_service, cursor="hand2")
        btn_save.pack(side="right")

        # Shortcuts & Keyboard Navigation
        win.bind("<F12>", save_service)
        win.bind("<Control-q>", lambda e: win.destroy())
        win.bind("<Control-Q>", lambda e: win.destroy())
        win.bind("<Escape>", lambda e: win.destroy())
        win.bind("<Alt-u>", lambda e: self._unit_form_from_service(cb_uom))
        win.bind("<Alt-U>", lambda e: self._unit_form_from_service(cb_uom))

        # Enter and Shift+Enter navigation
        field_order = [e_name, e_sku, txt_desc, cb_uom, cb_tax, e_remarks, btn_save]

        def focus_next(idx):
            if idx + 1 < len(field_order):
                field_order[idx + 1].focus_set()

        def focus_prev(idx):
            if idx - 1 >= 0:
                field_order[idx - 1].focus_set()

        e_name.bind("<Return>", lambda e: (focus_next(0), "break")[1])
        e_sku.bind("<Return>", lambda e: (focus_next(1), "break")[1])
        
        # In Text Widget: Ctrl+Return inserts newline, Return advances to next field
        def on_text_return(e):
            focus_next(2)
            return "break"
        txt_desc.bind("<Return>", on_text_return)
        
        cb_uom.bind("<Return>", lambda e: (focus_next(3), "break")[1])
        cb_tax.bind("<Return>", lambda e: (focus_next(4), "break")[1])
        e_remarks.bind("<Return>", lambda e: (save_service(), "break")[1])

        e_sku.bind("<Shift-Return>", lambda e: (focus_prev(1), "break")[1])
        txt_desc.bind("<Shift-Return>", lambda e: (focus_prev(2), "break")[1])
        cb_uom.bind("<Shift-Return>", lambda e: (focus_prev(3), "break")[1])
        cb_tax.bind("<Shift-Return>", lambda e: (focus_prev(4), "break")[1])
        e_remarks.bind("<Shift-Return>", lambda e: (focus_prev(5), "break")[1])

        # Focus initial field
        e_name.focus_set()

    # ═════════════════════════════════════════════════════════════════════════
    #  CREATE VOUCHER (Sale/Invoice/Bill)
    # ═════════════════════════════════════════════════════════════════════════

    def _open_payment_supplier(self):
        if not self.check_permission("purchase_create", "create payment to supplier"):
            return
        w = payment_supplier.PaymentSupplierWindow(self, app=self)
        self.wait_window(w)
        
    def _open_receipt_customer(self):
        if not self.check_permission("sales_create", "create receipt from customer"):
            return
        w = receipt_customer.ReceiptCustomerWindow(self, app=self)
        self.wait_window(w)
        
    def _open_journal_voucher(self, edit_inv=None, is_duplicate=False):
        if not self.check_permission("journal_create", "create journal voucher"):
            return
        w = journal_voucher.JournalVoucherWindow(self, app=self, edit_inv=edit_inv, is_duplicate=is_duplicate)
        self.wait_window(w)

    def _open_credit_note_window(self, edit_inv=None, is_duplicate=False):
        if not self.check_permission("sales_create", "create credit note"):
            return
        w = credit_note.CreditNoteWindow(self, app=self, edit_inv=edit_inv, is_duplicate=is_duplicate)
        self.wait_window(w)

    def _open_debit_note_window(self, edit_inv=None, is_duplicate=False):
        if not self.check_permission("purchase_create", "create debit note"):
            return
        w = debit_note.DebitNoteWindow(self, app=self, edit_inv=edit_inv, is_duplicate=is_duplicate)
        self.wait_window(w)

    def _open_expense_voucher(self, edit_inv=None, is_duplicate=False):
        if not self.check_permission("exp_inc_create", "create expense voucher"):
            return
        win = tk.Toplevel(self)
        win.title("Create Voucher")
        win.geometry("1100x680")
        try:
            win.state("zoomed")
        except tk.TclError:
            pass
        win.configure(bg=BG)
        win.resizable(True, True)
        win.grab_set()

        top_bar_container = tk.Frame(win, bg=BG)
        top_bar_container.pack(fill="x", side="top")
        top_bar = tk.Frame(top_bar_container, bg="#ffffff")
        top_bar.pack(fill="x", side="top")
        tk.Frame(top_bar_container, bg=BG_DARK, height=1).pack(fill="x", side="top")

        shortcuts = [
            ("accounts", " New Account", self._generic_account_form),
            ("accounts", " New Expense Account", lambda: self._account_form("expense")),
            ("accounts", " New Income Account", lambda: self._account_form("income")),
        ]
        
        for i, (icon_key, txt, cmd) in enumerate(shortcuts):
            btn = tk.Button(top_bar, text=txt, image=self.icons_cache.get(icon_key), compound="left", bg="#ffffff", fg="#000",
                            font=("Segoe UI", 11), relief="flat", bd=0,
                            activebackground="#f0f0f0", activeforeground="#000",
                            cursor="hand2", command=cmd or (lambda: None))
            btn.image = self.icons_cache.get(icon_key)
            btn.pack(side="left", padx=4, pady=2)
            if i < len(shortcuts) - 1:
                tk.Label(top_bar, text="|", bg="#ffffff", fg="#cccccc", font=("Segoe UI", 11)).pack(side="left")

        hdr = tk.Frame(win, bg=WHITE, pady=4)
        hdr.pack(fill="x", padx=8)

        tk.Label(hdr, text="Press ENTER to move forward SHIFT+ENTER to move back.", bg=WHITE, fg="darkred",
                 font=("Segoe UI", 11, "bold italic")).grid(row=0, column=0, columnspan=4, sticky="w", padx=10)

        tk.Label(hdr, text="Payment No", bg=WHITE, font=FONT).grid(row=1, column=0, sticky="w", padx=4, pady=3)
        inv_no_var = tk.StringVar(value=db.get_next_invoice_no("PAY", "expense"))
        tk.Entry(hdr, textvariable=inv_no_var, font=FONT, width=22, relief="solid", bd=1, bg="yellow").grid(row=1, column=1, padx=4, pady=3, sticky="w")

        tk.Label(hdr, text="Voucher Date", bg=WHITE, font=FONT).grid(row=2, column=0, sticky="w", padx=4, pady=3)
        date_var = tk.StringVar(value=self.get_default_date())
        date_frame = tk.Frame(hdr, bg=WHITE)
        date_frame.grid(row=2, column=1, sticky="w", padx=4, pady=3)
        tk.Entry(date_frame, textvariable=date_var, font=FONT, width=16, relief="solid", bd=1, bg=WHITE).pack(side="left")
        tk.Label(date_frame, text=" 📅", bg=WHITE, font=("Segoe UI", 11)).pack(side="left")

        all_accounts = db.get_all_accounts()
        cash_bank = [a["name"] for a in all_accounts if a["account_group"] in ["cash", "bank", "Cash-in-hand", "Bank A/Cs"]]
        other_accounts = [a["name"] for a in all_accounts if a["account_group"] not in ["cash", "bank", "Cash-in-hand", "Bank A/Cs"]]
        def check_autocomplete(event, cb, full_list):
            if event.keysym in ('Up', 'Down', 'Return', 'Left', 'Right', 'Tab', 'Shift_L', 'Shift_R', 'BackSpace'):
                if event.keysym == 'BackSpace' and not cb.get():
                    cb['values'] = full_list
                return
            typed = cb.get()
            if typed == "":
                cb['values'] = full_list
            else:
                cb['values'] = [x for x in full_list if x.lower().startswith(typed.lower())]
            try:
                cb.event_generate('<Down>')
            except: pass


        tk.Label(hdr, text="Paid From", bg=WHITE, font=FONT).grid(row=3, column=0, sticky="w", padx=4, pady=3)
        paid_from_fr = tk.Frame(hdr, bg=WHITE)
        paid_from_fr.grid(row=3, column=1, sticky="w", padx=4, pady=3)
        paid_from_var = tk.StringVar(value="")
        paid_from_cb = AutocompleteCombobox(paid_from_fr, textvariable=paid_from_var, values=cash_bank, font=FONT, width=30)
        paid_from_cb.pack(side="top", anchor="w")
        paid_from_cb.bind("<KeyRelease>", lambda e: check_autocomplete(e, paid_from_cb, cash_bank))
        paid_from_cb.bind("<Return>", lambda e: paid_to_cb.focus_set())
        paid_from_cb.bind("<<ComboboxSelected>>", lambda e: win.after(10, paid_to_cb.focus_set))
        paid_from_bal = tk.Label(paid_from_fr, text="balance 0.00", bg=WHITE, font=("Segoe UI", 10))
        paid_from_bal.pack(side="top", anchor="w")

        def update_pf_bal(*args):
            bal = db.get_account_balance(paid_from_var.get())
            paid_from_bal.config(text=f"balance {bal:,.2f}")
        paid_from_var.trace_add("write", update_pf_bal)

        tk.Label(hdr, text="F9: Paid To", bg=WHITE, font=FONT).grid(row=3, column=2, sticky="e", padx=(40,4), pady=3)
        tk.Label(hdr, text="Press ENTER key to add.", bg=WHITE, fg="darkred", font=("Segoe UI", 11, "bold italic")).grid(row=2, column=3, sticky="w", padx=4)
        
        paid_to_fr = tk.Frame(hdr, bg=WHITE)
        paid_to_fr.grid(row=3, column=3, sticky="w", padx=4, pady=3)
        paid_to_var = tk.StringVar(value="")
        paid_to_cb = AutocompleteCombobox(paid_to_fr, textvariable=paid_to_var, values=other_accounts, font=FONT, width=30)
        paid_to_cb.pack(side="top", anchor="w")
        
        def on_paid_to_enter(e=None):
            acc_name = paid_to_var.get().strip()
            if acc_name:
                add_grid_row(acc_name)
                paid_to_var.set("")
            else:
                nar_text.focus_set()
            return "break"
        
        paid_to_cb.bind("<Return>", on_paid_to_enter)
        paid_to_cb.bind("<<ComboboxSelected>>", lambda e: win.after(10, on_paid_to_enter))
        paid_to_cb.bind("<KeyRelease>", lambda e: check_autocomplete(e, paid_to_cb, other_accounts))
        paid_to_bal = tk.Label(paid_to_fr, text="balance 0.00", bg=WHITE, font=("Segoe UI", 10))
        paid_to_bal.pack(side="top", anchor="w")

        def update_pt_bal(*args):
            bal = db.get_account_balance(paid_to_var.get())
            paid_to_bal.config(text=f"balance {bal:,.2f}")
        paid_to_var.trace_add("write", update_pt_bal)

        update_pf_bal()
        update_pt_bal()

        header_frame = tk.Frame(win, bg=WHITE, relief="flat", bd=0)
        header_frame.pack(fill="x", padx=8, pady=(4, 0))
        
        tk.Label(header_frame, text="Account", bg=WHITE, fg="#000", font=FONT, width=54, anchor="w", relief="flat", bd=0, padx=4, pady=4).pack(side="left")
        tk.Label(header_frame, text="Amount", bg=WHITE, fg="#000", font=FONT, width=18, anchor="w", relief="flat", bd=0, padx=4, pady=4).pack(side="left")
        tk.Label(header_frame, text="Delete", bg=WHITE, fg="#000", font=FONT, width=6, anchor="center", relief="flat", bd=0, padx=4, pady=4).pack(side="left")
        tk.Label(header_frame, text="Click ✕ or press DELETE to remove line", bg=WHITE, fg="#666", font=("Segoe UI", 9, "italic")).pack(side="right", padx=10)

        bot_btns = tk.Frame(win, bg=BG)
        bot_btns.pack(fill="x", side="bottom", padx=8, pady=4)
        tk.Button(bot_btns, text="Ctrl+Q: Exit", bg="#e0e0e0", font=FONT, command=win.destroy, relief="solid", bd=1).pack(side="left", ipadx=10, ipady=5)
        tk.Button(bot_btns, text="F12:Save", bg="#e0e0e0", font=FONT, command=lambda: save(), relief="solid", bd=1).pack(side="right", ipadx=10, ipady=5)
        tk.Button(bot_btns, text="Alt+F12: Save & View", bg="#e0e0e0", font=FONT, command=lambda: save(view_after=True), relief="solid", bd=1).pack(side="right", padx=10, ipadx=10, ipady=5)
        import subprocess
        tk.Button(bot_btns, text="🖩", bg="#e0e0e0", font=FONT, command=lambda: subprocess.Popen("calc"), relief="solid", bd=1).pack(side="right", padx=10, ipadx=10, ipady=5)

        bot_frame = tk.Frame(win, bg=BG)
        bot_frame.pack(fill="x", side="bottom", padx=8, pady=4)

        bot_left = tk.Frame(bot_frame, bg=BG)
        bot_left.pack(side="left", fill="both", expand=True)

        tk.Label(bot_left, text="Narration\nUse Ctrl+Enter for next line", bg=BG, fg="#000", font=("Segoe UI", 10), anchor="n").pack(side="left", anchor="n")
        nar_text = tk.Text(bot_left, font=FONT, width=40, height=4, relief="sunken", bd=1, bg=WHITE)
        nar_text.pack(side="left", fill="x", expand=True, padx=(5, 20))

        ref_lf = tk.LabelFrame(bot_left, text="Reference Document", bg=BG, font=("Segoe UI", 10))
        ref_lf.pack(side="left", anchor="n", padx=4, fill="y")
        
        ref_var = tk.StringVar()
        tk.Entry(ref_lf, textvariable=ref_var, font=FONT, width=28, relief="solid", bd=1, bg="#f0f0f0").pack(padx=4, pady=4)
        
        def on_browse_ref():
            from tkinter import filedialog
            path = filedialog.askopenfilename(title="Select Reference Document", parent=win)
            if path:
                ref_var.set(path)
                
        def on_view_ref():
            import os
            from tkinter import messagebox
            path = ref_var.get().strip()
            if path and os.path.exists(path):
                try:
                    os.startfile(path)
                except Exception as e:
                    messagebox.showerror("Error", f"Could not open file: {e}", parent=win)
            else:
                messagebox.showwarning("Warning", "File does not exist or path is empty.", parent=win)
                
        def on_delete_ref():
            ref_var.set("")

        ref_btn_fr = tk.Frame(ref_lf, bg=BG)
        ref_btn_fr.pack(fill="x", pady=2)
        tk.Button(ref_btn_fr, text="Browse", bg="#e0e0e0", relief="flat", bd=1, command=on_browse_ref).pack(side="left", padx=2, fill="x", expand=True)
        tk.Button(ref_btn_fr, text="View", bg="#e0e0e0", relief="flat", bd=1, command=on_view_ref).pack(side="left", padx=2, fill="x", expand=True)
        tk.Button(ref_btn_fr, text="Delete", bg="#e0e0e0", relief="flat", bd=1, command=on_delete_ref).pack(side="left", padx=2, fill="x", expand=True)

        bot_right = tk.Frame(bot_frame, bg=BG)
        bot_right.pack(side="right", anchor="n")

        tk.Label(bot_right, text="Total", bg=BG, font=FONT).pack(side="left", padx=4)
        total_var = tk.StringVar(value="0")
        tk.Entry(bot_right, textvariable=total_var, font=FONT, width=15, justify="right", relief="solid", bd=1, state="readonly", readonlybackground="#e0e0e0").pack(side="left", padx=4)

        grid_frame = tk.Frame(win, bg=WHITE, relief="sunken", bd=2)
        grid_frame.pack(fill="both", expand=True, padx=8, pady=(0, 4))
        grid_canvas = tk.Canvas(grid_frame, bg=WHITE, highlightthickness=0)
        grid_vsb = ttk.Scrollbar(grid_frame, orient="vertical", command=grid_canvas.yview)
        grid_canvas.configure(yscrollcommand=grid_vsb.set)
        grid_vsb.pack(side="right", fill="y")
        grid_canvas.pack(side="left", fill="both", expand=True)

        grid_inner = tk.Frame(grid_canvas, bg=BG_DARK)
        grid_cw = grid_canvas.create_window((0, 0), window=grid_inner, anchor="nw")
        grid_inner.bind("<Configure>", lambda e: grid_canvas.configure(scrollregion=grid_canvas.bbox("all")))
        grid_canvas.bind("<Configure>", lambda e: grid_canvas.itemconfig(grid_cw, width=e.width))

        line_data = []
        def recalc_total():
            t = sum(float(l["amt_var"].get() or 0) for l in line_data)
            total_var.set(f"{t:,.0f}")

        def add_grid_row(initial_acc=""):
            ri = len(line_data) + 1
            bg_color = WHITE if ri % 2 == 1 else "#f0f0f0"
            
            acc_v = tk.StringVar(value=initial_acc)
            amt_v = tk.StringVar(value="")
            
            cb = AutocompleteCombobox(grid_inner, textvariable=acc_v, values=other_accounts, font=FONT)
            cb.grid(row=ri, column=0, padx=(0, 1), pady=(0, 1), sticky="ew", ipady=5)
            
            amt_e = tk.Entry(grid_inner, textvariable=amt_v, font=FONT, justify="right", relief="flat", bd=0, bg="yellow")
            amt_e.grid(row=ri, column=1, padx=(0, 1), pady=(0, 1), sticky="ew", ipady=5)
            
            row_dict = {"acc_var": acc_v, "amt_var": amt_v, "row_idx": ri, "amt_e": amt_e, "acc_cb": cb}

            def del_this_row(e=None):
                if row_dict not in line_data:
                    return "break"
                line_data.remove(row_dict)
                for w in [row_dict.get("acc_cb"), row_dict.get("amt_e"), row_dict.get("del_btn")]:
                    if w and w.winfo_exists():
                        w.destroy()
                # Re-index all remaining rows cleanly and re-configure grid row
                for new_idx, rem in enumerate(line_data, start=1):
                    rem["row_idx"] = new_idx
                    if rem.get("acc_cb") and rem["acc_cb"].winfo_exists():
                        rem["acc_cb"].grid_configure(row=new_idx)
                    if rem.get("amt_e") and rem["amt_e"].winfo_exists():
                        rem["amt_e"].grid_configure(row=new_idx)
                    if rem.get("del_btn") and rem["del_btn"].winfo_exists():
                        rem["del_btn"].grid_configure(row=new_idx)
                recalc_total()
                paid_to_cb.focus_set()
                return "break"

            del_btn = tk.Button(
                grid_inner, text="✕", bg="#ffeeee", fg="#cc0000",
                activebackground="#cc0000", activeforeground="white",
                font=("Segoe UI", 9, "bold"), relief="flat", bd=0, cursor="hand2",
                command=del_this_row
            )
            del_btn.grid(row=ri, column=2, padx=(0, 1), pady=(0, 1), sticky="nsew", ipady=3)
            row_dict["del_btn"] = del_btn
            
            amt_e.bind("<KeyRelease>", lambda e: recalc_total())
            
            def on_amt_enter(e=None):
                recalc_total()
                paid_to_cb.focus_set()
                paid_to_cb.selection_range(0, tk.END)
                paid_to_cb.icursor(tk.END)
                return "break"
            
            amt_e.bind("<Return>", on_amt_enter)

            # Keyboard shortcuts for deletion across all row widgets
            for w in (cb, amt_e, del_btn):
                w.bind("<Delete>", del_this_row)
                w.bind("<Shift-Delete>", del_this_row)
                w.bind("<Control-Delete>", del_this_row)
                w.bind("<Alt-Delete>", del_this_row)
                w.bind("<Control-d>", del_this_row)
                w.bind("<Control-D>", del_this_row)
                w.bind("<Alt-d>", del_this_row)
                w.bind("<Alt-D>", del_this_row)
            
            del_btn.bind("<Return>", del_this_row)
            del_btn.bind("<space>", del_this_row)

            # Right click context menu
            menu = tk.Menu(win, tearoff=0)
            menu.add_command(label="Delete Line (✕)", command=del_this_row)
            cb.bind("<Button-3>", lambda e: menu.post(e.x_root, e.y_root))
            amt_e.bind("<Button-3>", lambda e: menu.post(e.x_root, e.y_root))
            del_btn.bind("<Button-3>", lambda e: menu.post(e.x_root, e.y_root))
            
            grid_inner.columnconfigure(0, weight=4)
            grid_inner.columnconfigure(1, weight=1)
            grid_inner.columnconfigure(2, weight=0, minsize=35)
            
            line_data.append(row_dict)
            
            if initial_acc:
                win.after(20, lambda: (amt_e.focus_set(), amt_e.selection_range(0, tk.END)))


        if edit_inv:
            conn = db.get_conn()
            main_row = conn.execute("SELECT * FROM vouchers WHERE v_id=?", (edit_inv["id"],)).fetchone()
            if main_row:
                if not is_duplicate:
                    inv_no_var.set(main_row["vch_no"])
                date_var.set(main_row["date"])
                nar_text.insert("1.0", main_row["narration"] or "")
                ref_var.set(main_row["detail2"] or "")
                
                # Fetch line items
                lines = conn.execute("SELECT * FROM vouchers_all WHERE v_id=?", (edit_inv["id"],)).fetchall()
                if lines:
                    paid_from_var.set(lines[0]["credit"]) # All lines share the same paid_from (credit)
                    update_pf_bal()
                    
                    for line in lines:
                        add_grid_row(line["debit"])
                        line_data[-1]["amt_var"].set(str(line["amount"]))
                recalc_total()
            conn.close()

        def reset_screen():
            for rd in list(line_data):
                for w in [rd.get("acc_cb"), rd.get("amt_e"), rd.get("del_btn")]:
                    if w and w.winfo_exists():
                        w.destroy()
            line_data.clear()
            recalc_total()
            inv_no_var.set(db.get_next_invoice_no("PAY", "expense"))
            paid_to_var.set("")
            ref_var.set("")
            nar_text.delete("1.0", "end")
            total_var.set("0")
            update_pf_bal()
            update_pt_bal()
            paid_to_cb.focus_set()

        def save(view_after=False):
            items = []
            for l in line_data:
                name = l["acc_var"].get()
                amt = l["amt_var"].get()
                if name and amt:
                    try:
                        amt_f = float(str(amt).replace(',', ''))
                        if amt_f > 0:
                            items.append({"name": name, "total": amt_f})
                    except: pass
            if not items:
                from tkinter import messagebox
                messagebox.showerror("Error", "No valid items entered", parent=win)
                return
            
            try:
                if edit_inv and not is_duplicate:
                    db.delete_voucher(edit_inv["id"])
                    
                v_id = db.create_expense(
                    invoice_no=inv_no_var.get(),
                    date=date_var.get(),
                    paid_from_acc=paid_from_var.get(),
                    paid_to_acc=paid_to_var.get(),
                    line_items=items,
                    notes=nar_text.get("1.0", "end").strip(),
                    status="OPEN",
                    ref_doc=ref_var.get()
                )
                
                saved_inv_data = {
                    "id": v_id,
                    "v_id": v_id,
                    "invoice_no": inv_no_var.get(),
                    "date": date_var.get(),
                    "type": "expense",
                    "total": sum(it['total'] for it in items),
                    "paid_from": paid_from_var.get(),
                    "paid_to": paid_to_var.get(),
                    "items": items,
                    "notes": nar_text.get("1.0", "end").strip(),
                    "ref_doc": ref_var.get()
                }
                
                from tkinter import messagebox
                if edit_inv and not is_duplicate:
                    messagebox.showinfo("Success", "Expense updated successfully!", parent=win)
                    win.destroy()
                    if view_after:
                        invoice_preview.show_invoice_preview(self, saved_inv_data, db, doc_type="expense")
                    else:
                        self.show_invoices("expense")
                else:
                    messagebox.showinfo("Success", "Expense saved successfully!", parent=win)
                    if view_after:
                        invoice_preview.show_invoice_preview(self, saved_inv_data, db, doc_type="expense")
                    reset_screen()
            except Exception as e:
                from tkinter import messagebox
                messagebox.showerror("Database Error", str(e), parent=win)
                
        win.bind("<Control-q>", lambda e: win.destroy())
        win.bind("<Control-Q>", lambda e: win.destroy())
        win.bind("<Alt-a>", lambda e: self._generic_account_form())
        win.bind("<Alt-A>", lambda e: self._generic_account_form())
        win.bind("<Alt-e>", lambda e: self._account_form("expense"))
        win.bind("<Alt-E>", lambda e: self._account_form("expense"))
        win.bind("<Alt-i>", lambda e: self._account_form("income"))
        win.bind("<Alt-I>", lambda e: self._account_form("income"))
        win.bind("<F9>", lambda e: paid_to_cb.focus_set())
        win.bind("<F12>", lambda e: save())
        win.bind("<Alt-F12>", lambda e: save(view_after=True))
        win.bind("<F12>", lambda e: save())
        win.bind("<Alt-F12>", lambda e: save(view_after=True))

    def _open_create_voucher(self, v_type="sale", linked_po=None, edit_inv=None, is_duplicate=False):
        if v_type == "inventory_adjustment":
            if not self.check_permission("inv_create", "create inventory adjustment"):
                return
            try:
                import inventory_adjustment
                inventory_adjustment.InventoryAdjustmentWindow(self)
            except Exception as e:
                import traceback
                print(traceback.format_exc())
            return
            
        # Check permissions based on voucher type
        if v_type in ("estimate", "sales_invoice", "sale", "credit_note", "delivery_challan"):
            if not self.check_permission("sales_create", "create sales voucher"):
                return
        elif v_type in ("purchase", "purchase_order", "debit_note"):
            if not self.check_permission("purchase_create", "create purchase voucher"):
                return
        win = tk.Toplevel(self)
        if v_type == "estimate":
            win.title("Estimate")
        elif v_type == "purchase_order":
            win.title("Purchase Order")
        elif v_type == "purchase":
            win.title("Purchase Invoice")
        elif v_type == "credit_note":
            win.title("Credit Note")
        elif v_type == "debit_note":
            win.title("Debit Note")
        else:
            win.title("Sales Invoice")
        win.geometry("1100x680")
        try:
            win.state("zoomed")
        except tk.TclError:
            pass
        win.configure(bg=BG)
        win.resizable(True, True)

        # ── Top shortcut bar ─────────────────────────────────────────────────
        top_bar_container = tk.Frame(win, bg=BG)
        top_bar_container.pack(fill="x", side="top")
        
        top_bar = tk.Frame(top_bar_container, bg="#ffffff")
        top_bar.pack(fill="x", side="top")
        
        # Bottom border for top bar
        tk.Frame(top_bar_container, bg=BG_DARK, height=1).pack(fill="x", side="top")

        shortcuts = [
            ("accounts", " New Account", self._generic_account_form),
            ("customer", " New Customer", lambda: self._account_form("customer")),
            ("supplier", " New Supplier", lambda: self._account_form("supplier")),
            ("tax", " New Tax Account", None),
            ("inventory", " New Inventory Item", lambda: self._item_form(parent=win)),
            ("service", " New Service", None),
        ]
        
        if v_type == "estimate":
            def open_load_template():
                import db
                templates = db.get_estimate_templates()
                if not templates:
                    messagebox.showinfo("No Templates", "No templates saved yet.", parent=win)
                    return
                
                t_win = tk.Toplevel(win)
                t_win.title("Select Template")
                t_win.geometry("500x300")
                t_win.grab_set()
                
                tk.Label(t_win, text="Select an Estimate Template to load:", font=FONT_BOLD).pack(pady=10)
                
                lb = tk.Listbox(t_win, font=FONT, width=50)
                lb.pack(fill="both", expand=True, padx=10, pady=5)
                
                for t in templates:
                    lb.insert(tk.END, f"{t['invoice_no']} - {t['notes'] or 'Template'} - Total: {t['total']}")
                    
                def on_load():
                    sel = lb.curselection()
                    if not sel: return
                    t_data = templates[sel[0]]
                    items = db.get_invoice_items(t_data['id'])
                    
                    # Clear existing grid
                    for r in line_data[:]:
                        for k, w in r.items():
                            if k.endswith('_w') and w:
                                w.destroy()
                    line_data.clear()
                    
                    # Add items
                    for it in items:
                        add_grid_row(item_name=it.get("item_name", ""),
                                     qty=str(it.get("qty", 1)),
                                     unit=it.get("unit", "Nos"),
                                     rate=str(it.get("price", 0)),
                                     disc=str(it.get("discount", 0)),
                                     tax=str(it.get("tax_pct", 0)))
                    recalc_total()
                    t_win.destroy()
                    
                tk.Button(t_win, text="Load Template", command=on_load, bg="#4CAF50", fg="white", font=FONT_BOLD).pack(pady=10)
                
            shortcuts.append(("template", " Load Template", open_load_template))
        
        for i, (icon_key, txt, cmd) in enumerate(shortcuts):
            btn = tk.Button(top_bar, text=txt, bg="#ffffff", fg="#000000",
                            font=("Segoe UI", 8), relief="flat", bd=0,
                            activebackground="#f0f0f0", activeforeground="#004499",
                            cursor="hand2", command=cmd or (lambda: None))
            btn.pack(side="left", padx=4, pady=2)
            if i < len(shortcuts) - 1:
                tk.Label(top_bar, text="|", bg="#ffffff", fg="#cccccc", font=("Segoe UI", 8)).pack(side="left")

        # Right side of top bar
        btn_mode = tk.Button(top_bar, text="Ctrl+M: Item Mode",
                             bg="#ffffff", fg="#000000", font=("Segoe UI", 8),
                             relief="flat", bd=0, activebackground="#f0f0f0",
                             activeforeground="#004499", cursor="hand2")
        btn_mode.pack(side="right", padx=(2, 8), pady=2)
        
        tk.Label(top_bar, text="|", bg="#ffffff", fg="#cccccc", font=("Segoe UI", 8)).pack(side="right")
        
        btn_search = tk.Button(top_bar, text="🔍 Ctrl+F: Search",
                               bg="#ffffff", fg="#000000", font=("Segoe UI", 8),
                               relief="flat", bd=0, activebackground="#f0f0f0",
                               activeforeground="#004499", cursor="hand2")
        btn_search.pack(side="right", padx=(8, 2), pady=2)

        # ── Header fields (2-column grid) ────────────────────────────────────
        hdr = tk.Frame(win, bg=WHITE, pady=4)
        hdr.pack(fill="x", padx=8)
        hdr.columnconfigure(2, minsize=150, weight=1)

        def lbl(parent, text, row, col, padx=4, pady=3, **kw):
            tk.Label(parent, text=text, bg=WHITE, fg="#000",
                     font=FONT, anchor="w", **kw).grid(
                row=row, column=col, sticky="w", padx=padx, pady=pady)

        def entry_field(parent, row, col, width=22, default=""):
            var = tk.StringVar(value=default)
            e = tk.Entry(parent, textvariable=var, font=FONT,
                         width=width, relief="solid", bd=1, bg=WHITE)
            e.grid(row=row, column=col, padx=(4, 25) if col == 4 else 4, pady=3, sticky="w")
            return var, e

        # Left column
        if v_type == "purchase_order":
            vch_lbl = "Purchase Order No"
            prefix = "PO"
        elif v_type == "purchase":
            vch_lbl = "Purchase No"
            prefix = "PUR"
        elif v_type == "estimate":
            vch_lbl = "Estimate No"
            prefix = "EST"
        else:
            vch_lbl = "Invoice No"
            prefix = "INV"
            
        lbl(hdr, vch_lbl, 0, 0)
        inv_no_var, _ = entry_field(hdr, 0, 1, 14, db.get_next_invoice_no(prefix, v_type))
        
        tk.Label(hdr, text="Press ENTER to move forward SHIFT+ENTER to move back.", bg=WHITE, fg="darkred",
                 font=("Segoe UI", 11, "bold italic")).grid(row=0, column=2, sticky="w", padx=10)

        def popup_calendar(var, anchor_widget):
            try:
                from tkcalendar import Calendar
                import datetime
            except ImportError:
                messagebox.showwarning("Missing Library", "tkcalendar is not installed.", parent=win)
                return
            top = tk.Toplevel(win)
            top.title("Select Date")
            top.grab_set()
            top.update_idletasks()
            anchor_widget.update_idletasks()
            cal_w = 260
            cal_h = 220
            ax = anchor_widget.winfo_rootx()
            ay = anchor_widget.winfo_rooty() + anchor_widget.winfo_height() + 4
            screen_w = top.winfo_screenwidth()
            screen_h = top.winfo_screenheight()
            
            # If calendar would extend beyond the right edge of screen or parent window, shift left
            if ax + cal_w > screen_w - 20:
                ax = screen_w - cal_w - 20
            try:
                win_right = win.winfo_rootx() + win.winfo_width()
                if ax + cal_w > win_right - 10:
                    ax = max(win.winfo_rootx() + 10, win_right - cal_w - 20)
            except Exception:
                pass
            if ax < 10:
                ax = 10
            if ay + cal_h > screen_h - 40:
                ay = max(10, anchor_widget.winfo_rooty() - cal_h - 4)

            top.geometry(f"+{ax}+{ay}")
            cal = Calendar(top, selectmode='day')
            cal.pack(padx=10, pady=10)
            def on_date_select():
                d = cal.selection_get()
                var.set(d.strftime("%B %d, %Y"))
                top.destroy()
            tk.Button(top, text="Select", command=on_date_select, width=15).pack(pady=5)

        lbl(hdr, "Record Date" if v_type == "estimate" else "Voucher Date", 1, 0)
        date_frame = tk.Frame(hdr, bg=WHITE)
        date_frame.grid(row=1, column=1, sticky="w", padx=4, pady=3)
        date_var = tk.StringVar(value=self.get_default_date())
        tk.Entry(date_frame, textvariable=date_var, font=FONT,
                 width=16, relief="solid", bd=1, bg=WHITE).pack(side="left")
        cal1 = tk.Label(date_frame, text=" 📅", bg=WHITE, fg="#333",
                        font=("Segoe UI", 11), cursor="hand2")
        cal1.pack(side="left")
        cal1.bind("<Button-1>", lambda e: popup_calendar(date_var, cal1))

        # --- Dynamic Accounts ---
        if v_type in ["purchase", "purchase_order"]:
            party_type = "supplier"
            txn_type = "purchase"
        else:
            party_type = "customer"
            txn_type = "sales"
            
        party_accs = db.get_all_accounts(party_type)
        party_map = {a["name"]: a["balance"] for a in party_accs}
        party_map["Cash"] = 0.0 # Default fallback
        party_list = ["Cash"] + [a["name"] for a in party_accs]
        
        txn_accs = db.get_all_accounts(txn_type)
        txn_map = {a["name"]: a["balance"] for a in txn_accs}
        txn_default = "Purchase" if v_type == "purchase" else "Sales"
        if txn_default not in txn_map:
            txn_map[txn_default] = 0.0
        txn_list = [txn_default] + [a["name"] for a in txn_accs if a["name"] != txn_default]

        if v_type == "purchase":
            cust_lbl = "Supplier/Cash"
        elif v_type == "estimate":
            cust_lbl = "Customer/Debtor"
        else:
            cust_lbl = "Customer/Cash"
            
        lbl(hdr, cust_lbl, 2, 0)
        cust_frame = tk.Frame(hdr, bg=WHITE)
        cust_frame.grid(row=2, column=1, sticky="w", padx=4, pady=3)
        cust_var = tk.StringVar(value="Cash")
        cust_cb = AutocompleteCombobox(cust_frame, textvariable=cust_var, values=party_list, font=FONT, width=19)
        cust_cb.pack(side="left")
        cust_bal_lbl = tk.Label(cust_frame, text="0.00", bg=WHITE, fg="#000", font=("Segoe UI", 10), padx=6)
        cust_bal_lbl.pack(side="left")
        
        cash_adv_var = tk.StringVar(value="0")
        bank_adv_var = tk.StringVar(value="0")
        bal_var = tk.StringVar(value="0")
        _cash_accs = db.get_all_accounts("cash")
        _def_cash = _cash_accs[0]["name"] if _cash_accs else "Cash Account"
        bank_acc_var = tk.StringVar(value="")
        
        def update_cust_bal(*args):
            cname = cust_var.get()
            if cname:
                bal = db.get_account_balance(cname)
                cust_bal_lbl.config(text=format_amt(bal, show_symbol=False))
                if bal < 0:
                    cash_adv_var.set(str(abs(bal)))
                else:
                    cash_adv_var.set("0")
        cust_var.trace_add("write", update_cust_bal)
        update_cust_bal()

        lbl(hdr, "Purchase Account" if v_type == "purchase" else "Sales Account", 3, 0)
        sales_frame = tk.Frame(hdr, bg=WHITE)
        sales_frame.grid(row=3, column=1, sticky="w", padx=4, pady=3)
        sales_var = tk.StringVar(value=txn_default)
        sales_cb = AutocompleteCombobox(sales_frame, textvariable=sales_var, values=txn_list, font=FONT, width=19)
        sales_cb.pack(side="left")
        sales_bal_lbl = tk.Label(sales_frame, text="0.00", bg=WHITE, fg="#000", font=("Segoe UI", 10), padx=6)
        sales_bal_lbl.pack(side="left")

        def update_sales_bal(*args):
            bal = txn_map.get(sales_var.get(), 0.0)
            sales_bal_lbl.config(text=format_amt(bal, show_symbol=False))
        sales_var.trace_add("write", update_sales_bal)
        update_sales_bal()

        # Right column
        lbl(hdr, "Due Date", 1, 3, padx=(10, 4))
        due_frame = tk.Frame(hdr, bg=WHITE)
        due_frame.grid(row=1, column=4, sticky="w", padx=(4, 25), pady=3)
        due_var = tk.StringVar(value=datetime.date.today().strftime("%B %d, %Y"))
        tk.Entry(due_frame, textvariable=due_var, font=FONT,
                 width=16, relief="solid", bd=1, bg=WHITE).pack(side="left")
        cal2 = tk.Label(due_frame, text=" 📅", bg=WHITE, fg="#333",
                        font=("Segoe UI", 11), cursor="hand2")
        cal2.pack(side="left")
        cal2.bind("<Button-1>", lambda e: popup_calendar(due_var, cal2))

        lbl(hdr, "Purchase Order No", 2, 3, padx=(10, 4))
        po_var, _ = entry_field(hdr, 2, 4, 18)

        tk.Frame(win, bg="#999", height=1).pack(fill="x", padx=4)

        # ── Item entry section ────────────────────────────────────────────────
        item_hint = tk.Label(win, text="  Press ENTER key to add item.",
                             bg=BG, fg=RED, font=("Tahoma", 8, "bold"), anchor="w")
        item_hint.pack(fill="x", padx=8, pady=(4, 0))

        item_top = tk.Frame(win, bg=BG)
        item_top.pack(fill="x", padx=8, pady=2)

        # F9 Item search
        tk.Label(item_top, text="F9: Item", bg=BG, fg="#000",
                 font=FONT).pack(side="left", padx=(0, 4))
        item_search_var = tk.StringVar()
        all_inv_items = db.get_all_items()
        item_names_all = [r.get("name") or r.get("item") for r in all_inv_items if (r.get("name") or r.get("item"))]
        item_search_entry = tk.Entry(item_top, textvariable=item_search_var,
                                     width=34, font=FONT, relief="solid", bd=1, bg=WHITE)
        item_search_entry.pack(side="left")

        # Units left / Item history
        units_lbl = tk.Label(item_top, text="  Units Left: 0", bg=BG, fg="#000",
                             font=("Segoe UI", 10))
        units_lbl.pack(side="left", padx=10)
        tk.Label(item_top, text="Alt+F2: Item History", bg=BG, fg="#000000",
                 font=("Segoe UI", 10), cursor="hand2").pack(side="left", padx=8)
        tk.Label(item_top, text="View Photo", bg=BG, fg="#000000",
                 font=("Segoe UI", 10), cursor="hand2").pack(side="left")

        # F10 Service (right side)
        tk.Label(item_top, text="F10: Service", bg=BG, fg="#000",
                 font=FONT).pack(side="right", padx=(8, 2))
        service_var = tk.StringVar()
        service_entry = tk.Entry(item_top, textvariable=service_var, font=FONT,
                                 width=18, relief="solid", bd=1, bg=WHITE)
        service_entry.pack(side="right")
        tk.Label(item_top, text="DELETE: To Delete Row, Shift+UP/Down: To Rearrange Items",
                 bg=BG, fg="darkred", font=("Segoe UI", 10, "bold italic")).pack(side="right", padx=10)

        # ── Items GRID ────────────────────────────────────────────────────────
        # IMPORTANT: With side='bottom' packing, the FIRST packed element ends up
        # at the very bottom. So we must pack in this order:
        # 1) buttons bar (bottom-most) 
        # 2) bot_frame (narration + totals)
        # 3) header + grid canvas (fills remaining space, packed top)

        # ── 1. Bottom buttons bar (packed FIRST = stays at very bottom) ───────
        bottom = tk.Frame(win, bg=BG)
        bottom.pack(fill="x", side="bottom", padx=8, pady=4)

        # Grid header columns
        col_defs = [
            ("Item",         22), ("QTY", 6), ("Units", 7),
            ("Rate",          9), ("Per", 5), ("Discount(%)", 9),
            ("Tax",           7), ("Value", 10), ("Description", 14),
        ]
        COL_WEIGHTS = [5, 1, 1, 2, 1, 2, 1, 2, 3]
        if v_type in ["purchase", "purchase_order"]:
            col_defs.append(("+Costs", 8))
            COL_WEIGHTS.append(1)
            col_defs.append(("S.Price", 8))
            COL_WEIGHTS.append(2)
        COL_WIDTHS = [d[1] for d in col_defs]

        # ── 2. Bot frame: narration + totals (packed SECOND = above buttons) ──
        bot_frame = tk.Frame(win, bg=BG)
        bot_frame.pack(fill="x", side="bottom", padx=8, pady=(4, 0))

        # Left side: Other charges + Counts + Narration
        bot_left = tk.Frame(bot_frame, bg=BG)
        bot_left.pack(side="left", fill="both", expand=True)

        other_charges_data = [] # List of dicts {name, amount}
        other_charges_tot = tk.DoubleVar(value=0.0)

        def open_other_charges():
            popup = tk.Toplevel(win)
            popup.title("Select Other Charge Account")
            popup.geometry("400x300")
            popup.transient(win)
            popup.grab_set()

            tk.Label(popup, text="Select Account", font=FONT).pack(pady=5)
            acc_var = tk.StringVar()
            all_accounts = db.get_all_accounts()
            expense_income_accs = [a["name"] for a in all_accounts if "Expense" in str(a["account_group"]) or "Income" in str(a["account_group"])]
            if not expense_income_accs:
                expense_income_accs = ["Advertisement expenses", "Rent paid", "Cartage", "Discount"]
            cb = AutocompleteCombobox(popup, textvariable=acc_var, values=expense_income_accs, width=30)
            cb.pack(pady=5)

            tk.Label(popup, text="Amount", font=FONT).pack(pady=5)
            amt_var = tk.StringVar(value="0")
            tk.Entry(popup, textvariable=amt_var, font=FONT).pack(pady=5)

            def add_chg():
                try:
                    val = float(amt_var.get())
                    other_charges_data.append({"name": acc_var.get(), "amount": val})
                    other_charges_tot.set(sum(c["amount"] for c in other_charges_data))
                    recalc_total()
                    popup.destroy()
                except:
                    pass
            tk.Button(popup, text="Add", command=add_chg).pack(pady=10)

        oc_fr = tk.Frame(bot_left, bg=BG)
        oc_fr.pack(anchor="w", fill="x", pady=(0, 4))
        tk.Button(oc_fr, text="Select Other Charge", font=FONT, command=open_other_charges, bg="#e0e0e0", relief="flat").pack(side="left")
        tk.Label(oc_fr, textvariable=other_charges_tot, font=FONT, bg=BG).pack(side="left", padx=(8, 20))

        nar_hdr = tk.Frame(bot_left, bg=BG)
        nar_hdr.pack(anchor="w", fill="x", pady=(2, 2))
        tk.Label(nar_hdr, text="Narration", bg=BG, fg="#000000",
                 font=("Segoe UI", 9, "bold")).pack(side="left")
        tk.Label(nar_hdr, text="  (Ctrl+Enter for next line)",
                 bg=BG, fg="#666666", font=("Segoe UI", 8, "italic")).pack(side="left")
        nar_text = tk.Text(bot_left, font=FONT, width=40, height=4, relief="solid", bd=1, bg=WHITE)
        nar_text.pack(fill="x", expand=True, padx=(0, 20))

        # Right side: Totals
        bot_right = tk.Frame(bot_frame, bg=BG)
        bot_right.pack(side="right", anchor="n")

        round_var = tk.StringVar(value="0")
        total_var = tk.StringVar(value="0")
        amount_disp_var = tk.StringVar(value="")

        # Row 0: Round Off AND Sub Total
        tk.Label(bot_right, text="Round Off", bg=BG, font=FONT).grid(row=0, column=0, sticky="e", padx=4, pady=2)
        tk.Entry(bot_right, textvariable=round_var, font=FONT, width=12, justify="right",
                 relief="solid", bd=1).grid(row=0, column=1, sticky="w", padx=4, pady=2)

        tk.Label(bot_right, text="Sub Total", bg=BG, font=FONT).grid(row=0, column=2, sticky="e", padx=4, pady=2)
        tk.Entry(bot_right, textvariable=amount_disp_var, font=(FONT[0], 10, "bold"), width=15, justify="right",
                 relief="solid", bd=1, state="readonly", readonlybackground=WHITE).grid(row=0, column=3, sticky="w", padx=4, pady=2)

        # Row 1: Cash Paid AND Amount
        tk.Label(bot_right, text="Cash Paid", bg=BG, font=FONT).grid(row=1, column=0, sticky="e", padx=4, pady=2)
        tk.Entry(bot_right, textvariable=cash_adv_var, font=FONT, width=12, justify="right",
                 relief="solid", bd=1).grid(row=1, column=1, sticky="w", padx=4, pady=2)

        tk.Label(bot_right, text="Amount", bg=BG, font=FONT).grid(row=1, column=2, sticky="e", padx=4, pady=2)
        tk.Entry(bot_right, textvariable=total_var, font=(FONT[0], 10, "bold"), width=15, justify="right",
                 relief="solid", bd=1, state="readonly", readonlybackground=WHITE).grid(row=1, column=3, sticky="w", padx=4, pady=2)

        # Row 2: Bank Paid AND Balance
        tk.Label(bot_right, text="Bank Paid", bg=BG, font=FONT).grid(row=2, column=0, sticky="e", padx=4, pady=2)
        tk.Entry(bot_right, textvariable=bank_adv_var, font=FONT, width=12, justify="right",
                 relief="solid", bd=1).grid(row=2, column=1, sticky="w", padx=4, pady=2)

        tk.Label(bot_right, text="Balance", bg=BG, font=FONT).grid(row=2, column=2, sticky="e", padx=4, pady=2)
        tk.Entry(bot_right, textvariable=bal_var, font=(FONT[0], 10, "bold"), width=15, justify="right",
                 relief="solid", bd=1, state="readonly", readonlybackground=WHITE).grid(row=2, column=3, sticky="w", padx=4, pady=2)
        
        # Row 3: Bank A/C
        tk.Label(bot_right, text="Bank A/C", bg=BG, font=FONT).grid(row=3, column=0, sticky="e", padx=4, pady=2)
        bank_accounts = db.get_all_accounts("bank")
        bank_names = [c["name"] for c in bank_accounts]
        AutocompleteCombobox(bot_right, textvariable=bank_acc_var, values=bank_names, width=12).grid(row=3, column=1, sticky="w", padx=4, pady=2)

        # Row 4: Discount & Tax AND Reference Document (aligned side-by-side)
        disc_tax_lf = tk.LabelFrame(bot_right, text="Discount & Tax", bg=BG, font=("Segoe UI", 10))
        disc_tax_lf.grid(row=4, column=0, columnspan=2, sticky="nsew", padx=4, pady=(6, 2))

        disc_mode_var = tk.StringVar(value="per_item")
        tk.Radiobutton(disc_tax_lf, text="On Total", variable=disc_mode_var, value="on_total", bg=BG, font=FONT).pack(anchor="w")

        global_disc_fr = tk.Frame(disc_tax_lf, bg=BG)
        global_disc_fr.pack(anchor="w", padx=15)

        global_disc_val_var = tk.StringVar(value="0")
        tk.Entry(global_disc_fr, textvariable=global_disc_val_var, width=8, font=FONT, justify="right").pack(side="left")

        global_disc_type_var = tk.StringVar(value="%")
        AutocompleteCombobox(global_disc_fr, textvariable=global_disc_type_var, values=["%", "Amount"], width=8, state="readonly").pack(side="left", padx=2)

        tk.Radiobutton(disc_tax_lf, text="Per Item", variable=disc_mode_var, value="per_item", bg=BG, font=FONT).pack(anchor="w")

        ref_lf = tk.LabelFrame(bot_right, text="Reference Document", bg=BG, font=("Segoe UI", 10))
        ref_lf.grid(row=3, column=2, columnspan=2, sticky="nsew", padx=4, pady=(6, 2))

        ref_var = tk.StringVar()
        tk.Entry(ref_lf, textvariable=ref_var, font=FONT, width=28, relief="solid", bd=1, bg=WHITE).pack(padx=4, pady=4)

        ref_btn_fr = tk.Frame(ref_lf, bg=BG)
        ref_btn_fr.pack(fill="x", pady=2)
        def on_browse_ref():
            from tkinter import filedialog
            path = filedialog.askopenfilename(parent=win, title="Select Reference Document")
            if path: ref_var.set(path)

        def on_view_ref():
            import os
            path = ref_var.get()
            if path and os.path.exists(path):
                try: os.startfile(path)
                except Exception as e: messagebox.showerror("Error", str(e), parent=win)
            else: messagebox.showerror("Error", "Document not found or path is empty.", parent=win)

        def on_delete_ref():
            ref_var.set("")

        tk.Button(ref_btn_fr, text="Browse", bg="#e0e0e0", relief="flat", bd=1, command=on_browse_ref).pack(side="left", padx=2, fill="x", expand=True)
        tk.Button(ref_btn_fr, text="View",   bg="#e0e0e0", relief="flat", bd=1, command=on_view_ref).pack(side="left", padx=2, fill="x", expand=True)
        tk.Button(ref_btn_fr, text="Delete", bg="#e0e0e0", relief="flat", bd=1, command=on_delete_ref).pack(side="left", padx=2, fill="x", expand=True)

        # Row 4: Total Count & Total Qty
        counts_frame = tk.Frame(bot_right, bg=WHITE, relief="solid", bd=1)
        counts_frame.grid(row=4, column=0, columnspan=4, sticky="e", padx=4, pady=(6, 2))
        count_var = tk.StringVar(value="Total Count: 0")
        qty_sum_var = tk.StringVar(value="Total Qty: 0")
        tk.Label(counts_frame, textvariable=count_var, bg=WHITE, font=FONT).pack(side="left", padx=8, pady=2)
        tk.Label(counts_frame, textvariable=qty_sum_var, bg=WHITE, font=FONT).pack(side="left", padx=8, pady=2)

        # ── 4. Column header row (packed TOP after all bottom frames) ─────────
        header_frame = tk.Frame(win, bg=WHITE, relief="flat", bd=0)
        header_frame.pack(fill="x", padx=8, pady=(4, 0))

        dummy_sb_space = tk.Frame(header_frame, bg=WHITE, width=0)

        header_inner = tk.Frame(header_frame, bg="#d0d0d0")
        header_inner.pack(side="left", fill="x", expand=True)

        for j, (htext, cw_) in enumerate(col_defs):
            tk.Label(header_inner, text=htext, bg=WHITE, fg="#000",
                     font=FONT_BOLD, width=1, anchor="w",
                     relief="flat", bd=0, padx=4, pady=4).grid(
                row=0, column=j, sticky="nsew", padx=(1 if j==0 else 0, 1), pady=(1, 1))
            header_inner.columnconfigure(j, weight=COL_WEIGHTS[j], uniform="cols")

        # ── 5. Grid canvas (fills ALL remaining space) ─────────────────────────
        grid_frame = tk.Frame(win, bg=WHITE, relief="flat", bd=0)
        grid_frame.pack(fill="both", expand=True, padx=8, pady=(0, 4))

        grid_canvas = tk.Canvas(grid_frame, bg=WHITE, highlightthickness=0, bd=0)
        grid_vsb = ttk.Scrollbar(grid_frame, orient="vertical", command=grid_canvas.yview)

        def update_grid_scrollbar(first, last):
            try:
                f, l = float(first), float(last)
                if f <= 0.0 and l >= 1.0:
                    if grid_vsb.winfo_ismapped():
                        grid_vsb.pack_forget()
                    if dummy_sb_space.winfo_ismapped():
                        dummy_sb_space.pack_forget()
                else:
                    if not grid_vsb.winfo_ismapped():
                        grid_vsb.pack(side="right", fill="y")
                    if not dummy_sb_space.winfo_ismapped():
                        dummy_sb_space.pack(side="right", fill="y")
                        sb_w = grid_vsb.winfo_reqwidth()
                        dummy_sb_space.config(width=sb_w)
            except Exception:
                pass
            grid_vsb.set(first, last)

        grid_canvas.configure(yscrollcommand=update_grid_scrollbar)
        grid_canvas.pack(side="left", fill="both", expand=True)

        grid_inner = tk.Frame(grid_canvas, bg="#d0d0d0")
        grid_cw = grid_canvas.create_window((0, 0), window=grid_inner, anchor="nw")

        grid_inner.bind("<Configure>", lambda e: grid_canvas.configure(scrollregion=grid_canvas.bbox("all")))
        grid_canvas.bind("<Configure>", lambda e: grid_canvas.itemconfig(grid_cw, width=e.width))
        grid_canvas.bind("<MouseWheel>", lambda e: grid_canvas.yview_scroll(-1*(e.delta//120), "units"))
        
        for j in range(len(col_defs)):
            grid_inner.columnconfigure(j, weight=COL_WEIGHTS[j], uniform="cols")

        line_data = []

        def add_grid_row(item_name="", qty="1", unit="Nos", rate="0", per="", disc="0", tax="0", extra_costs="[]", sp="0"):
            
            # Fetch unit symbol and default rate if item exists
            final_unit = unit
            final_rate = rate
            if item_name:
                for it in all_inv_items:
                    if it["name"] == item_name:
                        if not final_unit or final_unit == "Nos":
                            final_unit = db.get_unit_symbol(it.get("unit") or it.get("units_name") or "Nos")
                        if final_rate == "0" or not final_rate:
                            price_val = it.get("purchase_price") if v_type in ["purchase", "purchase_order"] else it.get("sale_price")
                            if price_val is not None:
                                final_rate = str(price_val)
                        break
            if not final_unit:
                final_unit = db.get_unit_symbol(unit or "Nos")
            else:
                final_unit = db.get_unit_symbol(final_unit)
            
            if item_name:
                for r in line_data:
                    if r["item_v"].get() == item_name:
                        try:
                            curr_qty = float(r["qty_v"].get() or 0)
                            new_qty = curr_qty + float(qty)
                            r["qty_v"].set(f"{new_qty:g}")
                            # Recalculate this specific row
                            r_ = float(r["rate_v"].get() or 0)
                            t = float(r["tax_v"].get() or 0)
                            d = float(r["disc_v"].get() or 0) if disc_mode_var.get() == "per_item" else 0.0
                            val = new_qty * r_ * (1 - d/100) * (1 + t/100)
                            r["value_v"].set(format_amt(val, show_symbol=False))
                            recalc_total()
                            if "qty_w" in r:
                                r["qty_w"].focus_set()
                                r["qty_w"].selection_range(0, tk.END)
                            return
                        except Exception:
                            pass

            ri = len(line_data) + 1

            item_v  = tk.StringVar(value=item_name)
            qty_v   = tk.StringVar(value=qty)
            unit_v  = tk.StringVar(value=final_unit)
            rate_v  = tk.StringVar(value=final_rate)
            per_v   = tk.StringVar(value=per)
            disc_v  = tk.StringVar(value=disc)
            tax_v   = tk.StringVar(value=tax)
            value_v = tk.StringVar(value="0.00")
            desc_v  = tk.StringVar()
            extra_costs_var = tk.StringVar(value=extra_costs)
            sp_var = tk.StringVar(value=sp)

            def recalc(e=None):
                try:
                    import re
                    def safe_num(s):
                        m = re.search(r"[-+]?\d*\.\d+|\d+", str(s).replace(',', ''))
                        return float(m.group(0)) if m else 0.0
                        
                    q = safe_num(qty_v.get())
                    r_ = safe_num(rate_v.get())
                    import json
                    try:
                        ex_costs = sum(float(c.get("amount", 0)) for c in json.loads(extra_costs_var.get()))
                        r_ += ex_costs
                    except:
                        pass
                    t  = safe_num(tax_v.get())
                    
                    if disc_mode_var.get() == "per_item":
                        d = safe_num(disc_v.get())
                    else:
                        d = 0.0

                        
                    val = q * r_ * (1 - d/100) * (1 + t/100)
                    value_v.set(format_amt(val, show_symbol=False))
                    recalc_total()
                except Exception:
                    pass

            def on_item_select(e=None):
                name = item_v.get()
                for it in all_inv_items:
                    if it["name"] == name:
                        price_val = it.get("purchase_price") if v_type in ["purchase", "purchase_order"] else it.get("sale_price")
                        rate_v.set(str(price_val if price_val is not None else 0))
                        unit_v.set(db.get_unit_symbol(it.get("unit") or it.get("units_name") or "Nos"))
                        units_lbl.config(text=f"  Units Left: {it['stock']:.0f}")
                        recalc()
                        break

            bg_color = WHITE if ri % 2 == 1 else "#f0f0f0"

            def on_focus_in(e):
                w = e.widget
                if w.cget("state") == "readonly":
                    w.config(readonlybackground="yellow")
                else:
                    w.config(bg="yellow")

            def on_focus_out(e):
                w = e.widget
                if w.cget("state") == "readonly":
                    w.config(readonlybackground=bg_color)
                else:
                    w.config(bg=bg_color)

            # 0. Item
            cb = tk.Entry(grid_inner, textvariable=item_v, font=FONT,
                          width=1, relief="flat", bd=0, bg=bg_color)
            cb.grid(row=ri, column=0, padx=(1, 1), pady=(0, 1), sticky="nsew", ipady=4)
            cb.bind("<Return>", on_item_select)

            # 1. QTY (Right aligned)
            qty_e = tk.Entry(grid_inner, textvariable=qty_v, font=FONT, justify="right",
                             width=1, relief="flat", bd=0, bg=bg_color)
            qty_e.grid(row=ri, column=1, padx=(0, 1), pady=(0, 1), sticky="nsew", ipady=4)
            qty_e.bind("<FocusOut>", recalc)

            # 2. Units (Left aligned)
            unit_e = tk.Entry(grid_inner, textvariable=unit_v, font=FONT,
                              width=1, relief="flat", bd=0, bg=bg_color)
            unit_e.grid(row=ri, column=2, padx=(0, 1), pady=(0, 1), sticky="nsew", ipady=4)

            # 3. Rate (Right aligned)
            rate_e = tk.Entry(grid_inner, textvariable=rate_v, font=FONT, justify="right",
                              width=1, relief="flat", bd=0, bg=bg_color)
            rate_e.grid(row=ri, column=3, padx=(0, 1), pady=(0, 1), sticky="nsew", ipady=4)
            rate_e.bind("<FocusOut>", recalc)

            # 4. Per
            per_cb = tk.Entry(grid_inner, textvariable=per_v, font=FONT,
                              width=1, relief="flat", bd=0, bg=bg_color)
            per_cb.grid(row=ri, column=4, padx=(0, 1), pady=(0, 1), sticky="nsew", ipady=4)

            # 5. Discount(%) (Right aligned)
            disc_e = tk.Entry(grid_inner, textvariable=disc_v, font=FONT, justify="right",
                              width=1, relief="flat", bd=0, bg=bg_color)
            disc_e.grid(row=ri, column=5, padx=(0, 1), pady=(0, 1), sticky="nsew", ipady=4)
            disc_e.bind("<FocusOut>", recalc)
            disc_v.trace_add("write", lambda *a: recalc())

            # 6. Tax
            tax_cb = tk.Entry(grid_inner, textvariable=tax_v, font=FONT,
                              width=1, relief="flat", bd=0, bg=bg_color)
            tax_cb.grid(row=ri, column=6, padx=(0, 1), pady=(0, 1), sticky="nsew", ipady=4)
            tax_v.trace_add("write", lambda *a: recalc())

            # 7. Value (Right aligned, read-only appearance)
            val_e = tk.Entry(grid_inner, textvariable=value_v, font=FONT, justify="right",
                             width=1, relief="flat", bd=0, bg=bg_color, state="readonly")
            val_e.grid(row=ri, column=7, padx=(0, 1), pady=(0, 1), sticky="nsew", ipady=4)

            # 8. Description (Yellow bg handled by focus)
            desc_e = tk.Entry(grid_inner, textvariable=desc_v, font=FONT,
                              width=1, relief="flat", bd=0, bg=bg_color)
            desc_e.grid(row=ri, column=8, padx=(0, 1), pady=(0, 1), sticky="nsew", ipady=4)

            def open_costs_popup():
                import json
                popup = tk.Toplevel(win)
                popup.title("Extra Costs & Profit")
                popup.geometry("450x450")
                popup.grab_set()
                tk.Label(popup, text="Enter extra costs (per unit):", font=FONT_BOLD).pack(pady=5)
                
                f = tk.Frame(popup)
                f.pack(fill="both", expand=True, padx=10, pady=5)
                
                rows = []
                try:
                    existing = json.loads(extra_costs_var.get())
                except:
                    existing = []
                
                def add_row(name="", amt="0"):
                    fr = tk.Frame(f)
                    fr.pack(fill="x", pady=2)
                    n_v = tk.StringVar(value=name)
                    a_v = tk.StringVar(value=amt)
                    tk.Entry(fr, textvariable=n_v, width=20, font=FONT).pack(side="left", padx=2)
                    tk.Entry(fr, textvariable=a_v, width=15, font=FONT).pack(side="left", padx=2)
                    rows.append((n_v, a_v))
                
                for ex in existing:
                    add_row(ex.get("name", ""), str(ex.get("amount", 0)))
                if not rows:
                    add_row("Glass Cost", "0")
                    add_row("Rubber Cost", "0")
                    add_row("Supplier Cost", "0")
                
                tk.Button(popup, text="+ Add Cost", command=add_row).pack(pady=5)
                
                # Profit calculation section
                pf = tk.Frame(popup, bg="#eef")
                pf.pack(fill="x", pady=10, padx=10)
                tk.Label(pf, text="Expected Sell Price:", font=FONT, bg="#eef").pack(side="left", padx=5)
                tk.Entry(pf, textvariable=sp_var, font=FONT, width=15).pack(side="left", padx=5)
                
                prof_lbl = tk.Label(pf, text="Profit: 0.00", font=FONT_BOLD, fg="green", bg="#eef")
                prof_lbl.pack(side="left", padx=10)
                
                def calc_prof(*args):
                    try:
                        tot_cost = float(rate_v.get() or 0) + sum(float(a.get() or 0) for n, a in rows)
                        sp = float(sp_var.get() or 0)
                        prof = sp - tot_cost
                        prof_lbl.config(text=f"Profit: {prof:.2f}")
                        if prof < 0: prof_lbl.config(fg="red")
                        else: prof_lbl.config(fg="green")
                    except Exception:
                        pass
                
                for n, a in rows: a.trace_add("write", calc_prof)
                sp_var.trace_add("write", calc_prof)
                calc_prof()
                
                def save_costs():
                    data = []
                    for n, a in rows:
                        if n.get().strip():
                            data.append({"name": n.get().strip(), "amount": float(a.get() or 0)})
                    extra_costs_var.set(json.dumps(data))
                    recalc()
                    popup.destroy()
                
                tk.Button(popup, text="Save", command=save_costs, bg="#4CAF50", fg="white", font=FONT_BOLD).pack(pady=10)

            if v_type in ["purchase", "purchase_order"]:
                btn_costs = tk.Button(grid_inner, text="Costs", command=open_costs_popup, font=FONT)
                btn_costs.grid(row=ri, column=9, padx=(0, 1), pady=(0, 1), sticky="nsew")
                sp_e = tk.Entry(grid_inner, textvariable=sp_var, font=FONT, justify="right", width=1, relief="flat", bd=0, bg=bg_color)
                sp_e.grid(row=ri, column=10, padx=(0, 1), pady=(0, 1), sticky="nsew", ipady=4)

            # Focus helper
            def focus_field(target_widget):
                if target_widget and target_widget.winfo_exists():
                    target_widget.focus_set()
                    if hasattr(target_widget, "selection_range"):
                        target_widget.selection_range(0, tk.END)
                    elif hasattr(target_widget, "select_range"):
                        target_widget.select_range(0, tk.END)
                return "break"

            def on_qty_enter(e=None):
                recalc()
                return focus_field(unit_e)

            def on_qty_shift_enter(e=None):
                return focus_field(item_search_entry)

            def on_unit_enter(e=None):
                return focus_field(rate_e)

            def on_unit_shift_enter(e=None):
                return focus_field(qty_e)

            def on_rate_enter(e=None):
                recalc()
                return focus_field(per_cb)

            def on_rate_shift_enter(e=None):
                return focus_field(unit_e)

            def on_per_enter(e=None):
                if disc_mode_var.get() == "per_item":
                    return focus_field(disc_e)
                else:
                    return focus_field(desc_e)

            def on_per_shift_enter(e=None):
                return focus_field(rate_e)

            def on_disc_enter(e=None):
                recalc()
                return focus_field(tax_cb)

            def on_disc_shift_enter(e=None):
                return focus_field(per_cb)

            def on_tax_enter(e=None):
                recalc()
                return focus_field(desc_e)

            def on_tax_shift_enter(e=None):
                if disc_mode_var.get() == "per_item":
                    return focus_field(disc_e)
                else:
                    return focus_field(per_cb)

            def on_desc_enter(e=None):
                recalc()
                ans = messagebox.askyesno("Continue", "Add more item/service?", parent=win)
                if ans:
                    item_search_entry.focus_set()
                    item_search_entry.selection_range(0, tk.END)
                else:
                    nar_text.focus_set()
                return "break"

            def on_desc_shift_enter(e=None):
                if disc_mode_var.get() == "per_item":
                    return focus_field(tax_cb)
                else:
                    return focus_field(per_cb)

            # Bind Enter & Shift+Enter navigation
            qty_e.bind("<Return>", on_qty_enter)
            qty_e.bind("<Shift-Return>", on_qty_shift_enter)

            unit_e.bind("<Return>", on_unit_enter)
            unit_e.bind("<Shift-Return>", on_unit_shift_enter)

            rate_e.bind("<Return>", on_rate_enter)
            rate_e.bind("<Shift-Return>", on_rate_shift_enter)

            per_cb.bind("<Return>", on_per_enter)
            per_cb.bind("<Shift-Return>", on_per_shift_enter)

            disc_e.bind("<Return>", on_disc_enter)
            disc_e.bind("<Shift-Return>", on_disc_shift_enter)

            tax_cb.bind("<Return>", on_tax_enter)
            tax_cb.bind("<Shift-Return>", on_tax_shift_enter)

            desc_e.bind("<Return>", on_desc_enter)
            desc_e.bind("<Shift-Return>", on_desc_shift_enter)

            for w in (cb, qty_e, unit_e, rate_e, per_cb, disc_e, tax_cb, val_e, desc_e):
                w.bind("<FocusIn>", on_focus_in, add="+")
                w.bind("<FocusOut>", on_focus_out, add="+")

            row_dict = {
                "item_v": item_v, "qty_v": qty_v, "unit_v": unit_v,
                "rate_v": rate_v, "per_v": per_v, "disc_v": disc_v,
                "tax_v": tax_v, "value_v": value_v, "desc_v": desc_v,
                "ri": ri, "qty_w": qty_e, "unit_w": unit_e, "rate_w": rate_e,
                "per_w": per_cb, "disc_w": disc_e, "tax_w": tax_cb, "desc_w": desc_e
            }
            line_data.append(row_dict)
            recalc()
            qty_e.focus_set()
            qty_e.selection_range(0, tk.END)

            def del_row(rd=row_dict):
                # Bug 15/16: remove row cleanly and collapse gap
                if rd not in line_data:
                    return
                row_ri = rd["ri"]
                line_data.remove(rd)
                for widget in grid_inner.grid_slaves(row=row_ri):
                    widget.destroy()
                # Shift all rows below up by 1
                for remaining in line_data:
                    if remaining["ri"] > row_ri:
                        old_ri = remaining["ri"]
                        remaining["ri"] = old_ri - 1
                        for widget in grid_inner.grid_slaves(row=old_ri):
                            widget.grid(row=remaining["ri"])
                recalc_total()

            # Bind Delete key to every cell in this row
            for widget in list(grid_inner.grid_slaves(row=ri)):
                widget.bind("<Delete>", lambda e, d=row_dict: del_row(d))
            if item_name:
                on_item_select()

        def recalc_total():
            # Bug 4 fix: strip commas before float() to handle formatted strings like "1,250.00"
            def safe_float(s):
                try:
                    return float(str(s).replace(',', '') or 0)
                except:
                    return 0.0
            tot = sum(safe_float(r["value_v"].get()) for r in line_data)
            count = len([r for r in line_data if r["item_v"].get().strip()])
            qty = sum(safe_float(r["qty_v"].get()) for r in line_data if r["item_v"].get().strip())
            
            if disc_mode_var.get() == "on_total":
                try:
                    g_val = float(global_disc_val_var.get() or 0)
                except:
                    g_val = 0.0
                if global_disc_type_var.get() == "%":
                    tot -= (tot * g_val / 100)
                else:
                    tot -= g_val
            
            try:
                roff = float(round_var.get() or 0)
            except:
                roff = 0
            
            try:
                oc = other_charges_tot.get()
            except:
                oc = 0.0
                
            grand = tot + roff + oc
            # Bug 10 fix: use round() comparison instead of .is_integer() for float precision
            total_var.set(f"{grand:,.0f}" if grand == round(grand) else format_amt(grand, show_symbol=False))

            try:
                adv = float(cash_adv_var.get() or 0) + float(bank_adv_var.get() or 0)
            except:
                adv = 0.0
            bal = grand - adv
            bal_var.set(f"{bal:,.0f}" if bal == round(bal) else format_amt(bal, show_symbol=False))

            amount_disp_var.set(f"{tot:,.0f}" if tot == round(tot) else format_amt(tot, show_symbol=False))
            count_var.set(f"Total Count: {count}")
            qty_sum_var.set(f"Total Qty: {qty:g}")

        cash_adv_var.trace_add("write", lambda *args: recalc_total())
        bank_adv_var.trace_add("write", lambda *args: recalc_total())
        global_disc_val_var.trace_add("write", lambda *args: recalc_total())
        global_disc_type_var.trace_add("write", lambda *args: recalc_total())
        round_var.trace_add("write", lambda *args: recalc_total())

        def on_disc_mode_change(*args):
            for r in line_data:
                try:
                    q = float(r["qty_v"].get() or 0)
                    r_ = float(r["rate_v"].get() or 0)
                    t  = float(r["tax_v"].get() or 0)
                    if disc_mode_var.get() == "per_item":
                        d = float(r["disc_v"].get() or 0)
                    else:
                        d = 0.0
                    val = q * r_ * (1 - d/100) * (1 + t/100)
                    r["value_v"].set(format_amt(val, show_symbol=False))
                except:
                    pass
            recalc_total()

        disc_mode_var.trace_add("write", on_disc_mode_change)

        # ── Item Autocomplete Dropdown & Create Prompt ────────────────────────
        popup_list = None
        popup_listbox = None

        def refresh_inventory_cache():
            nonlocal all_inv_items, item_names_all
            all_inv_items = db.get_all_items()
            item_names_all = [r.get("name") or r.get("item") for r in all_inv_items if (r.get("name") or r.get("item"))]

        def close_dropdown(e=None):
            nonlocal popup_list, popup_listbox
            if popup_list and popup_list.winfo_exists():
                try:
                    popup_list.destroy()
                except Exception:
                    pass
            popup_list = None
            popup_listbox = None

        def on_listbox_select_item(event=None):
            nonlocal popup_listbox
            if not popup_listbox or not popup_listbox.winfo_exists():
                return
            try:
                cur = popup_listbox.curselection()
                if cur:
                    sel_name = popup_listbox.get(cur[0])
                    close_dropdown()
                    add_grid_row(item_name=sel_name)
                    item_search_var.set("")
                    recalc_total()
            except Exception:
                pass

        def open_dropdown(matches):
            nonlocal popup_list, popup_listbox
            if not matches:
                close_dropdown()
                return

            if popup_list is None or not popup_list.winfo_exists():
                popup_list = tk.Toplevel(win)
                popup_list.wm_overrideredirect(True)
                popup_list.attributes("-topmost", True)

                border_fr = tk.Frame(popup_list, bg="#7f9db9", bd=1)
                border_fr.pack(fill="both", expand=True)

                popup_listbox = tk.Listbox(border_fr, font=FONT, bg=WHITE, fg="#000000",
                                           selectbackground="#0078d7", selectforeground="#ffffff",
                                           activestyle="none", relief="flat", bd=0, highlightthickness=0)
                popup_listbox.pack(fill="both", expand=True)

                popup_listbox.bind("<ButtonRelease-1>", on_listbox_select_item)

            popup_listbox.delete(0, "end")
            for m in matches:
                popup_listbox.insert("end", m)

            popup_listbox.selection_clear(0, "end")
            popup_listbox.selection_set(0)
            popup_listbox.activate(0)

            item_search_entry.update_idletasks()
            ex = item_search_entry.winfo_rootx()
            ey = item_search_entry.winfo_rooty()
            ew = item_search_entry.winfo_width()
            eh = item_search_entry.winfo_height()

            num_rows = min(len(matches), 8)
            lh = max(30, min(200, num_rows * 22 + 4))
            popup_list.geometry(f"{ew}x{lh}+{ex}+{ey + eh}")
            popup_list.lift()

        def on_item_search_key(e):
            if hasattr(e, 'keysym') and e.keysym in ('Up', 'Down', 'Return', 'Escape', 'Tab'):
                return
            val = item_search_var.get().strip().lower()
            if not val:
                close_dropdown()
            else:
                matches = [n for n in item_names_all if val in n.lower()]
                if matches:
                    open_dropdown(matches)
                else:
                    close_dropdown()

        def on_item_key_press(e):
            nonlocal popup_listbox
            if e.keysym == "Down":
                if popup_listbox and popup_listbox.winfo_exists():
                    cur = popup_listbox.curselection()
                    next_idx = (cur[0] + 1) if cur else 0
                    if next_idx < popup_listbox.size():
                        popup_listbox.selection_clear(0, "end")
                        popup_listbox.selection_set(next_idx)
                        popup_listbox.activate(next_idx)
                        popup_listbox.see(next_idx)
                    return "break"
            elif e.keysym == "Up":
                if popup_listbox and popup_listbox.winfo_exists():
                    cur = popup_listbox.curselection()
                    prev_idx = (cur[0] - 1) if cur else 0
                    if prev_idx >= 0:
                        popup_listbox.selection_clear(0, "end")
                        popup_listbox.selection_set(prev_idx)
                        popup_listbox.activate(prev_idx)
                        popup_listbox.see(prev_idx)
                    return "break"
            elif e.keysym == "Escape":
                close_dropdown()
                return "break"
            elif e.keysym == "Return":
                on_enter_item()
                return "break"

        def on_enter_item(e=None):
            nonlocal all_inv_items, item_names_all, popup_listbox
            if popup_listbox and popup_listbox.winfo_exists():
                cur = popup_listbox.curselection()
                if cur:
                    sel_name = popup_listbox.get(cur[0])
                    close_dropdown()
                    add_grid_row(item_name=sel_name)
                    item_search_var.set("")
                    recalc_total()
                    return "break"

            typed_name = item_search_var.get().strip()
            if not typed_name:
                return "break"

            # Check if item exists in inventory
            match = next((n for n in item_names_all if n.lower() == typed_name.lower()), None)
            if match:
                close_dropdown()
                add_grid_row(item_name=match)
                item_search_var.set("")
                recalc_total()
            else:
                close_dropdown()
                ans = messagebox.askyesno("Query", "Inventory item doesnt exists.\nCreate new item?", parent=win)
                if ans:
                    def on_new_item_saved(new_created_name=None):
                        refresh_inventory_cache()
                        final_name = new_created_name or typed_name
                        add_grid_row(item_name=final_name)
                        item_search_var.set("")
                        recalc_total()
                        try:
                            win.lift()
                            win.focus_set()
                        except Exception:
                            pass
                    self._item_form(initial_name=typed_name, callback=on_new_item_saved, parent=win)
                else:
                    item_search_entry.focus_set()
                    item_search_entry.select_range(0, tk.END)
            return "break"

        item_search_entry.bind("<KeyRelease>", on_item_search_key)
        item_search_entry.bind("<KeyPress>", on_item_key_press)

        def on_entry_focus_in(e):
            item_search_entry.config(bg="#ffff00")

        def on_entry_focus_out(e):
            item_search_entry.config(bg=WHITE)

        def on_f9_focus_item(e=None):
            item_search_entry.focus_set()
            item_search_entry.selection_range(0, tk.END)
            return "break"

        def on_f10_focus_service(e=None):
            service_entry.focus_set()
            service_entry.selection_range(0, tk.END)
            return "break"

        win.bind("<F9>", on_f9_focus_item)
        win.bind("<F10>", on_f10_focus_service)
        win.bind("<Control-f>", on_f9_focus_item)
        win.bind("<Control-F>", on_f9_focus_item)
        win.bind("<Button-1>", lambda e: close_dropdown() if e.widget != item_search_entry and (not popup_listbox or e.widget != popup_listbox) else None, add="+")
        win.bind("<Destroy>", lambda e: close_dropdown() if e.widget == win else None, add="+")

        if linked_po:
            cname = linked_po.get("account_name") or ""
            cash_accs = db.get_all_accounts("cash")
            cash_names = [c["name"] for c in cash_accs]
            if cname in cash_names or cname == "Cash Account":
                cust_var.set("Cash")
            else:
                cust_var.set(cname)
            ref_no = linked_po.get('invoice_no', '') or linked_po.get('vch_no', '')
            nar_text.insert("1.0", f"Buyers Purchase Order Reference: {ref_no}")
            def fill_po_items():
                for widget in grid_inner.grid_slaves():
                    widget.destroy()
                line_data.clear()
                po_items = db.get_invoice_items(linked_po["id"])
                for p_item in po_items:
                    add_grid_row(item_name=p_item.get("item_name", ""),
                                 qty=str(p_item.get("qty", 1)),
                                 rate=str(p_item.get("price", 0)),
                                 tax=str(p_item.get("tax_pct", 0)))
                if not po_items:
                    add_grid_row()
            win.after(100, fill_po_items)

        if edit_inv:
            if not is_duplicate and v_type != "credit_note":
                inv_no_var.set(edit_inv.get("invoice_no", ""))
            cname = edit_inv.get("debit") if v_type in ["sale", "credit_note"] else edit_inv.get("credit")
            if cname:
                cust_var.set(cname)
            if "narration" in edit_inv:
                nar_text.insert("1.0", edit_inv["narration"])
            edit_items = db.get_invoice_items(edit_inv["id"])
            for it in edit_items:
                add_grid_row(item_name=it.get("item_name", ""),
                             qty=str(it.get("qty", 1)),
                             rate=str(it.get("price", 0)),
                             tax=str(it.get("tax_pct", 0)))

        is_template_var = tk.IntVar()
        def save_voucher(print_receipt=False, view_after=False):
            # Bug 4 fix: comma-safe float helper
            def sf(s):
                try:
                    return float(str(s).replace(',', '') or 0)
                except:
                    return 0.0

            items = []
            for r in line_data:
                name = r["item_v"].get().strip()
                if not name:
                    continue
                item_id = next((it["id"] for it in all_inv_items
                                if it["name"] == name), None)
                qty   = sf(r["qty_v"].get())
                rate  = sf(r["rate_v"].get())
                disc  = sf(r["disc_v"].get())
                tax   = sf(r["tax_v"].get())
                value = sf(r["value_v"].get())  # Bug 4 fix: no crash on "1,250.00"
                if qty == 0 and value == 0:
                    continue
                items.append({
                    "item_id": item_id, "name": name,
                    "qty": qty, "unit": r["unit_v"].get(),
                    "price": rate, "tax_pct": tax, "total": value,
                    "description": r["desc_v"].get(),
                    "extra_costs": r.get("extra_costs_v").get() if "extra_costs_v" in r else "[]",
                    "sp": r.get("sp_v").get() if "sp_v" in r else "0",
                })
            if not items:
                messagebox.showerror("Error",
                    "Please add at least one item!", parent=win)
                return

            # Bug 11: Duplicate invoice number check
            inv_no = inv_no_var.get().strip()
            if not inv_no:
                messagebox.showerror("Error", "Invoice number cannot be empty!", parent=win)
                return
            if not edit_inv or is_duplicate:
                conn_chk = db.get_conn()
                existing_no = conn_chk.execute(
                    "SELECT v_id FROM vouchers WHERE vch_no=?", (inv_no,)
                ).fetchone()
                conn_chk.close()
                if existing_no:
                    if not messagebox.askyesno("Duplicate Invoice",
                        f"Invoice '{inv_no}' already exists. Save anyway with a new copy?",
                        parent=win):
                        return

            # Bug 1 fix: Use user-entered date, not today's date
            raw_date = date_var.get().strip()
            try:
                parsed = datetime.datetime.strptime(raw_date, "%B %d, %Y")
                date_str = parsed.strftime("%Y-%m-%d")
            except:
                date_str = datetime.date.today().isoformat()

            # Negative inventory warning (only for sale/credit_note)
            if v_type in ("sale", "credit_note"):
                if not self.check_negative_inventory(items, win):
                    return

            # Fix 4 (settings): Auto roundoff grand total
            grand_total = sum(it["total"] for it in items)
            rounded = self.apply_roundoff(grand_total)
            if rounded != grand_total and items:
                items[-1]["total"] += (rounded - grand_total)

            # Resolve account
            cname = cust_var.get()
            acc_id = None
            cash_accounts = db.get_all_accounts("cash")
            all_accounts = db.get_all_accounts()

            if cname == "Cash":
                for ca in cash_accounts:
                    acc_id = ca["id"]; break
            else:
                for acc in all_accounts:
                    if acc["name"] == cname:
                        acc_id = acc["id"]; break

            # Bug 9 fix: correct field name is 'account_group', not 'agroup'
            if acc_id is None and cname and cname != "Cash":
                agroup = "Sundry Creditors" if v_type == "purchase" else "Sundry Debtors"
                db.add_account({"aname": cname, "account_group": agroup, "op_bal": 0, "cl_bal": 0})
                acc_id = cname

            # Bug 14: Collect round_off value
            roff = sf(round_var.get())

            # Bug 13: Collect other charges
            oc_total = other_charges_tot.get()
            oc_note = "; ".join(f"{c['name']}:{c['amount']}" for c in other_charges_data)

            try:
                if edit_inv and not is_duplicate and v_type != "credit_note":
                    db.delete_voucher(edit_inv["id"])

                status = "OPEN" if v_type in ["purchase_order", "estimate"] else None
                terms_val = ""
                linked_id = (linked_po.get("id") or linked_po.get("v_id")) if linked_po else None
                cash_adv = sf(cash_adv_var.get())
                bank_adv = sf(bank_adv_var.get())
                adv = cash_adv + bank_adv

                narration = nar_text.get("1.0", "end").strip()
                # Bug 13/14: append charges/roundoff info to narration for record
                if oc_total:
                    narration += f"\n[Other Charges: {oc_note} = {oc_total}]"
                if roff:
                    narration += f"\n[Round Off: {roff}]"

                db.create_invoice(inv_no, v_type, acc_id, date_str,
                                  items, notes=narration, status=status,
                                  terms=terms_val, linked_po_id=linked_id,
                                  paid_amount=adv, is_template=is_template_var.get())

                if linked_id:
                    db.update_po_status(linked_id, "CLOSED")

                # Create receipt for cash
                if cash_adv > 0:
                    pmt_acc = "Cash Account" # fallback
                    if _cash_accs: pmt_acc = _cash_accs[0]["name"]
                    receipt_no = db.get_next_invoice_no("RCP", "receipt")
                    db.create_receipt(
                        receipt_no,          # receipt_no
                        date_str,            # date
                        pmt_acc,             # received_into (cash/bank account)
                        cname,               # received_from (customer)
                        cash_adv,            # sub_total
                        0,                   # discount
                        0,                   # tax
                        cash_adv,            # grand_total
                        "Advance for invoice " + inv_no,  # narration
                        []                   # selected_vouchers
                    )

                # Create receipt for bank
                if bank_adv > 0:
                    pmt_acc = bank_acc_var.get()
                    if not pmt_acc and bank_names:
                        pmt_acc = bank_names[0]
                    receipt_no = db.get_next_invoice_no("RCP", "receipt")
                    db.create_receipt(
                        receipt_no,          # receipt_no
                        date_str,            # date
                        pmt_acc,             # received_into (cash/bank account)
                        cname,               # received_from (customer)
                        bank_adv,            # sub_total
                        0,                   # discount
                        0,                   # tax
                        bank_adv,            # grand_total
                        "Advance for invoice " + inv_no,  # narration
                        []                   # selected_vouchers
                    )
            except Exception as ex:
                messagebox.showerror("Save Error", str(ex), parent=win)
                return

            messagebox.showinfo("Saved",
                f"Invoice '{inv_no}' saved successfully!", parent=win)

            # Bug 12 fix: correct order — preview first, then close and refresh
            if view_after or print_receipt:
                invs = db.get_all_invoices(v_type)
                inv_data = next((i for i in invs if i["invoice_no"] == inv_no), None)
                if inv_data:
                    inv_data['items'] = db.get_invoice_items(inv_data['id'])
                    invoice_preview.show_invoice_preview(self, inv_data, db, doc_type=v_type, auto_print=bool(print_receipt))

            win.destroy()
            self.show_invoices(v_type)

        # ── Bottom action bar buttons ─────────────────────────────────────────
        # Add a subtle top border line
        tk.Frame(bottom, bg="#ccc", height=1).grid(row=0, column=0, columnspan=2, sticky="ew")
        
        bottom.columnconfigure(0, weight=1)
        bottom.columnconfigure(1, weight=1)

        bot_left = tk.Frame(bottom, bg=BG)
        bot_left.grid(row=1, column=0, sticky="w", pady=4)
        bot_right_btns = tk.Frame(bottom, bg=BG)
        bot_right_btns.grid(row=1, column=1, sticky="e", pady=4)

        tk.Button(bot_left, text="Ctrl+Q: Exit", font=FONT,
                  command=win.destroy, bg="#e0e0e0", fg="#000",
                  relief="solid", bd=1).pack(side="left", padx=10, ipadx=10, ipady=5)
        
        # Pack from left to right inside the right-aligned container
        if v_type == "estimate":
            tk.Checkbutton(bot_right_btns, text="Save as Template", variable=is_template_var, bg=BG, font=FONT_BOLD).pack(side="left", padx=10)

        tk.Button(bot_right_btns, text="Ctrl+F12: Save & Receipt", font=FONT,
                  command=lambda: save_voucher(print_receipt=True),
                  bg="#e0e0e0", fg="#000", relief="solid", bd=1).pack(side="left", padx=5, ipadx=10, ipady=5)
        tk.Button(bot_right_btns, text="Alt+F12: Save & View", font=FONT,
                  command=lambda: save_voucher(view_after=True),
                  bg="#e0e0e0", fg="#000", relief="solid", bd=1).pack(side="left", padx=5, ipadx=10, ipady=5)
        tk.Button(bot_right_btns, text="F12:Save", font=FONT,
                  command=save_voucher, bg="#e0e0e0", fg="#000",
                  relief="solid", bd=1).pack(side="left", padx=(5, 10), ipadx=10, ipady=5)

        # ── Keyboard shortcuts ───────────────────────────────
        btn_search.config(command=on_f9_focus_item)
        win.bind("<F12>", lambda e: [save_voucher(), "break"][1])
        win.bind("<Alt-F12>", lambda e: [save_voucher(view_after=True), "break"][1])
        win.bind("<Control-F12>", lambda e: [save_voucher(print_receipt=True), "break"][1])
        win.bind("<Control-q>", lambda e: [win.destroy(), "break"][1])
        win.bind("<Control-Q>", lambda e: [win.destroy(), "break"][1])

        win.bind("<Alt-F2>", lambda e: [self.open_inventory_stock_level(), "break"][1])

        # Ctrl+M toggles Item Mode label
        def toggle_item_mode(e=None):
            current = btn_mode.cget("text")
            if "Item" in current:
                btn_mode.config(text="Ctrl+M: Account Mode", fg="#004499")
            else:
                btn_mode.config(text="Ctrl+M: Item Mode", fg="#000000")
            return "break"
        btn_mode.config(command=toggle_item_mode)
        win.bind("<Control-m>", toggle_item_mode)
        win.bind("<Control-M>", toggle_item_mode)

        # Account / Item Creation shortcuts from topbar
        win.bind("<Alt-a>", lambda e: [self._generic_account_form(parent=win), "break"][1])
        win.bind("<Alt-A>", lambda e: [self._generic_account_form(parent=win), "break"][1])
        win.bind("<Alt-c>", lambda e: [self._account_form("customer", parent=win), "break"][1])
        win.bind("<Alt-C>", lambda e: [self._account_form("customer", parent=win), "break"][1])
        win.bind("<Alt-s>", lambda e: [self._account_form("supplier", parent=win), "break"][1])
        win.bind("<Alt-S>", lambda e: [self._account_form("supplier", parent=win), "break"][1])
        win.bind("<Alt-t>", lambda e: [self._account_form("tax", parent=win), "break"][1])
        win.bind("<Alt-T>", lambda e: [self._account_form("tax", parent=win), "break"][1])
        win.bind("<Alt-i>", lambda e: [self._item_form(parent=win), "break"][1])
        win.bind("<Alt-I>", lambda e: [self._item_form(parent=win), "break"][1])

# ── Entry ─────────────────────────────────────────────────────────────────────
    def _open_income_voucher(self, edit_inv=None, is_duplicate=False):
        win = tk.Toplevel(self)
        win.title("Create Voucher")
        win.geometry("1100x680")
        try:
            win.state("zoomed")
        except tk.TclError:
            pass
        win.configure(bg=BG)
        win.resizable(True, True)
        win.grab_set()

        top_bar_container = tk.Frame(win, bg=BG)
        top_bar_container.pack(fill="x", side="top")
        top_bar = tk.Frame(top_bar_container, bg="#ffffff")
        top_bar.pack(fill="x", side="top")
        tk.Frame(top_bar_container, bg=BG_DARK, height=1).pack(fill="x", side="top")

        shortcuts = [
            ("accounts", " New Account", self._generic_account_form),
            ("accounts", " New Expense Account", lambda: self._account_form("expense")),
            ("accounts", " New Income Account", lambda: self._account_form("income")),
        ]
        
        for i, (icon_key, txt, cmd) in enumerate(shortcuts):
            btn = tk.Button(top_bar, text=txt, image=self.icons_cache.get(icon_key), compound="left", bg="#ffffff", fg="#000",
                            font=("Segoe UI", 11), relief="flat", bd=0,
                            activebackground="#f0f0f0", activeforeground="#000",
                            cursor="hand2", command=cmd or (lambda: None))
            btn.image = self.icons_cache.get(icon_key)
            btn.pack(side="left", padx=4, pady=2)
            if i < len(shortcuts) - 1:
                tk.Label(top_bar, text="|", bg="#ffffff", fg="#cccccc", font=("Segoe UI", 11)).pack(side="left")

        hdr = tk.Frame(win, bg=WHITE, pady=4)
        hdr.pack(fill="x", padx=8)

        tk.Label(hdr, text="Press ENTER to move forward SHIFT+ENTER to move back.", bg=WHITE, fg="darkred",
                 font=("Segoe UI", 11, "bold italic")).grid(row=0, column=0, columnspan=4, sticky="w", padx=10)

        tk.Label(hdr, text="Receipt No", bg=WHITE, font=FONT).grid(row=1, column=0, sticky="w", padx=4, pady=3)
        inv_no_var = tk.StringVar(value=db.get_next_invoice_no("RCV", "income"))
        tk.Entry(hdr, textvariable=inv_no_var, font=FONT, width=22, relief="solid", bd=1, bg="yellow").grid(row=1, column=1, padx=4, pady=3, sticky="w")

        tk.Label(hdr, text="Voucher Date", bg=WHITE, font=FONT).grid(row=2, column=0, sticky="w", padx=4, pady=3)
        date_var = tk.StringVar(value=self.get_default_date())
        date_frame = tk.Frame(hdr, bg=WHITE)
        date_frame.grid(row=2, column=1, sticky="w", padx=4, pady=3)
        tk.Entry(date_frame, textvariable=date_var, font=FONT, width=16, relief="solid", bd=1, bg=WHITE).pack(side="left")
        tk.Label(date_frame, text=" 📅", bg=WHITE, font=("Segoe UI", 11)).pack(side="left")

        all_accounts = db.get_all_accounts()
        cash_bank = [a["name"] for a in all_accounts if a["account_group"] in ["cash", "bank", "Cash-in-hand", "Bank A/Cs"]]
        other_accounts = [a["name"] for a in all_accounts if a["account_group"] not in ["cash", "bank", "Cash-in-hand", "Bank A/Cs"]]
        def check_autocomplete(event, cb, full_list):
            if event.keysym in ('Up', 'Down', 'Return', 'Left', 'Right', 'Tab', 'Shift_L', 'Shift_R', 'BackSpace'):
                if event.keysym == 'BackSpace' and not cb.get():
                    cb['values'] = full_list
                return
            typed = cb.get()
            if typed == "":
                cb['values'] = full_list
            else:
                cb['values'] = [x for x in full_list if x.lower().startswith(typed.lower())]
            try:
                cb.event_generate('<Down>')
            except: pass


        tk.Label(hdr, text="Received Into", bg=WHITE, font=FONT).grid(row=3, column=0, sticky="w", padx=4, pady=3)
        received_into_fr = tk.Frame(hdr, bg=WHITE)
        received_into_fr.grid(row=3, column=1, sticky="w", padx=4, pady=3)
        received_into_var = tk.StringVar(value="")
        received_into_cb = AutocompleteCombobox(received_into_fr, textvariable=received_into_var, values=cash_bank, font=FONT, width=30)
        received_into_cb.pack(side="top", anchor="w")
        received_into_cb.bind("<KeyRelease>", lambda e: check_autocomplete(e, received_into_cb, cash_bank))
        received_into_cb.bind("<Return>", lambda e: received_from_cb.focus_set())
        received_into_cb.bind("<<ComboboxSelected>>", lambda e: win.after(10, received_from_cb.focus_set))
        received_into_bal = tk.Label(received_into_fr, text="balance 0.00", bg=WHITE, font=("Segoe UI", 10))
        received_into_bal.pack(side="top", anchor="w")

        def update_pf_bal(*args):
            bal = db.get_account_balance(received_into_var.get())
            received_into_bal.config(text=f"balance {bal:,.2f}")
        received_into_var.trace_add("write", update_pf_bal)

        tk.Label(hdr, text="F9: Received From", bg=WHITE, font=FONT).grid(row=3, column=2, sticky="e", padx=(40,4), pady=3)
        tk.Label(hdr, text="Press ENTER key to add.", bg=WHITE, fg="darkred", font=("Segoe UI", 11, "bold italic")).grid(row=2, column=3, sticky="w", padx=4)
        
        received_from_fr = tk.Frame(hdr, bg=WHITE)
        received_from_fr.grid(row=3, column=3, sticky="w", padx=4, pady=3)
        received_from_var = tk.StringVar(value="")
        received_from_cb = AutocompleteCombobox(received_from_fr, textvariable=received_from_var, values=other_accounts, font=FONT, width=30)
        received_from_cb.pack(side="top", anchor="w")
        
        def on_received_from_enter(e=None):
            acc_name = received_from_var.get().strip()
            if acc_name:
                add_grid_row(acc_name)
                received_from_var.set("")
            else:
                nar_text.focus_set()
            return "break"
        
        received_from_cb.bind("<Return>", on_received_from_enter)
        received_from_cb.bind("<<ComboboxSelected>>", lambda e: win.after(10, on_received_from_enter))
        received_from_cb.bind("<KeyRelease>", lambda e: check_autocomplete(e, received_from_cb, other_accounts))
        received_from_bal = tk.Label(received_from_fr, text="balance 0.00", bg=WHITE, font=("Segoe UI", 10))
        received_from_bal.pack(side="top", anchor="w")

        def update_pt_bal(*args):
            bal = db.get_account_balance(received_from_var.get())
            received_from_bal.config(text=f"balance {bal:,.2f}")
        received_from_var.trace_add("write", update_pt_bal)

        update_pf_bal()
        update_pt_bal()

        header_frame = tk.Frame(win, bg=WHITE, relief="flat", bd=0)
        header_frame.pack(fill="x", padx=8, pady=(4, 0))
        
        tk.Label(header_frame, text="Account", bg=WHITE, fg="#000", font=FONT, width=54, anchor="w", relief="flat", bd=0, padx=4, pady=4).pack(side="left")
        tk.Label(header_frame, text="Amount", bg=WHITE, fg="#000", font=FONT, width=18, anchor="w", relief="flat", bd=0, padx=4, pady=4).pack(side="left")
        tk.Label(header_frame, text="Delete", bg=WHITE, fg="#000", font=FONT, width=6, anchor="center", relief="flat", bd=0, padx=4, pady=4).pack(side="left")
        tk.Label(header_frame, text="Click ✕ or press DELETE to remove line", bg=WHITE, fg="#666", font=("Segoe UI", 9, "italic")).pack(side="right", padx=10)

        bot_btns = tk.Frame(win, bg=BG)
        bot_btns.pack(fill="x", side="bottom", padx=8, pady=4)
        tk.Button(bot_btns, text="Ctrl+Q: Exit", bg="#e0e0e0", font=FONT, command=win.destroy, relief="solid", bd=1).pack(side="left", ipadx=10, ipady=5)
        tk.Button(bot_btns, text="F12:Save", bg="#e0e0e0", font=FONT, command=lambda: save(), relief="solid", bd=1).pack(side="right", ipadx=10, ipady=5)
        tk.Button(bot_btns, text="Alt+F12: Save & View", bg="#e0e0e0", font=FONT, command=lambda: save(view_after=True), relief="solid", bd=1).pack(side="right", padx=10, ipadx=10, ipady=5)
        import subprocess
        tk.Button(bot_btns, text="🖩", bg="#e0e0e0", font=FONT, command=lambda: subprocess.Popen("calc"), relief="solid", bd=1).pack(side="right", padx=10, ipadx=10, ipady=5)

        bot_frame = tk.Frame(win, bg=BG)
        bot_frame.pack(fill="x", side="bottom", padx=8, pady=4)

        bot_left = tk.Frame(bot_frame, bg=BG)
        bot_left.pack(side="left", fill="both", expand=True)

        tk.Label(bot_left, text="Narration\nUse Ctrl+Enter for next line", bg=BG, fg="#000", font=("Segoe UI", 10), anchor="n").pack(side="left", anchor="n")
        nar_text = tk.Text(bot_left, font=FONT, width=40, height=4, relief="sunken", bd=1, bg=WHITE)
        nar_text.pack(side="left", fill="x", expand=True, padx=(5, 20))

        ref_lf = tk.LabelFrame(bot_left, text="Reference Document", bg=BG, font=("Segoe UI", 10))
        ref_lf.pack(side="left", anchor="n", padx=4, fill="y")
        
        ref_var = tk.StringVar()
        tk.Entry(ref_lf, textvariable=ref_var, font=FONT, width=28, relief="solid", bd=1, bg="#f0f0f0").pack(padx=4, pady=4)
        
        def on_browse_ref():
            from tkinter import filedialog
            path = filedialog.askopenfilename(title="Select Reference Document", parent=win)
            if path:
                ref_var.set(path)
                
        def on_view_ref():
            import os
            from tkinter import messagebox
            path = ref_var.get().strip()
            if path and os.path.exists(path):
                try:
                    os.startfile(path)
                except Exception as e:
                    messagebox.showerror("Error", f"Could not open file: {e}", parent=win)
            else:
                messagebox.showwarning("Warning", "File does not exist or path is empty.", parent=win)
                
        def on_delete_ref():
            ref_var.set("")

        ref_btn_fr = tk.Frame(ref_lf, bg=BG)
        ref_btn_fr.pack(fill="x", pady=2)
        tk.Button(ref_btn_fr, text="Browse", bg="#e0e0e0", relief="flat", bd=1, command=on_browse_ref).pack(side="left", padx=2, fill="x", expand=True)
        tk.Button(ref_btn_fr, text="View", bg="#e0e0e0", relief="flat", bd=1, command=on_view_ref).pack(side="left", padx=2, fill="x", expand=True)
        tk.Button(ref_btn_fr, text="Delete", bg="#e0e0e0", relief="flat", bd=1, command=on_delete_ref).pack(side="left", padx=2, fill="x", expand=True)

        bot_right = tk.Frame(bot_frame, bg=BG)
        bot_right.pack(side="right", anchor="n")

        tk.Label(bot_right, text="Total", bg=BG, font=FONT).pack(side="left", padx=4)
        total_var = tk.StringVar(value="0")
        tk.Entry(bot_right, textvariable=total_var, font=FONT, width=15, justify="right", relief="solid", bd=1, state="readonly", readonlybackground="#e0e0e0").pack(side="left", padx=4)

        grid_frame = tk.Frame(win, bg=WHITE, relief="sunken", bd=2)
        grid_frame.pack(fill="both", expand=True, padx=8, pady=(0, 4))
        grid_canvas = tk.Canvas(grid_frame, bg=WHITE, highlightthickness=0)
        grid_vsb = ttk.Scrollbar(grid_frame, orient="vertical", command=grid_canvas.yview)
        grid_canvas.configure(yscrollcommand=grid_vsb.set)
        grid_vsb.pack(side="right", fill="y")
        grid_canvas.pack(side="left", fill="both", expand=True)

        grid_inner = tk.Frame(grid_canvas, bg=BG_DARK)
        grid_cw = grid_canvas.create_window((0, 0), window=grid_inner, anchor="nw")
        grid_inner.bind("<Configure>", lambda e: grid_canvas.configure(scrollregion=grid_canvas.bbox("all")))
        grid_canvas.bind("<Configure>", lambda e: grid_canvas.itemconfig(grid_cw, width=e.width))

        line_data = []
        def recalc_total():
            t = sum(float(l["amt_var"].get() or 0) for l in line_data)
            total_var.set(f"{t:,.0f}")

        def add_grid_row(initial_acc=""):
            ri = len(line_data) + 1
            bg_color = WHITE if ri % 2 == 1 else "#f0f0f0"
            
            acc_v = tk.StringVar(value=initial_acc)
            amt_v = tk.StringVar(value="")
            
            cb = AutocompleteCombobox(grid_inner, textvariable=acc_v, values=other_accounts, font=FONT)
            cb.grid(row=ri, column=0, padx=(0, 1), pady=(0, 1), sticky="ew", ipady=5)
            
            amt_e = tk.Entry(grid_inner, textvariable=amt_v, font=FONT, justify="right", relief="flat", bd=0, bg="yellow")
            amt_e.grid(row=ri, column=1, padx=(0, 1), pady=(0, 1), sticky="ew", ipady=5)
            
            row_dict = {"acc_var": acc_v, "amt_var": amt_v, "row_idx": ri, "amt_e": amt_e, "acc_cb": cb}

            def del_this_row(e=None):
                if row_dict not in line_data:
                    return "break"
                line_data.remove(row_dict)
                for w in [row_dict.get("acc_cb"), row_dict.get("amt_e"), row_dict.get("del_btn")]:
                    if w and w.winfo_exists():
                        w.destroy()
                # Re-index all remaining rows cleanly and re-configure grid row
                for new_idx, rem in enumerate(line_data, start=1):
                    rem["row_idx"] = new_idx
                    if rem.get("acc_cb") and rem["acc_cb"].winfo_exists():
                        rem["acc_cb"].grid_configure(row=new_idx)
                    if rem.get("amt_e") and rem["amt_e"].winfo_exists():
                        rem["amt_e"].grid_configure(row=new_idx)
                    if rem.get("del_btn") and rem["del_btn"].winfo_exists():
                        rem["del_btn"].grid_configure(row=new_idx)
                recalc_total()
                received_from_cb.focus_set()
                return "break"

            del_btn = tk.Button(
                grid_inner, text="✕", bg="#ffeeee", fg="#cc0000",
                activebackground="#cc0000", activeforeground="white",
                font=("Segoe UI", 9, "bold"), relief="flat", bd=0, cursor="hand2",
                command=del_this_row
            )
            del_btn.grid(row=ri, column=2, padx=(0, 1), pady=(0, 1), sticky="nsew", ipady=3)
            row_dict["del_btn"] = del_btn
            
            amt_e.bind("<KeyRelease>", lambda e: recalc_total())
            
            def on_amt_enter(e=None):
                recalc_total()
                received_from_cb.focus_set()
                received_from_cb.selection_range(0, tk.END)
                received_from_cb.icursor(tk.END)
                return "break"
            
            amt_e.bind("<Return>", on_amt_enter)

            # Keyboard shortcuts for deletion across all row widgets
            for w in (cb, amt_e, del_btn):
                w.bind("<Delete>", del_this_row)
                w.bind("<Shift-Delete>", del_this_row)
                w.bind("<Control-Delete>", del_this_row)
                w.bind("<Alt-Delete>", del_this_row)
                w.bind("<Control-d>", del_this_row)
                w.bind("<Control-D>", del_this_row)
                w.bind("<Alt-d>", del_this_row)
                w.bind("<Alt-D>", del_this_row)
            
            del_btn.bind("<Return>", del_this_row)
            del_btn.bind("<space>", del_this_row)

            # Right click context menu
            menu = tk.Menu(win, tearoff=0)
            menu.add_command(label="Delete Line (✕)", command=del_this_row)
            cb.bind("<Button-3>", lambda e: menu.post(e.x_root, e.y_root))
            amt_e.bind("<Button-3>", lambda e: menu.post(e.x_root, e.y_root))
            del_btn.bind("<Button-3>", lambda e: menu.post(e.x_root, e.y_root))
            
            grid_inner.columnconfigure(0, weight=4)
            grid_inner.columnconfigure(1, weight=1)
            grid_inner.columnconfigure(2, weight=0, minsize=35)
            
            line_data.append(row_dict)
            
            if initial_acc:
                win.after(20, lambda: (amt_e.focus_set(), amt_e.selection_range(0, tk.END)))


        if edit_inv:
            conn = db.get_conn()
            main_row = conn.execute("SELECT * FROM vouchers WHERE v_id=?", (edit_inv["id"],)).fetchone()
            if main_row:
                if not is_duplicate:
                    inv_no_var.set(main_row["vch_no"])
                date_var.set(main_row["date"])
                nar_text.insert("1.0", main_row["narration"] or "")
                ref_var.set(main_row["detail2"] or "")
                
                # Fetch line items
                lines = conn.execute("SELECT * FROM vouchers_all WHERE v_id=?", (edit_inv["id"],)).fetchall()
                if lines:
                    received_into_var.set(lines[0]["debit"]) # All lines share the same received_into (debit)
                    update_pf_bal()
                    
                    for line in lines:
                        add_grid_row(line["credit"])
                        line_data[-1]["amt_var"].set(str(line["amount"]))
                recalc_total()
            conn.close()

        def reset_screen():
            for rd in list(line_data):
                for w in [rd.get("acc_cb"), rd.get("amt_e"), rd.get("del_btn")]:
                    if w and w.winfo_exists():
                        w.destroy()
            line_data.clear()
            recalc_total()
            inv_no_var.set(db.get_next_invoice_no("REC", "income"))
            received_from_var.set("")
            ref_var.set("")
            nar_text.delete("1.0", "end")
            total_var.set("0")
            update_pf_bal()
            update_pt_bal()
            received_from_cb.focus_set()

        def save(view_after=False):
            items = []
            for l in line_data:
                name = l["acc_var"].get()
                amt = l["amt_var"].get()
                if name and amt:
                    try:
                        amt_f = float(str(amt).replace(',', ''))
                        if amt_f > 0:
                            items.append({"name": name, "total": amt_f})
                    except: pass
            if not items:
                from tkinter import messagebox
                messagebox.showerror("Error", "No valid items entered", parent=win)
                return
            
            try:
                if edit_inv and not is_duplicate:
                    db.delete_voucher(edit_inv["id"])
                    
                v_id = db.create_income(
                    invoice_no=inv_no_var.get(),
                    date=date_var.get(),
                    received_into_acc=received_into_var.get(),
                    received_from_acc=received_from_var.get(),
                    line_items=items,
                    notes=nar_text.get("1.0", "end").strip(),
                    status="OPEN",
                    ref_doc=ref_var.get()
                )
                
                saved_inv_data = {
                    "id": v_id,
                    "v_id": v_id,
                    "invoice_no": inv_no_var.get(),
                    "date": date_var.get(),
                    "type": "income",
                    "total": sum(it['total'] for it in items),
                    "received_into": received_into_var.get(),
                    "received_from": received_from_var.get(),
                    "items": items,
                    "notes": nar_text.get("1.0", "end").strip(),
                    "ref_doc": ref_var.get()
                }
                
                from tkinter import messagebox
                if edit_inv and not is_duplicate:
                    messagebox.showinfo("Success", "Income updated successfully!", parent=win)
                    win.destroy()
                    if view_after:
                        invoice_preview.show_invoice_preview(self, saved_inv_data, db, doc_type="income")
                    else:
                        self.show_invoices("income")
                else:
                    messagebox.showinfo("Success", "Income saved successfully!", parent=win)
                    if view_after:
                        invoice_preview.show_invoice_preview(self, saved_inv_data, db, doc_type="income")
                    reset_screen()
            except Exception as e:
                from tkinter import messagebox
                messagebox.showerror("Database Error", str(e), parent=win)
                
        win.bind("<Control-q>", lambda e: win.destroy())
        win.bind("<Control-Q>", lambda e: win.destroy())
        win.bind("<Alt-a>", lambda e: self._generic_account_form())
        win.bind("<Alt-A>", lambda e: self._generic_account_form())
        win.bind("<Alt-e>", lambda e: self._account_form("expense"))
        win.bind("<Alt-E>", lambda e: self._account_form("expense"))
        win.bind("<Alt-i>", lambda e: self._account_form("income"))
        win.bind("<Alt-I>", lambda e: self._account_form("income"))
        win.bind("<F9>", lambda e: received_from_cb.focus_set())
        win.bind("<F12>", lambda e: save())
        win.bind("<Alt-F12>", lambda e: save(view_after=True))



    def _open_contra_voucher(self, edit_inv=None, is_duplicate=False, default_to=None, default_from=None):
        import datetime
        from tkinter import ttk, filedialog, messagebox
        import os
        import invoice_preview

        win = tk.Toplevel(self)
        win.title("Create Voucher - Contra")
        win.geometry("1100x680")
        try:
            win.state("zoomed")
        except tk.TclError:
            pass
        win.configure(bg=BG)
        win.resizable(True, True)
        win.grab_set()

        top_bar_container = tk.Frame(win, bg=BG)
        top_bar_container.pack(fill="x", side="top")
        top_bar = tk.Frame(top_bar_container, bg="#ffffff")
        top_bar.pack(fill="x", side="top")
        tk.Frame(top_bar_container, bg=BG_DARK, height=1).pack(fill="x", side="top")

        shortcuts = [
            ("accounts", " New Account", self._generic_account_form),
            ("customer", " New Customer", lambda: self._account_form("customer")),
            ("supplier", " New Supplier", lambda: self._account_form("supplier")),
            ("tax", " New Tax Account", lambda: self._account_form("tax")),
            ("inventory", " New Inventory Item", self._item_form),
            ("service", " New Service", None),
        ]
        
        for i, (icon_key, txt, cmd) in enumerate(shortcuts):
            btn = tk.Button(top_bar, text=txt, image=self.icons_cache.get(icon_key), compound="left", bg="#ffffff", fg="#000",
                            font=("Segoe UI", 11), relief="flat", bd=0,
                            activebackground="#f0f0f0", activeforeground="#000",
                            cursor="hand2", command=cmd or (lambda: None))
            btn.image = self.icons_cache.get(icon_key)
            btn.pack(side="left", padx=4, pady=2)
            if i < len(shortcuts) - 1:
                tk.Label(top_bar, text="|", bg="#ffffff", fg="#cccccc", font=("Segoe UI", 11)).pack(side="left")

        hdr = tk.Frame(win, bg=WHITE, pady=4)
        hdr.pack(fill="x", padx=8)

        tk.Label(hdr, text="Press ENTER to move forward", bg=WHITE, fg="darkred",
                 font=("Segoe UI", 11, "bold italic")).grid(row=0, column=0, columnspan=4, sticky="w", padx=10)

        tk.Label(hdr, text="Contra No", bg=WHITE, font=FONT).grid(row=1, column=0, sticky="w", padx=4, pady=3)
        inv_no_var = tk.StringVar(value=db.get_next_invoice_no("CON", "contra"))
        inv_entry = tk.Entry(hdr, textvariable=inv_no_var, font=FONT, width=22, relief="solid", bd=1, bg="yellow")
        inv_entry.grid(row=1, column=1, padx=4, pady=3, sticky="w")

        tk.Label(hdr, text="Voucher Date", bg=WHITE, font=FONT).grid(row=2, column=0, sticky="w", padx=4, pady=3)
        date_var = tk.StringVar(value=self.get_default_date())
        date_frame = tk.Frame(hdr, bg=WHITE)
        date_frame.grid(row=2, column=1, sticky="w", padx=4, pady=3)
        date_entry = tk.Entry(date_frame, textvariable=date_var, font=FONT, width=16, relief="solid", bd=1, bg=WHITE)
        date_entry.pack(side="left")
        tk.Label(date_frame, text=" 📅", bg=WHITE, font=("Segoe UI", 11)).pack(side="left")

        all_accounts = db.get_all_accounts()
        all_acc_names = [a["name"] for a in all_accounts]
        cash_bank = [a["name"] for a in all_accounts if a.get("account_group","").lower() in ["cash", "bank", "cash-in-hand", "bank a/cs", "bank accounts", "cash in hand", "cash a/c", "bank a/c"] or "cash" in a.get("account_group","").lower() or "bank" in a.get("account_group","").lower() or a["name"].lower() in ["cash", "bank"]]
        if not cash_bank:
            cash_bank = all_acc_names

        def check_autocomplete(event, cb, full_list):
            if event.keysym in ('Up', 'Down', 'Return', 'Left', 'Right', 'Tab', 'Shift_L', 'Shift_R', 'BackSpace'):
                if event.keysym == 'BackSpace' and not cb.get():
                    cb['values'] = full_list
                return
            typed = cb.get().strip()
            if typed == "":
                cb['values'] = full_list
            else:
                matches = [x for x in full_list if typed.lower() in x.lower()]
                cb['values'] = matches if matches else all_acc_names
            try:
                cb.event_generate('<Down>')
            except:
                pass

        tk.Label(hdr, text="To Account", bg=WHITE, font=FONT).grid(row=3, column=0, sticky="w", padx=4, pady=3)
        to_acc_var = tk.StringVar(value=default_to if default_to else "")
        to_cb = AutocompleteCombobox(hdr, textvariable=to_acc_var, values=cash_bank, font=FONT, width=40)
        to_cb.grid(row=3, column=1, padx=4, pady=3, sticky="w")
        to_cb.bind("<KeyRelease>", lambda e: check_autocomplete(e, to_cb, cash_bank))
        to_bal_lbl = tk.Label(hdr, text="balance", bg=WHITE, font=("Segoe UI", 10), fg="#666")
        to_bal_lbl.grid(row=3, column=2, sticky="w", padx=4)

        tk.Label(hdr, text="From Account", bg=WHITE, font=FONT).grid(row=4, column=0, sticky="w", padx=4, pady=3)
        from_acc_var = tk.StringVar(value=default_from if default_from else "")
        from_cb = AutocompleteCombobox(hdr, textvariable=from_acc_var, values=cash_bank, font=FONT, width=40)
        from_cb.grid(row=4, column=1, padx=4, pady=3, sticky="w")
        from_cb.bind("<KeyRelease>", lambda e: check_autocomplete(e, from_cb, cash_bank))
        from_bal_lbl = tk.Label(hdr, text="balance", bg=WHITE, font=("Segoe UI", 10), fg="#666")
        from_bal_lbl.grid(row=4, column=2, sticky="w", padx=4)

        def update_bal(*args):
            for var, lbl in [(to_acc_var, to_bal_lbl), (from_acc_var, from_bal_lbl)]:
                name = var.get().strip()
                if name:
                    bal = db.get_account_balance(name)
                    lbl.config(text=f"Cur Bal: {bal:,.2f}")
                else:
                    lbl.config(text="balance")

        to_acc_var.trace_add("write", update_bal)
        from_acc_var.trace_add("write", update_bal)

        mid_frame = tk.Frame(win, bg=WHITE)
        mid_frame.pack(fill="both", expand=True, padx=8, pady=4)
        
        amt_fr = tk.Frame(mid_frame, bg=WHITE)
        amt_fr.pack(side="right", anchor="s", pady=20)
        
        tk.Label(amt_fr, text="Amount", bg=WHITE, font=FONT).pack(side="left", padx=4)
        amt_var = tk.StringVar()
        amt_entry = tk.Entry(amt_fr, textvariable=amt_var, font=FONT, width=15, relief="solid", bd=1, justify="right")
        amt_entry.pack(side="left")

        bot_upper = tk.Frame(win, bg=WHITE)
        bot_upper.pack(fill="x", padx=8, pady=(0, 2))
        
        total_fr = tk.Frame(bot_upper, bg=WHITE)
        total_fr.pack(side="right", padx=14)
        tk.Label(total_fr, text="Total Amount", bg=WHITE, font=FONT).pack(side="left", padx=4)
        tot_lbl = tk.Label(total_fr, text="0.00", bg=WHITE, font=FONT_BOLD, width=15, relief="solid", bd=1, justify="right", anchor="e")
        tot_lbl.pack(side="left")
        
        def update_tot(*args):
            try:
                val = float(amt_var.get() or 0)
                tot_lbl.config(text=f"{val:,.2f}")
            except:
                tot_lbl.config(text="0.00")
        amt_var.trace_add("write", update_tot)

        bot_lower = tk.Frame(win, bg=WHITE)
        bot_lower.pack(fill="x", padx=8, pady=4)
        
        tk.Label(bot_lower, text="Narration\nCtrl+Enter for next line", justify="right", bg=WHITE, font=("Segoe UI", 10, "italic")).pack(side="left", anchor="n", padx=4)
        nar_text = tk.Text(bot_lower, height=3, width=70, font=FONT, relief="solid", bd=1)
        nar_text.pack(side="left", padx=4)
        
        ref_fr = tk.LabelFrame(bot_lower, text="Reference Document", bg=WHITE, font=("Segoe UI", 10))
        ref_fr.pack(side="right", padx=10, fill="y")
        ref_var = tk.StringVar()
        tk.Entry(ref_fr, textvariable=ref_var, width=30, relief="solid", bd=1, bg="#f0f0f0").pack(padx=4, pady=(2, 4))

        def on_browse_ref():
            path = filedialog.askopenfilename(title="Select Reference Document", parent=win)
            if path:
                ref_var.set(path)
                
        def on_view_ref():
            path = ref_var.get().strip()
            if path and os.path.exists(path):
                try:
                    os.startfile(path)
                except Exception as e:
                    messagebox.showerror("Error", f"Could not open file: {e}", parent=win)
            else:
                messagebox.showwarning("Warning", "File does not exist or path is empty.", parent=win)
                
        def on_delete_ref():
            ref_var.set("")

        b_fr = tk.Frame(ref_fr, bg=WHITE)
        b_fr.pack(fill="x", padx=4, pady=2)
        tk.Button(b_fr, text="Browse", bg="#e0e0e0", relief="flat", bd=1, font=("Segoe UI", 10), command=on_browse_ref).pack(side="left", padx=2, fill="x", expand=True)
        tk.Button(b_fr, text="View", bg="#e0e0e0", relief="flat", bd=1, font=("Segoe UI", 10), command=on_view_ref).pack(side="left", padx=2, fill="x", expand=True)
        tk.Button(b_fr, text="Delete", bg="#e0e0e0", relief="flat", bd=1, font=("Segoe UI", 10), command=on_delete_ref).pack(side="left", padx=2, fill="x", expand=True)

        bot_btns = tk.Frame(win, bg=BG)
        bot_btns.pack(fill="x", padx=8, pady=8)

        tk.Button(bot_btns, text="Ctrl+Q: Exit", bg="#e0e0e0", font=FONT, command=win.destroy, relief="solid", bd=1).pack(side="left", padx=10, ipadx=10, ipady=5)
        
        # Navigation bindings
        inv_entry.bind("<Return>", lambda e: date_entry.focus_set())
        date_entry.bind("<Return>", lambda e: to_cb.focus_set())
        to_cb.bind("<Return>", lambda e: from_cb.focus_set())
        to_cb.bind("<<ComboboxSelected>>", lambda e: win.after(10, from_cb.focus_set))
        from_cb.bind("<Return>", lambda e: amt_entry.focus_set())
        from_cb.bind("<<ComboboxSelected>>", lambda e: win.after(10, amt_entry.focus_set))
        amt_entry.bind("<Return>", lambda e: nar_text.focus_set())

        if edit_inv:
            conn = db.get_conn()
            main_row = conn.execute("SELECT * FROM vouchers WHERE v_id=?", (edit_inv["id"],)).fetchone()
            if main_row:
                if not is_duplicate:
                    inv_no_var.set(main_row["vch_no"])
                date_var.set(main_row["date"])
                amt_var.set(str(main_row["amount"]))
                nar_text.delete("1.0", "end")
                nar_text.insert("1.0", main_row["narration"] or "")
                ref_var.set(main_row["detail2"] or "")
                
                lines = conn.execute("SELECT * FROM vouchers_all WHERE v_id=?", (edit_inv["id"],)).fetchall()
                if lines:
                    to_acc_var.set(lines[0]["debit"] or "")
                    from_acc_var.set(lines[0]["credit"] or "")
            conn.close()
            update_bal()

        def reset_screen():
            inv_no_var.set(db.get_next_invoice_no("CON", "contra"))
            date_var.set(self.get_default_date())
            to_acc_var.set("")
            from_acc_var.set("")
            amt_var.set("")
            nar_text.delete("1.0", "end")
            ref_var.set("")
            to_cb['values'] = cash_bank
            from_cb['values'] = cash_bank
            update_bal()
            win.after(20, lambda: to_cb.focus_set())

        def save(view_after=False):
            t_acc = to_acc_var.get().strip()
            f_acc = from_acc_var.get().strip()
            amt_s = amt_var.get().strip()
            if not t_acc or not f_acc or not amt_s:
                messagebox.showerror("Error", "Please fill To Account, From Account and Amount", parent=win)
                return
            try:
                amt = float(amt_s)
                if amt <= 0:
                    raise ValueError
            except:
                messagebox.showerror("Error", "Please enter a valid positive Amount", parent=win)
                return
            
            try:
                if edit_inv and not is_duplicate:
                    db.delete_voucher(edit_inv["id"])
                    
                v_id = db.create_contra(
                    invoice_no=inv_no_var.get().strip(),
                    date=date_var.get().strip(),
                    to_account=t_acc,
                    from_account=f_acc,
                    amount=amt,
                    notes=nar_text.get("1.0", "end").strip(),
                    status="OPEN",
                    ref_doc=ref_var.get().strip()
                )

                saved_inv_data = {
                    "id": v_id,
                    "v_id": v_id,
                    "invoice_no": inv_no_var.get().strip(),
                    "date": date_var.get().strip(),
                    "type": "contra",
                    "total": amt,
                    "to_account": t_acc,
                    "from_account": f_acc,
                    "notes": nar_text.get("1.0", "end").strip(),
                    "ref_doc": ref_var.get().strip()
                }

                if edit_inv and not is_duplicate:
                    messagebox.showinfo("Success", "Contra updated successfully!", parent=win)
                    win.destroy()
                    if view_after:
                        invoice_preview.show_invoice_preview(self, saved_inv_data, db, doc_type="contra")
                    else:
                        self.show_invoices("contra")
                else:
                    messagebox.showinfo("Success", "Contra saved successfully!", parent=win)
                    if view_after:
                        invoice_preview.show_invoice_preview(self, saved_inv_data, db, doc_type="contra")
                    reset_screen()
            except Exception as e:
                messagebox.showerror("Database Error", str(e), parent=win)

        tk.Button(bot_btns, text="F12:Save", bg="#e0e0e0", font=FONT, command=save, relief="solid", bd=1).pack(side="right", padx=10, ipadx=10, ipady=5)
        win.bind("<Control-q>", lambda e: win.destroy())
        win.bind("<Control-Q>", lambda e: win.destroy())
        win.bind("<Alt-a>", lambda e: self._generic_account_form())
        win.bind("<Alt-A>", lambda e: self._generic_account_form())
        win.bind("<F9>", lambda e: to_cb.focus_set())
        win.bind("<F12>", lambda e: save())
        win.bind("<Alt-F12>", lambda e: save(view_after=True))



def check_for_updates(root):
    import urllib.request
    import threading
    from tkinter import messagebox
    import subprocess
    import sys
    import os

    # Replace with the actual URL to the raw version.txt in the GitHub repo
    VERSION_URL = "https://raw.githubusercontent.com/vsuretobe-del/Bookkeeper-by-Raheem-Soft/main/version.txt"
    
    def run_check():
        try:
            if "YOUR_GITHUB_USERNAME" in VERSION_URL:
                return # Not configured yet
                
            # Read local version
            local_version = "1.0.0"
            if os.path.exists("version.txt"):
                with open("version.txt", "r") as vf:
                    local_version = vf.read().strip()
            
            # Fetch remote version
            req = urllib.request.Request(VERSION_URL, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=10) as response:
                remote_version = response.read().decode('utf-8').strip()
                
            # Simple string comparison for versions (assuming format X.Y.Z)
            def parse_version(v):
                return [int(x) for x in v.split('.') if x.isdigit()]
                
            if parse_version(remote_version) > parse_version(local_version):
                root.after(0, prompt_update, remote_version)
        except Exception as e:
            pass # Fail silently if no internet or error

    def prompt_update(new_ver):
        if messagebox.askyesno("Update Available", f"A new version ({new_ver}) is available. Would you like to update now?"):
            try:
                subprocess.Popen([sys.executable, "updater.py"], creationflags=subprocess.CREATE_NEW_CONSOLE)
            except:
                os.startfile("updater.py")
            root.destroy()
            sys.exit(0)

    threading.Thread(target=run_check, daemon=True).start()

if __name__ == "__main__":
    app = BookKeeperApp()
    check_for_updates(app)
    app.mainloop()


