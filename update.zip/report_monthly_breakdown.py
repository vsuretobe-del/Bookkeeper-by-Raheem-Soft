import tkinter as tk
from tkinter import ttk, messagebox
import db
import datetime

BG_DARK = "#2B579A"
WHITE = "#FFFFFF"
GRAY = "#E0E0E0"
DARK_GRAY = "#666666"

FONT = ("Segoe UI", 10)
FONT_BOLD = ("Segoe UI", 10, "bold")
TITLE_FONT = ("Segoe UI", 14, "bold")
CATEGORY_FONT = ("Segoe UI", 10, "bold")
GROUP_FONT = ("Segoe UI", 9, "bold")
ACCOUNT_FONT = ("Segoe UI", 9)

class ReportMonthlyBreakdown(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent, bg=WHITE)
        self.app_ref = parent
        self.title("Monthly Breakdown")
        self.state("zoomed")
        self.geometry("1024x768")
        
        # Try to get dates from the main app
        try:
            self.start_d = self.app_ref.reporting_from_dp.get_date().strftime("%Y-%m-%d")
            self.end_d = self.app_ref.reporting_to_dp.get_date().strftime("%Y-%m-%d")
        except:
            today = datetime.date.today()
            self.start_d = datetime.date(today.year if today.month >= 4 else today.year - 1, 4, 1).strftime("%Y-%m-%d")
            self.end_d = today.strftime("%Y-%m-%d")
            
        self.build_ui()
        self.load_data()
        
    def not_implemented(self, event=None):
        messagebox.showinfo("Coming Soon", "This feature is not implemented yet.")

    def build_ui(self):
        # Toolbar
        tb = tk.Frame(self, bg=WHITE)
        tb.pack(fill="x", padx=10, pady=5)
        
        btn_exit = tk.Button(tb, text="✖ Ctrl+Q: Exit", bg="black", fg="white", font=("Tahoma", 8, "bold"), padx=4, pady=2, relief="flat", cursor="hand2", command=self.destroy)
        btn_exit.pack(side="left", padx=2)
        
        btn_print = tk.Button(tb, text="🖨 Alt+P: Print", bg="white", fg="black", font=("Tahoma", 8), padx=4, pady=2, relief="flat", cursor="hand2", command=self.not_implemented)
        btn_print.pack(side="left", padx=2)
        
        btn_word = tk.Button(tb, text="📄 Ctrl+W: Open In MS Word", bg="#DCDCDC", fg="black", font=("Tahoma", 8), padx=4, pady=2, relief="flat", cursor="hand2", command=self.not_implemented)
        btn_word.pack(side="left", padx=2)
        
        btn_excel = tk.Button(tb, text="📊 Ctrl+E: Open In MS Excel", bg="#DCDCDC", fg="black", font=("Tahoma", 8), padx=4, pady=2, relief="flat", cursor="hand2", command=self.not_implemented)
        btn_excel.pack(side="left", padx=2)
        
        btn_pdf = tk.Button(tb, text="📄 Ctrl+V: Open In PDF", bg="white", fg="black", font=("Tahoma", 8), padx=4, pady=2, relief="flat", cursor="hand2", command=self.not_implemented)
        btn_pdf.pack(side="left", padx=2)
        
        btn_browser = tk.Button(tb, text="🌐 Ctrl+H: Open In Browser", bg="black", fg="white", font=("Tahoma", 8, "bold"), padx=4, pady=2, relief="flat", cursor="hand2", command=self.not_implemented)
        btn_browser.pack(side="left", padx=2)
        
        tk.Frame(self, bg="#bbb", height=1).pack(fill="x")
        
        # Header
        self.header_f = tk.Frame(self, bg=WHITE)
        self.header_f.pack(fill="x", padx=20, pady=(20, 10))
        
        lbl_co = tk.Label(self.header_f, text="ALHUMDULILLAH", font=FONT_BOLD, bg=WHITE, fg=BG_DARK)
        lbl_co.pack(anchor="w")
        
        lbl_report = tk.Label(self.header_f, text="Monthly Breakdown", font=TITLE_FONT, bg=WHITE, fg="black")
        lbl_report.pack(anchor="w")
        
        lbl_date_range = tk.Label(self.header_f, text=f"{self.start_d} To {self.end_d}", font=FONT, bg=WHITE, fg=DARK_GRAY)
        lbl_date_range.pack(anchor="w")
        
        # Treeview container
        self.tree_f = tk.Frame(self, bg=WHITE)
        self.tree_f.pack(fill="both", expand=True, padx=20, pady=10)
        
    def format_money(self, val):
        if val is None or val == 0:
            return "0"
        return f"{val:,.0f}"

    def build_treeview(self, months):
        for widget in self.tree_f.winfo_children():
            widget.destroy()
            
        month_labels = [datetime.datetime.strptime(m, "%Y-%m").strftime("%b'%Y").upper() for m in months]
        
        cols = ["ACCOUNT"] + month_labels + ["TOTAL", "AVERAGE"]
                
        self.tree = ttk.Treeview(self.tree_f, columns=cols, show="headings", height=20, selectmode="none")
        
        self.tree.heading("ACCOUNT", text="")
        self.tree.column("ACCOUNT", width=250, minwidth=250, anchor="w", stretch=False)
        
        for c in cols[1:]:
            self.tree.heading(c, text=c)
            self.tree.column(c, width=100, minwidth=100, anchor="e", stretch=False)
            
        def disable_resize(event):
            if self.tree.identify_region(event.x, event.y) == "separator":
                return "break"
        self.tree.bind('<Button-1>', disable_resize)
        self.tree.bind('<B1-Motion>', disable_resize)
        style = ttk.Style()
        style.configure("Treeview", font=ACCOUNT_FONT, rowheight=35)
        style.configure("Treeview.Heading", font=FONT_BOLD)
        
        self.tree.tag_configure("category", font=CATEGORY_FONT, background="#f0f0f0")
        self.tree.tag_configure("group", font=GROUP_FONT, background="#fafafa")
        self.tree.tag_configure("account", font=ACCOUNT_FONT)
        
        ysb = ttk.Scrollbar(self.tree_f, orient="vertical", command=self.tree.yview)
        xsb = ttk.Scrollbar(self.tree_f, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscroll=ysb.set, xscroll=xsb.set)
        
        ysb.pack(side="right", fill="y")
        xsb.pack(side="bottom", fill="x")
        self.tree.pack(fill="both", expand=True)

    def load_data(self):
        try:
            res = db.get_monthly_breakdown_data(self.start_d, self.end_d)
            months = res["months"]
            data = res["data"]
        except Exception as e:
            messagebox.showerror("Error", f"Failed to fetch data:\n{e}")
            return
            
        self.build_treeview(months)
        
        for category in ["INCOME", "EXPENSE"]:
            # Category Header
            cat_vals = [category] + [""] * (len(months) + 2)
            self.tree.insert("", "end", values=cat_vals, tags=("category",))
            
            for group_name, accounts in data[category].items():
                # Group Header (Calculate group totals)
                grp_totals = {m: sum([acc["months"][m] for acc in accounts]) for m in months}
                grp_grand_tot = sum(grp_totals.values())
                grp_avg = grp_grand_tot / len(months) if months else 0
                
                grp_vals = [group_name]
                for m in months:
                    grp_vals.append(self.format_money(grp_totals[m]))
                grp_vals.append(self.format_money(grp_grand_tot))
                grp_vals.append(self.format_money(grp_avg))
                
                self.tree.insert("", "end", values=grp_vals, tags=("group",))
                
                # Accounts Rows
                for acc in accounts:
                    acc_tot = sum(acc["months"].values())
                    acc_avg = acc_tot / len(months) if months else 0
                    
                    acc_vals = [f"    {acc['account']}"]
                    for m in months:
                        acc_vals.append(self.format_money(acc["months"][m]))
                    acc_vals.append(self.format_money(acc_tot))
                    acc_vals.append(self.format_money(acc_avg))
                    
                    self.tree.insert("", "end", values=acc_vals, tags=("account",))

if __name__ == "__main__":
    root = tk.Tk()
    root.withdraw()
    app = ReportMonthlyBreakdown(root)
    root.mainloop()
