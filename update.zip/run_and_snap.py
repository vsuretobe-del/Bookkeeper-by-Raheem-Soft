import subprocess
import time

p = subprocess.Popen(['python', 'bookkeeper.py'])
time.sleep(3)

# take screenshot
import os
os.system('''powershell -Command "Add-Type -AssemblyName System.Windows.Forms; Add-Type -AssemblyName System.Drawing; $Screen = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds; $Bitmap = New-Object System.Drawing.Bitmap $Screen.Width, $Screen.Height; $Graphics = [System.Drawing.Graphics]::FromImage($Bitmap); $Graphics.CopyFromScreen($Screen.X, $Screen.Y, 0, 0, $Bitmap.Size); $Bitmap.Save('C:\\Users\\hk546\\Downloads\\Book Keeper\\screenshot.png', [System.Drawing.Imaging.ImageFormat]::Png); $Graphics.Dispose(); $Bitmap.Dispose()"''')

time.sleep(1)
p.kill()
