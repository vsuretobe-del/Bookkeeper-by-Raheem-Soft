import tkinter as tk
from tkinter import ttk, messagebox
import db
import datetime
import calendar
from custom_calendar import DateEntry
from autocomplete import AutocompleteCombobox

BG_DARK = "#2B579A"
WHITE = "#FFFFFF"
GRAY = "#E0E0E0"
DARK_GRAY = "#666666"

FONT = ("Segoe UI", 10)
FONT_BOLD = ("Segoe UI", 10, "bold")
TITLE_FONT = ("Segoe UI", 14, "bold")
ITEM_FONT = ("Segoe UI", 10)
SUB_HEADER_FONT = ("Segoe UI", 9, "bold")
SUB_ROW_FONT = ("Segoe UI", 9)

class ReportPurchaseRegister(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent, bg=WHITE)
        self.title("Purchase Register")
        self.state("zoomed")
        self.geometry("1024x768")
        
        self.chk_vars = {
            'tax_no': tk.BooleanVar(value=False),
            'quantity': tk.BooleanVar(value=True),
            'item_details': tk.BooleanVar(value=False)
        }
        
        self.build_ui()
        self.load_data()
        
    def not_implemented(self, event=None):
        messagebox.showinfo("Coming Soon", "This feature is not implemented yet.")

    def build_ui(self):
        # Toolbar
        tb = tk.Frame(self, bg=WHITE)
        tb.pack(fill="x", padx=10, pady=5)
        
        btn_exit = tk.Button(tb, text="✖ Ctrl+Q: Exit", bg="black", fg="white", font=("Tahoma", 8, "bold"), padx=4, pady=2, relief="flat", cursor="hand2", command=self.destroy)
        btn_exit.pack(side="left", padx=2)
        
        btn_print = tk.Button(tb, text="🖨 Alt+P: Print", bg="white", fg="black", font=("Tahoma", 8), padx=4, pady=2, relief="flat", cursor="hand2", command=self.not_implemented)
        btn_print.pack(side="left", padx=2)
        
        btn_word = tk.Button(tb, text="📄 Ctrl+W: Open In MS Word", bg="#DCDCDC", fg="black", font=("Tahoma", 8), padx=4, pady=2, relief="flat", cursor="hand2", command=self.not_implemented)
        btn_word.pack(side="left", padx=2)
        
        btn_excel = tk.Button(tb, text="📊 Ctrl+E: Open In MS Excel", bg="#DCDCDC", fg="black", font=("Tahoma", 8), padx=4, pady=2, relief="flat", cursor="hand2", command=self.not_implemented)
        btn_excel.pack(side="left", padx=2)
        
        btn_pdf = tk.Button(tb, text="📄 Ctrl+V: Open In PDF", bg="white", fg="black", font=("Tahoma", 8), padx=4, pady=2, relief="flat", cursor="hand2", command=self.not_implemented)
        btn_pdf.pack(side="left", padx=2)
        
        btn_browser = tk.Button(tb, text="🌐 Ctrl+H: Open In Browser", bg="black", fg="white", font=("Tahoma", 8, "bold"), padx=4, pady=2, relief="flat", cursor="hand2", command=self.not_implemented)
        btn_browser.pack(side="left", padx=2)
        
        tk.Frame(self, bg="#bbb", height=1).pack(fill="x")
        
        # Left and Right panels
        self.left_panel = tk.Frame(self, bg=BG_DARK, width=280)
        self.left_panel.pack(side="left", fill="y")
        self.left_panel.pack_propagate(False)
        
        self.right_panel = tk.Frame(self, bg=WHITE)
        self.right_panel.pack(side="right", fill="both", expand=True)
        
        self.build_left_panel()
        self.build_right_panel()

    def build_left_panel(self):
        canvas = tk.Canvas(self.left_panel, bg=BG_DARK, highlightthickness=0)
        scrollbar = ttk.Scrollbar(self.left_panel, orient="vertical", command=canvas.yview)
        
        self.f = tk.Frame(canvas, bg=BG_DARK)
        self.f.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=self.f, anchor="nw", width=260)
        canvas.configure(yscrollcommand=scrollbar.set)
        
        def _on_mousewheel(event):
            canvas.yview_scroll(int(-1*(event.delta/120)), "units")
        canvas.bind_all("<MouseWheel>", _on_mousewheel)
        
        scrollbar.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True, padx=(10,0), pady=10)
        
        today = datetime.date.today()
        start_d = datetime.date(today.year if today.month >= 4 else today.year - 1, 4, 1)
        
        # Dates
        tk.Label(self.f, text="F2: Start Date:", bg=BG_DARK, fg=WHITE, font=FONT).pack(anchor="w", pady=(10,0))
        self.start_dp = DateEntry(self.f)
        self.start_dp.set_date(start_d)
        self.start_dp.pack(fill="x", pady=2)
        
        tk.Label(self.f, text="End date:", bg=BG_DARK, fg=WHITE, font=FONT).pack(anchor="w", pady=(10,0))
        self.end_dp = DateEntry(self.f)
        self.end_dp.set_date(today)
        self.end_dp.pack(fill="x", pady=2)
        
        # Account Name Listbox (mimicked with Combobox)
        tk.Label(self.f, text="F9: Account Name:", bg=BG_DARK, fg=WHITE, font=FONT).pack(anchor="w", pady=(10,0))
        
        self.cb_account = AutocompleteCombobox(self.f, font=FONT, state="readonly")
        try:
            conn = db.get_conn()
            acts = conn.execute("SELECT aname as account_name FROM account_detail ORDER BY account_name").fetchall()
            conn.close()
            act_list = ["ALL"] + [a['account_name'] for a in acts]
            self.cb_account['values'] = act_list
        except:
            self.cb_account['values'] = ["ALL"]
        
        self.cb_account.set("ALL")
        self.cb_account.pack(fill="x", pady=2)
        
        # Checkboxes
        checks = [
            ("Display Tax No", 'tax_no'),
            ("Display Quantity", 'quantity'),
            ("Display Item Details\n(may take long time)", 'item_details')
        ]
        
        for text, key in checks:
            cb = tk.Checkbutton(self.f, text=text, variable=self.chk_vars[key],
                                bg=BG_DARK, fg=WHITE, selectcolor=BG_DARK, 
                                activebackground=BG_DARK, activeforeground=WHITE, font=FONT,
                                justify="left")
            cb.pack(anchor="w", pady=2)
            
        btn_display = tk.Button(self.f, text="Display", bg="#2B579A", fg="white", 
                                font=FONT, relief="sunken", bd=1, command=self.load_data)
        btn_display.pack(fill="x", pady=20)

    def build_right_panel(self):
        # Header
        self.header_f = tk.Frame(self.right_panel, bg=WHITE)
        self.header_f.pack(fill="x", padx=20, pady=(20, 10))
        
        lbl_co = tk.Label(self.header_f, text="ALHUMDULILLAH", font=FONT_BOLD, bg=WHITE, fg=BG_DARK)
        lbl_co.pack(anchor="w")
        
        lbl_report = tk.Label(self.header_f, text="PURCHASE REGISTER", font=TITLE_FONT, bg=WHITE, fg="black")
        lbl_report.pack(anchor="w")
        
        self.lbl_date_range = tk.Label(self.header_f, text="", font=FONT, bg=WHITE, fg=DARK_GRAY)
        self.lbl_date_range.pack(anchor="w")
        
        # Treeview container
        self.tree_f = tk.Frame(self.right_panel, bg=WHITE)
        self.tree_f.pack(fill="both", expand=True, padx=20, pady=10)
        
    def build_treeview(self):
        for widget in self.tree_f.winfo_children():
            widget.destroy()
            
        cols = ["VOUCHER DATE", "PARTICULARS", "VCH NO.", "SUPPLIER INVOICE NO", 
                "QUANTITY", "TAX AMOUNT", "VOUCHER VALUE", "NARRATION"]
                
        self.tree = ttk.Treeview(self.tree_f, columns=cols, show="headings", height=20, selectmode="none")
        
        widths = {
            "VOUCHER DATE": 140, "PARTICULARS": 210, "VCH NO.": 112, "SUPPLIER INVOICE NO": 210,
            "QUANTITY": 112, "TAX AMOUNT": 140, "VOUCHER VALUE": 168, "NARRATION": 280
        }
        
        for c in cols:
            self.tree.heading(c, text=c)
            anchor = "e" if c in ["QUANTITY", "TAX AMOUNT", "VOUCHER VALUE"] else "w"
            self.tree.column(c, width=widths.get(c, 100), anchor=anchor)
            
        def disable_resize(event):
            if self.tree.identify_region(event.x, event.y) == "separator":
                return "break"
        self.tree.bind('<Button-1>', disable_resize)
        self.tree.bind('<B1-Motion>', disable_resize)
        style = ttk.Style()
        style.configure("Treeview", font=FONT, rowheight=35)
        style.configure("Treeview.Heading", font=FONT_BOLD)
        
        self.tree.tag_configure("item", font=ITEM_FONT)
        self.tree.tag_configure("grand", font=FONT_BOLD, background="#f0f0f0")
        
        # Tags for sub-table
        self.tree.tag_configure("sub_header", font=SUB_HEADER_FONT, background="#e8e8e8", foreground="#333333")
        self.tree.tag_configure("sub_row", font=SUB_ROW_FONT)
        
        ysb = ttk.Scrollbar(self.tree_f, orient="vertical", command=self.tree.yview)
        xsb = ttk.Scrollbar(self.tree_f, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscroll=ysb.set, xscroll=xsb.set)
        
        ysb.pack(side="right", fill="y")
        xsb.pack(side="bottom", fill="x")
        self.tree.pack(fill="both", expand=True)

    def format_money(self, val):
        if val is None or val == 0:
            return "0"
        return f"{val:,.0f}"
        
    def format_qty(self, val):
        if val is None or val == 0:
            return ""
        return f"{val:g}"

    def load_data(self):
        self.build_treeview()
        
        s_date = self.start_dp.get_date().strftime("%Y-%m-%d")
        e_date = self.end_dp.get_date().strftime("%Y-%m-%d")
        acc = self.cb_account.get()
        fetch_items = self.chk_vars['item_details'].get()
        
        self.lbl_date_range.config(text=f"{s_date} TO {e_date}")
        
        try:
            data = db.get_purchase_register_data(s_date, e_date, acc, fetch_items=fetch_items)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to fetch data:\n{e}")
            return
            
        tot_qty = 0
        tot_tax = 0
        tot_val = 0
        
        for row in data:
            v_date = row['date']
            part = row['particulars']
            vchno = row['vchno']
            sup_inv = row['supplier_inv_no']
            
            qty = row['quantity']
            tax = row['tax']
            val = row['voucher_value']
            nar = row['narration']
            
            tot_qty += qty
            tot_tax += tax
            tot_val += val
            
            # Main row
            self.tree.insert("", "end", values=(
                v_date, part, vchno, sup_inv,
                self.format_qty(qty), self.format_money(tax), self.format_money(val), nar
            ), tags=("item"))
            
            # Sub-table
            if fetch_items and row['items']:
                # Sub Header
                self.tree.insert("", "end", values=(
                    "", "    ITEM/SERVICE", "", "    QUANTITY", "    RATE", "    DESCRIPTION", "", ""
                ), tags=("sub_header"))
                
                # Sub rows
                for itm in row['items']:
                    self.tree.insert("", "end", values=(
                        "", f"    {itm['item']}", "", f"    {self.format_qty(itm['qty'])}", f"    {self.format_money(itm['rate'])}", f"    {itm['desc']}", "", ""
                    ), tags=("sub_row"))
                    
                # Add a blank line for spacing
                self.tree.insert("", "end", values=("", "", "", "", "", "", "", ""), tags=("sub_row"))
            
        self.tree.insert("", "end", values=(
            f"TOTAL ( {len(data)} TRANSACTIONS )", "", "", "",
            self.format_qty(tot_qty), f"Rs{self.format_money(tot_tax)}", f"Rs{self.format_money(tot_val)}", ""
        ), tags=("grand"))

if __name__ == "__main__":
    root = tk.Tk()
    root.withdraw()
    app = ReportPurchaseRegister(root)
    root.mainloop()
