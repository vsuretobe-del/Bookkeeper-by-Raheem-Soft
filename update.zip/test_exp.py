import sqlite3
conn = sqlite3.connect('bookkeeper.db')
conn.row_factory = sqlite3.Row
rows = conn.execute("SELECT * FROM vouchers WHERE v_type='expense'").fetchall()
if not rows:
    print('No expense vouchers found.')
else:
    for r in rows:
        print(dict(r))
        va_rows = conn.execute("SELECT * FROM vouchers_all WHERE v_id=?", (r['v_id'],)).fetchall()
        print('  vouchers_all:', [dict(va) for va in va_rows])
