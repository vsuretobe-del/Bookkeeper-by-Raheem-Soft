import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import os
import datetime

WHITE = "#ffffff"
BG = "#f2f2f2"
BLUE_SEL = "#0078d7"
FONT = ("Segoe UI", 10)
FONT_BOLD = ("Segoe UI", 10, "bold")


def check_pwd_and_login(app_ref, filepath, from_startup=True):
    import os, sqlite3
    import db
    from tkinter import messagebox
    import tkinter as tk
    
    if not os.path.exists(filepath):
        if from_startup:
            app_ref.show_standalone_selection()
        else:
            messagebox.showerror("Error", "File not found!")
        return

    # Check if database requires password
    enable_pwd = "0"
    admin_pwd = ""
    admin_user = ""
    try:
        conn = sqlite3.connect(os.path.abspath(filepath))
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        s_rows = c.execute(
            "SELECT key, value FROM app_settings WHERE key IN ('company_enable_pwd', 'company_username', 'company_password')"
        ).fetchall()
        settings = {r['key']: str(r['value'] or '') for r in s_rows}
        enable_pwd = settings.get('company_enable_pwd', '0')
        admin_user = settings.get('company_username', '')
        admin_pwd = settings.get('company_password', '')
        conn.close()
    except Exception:
        pass

    if enable_pwd != "1" or not admin_pwd:
        app_ref.current_user = None
        app_ref.load_company(filepath)
        app_ref.deiconify()
        return

    # Show floating login
    login_win = tk.Toplevel(app_ref)
    login_win.title("Company Login")
    login_win.geometry("450x240")
    login_win.configure(bg="#F0F0F0")
    
    login_win.update_idletasks()
    w = login_win.winfo_width()
    h = login_win.winfo_height()
    x = max(0, (login_win.winfo_screenwidth() // 2) - (w // 2))
    y = max(0, (login_win.winfo_screenheight() // 2) - (h // 2))
    login_win.geometry(f"+{x}+{y}")
    login_win.grab_set()

    fr = tk.Frame(login_win, bg="#F0F0F0")
    fr.pack(pady=25)

    tk.Label(fr, text="User Name:", bg="#F0F0F0", font=("Segoe UI", 10, "bold")).grid(row=0, column=0, sticky="e", pady=6, padx=6)
    txt_user = tk.Entry(fr, font=("Segoe UI", 10), width=25)
    txt_user.grid(row=0, column=1, pady=6, padx=6)
    if admin_user:
        txt_user.insert(0, admin_user)

    tk.Label(fr, text="Password:", bg="#F0F0F0", font=("Segoe UI", 10, "bold")).grid(row=1, column=0, sticky="e", pady=6, padx=6)
    pass_fr = tk.Frame(fr, bg="#F0F0F0")
    pass_fr.grid(row=1, column=1, pady=6, padx=6, sticky="w")
    
    txt_pass = tk.Entry(pass_fr, show="*", font=("Segoe UI", 10), width=20)
    txt_pass.pack(side="left")

    show_pwd_var = tk.BooleanVar(value=False)
    def toggle_pwd():
        txt_pass.config(show="" if show_pwd_var.get() else "*")
    chk_show = tk.Checkbutton(pass_fr, text="Show", variable=show_pwd_var, command=toggle_pwd, bg="#F0F0F0", font=("Segoe UI", 8))
    chk_show.pack(side="left", padx=4)

    def attempt_login(event=None):
        u = txt_user.get().strip()
        p = txt_pass.get().strip()
        
        ok, user_data, err = db.authenticate_user(filepath, u, p)
        if ok:
            try:
                login_win.grab_release()
            except Exception:
                pass
            login_win.destroy()
            app_ref.current_user = user_data
            app_ref.load_company(filepath)
            app_ref.deiconify()
            return
        else:
            messagebox.showerror("Error", err or "Invalid username or password", parent=login_win)
            txt_pass.delete(0, "end")
            txt_pass.focus_set()

    def exit_login(event=None):
        try:
            login_win.grab_release()
        except Exception:
            pass
        login_win.destroy()
        if from_startup:
            app_ref.show_standalone_selection()

    bot_bar = tk.Frame(login_win, bg="#F0F0F0")
    bot_bar.pack(side="bottom", fill="x", padx=15, pady=12)
    
    btn_exit = tk.Button(bot_bar, text="Ctrl+Q: Exit", font=("Segoe UI", 10), command=exit_login, bg="#e0e0e0", relief="groove")
    btn_exit.pack(side="left")
    
    btn_login = tk.Button(bot_bar, text="Enter: Login", font=("Segoe UI", 10, "bold"), command=attempt_login, bg="#32cd32", fg="white", relief="raised", padx=15)
    btn_login.pack(side="right")
    
    txt_user.bind("<Return>", lambda e: (txt_pass.focus_set(), "break")[1])
    txt_pass.bind("<Return>", attempt_login)
    login_win.bind("<Control-q>", exit_login)
    login_win.bind("<Control-Q>", exit_login)
    login_win.bind("<Escape>", exit_login)
    login_win.protocol("WM_DELETE_WINDOW", exit_login)
    
    if txt_user.get():
        txt_pass.focus_set()
    else:
        txt_user.focus_set()


class CompanySelectionView(tk.Frame):

    def __init__(self, master, app_ref):
        super().__init__(master, bg=BG)
        self.app_ref = app_ref
        self.current_tab = "local"
        
        self.pack(fill="both", expand=True)
        
        user_home = os.path.expanduser("~")
        self.search_dirs = [
            r"C:\Users\hk546\OneDrive\Desktop",
            os.path.join(user_home, "Desktop"),
            os.path.join(user_home, "OneDrive", "Desktop"),
            os.getcwd()
        ]
        
        self.setup_ui()
        self.load_companies()
        
    def setup_ui(self):
        # 1. Top Title Frame
        title_fr = tk.Frame(self, bg=WHITE, relief="solid", bd=1)
        title_fr.pack(side="top", fill="x", padx=10, pady=(10, 0))
        tk.Label(
            title_fr,
            text="Open Company From Dropbox",
            bg=WHITE,
            fg="#222222",
            font=("Segoe UI", 9)
        ).pack(side="left", padx=6, pady=3)
        
        # 2. Tabs Container Frame
        tabs_fr = tk.Frame(self, bg=WHITE)
        tabs_fr.pack(side="top", fill="x", padx=10)
        
        self.btn_local = tk.Button(
            tabs_fr,
            text="Local Companies",
            font=("Segoe UI", 11, "underline bold"),
            fg="#111111",
            bg=WHITE,
            activebackground=WHITE,
            activeforeground="#111111",
            relief="flat",
            bd=0,
            cursor="hand2",
            command=lambda: self.switch_tab("local")
        )
        self.btn_local.pack(side="left", padx=(5, 10), pady=6)
        
        self.btn_dropbox = tk.Button(
            tabs_fr,
            text="Companies On Dropbox",
            font=("Segoe UI", 11),
            fg="#444444",
            bg=WHITE,
            activebackground=WHITE,
            activeforeground="#111111",
            relief="flat",
            bd=0,
            cursor="hand2",
            command=lambda: self.switch_tab("dropbox")
        )
        self.btn_dropbox.pack(side="left", padx=10, pady=6)
        
        self.btn_bkweb = tk.Button(
            tabs_fr,
            text="Companies On BKWeb",
            font=("Segoe UI", 11),
            fg="#444444",
            bg=WHITE,
            activebackground=WHITE,
            activeforeground="#111111",
            relief="flat",
            bd=0,
            cursor="hand2",
            command=lambda: self.switch_tab("bkweb")
        )
        self.btn_bkweb.pack(side="left", padx=10, pady=6)
        
        # 3. Bottom Action Bar (PACKED AT BOTTOM FIRST TO PREVENT CLIPPING)
        bot_bar = tk.Frame(self, bg=BG)
        bot_bar.pack(side="bottom", fill="x", padx=10, pady=10)
        
        btn_exit = tk.Button(
            bot_bar,
            text="✖  Ctrl+Q: Exit",
            font=FONT,
            bg="#e74c3c",
            fg="white",
            activebackground="#c0392b",
            activeforeground="white",
            relief="raised",
            bd=1,
            padx=12,
            pady=4,
            cursor="hand2",
            command=self.on_exit
        )
        btn_exit.pack(side="left", padx=(0, 6))
        
        btn_browse = tk.Button(
            bot_bar,
            text="📁  Browse",
            font=FONT,
            bg="#e6e6e6",
            fg="#111111",
            activebackground="#d5d5d5",
            relief="raised",
            bd=1,
            padx=12,
            pady=4,
            cursor="hand2",
            command=self.on_browse
        )
        btn_browse.pack(side="left", padx=6)
        
        btn_new = tk.Button(
            bot_bar,
            text="➕ New Company",
            font=FONT_BOLD,
            bg="#27ae60",
            fg="white",
            activebackground="#219150",
            activeforeground="white",
            relief="raised",
            bd=1,
            padx=12,
            pady=4,
            cursor="hand2",
            command=lambda: self.app_ref.open_company_settings(is_new=True, parent_win=self.winfo_toplevel())
        )
        btn_new.pack(side="left", padx=6)
        
        btn_open = tk.Button(
            bot_bar,
            text="🖥️  Enter: Open",
            font=FONT,
            bg="#e6e6e6",
            fg="#111111",
            activebackground="#d5d5d5",
            relief="raised",
            bd=1,
            padx=12,
            pady=4,
            cursor="hand2",
            command=self.on_open
        )
        btn_open.pack(side="left", padx=6)
        
        # 4. Central Grid Frame (Fills remaining space cleanly)
        grid_fr = tk.Frame(
            self,
            bg=WHITE,
            relief="solid",
            bd=1,
            highlightbackground="#c69214",
            highlightthickness=2
        )
        grid_fr.pack(side="top", fill="both", expand=True, padx=10, pady=(0, 10))
        
        # Style treeview
        style = ttk.Style()
        style.configure("CompanySel.Treeview", font=FONT, rowheight=26, background=WHITE, fieldbackground=WHITE)
        style.configure("CompanySel.Treeview.Heading", font=FONT_BOLD, background="#e6e6e6", relief="raised")
        style.map("CompanySel.Treeview",
            background=[("selected", "#0078d7")],
            foreground=[("selected", "white")]
        )
        
        cols = ("File Name", "Date Modified", "File Size")
        self.tree = ttk.Treeview(
            grid_fr,
            columns=cols,
            show="headings",
            style="CompanySel.Treeview",
            selectmode="browse"
        )
        
        self.tree.heading("File Name", text="File Name", anchor="w")
        self.tree.heading("Date Modified", text="Date Modified", anchor="w")
        self.tree.heading("File Size", text="File Size", anchor="w")
        
        self.tree.column("File Name", width=340, minwidth=200, anchor="w")
        self.tree.column("Date Modified", width=220, minwidth=140, anchor="w")
        self.tree.column("File Size", width=140, minwidth=80, anchor="w")
        
        scroll_y = ttk.Scrollbar(grid_fr, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll_y.set)
        
        self.tree.pack(side="left", fill="both", expand=True, padx=(2, 0), pady=2)
        scroll_y.pack(side="right", fill="y", pady=2, padx=(0, 2))
        
        self.tree.bind("<Double-1>", self.on_open)
        self.tree.bind("<Return>", self.on_open)
        
        # Bind keyboard shortcuts
        toplevel = self.winfo_toplevel()
        toplevel.bind("<Control-q>", lambda e: self.on_exit())
        toplevel.bind("<Control-Q>", lambda e: self.on_exit())
        toplevel.bind("<Escape>", lambda e: self.on_exit())
        toplevel.bind("<Control-n>", lambda e: self.app_ref.open_company_settings(is_new=True, parent_win=self.winfo_toplevel()))
        toplevel.bind("<Control-N>", lambda e: self.app_ref.open_company_settings(is_new=True, parent_win=self.winfo_toplevel()))
        toplevel.bind("<Control-o>", lambda e: self.on_browse())
        toplevel.bind("<Control-O>", lambda e: self.on_browse())

    def switch_tab(self, tab_name):
        self.current_tab = tab_name
        if tab_name == "local":
            self.btn_local.config(font=("Segoe UI", 11, "underline bold"), fg="#111111")
            self.btn_dropbox.config(font=("Segoe UI", 11), fg="#555555")
            self.btn_bkweb.config(font=("Segoe UI", 11), fg="#555555")
            self.load_companies()
        elif tab_name == "dropbox":
            self.btn_local.config(font=("Segoe UI", 11), fg="#555555")
            self.btn_dropbox.config(font=("Segoe UI", 11, "underline bold"), fg="#111111")
            self.btn_bkweb.config(font=("Segoe UI", 11), fg="#555555")
            self.load_dropbox_companies()
        elif tab_name == "bkweb":
            self.btn_local.config(font=("Segoe UI", 11), fg="#555555")
            self.btn_dropbox.config(font=("Segoe UI", 11), fg="#555555")
            self.btn_bkweb.config(font=("Segoe UI", 11, "underline bold"), fg="#111111")
            self.load_bkweb_companies()

    def load_companies(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
            
        found_files = {}
        for d in self.search_dirs:
            if os.path.exists(d):
                try:
                    for f in os.listdir(d):
                        if f.endswith(".db") and not f.startswith("._") and f not in found_files:
                            path = os.path.join(d, f)
                            if os.path.isfile(path):
                                stat = os.stat(path)
                                dt = datetime.datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %I:%M %p")
                                size = f"{max(1, stat.st_size // 1024)}KB"
                                found_files[f] = (path, dt, size, stat.st_mtime)
                except Exception:
                    pass
                    
        sorted_files = sorted(found_files.items(), key=lambda x: x[0].lower())
        
        first_id = None
        for filename, (path, dt, size, _) in sorted_files:
            item_id = self.tree.insert("", "end", values=(filename, dt, size), tags=(path,))
            if first_id is None:
                first_id = item_id
                
        if first_id:
            self.tree.selection_set(first_id)
            self.tree.focus(first_id)

    def load_dropbox_companies(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
            
        user_home = os.path.expanduser("~")
        dropbox_dirs = [
            os.path.join(user_home, "Dropbox"),
            os.path.join(user_home, "Dropbox", "Book Keeper"),
            r"C:\Users\hk546\Dropbox"
        ]
        found = False
        for d in dropbox_dirs:
            if os.path.exists(d):
                try:
                    for f in os.listdir(d):
                        if f.endswith(".db") and not f.startswith("._"):
                            path = os.path.join(d, f)
                            if os.path.isfile(path):
                                stat = os.stat(path)
                                dt = datetime.datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %I:%M %p")
                                size = f"{max(1, stat.st_size // 1024)}KB"
                                self.tree.insert("", "end", values=(f, dt, size), tags=(path,))
                                found = True
                except Exception:
                    pass
        if not found:
            # If no special dropbox folder, show local companies
            self.load_companies()

    def load_bkweb_companies(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        messagebox.showinfo("BKWeb", "No cloud companies found on BKWeb.", parent=self.winfo_toplevel())
        self.switch_tab("local")

    def on_exit(self):
        top = self.winfo_toplevel()
        if top != self.app_ref:
            top.destroy()
        if not getattr(self.app_ref, "active_company_path", None):
            self.app_ref.destroy()

    def on_browse(self):
        initial = self.search_dirs[0] if os.path.exists(self.search_dirs[0]) else os.getcwd()
        filepath = filedialog.askopenfilename(
            title="Open Company Database",
            filetypes=(("Book Keeper DB", "*.db"), ("All Files", "*.*")),
            initialdir=initial,
            parent=self.winfo_toplevel()
        )
        if filepath:
            self.open_company(filepath)
            
    def on_open(self, event=None):
        selected = self.tree.selection()
        if not selected:
            messagebox.showerror("Error", "Please select a company to open.", parent=self.winfo_toplevel())
            return
        
        item_tags = self.tree.item(selected[0], "tags")
        if item_tags and os.path.exists(item_tags[0]):
            self.open_company(item_tags[0])
        else:
            item_vals = self.tree.item(selected[0], "values")
            if item_vals:
                filename = item_vals[0]
                for d in self.search_dirs:
                    p = os.path.join(d, filename)
                    if os.path.exists(p):
                        self.open_company(p)
                        return

    def open_company(self, filepath):
        if not os.path.exists(filepath):
            messagebox.showerror("Error", "File not found!", parent=self.winfo_toplevel())
            return
            
        # Check if db requires auth
        import sqlite3, db
        try:
            conn = sqlite3.connect(os.path.abspath(filepath))
            conn.row_factory = sqlite3.Row
            c = conn.cursor()
            
            enable_pwd = "0"
            username = ""
            password = ""
            
            try:
                res = c.execute("SELECT key, value FROM app_settings WHERE key IN ('company_enable_pwd', 'company_username', 'company_password')").fetchall()
                for r in res:
                    k, v = r['key'], r['value']
                    if k == "company_enable_pwd": enable_pwd = str(v or "")
                    elif k == "company_username": username = str(v or "")
                    elif k == "company_password": password = str(v or "")
            except sqlite3.OperationalError:
                pass
                
            conn.close()
            
            if str(enable_pwd) == "1" and password:
                self.show_login_dialog(filepath, username, password)
            else:
                top = self.winfo_toplevel()
                if top != self.app_ref:
                    top.destroy()
                self.app_ref.current_user = None
                self.app_ref.load_company(filepath)
                self.app_ref.deiconify()
        except Exception as e:
            messagebox.showerror("Error", f"Could not read database: {e}", parent=self.winfo_toplevel())

    def show_login_dialog(self, filepath, correct_user, correct_pass):
        import db
        login_win = tk.Toplevel(self)
        login_win.title("Login")
        login_win.geometry("420x240")
        login_win.configure(bg=WHITE)
        login_win.grab_set()
        
        # Center the window
        login_win.update_idletasks()
        w = login_win.winfo_width()
        h = login_win.winfo_height()
        x = max(0, (login_win.winfo_screenwidth() // 2) - (w // 2))
        y = max(0, (login_win.winfo_screenheight() // 2) - (h // 2))
        login_win.geometry(f"+{x}+{y}")
        
        tk.Label(login_win, text="Company is password protected", bg=WHITE, font=FONT_BOLD).pack(pady=(12, 5))
        
        fr = tk.Frame(login_win, bg=WHITE)
        fr.pack(pady=10)
        
        tk.Label(fr, text="User Name:", bg=WHITE, font=FONT).grid(row=0, column=0, sticky="e", pady=5, padx=5)
        txt_user = tk.Entry(fr, font=FONT, width=22, relief="solid", bd=1)
        txt_user.grid(row=0, column=1, pady=5, padx=5, sticky="w")
        txt_user.focus_set()
        
        tk.Label(fr, text="Password:", bg=WHITE, font=FONT).grid(row=1, column=0, sticky="e", pady=5, padx=5)
        pass_fr = tk.Frame(fr, bg=WHITE)
        pass_fr.grid(row=1, column=1, pady=5, padx=5, sticky="w")
        
        txt_pass = tk.Entry(pass_fr, show="*", font=FONT, width=17, relief="solid", bd=1)
        txt_pass.pack(side="left")
        
        show_pwd_var = tk.BooleanVar(value=False)
        def toggle_pwd():
            txt_pass.config(show="" if show_pwd_var.get() else "*")
        chk_show = tk.Checkbutton(pass_fr, text="Show", variable=show_pwd_var, command=toggle_pwd, bg=WHITE, font=("Segoe UI", 8))
        chk_show.pack(side="left", padx=4)
        
        def attempt_login(event=None):
            u = txt_user.get().strip()
            p = txt_pass.get().strip()
            
            ok, user_data, err = db.authenticate_user(filepath, u, p)
            if ok:
                app = getattr(self, 'app_ref', None)
                if not app:
                    app = self
                try:
                    login_win.grab_release()
                except Exception:
                    pass
                login_win.destroy()
                
                top = self.winfo_toplevel()
                if top != app:
                    top.destroy()
                    
                app.current_user = user_data
                app.load_company(filepath)
                app.deiconify()
                return
            else:
                messagebox.showerror("Error", err or "Invalid username or password", parent=login_win)
                txt_pass.delete(0, "end")
                txt_pass.focus_set()
                
        def close_dialog(event=None):
            try:
                login_win.grab_release()
            except Exception:
                pass
            login_win.destroy()

        bot = tk.Frame(login_win, bg=WHITE)
        bot.pack(fill="x", pady=10, padx=20)
        
        tk.Button(bot, text="Cancel", font=FONT, command=close_dialog, bg="#e0e0e0", relief="raised", padx=10).pack(side="left")
        tk.Button(bot, text="Login", bg="#32cd32", fg="white", font=FONT_BOLD, command=attempt_login, relief="raised", padx=15).pack(side="right")
        
        txt_user.bind("<Return>", lambda e: (txt_pass.focus_set(), "break")[1])
        txt_pass.bind("<Return>", attempt_login)
        login_win.bind("<Control-q>", close_dialog)
        login_win.bind("<Control-Q>", close_dialog)
        login_win.bind("<Escape>", close_dialog)
        login_win.protocol("WM_DELETE_WINDOW", close_dialog)
