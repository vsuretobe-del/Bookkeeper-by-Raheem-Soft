import re

with open('bookkeeper.py', 'r', encoding='utf-8') as f:
    text = f.read()

# First, remove any existing check_for_updates definition if it's lingering
text = re.sub(r'def check_for_updates\(root\):.*?threading\.Thread\(target=run_check, daemon=True\)\.start\(\)', '', text, flags=re.DOTALL)

update_logic = '''
def check_for_updates(root):
    import urllib.request
    import threading
    from tkinter import messagebox
    import subprocess
    import sys
    import os

    # Replace with the actual URL to the raw version.txt in the GitHub repo
    VERSION_URL = "https://raw.githubusercontent.com/YOUR_GITHUB_USERNAME/YOUR_REPO_NAME/main/version.txt"
    
    def run_check():
        try:
            if "YOUR_GITHUB_USERNAME" in VERSION_URL:
                return # Not configured yet
                
            # Read local version
            local_version = "1.0.0"
            if os.path.exists("version.txt"):
                with open("version.txt", "r") as vf:
                    local_version = vf.read().strip()
            
            # Fetch remote version
            req = urllib.request.Request(VERSION_URL, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=10) as response:
                remote_version = response.read().decode('utf-8').strip()
                
            # Simple string comparison for versions (assuming format X.Y.Z)
            def parse_version(v):
                return [int(x) for x in v.split('.') if x.isdigit()]
                
            if parse_version(remote_version) > parse_version(local_version):
                root.after(0, prompt_update, remote_version)
        except Exception as e:
            pass # Fail silently if no internet or error

    def prompt_update(new_ver):
        if messagebox.askyesno("Update Available", f"A new version ({new_ver}) is available. Would you like to update now?"):
            try:
                subprocess.Popen([sys.executable, "updater.py"], creationflags=subprocess.CREATE_NEW_CONSOLE)
            except:
                os.startfile("updater.py")
            root.destroy()
            sys.exit(0)

    threading.Thread(target=run_check, daemon=True).start()

if __name__ == "__main__":
    app = BookKeeperApp()
    check_for_updates(app)
    app.mainloop()
'''

# Replace the bottom block
old_bottom = '''if __name__ == "__main__":
    app = BookKeeperApp()
    app.mainloop()'''

if old_bottom in text:
    text = text.replace(old_bottom, update_logic)
else:
    print("Warning: old_bottom not found!")

with open('bookkeeper.py', 'w', encoding='utf-8') as f:
    f.write(text)
print("Updater logic injected successfully.")
