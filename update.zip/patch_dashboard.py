import re

with open('bookkeeper.py', 'r', encoding='utf-8') as f:
    text = f.read()

# 1. Add "Estimate Templates" to sidebar
old_sidebar = '''        create_dropdown_link("Alt+F5:", "Estimate", lambda: self._open_create_voucher("estimate"), lambda: self.show_invoices("estimate"))'''
new_sidebar = '''        create_dropdown_link("Alt+F5:", "Estimate", lambda: self._open_create_voucher("estimate"), lambda: self.show_invoices("estimate"))
        row_link("Alt+E:", "Estimate Templates", arrow=False, command=self.show_estimate_templates)'''
text = text.replace(old_sidebar, new_sidebar)

# 2. Add show_estimate_templates method before show_invoices
old_method = '''    def show_invoices(self, v_type="sale"):'''
new_method = '''    def show_estimate_templates(self):
        self._clear_main()
        self._make_tab_header("Estimate Templates")
        
        main_fr = tk.Frame(self.main_frame, bg=WHITE)
        main_fr.pack(fill="both", expand=True)
        
        top_fr = tk.Frame(main_fr, bg=WHITE)
        top_fr.pack(fill="x", padx=10, pady=10)
        
        tk.Label(top_fr, text="Estimate Templates", font=FONT_BOLD, bg=WHITE).pack(side="left")
        tk.Button(top_fr, text="New Template", command=lambda: self._open_create_voucher("estimate"), bg="#4CAF50", fg="white", font=FONT).pack(side="right")
        
        tv_fr = tk.Frame(main_fr, bg=WHITE)
        tv_fr.pack(fill="both", expand=True, padx=10, pady=(0, 10))
        
        cols = ("Template No", "Description", "Total Amount")
        tv = ttk.Treeview(tv_fr, columns=cols, show="headings", height=15)
        for c in cols:
            tv.heading(c, text=c)
            tv.column(c, width=150, anchor="w")
        tv.pack(side="left", fill="both", expand=True)
        
        sb = ttk.Scrollbar(tv_fr, orient="vertical", command=tv.yview)
        sb.pack(side="right", fill="y")
        tv.configure(yscrollcommand=sb.set)
        
        import db
        templates = db.get_estimate_templates()
        for t in templates:
            tv.insert("", "end", iid=str(t['id']), values=(t['invoice_no'], t['notes'], t['total']))
            
        def on_generate_estimate(e=None):
            sel = tv.selection()
            if not sel: return
            t_id = int(sel[0])
            t_data = next((t for t in templates if t['id'] == t_id), None)
            if not t_data: return
            
            # Use duplicate feature to load into a new estimate window!
            self._open_create_voucher("estimate", edit_inv=t_data, is_duplicate=True)
            
        tv.bind("<Double-1>", on_generate_estimate)
        
        tk.Label(main_fr, text="Double-click a template to generate a new Estimate for a customer.", font=("Segoe UI", 9, "italic"), bg=WHITE).pack(pady=5)

    def show_invoices(self, v_type="sale"):'''
text = text.replace(old_method, new_method)

with open('bookkeeper.py', 'w', encoding='utf-8') as f:
    f.write(text)
print("bookkeeper.py patched for Estimate Templates Dashboard")
