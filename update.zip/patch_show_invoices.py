import re
from autocomplete import AutocompleteCombobox

with open('bookkeeper.py', 'r', encoding='utf-8') as f:
    content = f.read()

start_marker = "    def show_invoices(self):"
end_marker = "    def _new_invoice_form(self):"

start_idx = content.find(start_marker)
end_idx = content.find(end_marker)

if start_idx == -1 or end_idx == -1:
    print("Markers not found")
    exit(1)

new_code = '''    def show_invoices(self):
        self._clear_main()
        self._make_tab_header("Accounts/Transactions")
        
        # 1. Toolbar Frame
        toolbar = tk.Frame(self.main_frame, bg=WHITE)
        toolbar.pack(fill="x", pady=(0, 2))
        
        btn_close = tk.Button(toolbar, text="X", bg="black", fg="white", font=FONT_BOLD, relief="flat", bd=0, width=2)
        btn_close.pack(side="left", padx=4)
        tk.Label(toolbar, text="Ctrl+Q: Exit | F5: Payment To Supplier | F6: Receipt From Customer | F7: Journal | F8: Sale/Invoice/Bill | F9: Purchase | Alt+E: Expense | Alt+I: Income | F4: Contra", bg=WHITE, font=("Tahoma", 8)).pack(side="left", padx=5)

        # 2. Search Frame
        search_fr = tk.Frame(self.main_frame, bg=WHITE, relief="sunken", bd=1)
        search_fr.pack(fill="x", padx=4, pady=2)
        tk.Label(search_fr, text="F3: Search:", bg=WHITE, font=FONT).pack(side="left", padx=4, pady=2)
        search_var = tk.StringVar()
        tk.Entry(search_fr, textvariable=search_var, font=FONT, relief="flat", bd=0).pack(side="left", padx=4, fill="x", expand=True)
        tk.Button(search_fr, text="Search All Vouchers", bg="#f0f0f0", relief="solid", bd=1, font=("Tahoma", 9)).pack(side="right", fill="y")
        
        tk.Label(self.main_frame, text="Press ENTER for more options. Use ARROW KEYS to move left/right.", fg="darkred", bg=BG, font=("Tahoma", 8, "bold italic"), anchor="w").pack(fill="x", padx=4)

        # 3. Main Split (Left: Transactions, Right: Filters)
        main_split = tk.Frame(self.main_frame, bg=BG)
        main_split.pack(fill="both", expand=True, padx=4, pady=2)

        right_pane = tk.Frame(main_split, bg=WHITE, width=120)
        right_pane.pack(side="right", fill="y", padx=(4, 0))
        right_pane.pack_propagate(False)

        left_pane = tk.Frame(main_split, bg=WHITE, relief="solid", bd=1)
        left_pane.pack(side="left", fill="both", expand=True)

        # 4. Filters (Right Pane)
        fin_year = AutocompleteCombobox(right_pane, values=["2025-2026"], state="readonly", font=("Tahoma", 8))
        fin_year.pack(fill="x", pady=2)
        fin_year.current(0)
        
        months_lb = tk.Listbox(right_pane, font=("Tahoma", 8), selectbackground="#3399ff", relief="solid", bd=1, highlightthickness=0)
        months_lb.pack(fill="both", expand=True)
        months = ["All", "Apr-2025", "May-2025", "Jun-2025", "Jul-2025", "Aug-2025", "Sep-2025", "Oct-2025", "Nov-2025", "Dec-2025", "Jan-2026", "Feb-2026", "Mar-2026"]
        for m in months: months_lb.insert("end", m)
        months_lb.selection_set(0)

        # 5. Pagination (Left Pane Header)
        page_fr = tk.Frame(left_pane, bg=BG)
        page_fr.pack(fill="x")
        
        tk.Button(page_fr, text="< Alt+P: Previous Page\\n(Newer Transactions)", justify="left", bg="#e0e0e0", relief="flat", bd=1, font=("Tahoma", 8)).pack(side="left", padx=2, pady=2)
        tk.Label(page_fr, text="Displaying page: 1", bg=BG, font=FONT_BOLD).pack(side="left", expand=True)
        tk.Button(page_fr, text="Alt+N: Next Page >\\n(Older Transactions)", justify="right", bg="#e0e0e0", relief="flat", bd=1, font=("Tahoma", 8)).pack(side="right", padx=2, pady=2)

        # 6. Transactions Header
        hdr_fr = tk.Frame(left_pane, bg=WHITE)
        hdr_fr.pack(fill="x")
        
        col_widths = [("Date", 80), ("Accounts", 150), ("Description", 250), ("Amount", 100), ("Status", 80)]
        for text, w in col_widths:
            fr = tk.Frame(hdr_fr, width=w, bg=WHITE)
            fr.pack(side="left")
            fr.pack_propagate(False)
            tk.Label(fr, text=text, font=FONT_BOLD, bg=WHITE, anchor="w" if text != "Amount" else "e").pack(fill="both", expand=True, padx=4, pady=4)
        
        # Draw a line below header
        tk.Frame(left_pane, bg="#cccccc", height=1).pack(fill="x")

        # 7. Transactions Canvas
        list_canvas = tk.Canvas(left_pane, bg=WHITE, highlightthickness=0)
        list_vsb = ttk.Scrollbar(left_pane, orient="vertical", command=list_canvas.yview)
        list_canvas.configure(yscrollcommand=list_vsb.set)
        list_vsb.pack(side="right", fill="y")
        list_canvas.pack(side="left", fill="both", expand=True)

        list_inner = tk.Frame(list_canvas, bg=WHITE)
        list_cw = list_canvas.create_window((0, 0), window=list_inner, anchor="nw")

        list_inner.bind("<Configure>", lambda e: list_canvas.configure(scrollregion=list_canvas.bbox("all")))
        list_canvas.bind("<Configure>", lambda e: list_canvas.itemconfig(list_cw, width=e.width))

        # 8. Render Rows
        invoices = db.get_all_invoices("sale")
        if not invoices:
            # Dummy data for UI replication if db has no invoices
            invoices = [
                {"date": "2025-08-31", "account_name": "Customer A", "invoice_no": "INV1", "total": 7200, "paid": 7200},
                {"date": "2025-08-31", "account_name": "Cash", "invoice_no": "INV2", "total": 1500, "paid": 0},
                {"date": "2025-08-31", "account_name": "Cash", "invoice_no": "INV3", "total": 1500, "paid": 0},
                {"date": "2025-08-31", "account_name": "Cash", "invoice_no": "INV4", "total": 1500, "paid": 0},
                {"date": "2025-08-31", "account_name": "Cash", "invoice_no": "INV5", "total": 1500, "paid": 0},
                {"date": "2025-08-31", "account_name": "Cash", "invoice_no": "INV6", "total": 1500, "paid": 0},
                {"date": "2025-08-31", "account_name": "Cash", "invoice_no": "INV7", "total": 1722, "paid": 0},
                {"date": "2025-08-31", "account_name": "Cash", "invoice_no": "INV8", "total": 1722, "paid": 0},
            ]

        rows = []
        def on_row_click(event, clicked_row_fr):
            for r in rows:
                for widget in r.winfo_children():
                    widget.configure(bg="#f0f0f0" if r.row_idx % 2 == 1 else WHITE)
                r.configure(bg="#f0f0f0" if r.row_idx % 2 == 1 else WHITE)
            for widget in clicked_row_fr.winfo_children():
                widget.configure(bg="yellow")
            clicked_row_fr.configure(bg="yellow")

        for idx, inv in enumerate(invoices):
            bg_col = "#f0f0f0" if idx % 2 == 1 else WHITE
            row_fr = tk.Frame(list_inner, bg=bg_col)
            row_fr.pack(fill="x")
            row_fr.row_idx = idx
            rows.append(row_fr)

            # Date
            d_fr = tk.Frame(row_fr, bg=bg_col, width=col_widths[0][1], height=40)
            d_fr.pack(side="left")
            d_fr.pack_propagate(False)
            tk.Label(d_fr, text=inv["date"], font=FONT, bg=bg_col, anchor="w").pack(side="top", anchor="nw", padx=4, pady=4)
            
            # Accounts
            a_fr = tk.Frame(row_fr, bg=bg_col, width=col_widths[1][1], height=40)
            a_fr.pack(side="left")
            a_fr.pack_propagate(False)
            tk.Label(a_fr, text=inv.get("account_name", ""), font=FONT, bg=bg_col, anchor="w").pack(anchor="w", padx=4, pady=(2, 0))
            tk.Label(a_fr, text="Sales", font=FONT, bg=bg_col, anchor="w").pack(anchor="w", padx=4)

            # Description
            desc_fr = tk.Frame(row_fr, bg=bg_col, width=col_widths[2][1], height=40)
            desc_fr.pack(side="left")
            desc_fr.pack_propagate(False)
            tk.Label(desc_fr, text="Sales", font=FONT, bg=bg_col, anchor="w").pack(anchor="w", padx=4, pady=(2, 0))
            tk.Label(desc_fr, text=f"Voucher No:{inv['invoice_no']}", font=FONT, bg=bg_col, anchor="w").pack(anchor="w", padx=4)

            # Amount
            amt_val = float(inv.get("total", 0))
            amt_fr = tk.Frame(row_fr, bg=bg_col, width=col_widths[3][1], height=40)
            amt_fr.pack(side="left")
            amt_fr.pack_propagate(False)
            tk.Label(amt_fr, text=f"{amt_val:,.0f}" if amt_val.is_integer() else f"{amt_val:,.2f}", font=FONT, bg=bg_col, anchor="e").pack(side="top", fill="x", padx=4, pady=4)

            # Status
            s_fr = tk.Frame(row_fr, bg=bg_col, width=col_widths[4][1], height=40)
            s_fr.pack(side="left")
            s_fr.pack_propagate(False)
            
            is_paid = float(inv.get("paid", 0)) >= amt_val and amt_val > 0
            # For mockup data simulation
            if inv.get("invoice_no") == "INV1":
                is_paid = True
                
            if is_paid:
                stat_lbl = tk.Label(s_fr, text="Paid", bg="#8cc63f", fg="black", font=FONT_BOLD, padx=6, pady=2)
                stat_lbl.pack(anchor="center", expand=True)

            # Bind clicks to everything
            for widget in (row_fr, d_fr, a_fr, desc_fr, amt_fr, s_fr) + tuple(d_fr.winfo_children()) + tuple(a_fr.winfo_children()) + tuple(desc_fr.winfo_children()) + tuple(amt_fr.winfo_children()):
                widget.bind("<Button-1>", lambda e, r=row_fr: on_row_click(e, r))
            if is_paid:
                stat_lbl.bind("<Button-1>", lambda e, r=row_fr: on_row_click(e, r))
                
            tk.Frame(list_inner, bg="#cccccc", height=1).pack(fill="x")

'''

new_content = content[:start_idx] + new_code + content[end_idx:]

with open('bookkeeper.py', 'w', encoding='utf-8') as f:
    f.write(new_content)

print("Replacement successful")
