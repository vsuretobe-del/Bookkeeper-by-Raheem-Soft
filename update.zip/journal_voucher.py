import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import datetime
import os
import db
from autocomplete import AutocompleteCombobox

FONT = ("Segoe UI", 10)
FONT_BOLD = ("Segoe UI", 10, "bold")
FONT_TITLE = ("Segoe UI", 12, "bold")
BG = "#f0f0f0"
BG_WHITE = "#ffffff"
YELLOW_BG = "#ffff00"

class JournalVoucherWindow(tk.Toplevel):
    def __init__(self, master, app=None, edit_inv=None, is_duplicate=False):
        super().__init__(master)
        self.app = app
        self.edit_inv = edit_inv
        self.is_duplicate = is_duplicate

        self.title("Create Voucher" if not edit_inv or is_duplicate else "Edit Voucher")
        self.geometry("1100x680")
        self.configure(bg=BG)
        self.grab_set()
        self.transient(master)

        self.line_items = [] # list of dicts: {'account': name, 'debit': 0.0, 'credit': 0.0}
        self.ref_file_path = ""
        self.active_entry = None

        self._build_ui()
        self._bind_shortcuts()

        if self.edit_inv:
            self._load_edit_data()

    def _build_ui(self):
        # 1. Top Shortcut Bar
        tb = tk.Frame(self, bg=BG_WHITE, relief="groove", bd=1)
        tb.pack(fill="x", side="top")

        shortcuts = [
            ("Alt+A: New Account", lambda: self.app._account_form("account") if self.app else None),
            ("Alt+E: New Expense Account", lambda: self.app._account_form("expense") if self.app else None),
            ("Alt+I: New Income Account", lambda: self.app._account_form("income") if self.app else None),
        ]
        for txt, cmd in shortcuts:
            btn = tk.Button(tb, text=txt, font=FONT_BOLD, bg=BG_WHITE, relief="flat", bd=0, cursor="hand2", command=cmd)
            btn.pack(side="left", padx=10, pady=4)

        tk.Frame(self, bg="#cccccc", height=1).pack(fill="x")

        # 2. Main Content Frame
        content = tk.Frame(self, bg=BG)
        content.pack(fill="both", expand=True, padx=15, pady=10)

        # Instruction Notice
        lbl_inst = tk.Label(content, text="Press ENTER to move forward  SHIFT+ENTER to move back.",
                            font=("Segoe UI", 11, "bold italic"), fg="#990000", bg=BG)
        lbl_inst.pack(anchor="w", pady=(0, 10))

        # Top Header Section (Journal No, Date & Select Account)
        top_hdr = tk.Frame(content, bg=BG)
        top_hdr.pack(fill="x", pady=(0, 10))

        # Left Header: Journal No & Voucher Date
        hdr_left = tk.Frame(top_hdr, bg=BG)
        hdr_left.pack(side="left", anchor="n")

        # Journal No Row
        r1 = tk.Frame(hdr_left, bg=BG)
        r1.pack(fill="x", pady=2)
        tk.Label(r1, text="Journal No", font=FONT_BOLD, bg=BG, width=12, anchor="w").pack(side="left")
        self.v_journal_no = tk.StringVar(value=db.get_next_journal_no())
        e_jrn = tk.Entry(r1, textvariable=self.v_journal_no, font=FONT_BOLD, bg=YELLOW_BG, width=28, relief="solid", bd=1)
        e_jrn.pack(side="left")

        # Voucher Date Row
        r2 = tk.Frame(hdr_left, bg=BG)
        r2.pack(fill="x", pady=4)
        tk.Label(r2, text="Voucher Date", font=FONT, bg=BG, width=12, anchor="w").pack(side="left")
        
        today_str = datetime.date.today().strftime("%B %d, %Y")
        self.v_date = tk.StringVar(value=today_str)
        e_date = tk.Entry(r2, textvariable=self.v_date, font=FONT, width=22, relief="solid", bd=1)
        e_date.pack(side="left")
        btn_cal = tk.Button(r2, text="📅", font=("Segoe UI", 9), relief="solid", bd=1, command=self._pick_date, cursor="hand2")
        btn_cal.pack(side="left", padx=2)

        # Right Header: Account Select & Add
        hdr_right = tk.Frame(top_hdr, bg=BG)
        hdr_right.pack(side="right", anchor="n")

        tk.Label(hdr_right, text="Press ENTER key to add.", font=("Segoe UI", 11, "bold italic"), fg="#990000", bg=BG).pack(anchor="e")

        sel_acc_fr = tk.Frame(hdr_right, bg=BG)
        sel_acc_fr.pack(anchor="e", pady=2)

        tk.Label(sel_acc_fr, text="F9: Select Account", font=FONT_BOLD, bg=BG).pack(side="left", padx=(0, 5))
        
        self.all_accounts = [acc["name"] for acc in db.get_all_accounts()]
        self.v_sel_acc = tk.StringVar()
        
        def on_account_created(new_name=None):
            if new_name:
                self.all_accounts = [acc["name"] for acc in db.get_all_accounts()]
                self.cb_acc.config(values=self.all_accounts)
                self.v_sel_acc.set(new_name)
                self._on_account_select(None)
                
        def create_account_inline(name):
            self.master._generic_account_form(initial_name=name, callback=on_account_created)
            
        self.cb_acc = AutocompleteCombobox(sel_acc_fr, textvariable=self.v_sel_acc, values=self.all_accounts, font=FONT, width=30, allow_create=True, create_callback=create_account_inline)
        self.cb_acc.pack(side="left")
        self.cb_acc.bind("<<ComboboxSelected>>", self._on_account_select)
        self.cb_acc.bind("<Return>", lambda e: self._add_account_row())

        self.lbl_acc_bal = tk.Label(hdr_right, text="balance 0", font=FONT, bg=BG, fg="#333333")
        self.lbl_acc_bal.pack(anchor="e", padx=(0, 50))

        # 3. Journal Items Table / Grid
        grid_frame = tk.Frame(content, bg=BG_WHITE, relief="solid", bd=1)
        grid_frame.pack(fill="both", expand=True, pady=5)

        columns = ("Account", "Debit Amount", "Credit Amount")
        self.tree = ttk.Treeview(grid_frame, columns=columns, show="headings", height=8)
        
        self.tree.heading("Account", text="Account", anchor="w")
        self.tree.heading("Debit Amount", text="Debit Amount", anchor="e")
        self.tree.heading("Credit Amount", text="Credit Amount", anchor="e")

        self.tree.column("Account", width=500, anchor="w")
        self.tree.column("Debit Amount", width=250, anchor="e")
        self.tree.column("Credit Amount", width=250, anchor="e")

        sb = ttk.Scrollbar(grid_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=sb.set)

        self.tree.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")

        self.tree.bind("<Button-1>", self._on_cell_click)
        self.tree.bind("<Double-1>", self._on_cell_click)
        self.tree.bind("<Delete>", self._on_row_delete)

        # 4. Totals Bar
        tot_fr = tk.Frame(content, bg=BG)
        tot_fr.pack(fill="x", pady=5)

        # Debit Total
        tk.Label(tot_fr, text="Debit Total", font=FONT_BOLD, bg=BG).pack(side="left", padx=(200, 5))
        self.v_debit_tot = tk.StringVar(value="0")
        e_deb_tot = tk.Entry(tot_fr, textvariable=self.v_debit_tot, font=FONT_BOLD, width=30, justify="right", state="readonly", relief="solid", bd=1)
        e_deb_tot.pack(side="left")

        # Credit Total
        tk.Label(tot_fr, text="Credit Total", font=FONT_BOLD, bg=BG).pack(side="left", padx=(20, 5))
        self.v_credit_tot = tk.StringVar(value="0")
        e_cred_tot = tk.Entry(tot_fr, textvariable=self.v_credit_tot, font=FONT_BOLD, width=30, justify="right", state="readonly", relief="solid", bd=1)
        e_cred_tot.pack(side="left")

        # 5. Bottom Section (Narration & Action Buttons)
        bot = tk.Frame(content, bg=BG)
        bot.pack(fill="x", pady=(10, 0))

        # Bottom Left: Narration & Exit
        bot_left = tk.Frame(bot, bg=BG)
        bot_left.pack(side="left", fill="both", expand=True)

        nar_lbl_fr = tk.Frame(bot_left, bg=BG)
        nar_lbl_fr.pack(side="left", anchor="n", padx=(0, 10))
        tk.Label(nar_lbl_fr, text="Narration", font=FONT_BOLD, bg=BG).pack(anchor="w")
        tk.Label(nar_lbl_fr, text="Use Ctrl+Enter for next line", font=("Segoe UI", 9, "italic"), fg="#555555", bg=BG).pack(anchor="w")

        self.txt_narration = tk.Text(bot_left, width=45, height=4, font=FONT, relief="solid", bd=1)
        self.txt_narration.pack(side="left", padx=(0, 10))

        btn_exit = tk.Button(bot_left, text="Ctrl+Q: Exit", font=FONT_BOLD, bg="#e0e0e0", relief="solid", bd=1,
                             padx=15, pady=8, command=self.destroy)
        btn_exit.pack(side="left", anchor="s")

        # Bottom Right: Reference Document & Save Buttons
        bot_right = tk.Frame(bot, bg=BG)
        bot_right.pack(side="right", anchor="se")

        # Reference Document Frame
        ref_frame = tk.LabelFrame(bot_right, text="Reference Document", font=FONT, bg=BG, padx=5, pady=5)
        ref_frame.pack(fill="x", pady=(0, 10))

        self.v_ref_doc = tk.StringVar()
        e_ref = tk.Entry(ref_frame, textvariable=self.v_ref_doc, font=FONT, width=40, relief="solid", bd=1)
        e_ref.pack(fill="x", pady=(0, 5))

        btn_ref_fr = tk.Frame(ref_frame, bg=BG)
        btn_ref_fr.pack(fill="x")

        tk.Button(btn_ref_fr, text="Browse", font=FONT, bg="#e0e0e0", relief="solid", bd=1, width=10, command=self._browse_ref).pack(side="left", padx=2)
        tk.Button(btn_ref_fr, text="View", font=FONT, bg="#e0e0e0", relief="solid", bd=1, width=10, command=self._view_ref).pack(side="left", padx=2)
        tk.Button(btn_ref_fr, text="Delete", font=FONT, bg="#e0e0e0", relief="solid", bd=1, width=10, command=self._delete_ref).pack(side="left", padx=2)

        # Save Action Buttons
        save_btn_fr = tk.Frame(bot_right, bg=BG)
        save_btn_fr.pack(anchor="e")

        btn_save_view = tk.Button(save_btn_fr, text="🧮 Alt+F12: Save & View", font=FONT_BOLD, bg="#e0e0e0", relief="solid", bd=1, padx=10, pady=6,
                                  command=lambda: self.save(view_after=True))
        btn_save_view.pack(side="left", padx=5)

        btn_save = tk.Button(save_btn_fr, text="F12:Save", font=FONT_BOLD, bg="#e0e0e0", relief="solid", bd=1, padx=15, pady=6,
                             command=self.save)
        btn_save.pack(side="left")

    def _bind_shortcuts(self):
        self.bind("<Control-q>", lambda e: self.destroy())
        self.bind("<Control-Q>", lambda e: self.destroy())
        self.bind("<F12>", lambda e: self.save())
        self.bind("<Alt-F12>", lambda e: self.save(view_after=True))
        self.bind("<F9>", lambda e: self.cb_acc.focus_set())
        self.bind("<Alt-a>", lambda e: self.app._account_form("account") if self.app else None)
        self.bind("<Alt-A>", lambda e: self.app._account_form("account") if self.app else None)
        self.bind("<Alt-e>", lambda e: self.app._account_form("expense") if self.app else None)
        self.bind("<Alt-E>", lambda e: self.app._account_form("expense") if self.app else None)
        self.bind("<Alt-i>", lambda e: self.app._account_form("income") if self.app else None)
        self.bind("<Alt-I>", lambda e: self.app._account_form("income") if self.app else None)

    def _pick_date(self):
        top = tk.Toplevel(self)
        top.title("Select Date")
        top.geometry("280x250")
        top.grab_set()
        top.transient(self)

        try:
            from tkcalendar import Calendar
            cal = Calendar(top, selectmode='day', date_pattern='yyyy-mm-dd')
            cal.pack(padx=10, pady=10, fill="both", expand=True)

            def on_select():
                sel_d = cal.selection_get()
                self.v_date.set(sel_d.strftime("%B %d, %Y"))
                top.destroy()

            tk.Button(top, text="Select", font=FONT_BOLD, bg="#e0e0e0", relief="solid", bd=1, command=on_select).pack(pady=(0, 10))
        except Exception:
            top.destroy()

    def _on_account_select(self, event=None):
        acc_name = self.v_sel_acc.get()
        if acc_name:
            bal = db.get_account_balance(acc_name)
            self.lbl_acc_bal.config(text=f"balance {bal:,.0f}" if bal.is_integer() else f"balance {bal:,.2f}")

    def _add_account_row(self):
        acc_name = self.v_sel_acc.get().strip()
        if not acc_name:
            return
        
        # Check if already added
        existing = [item for item in self.line_items if item['account'] == acc_name]
        if existing:
            messagebox.showwarning("Warning", f"Account '{acc_name}' is already added.", parent=self)
            return

        # Calculate current total debits and credits for auto-balancing
        deb_tot = sum(item['debit'] for item in self.line_items)
        cred_tot = sum(item['credit'] for item in self.line_items)

        d_val = 0.0
        c_val = 0.0

        # Auto-balance 2nd account or subsequent accounts if there's a difference
        if deb_tot > cred_tot:
            c_val = deb_tot - cred_tot
        elif cred_tot > deb_tot:
            d_val = cred_tot - deb_tot

        new_item = {'account': acc_name, 'debit': d_val, 'credit': c_val}
        self.line_items.append(new_item)
        self._refresh_tree()
        self.v_sel_acc.set("")
        self.lbl_acc_bal.config(text="balance 0")

    def _refresh_tree(self):
        if self.active_entry:
            try:
                self.active_entry.destroy()
            except Exception:
                pass
            self.active_entry = None

        for row in self.tree.get_children():
            self.tree.delete(row)

        deb_tot = 0.0
        cred_tot = 0.0

        for item in self.line_items:
            d_val = item['debit']
            c_val = item['credit']
            deb_tot += d_val
            cred_tot += c_val

            d_str = f"{d_val:,.0f}" if d_val > 0 else "0"
            c_str = f"{c_val:,.0f}" if c_val > 0 else "0"

            self.tree.insert("", "end", values=(item['account'], d_str, c_str))

        self.v_debit_tot.set(f"{deb_tot:,.0f}" if deb_tot.is_integer() else f"{deb_tot:,.2f}")
        self.v_credit_tot.set(f"{cred_tot:,.0f}" if cred_tot.is_integer() else f"{cred_tot:,.2f}")

    def _on_cell_click(self, event):
        if self.active_entry:
            try:
                self.active_entry.destroy()
            except Exception:
                pass
            self.active_entry = None

        region = self.tree.identify_region(event.x, event.y)
        if region != "cell":
            return

        column = self.tree.identify_column(event.x)
        item_id = self.tree.identify_row(event.y)
        if not item_id or column not in ("#2", "#3"): # Debit or Credit
            return

        item_idx = self.tree.index(item_id)
        if item_idx >= len(self.line_items):
            return

        target_item = self.line_items[item_idx]
        bbox = self.tree.bbox(item_id, column)
        if not bbox:
            return

        x, y, w, h = bbox
        col_key = 'debit' if column == "#2" else 'credit'
        val = target_item[col_key]

        entry_var = tk.StringVar(value=str(int(val)) if val.is_integer() else str(val))
        
        entry = tk.Entry(self.tree, textvariable=entry_var, font=FONT, justify="right", relief="solid", bd=1)
        entry.place(x=x, y=y, width=w, height=h)
        entry.focus_set()
        entry.select_range(0, tk.END)
        self.active_entry = entry

        def save_edit(e=None):
            if not entry.winfo_exists():
                return
            try:
                new_val = float(entry_var.get() or 0)
            except ValueError:
                new_val = 0.0

            target_item[col_key] = new_val
            if new_val > 0:
                opp_key = 'credit' if col_key == 'debit' else 'debit'
                target_item[opp_key] = 0.0

            entry.destroy()
            self.active_entry = None
            self._refresh_tree()

        entry.bind("<Return>", save_edit)
        entry.bind("<FocusOut>", save_edit)
        entry.bind("<Escape>", lambda e: entry.destroy())

    def _on_row_delete(self, event):
        sel = self.tree.selection()
        if not sel:
            return
        idx = self.tree.index(sel[0])
        if idx < len(self.line_items):
            del self.line_items[idx]
            self._refresh_tree()

    def _load_edit_data(self):
        conn = db.get_conn()
        main_row = conn.execute("SELECT * FROM vouchers WHERE v_id=?", (self.edit_inv["id"])).fetchone()
        if main_row:
            if not self.is_duplicate:
                self.v_journal_no.set(main_row["vch_no"])
            self.v_date.set(main_row["date"])
            if hasattr(self, 'txt_narration'):
                self.txt_narration.insert("1.0", main_row["narration"] or "")
            if hasattr(self, 'v_ref_doc'):
                self.v_ref_doc.set(main_row["detail1"] or "")

            lines = conn.execute("SELECT * FROM vouchers_all WHERE v_id=?", (self.edit_inv["id"])).fetchall()
            self.line_items = []
            for r in lines:
                d_amt = float(r["amount"]) if r["debit"] else 0.0
                c_amt = float(r["amount"]) if r["credit"] else 0.0
                acc_name = r["debit"] if r["debit"] else r["credit"]
                if acc_name:
                    self.line_items.append({'account': acc_name, 'debit': d_amt, 'credit': c_amt})

            self._refresh_tree()
        conn.close()

    def _browse_ref(self):
        file_path = filedialog.askopenfilename(title="Select Reference Document", parent=self)
        if file_path:
            self.ref_file_path = file_path
            self.v_ref_doc.set(file_path)

    def _view_ref(self):
        path = self.v_ref_doc.get()
        if path and os.path.exists(path):
            try:
                os.startfile(path)
            except Exception as e:
                messagebox.showerror("Error", f"Could not open file: {e}", parent=self)
        else:
            messagebox.showwarning("Warning", "File does not exist.", parent=self)

    def _delete_ref(self):
        self.ref_file_path = ""
        self.v_ref_doc.set("")

    def save(self, view_after=False):
        if not self.line_items:
            messagebox.showerror("Error", "Please add accounts to the journal voucher.", parent=self)
            return

        deb_tot = sum(item['debit'] for item in self.line_items)
        cred_tot = sum(item['credit'] for item in self.line_items)

        if deb_tot <= 0 or cred_tot <= 0:
            messagebox.showerror("Error", "Please enter debit and credit amounts greater than zero.", parent=self)
            return

        if abs(deb_tot - cred_tot) > 0.01:
            messagebox.showerror("Error", f"Debit Total ({deb_tot:,.2f}) and Credit Total ({cred_tot:,.2f}) must be equal!", parent=self)
            return

        jrn_no = self.v_journal_no.get().strip()
        date_str = self.v_date.get().strip()
        try:
            date_str = datetime.datetime.strptime(date_str, "%B %d, %Y").strftime("%Y-%m-%d")
        except Exception:
            pass
        narration = self.txt_narration.get("1.0", "end").strip()
        ref_doc = self.v_ref_doc.get().strip()

        # Save to DB
        v_id = db.create_journal(
            journal_no=jrn_no,
            date=date_str,
            line_items=self.line_items,
            narration=narration,
            ref_doc=ref_doc
        )

        messagebox.showinfo("Saved", "Journal Voucher saved successfully!", parent=self)
        self.destroy()

        if view_after and self.app:
            self.app.show_invoices("journal")
