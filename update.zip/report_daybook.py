import tkinter as tk
from tkinter import ttk, messagebox
import db
import datetime
import calendar
from autocomplete import AutocompleteCombobox

BG_DARK = "#2B579A"
WHITE = "#FFFFFF"
GRAY = "#E0E0E0"
DARK_GRAY = "#666666"

FONT = ("Segoe UI", 10)
FONT_BOLD = ("Segoe UI", 10, "bold")
TITLE_FONT = ("Segoe UI", 14, "bold")

class ReportDaybook(tk.Toplevel):
    def __init__(self, parent, is_post_dated=False):
        super().__init__(parent, bg=WHITE)
        self.title("Post Dated Vouchers" if is_post_dated else "Day Book")
        self.state("zoomed")
        self.geometry("1024x768")
        self.is_post_dated = is_post_dated
        self.report_title = "POST DATED VOUCHERS" if is_post_dated else "DAY BOOK"
        
        self.chk_vars = {
            "Display Duplicate Vouchers": tk.BooleanVar(value=False),
            "Display Amount For All Accounts": tk.BooleanVar(value=False),
            "Display Item Details": tk.BooleanVar(value=False),
            "Display Narration": tk.BooleanVar(value=False),
            "Display Location": tk.BooleanVar(value=False),
            "Display Username": tk.BooleanVar(value=False),
            "Display Time Stamp": tk.BooleanVar(value=False),
        }
        
        self.build_ui()
        self.load_data()
        
    def build_ui(self):
        self.left_panel = tk.Frame(self, bg=BG_DARK, width=280)
        self.left_panel.pack(side="left", fill="y")
        self.left_panel.pack_propagate(False)
        
        self.right_panel = tk.Frame(self, bg=WHITE)
        self.right_panel.pack(side="right", fill="both", expand=True)
        
        self.build_left_panel()
        self.build_right_panel()
        
    def build_left_panel(self):
        canvas = tk.Canvas(self.left_panel, bg=BG_DARK, highlightthickness=0)
        scrollbar = ttk.Scrollbar(self.left_panel, orient="vertical", command=canvas.yview)
        
        self.f = tk.Frame(canvas, bg=BG_DARK)
        self.f.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=self.f, anchor="nw", width=260)
        canvas.configure(yscrollcommand=scrollbar.set)
        
        def _on_mousewheel(event):
            canvas.yview_scroll(int(-1*(event.delta/120)), "units")
        canvas.bind_all("<MouseWheel>", _on_mousewheel)
        
        canvas.pack(side="left", fill="both", expand=True, padx=(10, 0), pady=10)
        scrollbar.pack(side="right", fill="y")
        
        # --- Filters ---
        today = datetime.date.today()
        
        if self.is_post_dated:
            # Post Dated defaults: tomorrow to +1 year
            start_d = today + datetime.timedelta(days=1)
            end_d = today + datetime.timedelta(days=365)
        else:
            # Day Book defaults: today
            start_d = today
            end_d = today
            
        # Start Date
        tk.Label(self.f, text="F2: Start Date:", bg=BG_DARK, fg=WHITE, font=FONT).pack(anchor="w", pady=(10,0))
        from custom_calendar import DateEntry
        self.start_dp = DateEntry(self.f)
        self.start_dp.set_date(start_d)
        self.start_dp.pack(fill="x", pady=2)
        
        # End Date
        tk.Label(self.f, text="End date:", bg=BG_DARK, fg=WHITE, font=FONT).pack(anchor="w", pady=(10,0))
        self.end_dp = DateEntry(self.f)
        self.end_dp.set_date(end_d)
        self.end_dp.pack(fill="x", pady=2)
        
        # Account Name
        tk.Label(self.f, text="Account Name", bg=BG_DARK, fg=WHITE, font=FONT).pack(anchor="w", pady=(10,0))
        self.cb_account = AutocompleteCombobox(self.f, font=FONT, state="readonly")
        self.cb_account.pack(fill="x", pady=2)
        
        # Fetch accounts
        try:
            conn = db.get_conn()
            acts = conn.execute("SELECT aname as account_name FROM account_detail ORDER BY account_name").fetchall()
            conn.close()
            act_list = ["ALL"] + [a['account_name'] for a in acts]
            self.cb_account['values'] = act_list
        except:
            self.cb_account['values'] = ["ALL"]
        self.cb_account.set(self.cb_account['values'][0])
        
        # Voucher Type
        tk.Label(self.f, text="Voucher Type:", bg=BG_DARK, fg=WHITE, font=FONT).pack(anchor="w", pady=(10,0))
        self.cb_vtype = AutocompleteCombobox(self.f, font=FONT, state="readonly")
        self.cb_vtype.pack(fill="x", pady=2)
        self.cb_vtype['values'] = [
            "ALL", "Journal", "Expense", "Income", "Receipt", "Payment", 
            "Purchase", "Sales", "Contra", "Purchases Return", "Sales Return", 
            "Manufacturing", "Stock Journal", "Stock Adjustment", 
            "Purchase Order", "Estimate", "Delivery Challan"
        ]
        self.cb_vtype.set(self.cb_vtype['values'][0])
        
        # Checkboxes
        tk.Frame(self.f, bg=BG_DARK, height=10).pack()
        for text, var in self.chk_vars.items():
            cb = tk.Checkbutton(self.f, text=text, variable=var, bg=BG_DARK, fg=WHITE, 
                                font=FONT, selectcolor=BG_DARK, activebackground=BG_DARK, activeforeground=WHITE)
            cb.pack(anchor="w", pady=2)
            
        # Display Button
        tk.Frame(self.f, bg=BG_DARK, height=20).pack()
        btn = tk.Button(self.f, text="Display", bg=BG_DARK, fg=WHITE, font=FONT, 
                        relief="ridge", command=self.load_data)
        btn.pack(fill="x", pady=10, ipady=5)
        
    def build_right_panel(self):
        # Header
        self.header_f = tk.Frame(self.right_panel, bg=WHITE)
        self.header_f.pack(fill="x", padx=20, pady=(20, 10))
        
        lbl_co = tk.Label(self.header_f, text="ALHUMDULILLAH", font=FONT_BOLD, bg=WHITE, fg=BG_DARK)
        lbl_co.pack(anchor="w")
        
        lbl_report = tk.Label(self.header_f, text=self.report_title, font=TITLE_FONT, bg=WHITE, fg=BG_DARK)
        lbl_report.pack(anchor="w")
        
        self.lbl_date_range = tk.Label(self.header_f, text="", font=FONT, bg=WHITE, fg=DARK_GRAY)
        self.lbl_date_range.pack(anchor="w")
        
        # Treeview
        self.tree_f = tk.Frame(self.right_panel, bg=WHITE)
        self.tree_f.pack(fill="both", expand=True, padx=20, pady=10)
        
        self.tree = None
        self.build_treeview()
        
    def build_treeview(self):
        for widget in self.tree_f.winfo_children():
            widget.destroy()
            
        cols = ["VOUCHER DATE", "DEBIT", "CREDIT", "VCH TYPE", "VCHNO", "DEBIT AMOUNT", "CREDIT AMOUNT"]
        
        self.tree = ttk.Treeview(self.tree_f, columns=cols, show="headings", height=20, selectmode="none")
        
        for c in cols:
            self.tree.heading(c, text=c)
            if "AMOUNT" in c:
                self.tree.column(c, width=120, minwidth=120, anchor="e", stretch=False)
            elif c in ["DEBIT", "CREDIT"]:
                self.tree.column(c, width=150, minwidth=150, anchor="w", stretch=False)
            else:
                self.tree.column(c, width=120, minwidth=120, anchor="w", stretch=False)
                
        def disable_resize(event):
            if self.tree.identify_region(event.x, event.y) == "separator":
                return "break"
        self.tree.bind('<Button-1>', disable_resize)
        self.tree.bind('<B1-Motion>', disable_resize)
        style = ttk.Style()
        style.configure("Treeview", font=FONT, rowheight=25)
        style.configure("Treeview.Heading", font=FONT_BOLD)
        
        self.tree.tag_configure("stripe1", background="#F9F9F9")
        self.tree.tag_configure("stripe2", background=WHITE)
        self.tree.tag_configure("grand", font=FONT_BOLD, background=WHITE)
        
        ysb = ttk.Scrollbar(self.tree_f, orient="vertical", command=self.tree.yview)
        xsb = ttk.Scrollbar(self.tree_f, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscroll=ysb.set, xscroll=xsb.set)
        
        ysb.pack(side="right", fill="y")
        xsb.pack(side="bottom", fill="x")
        self.tree.pack(fill="both", expand=True)

    def format_money(self, val):
        if not val: return ""
        if val == 0: return ""
        return f"{val:,.0f}"

    def load_data(self):
        self.build_treeview()
        
        s_date = self.start_dp.get_date().strftime("%Y-%m-%d")
        e_date = self.end_dp.get_date().strftime("%Y-%m-%d")
        self.lbl_date_range.config(text=f"{s_date} TO {e_date}")
        
        acc = self.cb_account.get()
        vtype = self.cb_vtype.get()
        
        try:
            data = db.get_daybook_data(s_date, e_date, acc, vtype)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to fetch data:\n{e}")
            return
            
        tot_debit = 0.0
        tot_credit = 0.0
        
        for i, row in enumerate(data):
            tag = "stripe1" if i % 2 == 0 else "stripe2"
            
            amt_dr = ""
            amt_cr = ""
            val = row['amount']
            
            if acc != "ALL":
                if row['debit'] == acc:
                    amt_dr = self.format_money(val)
                    tot_debit += val
                if row['credit'] == acc:
                    amt_cr = self.format_money(val)
                    tot_credit += val
            else:
                if row['v_type'] in ["Contra", "Purchase", "Payment", "Purchases Return"]:
                    amt_cr = self.format_money(val)
                    tot_credit += val
                elif row['v_type'] in ["Manufacturing", "Stock Journal", "Stock Adjustment"]:
                    amt_dr = self.format_money(val)
                    amt_cr = self.format_money(val)
                    tot_debit += val
                    tot_credit += val
                else:
                    amt_dr = self.format_money(val)
                    tot_debit += val
            
            self.tree.insert("", "end", values=(
                row['date'],
                row['debit'],
                row['credit'],
                row['v_type'],
                row['vch_no'],
                amt_dr,
                amt_cr
            ), tags=(tag))
            
        bot_vals = (
            "", "", "", "",
            f"TOTAL ({len(data)} transactions)",
            self.format_money(tot_debit),
            self.format_money(tot_credit)
        )
        self.tree.insert("", "end", values=bot_vals, tags=("grand"))

if __name__ == "__main__":
    root = tk.Tk()
    root.title("Day Book Test")
    root.geometry("1024x768")
    app = ReportDaybook(root, is_post_dated=False)
    app.pack(fill="both", expand=True)
    root.mainloop()
