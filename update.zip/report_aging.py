import tkinter as tk
from tkinter import ttk, messagebox
import db
from datetime import datetime
from autocomplete import AutocompleteCombobox

BG_BLUE = "#2b579a"
BG_WHITE = "#ffffff"
BG_YELLOW = "#ffff00"
FONT = ("Segoe UI", 10)
FONT_BOLD = ("Segoe UI", 10, "bold")

class AgingReportView:
    def __init__(self, master, app_ref, is_receivable=False):
        self.master = tk.Toplevel(master)
        self.app_ref = app_ref
        self.is_receivable = is_receivable
        self.title_text = "Aged Receivable" if is_receivable else "Aged Payable"
        
        self.master.title(self.title_text)
        self.master.geometry("1000x600")
        self.master.configure(bg=BG_WHITE)
        self.master.grab_set()
        
        self._build_ui()
        self.load_combos()
        
    def _build_ui(self):
        # 1. Top Toolbar
        top_bar = tk.Frame(self.master, bg=BG_WHITE)
        top_bar.pack(fill="x", side="top")
        
        buttons = [
            ("✖ Ctrl+Q: Exit", self.master.destroy),
            ("🖨️ Alt+P: Print", self.not_implemented),
            ("📝 Ctrl+W: Open In MS Word", self.not_implemented),
            ("📊 Ctrl+E: Open In MS Excel", self.not_implemented),
            ("📄 Ctrl+V: Open In PDF", self.not_implemented),
            ("🌐 Ctrl+H: Open In Browser", self.not_implemented)
        ]
        for text, cmd in buttons:
            btn = tk.Button(top_bar, text=text, font=("Segoe UI", 9), relief="flat", bg=BG_WHITE, cursor="hand2", command=cmd)
            btn.pack(side="left", padx=2, pady=2)
            
        tk.Frame(self.master, bg="#cccccc", height=1).pack(fill="x")
        
        # 2. Main Content
        content_fr = tk.Frame(self.master, bg=BG_WHITE)
        content_fr.pack(fill="both", expand=True)
        
        # Left Panel
        left_fr = tk.Frame(content_fr, bg=BG_BLUE, width=280)
        left_fr.pack(side="left", fill="y")
        left_fr.pack_propagate(False)
        
        # Right Panel
        self.right_fr = tk.Frame(content_fr, bg=BG_WHITE)
        self.right_fr.pack(side="left", fill="both", expand=True)
        
        # --- Left Panel Content ---
        self.filter_mode = tk.StringVar(value="group")
        
        # Group Radio
        rb_group = tk.Radiobutton(left_fr, text="Account Group", variable=self.filter_mode, value="group", 
                                  bg=BG_BLUE, fg="white", font=FONT, selectcolor=BG_BLUE, activebackground=BG_BLUE, activeforeground="white", command=self.on_mode_change)
        rb_group.pack(anchor="w", padx=10, pady=(10, 2))
        
        self.cb_group = AutocompleteCombobox(left_fr, font=FONT, state="readonly")
        self.cb_group.pack(fill="x", padx=20, pady=2)
        
        # Name Radio
        rb_name = tk.Radiobutton(left_fr, text="F9: Account Name:", variable=self.filter_mode, value="name", 
                                  bg=BG_BLUE, fg="white", font=FONT, selectcolor=BG_BLUE, activebackground=BG_BLUE, activeforeground="white", command=self.on_mode_change)
        rb_name.pack(anchor="w", padx=10, pady=(10, 2))
        
        self.cb_name = AutocompleteCombobox(left_fr, font=FONT, state="readonly")
        self.cb_name.pack(fill="x", padx=20, pady=2)
        
        # Display Button
        btn_display = tk.Button(left_fr, text="Display", bg="#2b579a", fg="white", font=FONT, relief="raised", bd=2, command=self.display_report)
        btn_display.pack(fill="x", padx=20, pady=40)
        
        # --- Right Panel Content ---
        self.report_header = tk.Frame(self.right_fr, bg=BG_WHITE)
        self.report_header.pack(fill="x", pady=10, padx=10)
        
        self.lbl_company = tk.Label(self.report_header, text=db.get_company_name().upper() if db.get_company_name() else "ALHUMDULILLAH", 
                                    font=("Segoe UI", 16, "bold"), bg=BG_WHITE, fg="#2b579a")
        self.lbl_company.pack(anchor="w")
        
        self.lbl_title = tk.Label(self.report_header, text=f"{self.title_text} As On {datetime.today().strftime('%Y-%m-%d')}", 
                                  font=("Segoe UI", 14, "bold"), bg=BG_WHITE, fg="black")
        self.lbl_title.pack(anchor="w")
        
        # Treeview
        tree_fr = tk.Frame(self.right_fr, bg=BG_WHITE)
        tree_fr.pack(fill="both", expand=True, padx=10, pady=10)
        
        columns = ("name", "col1", "col2", "col3", "col4", "col5", "total")
        self.tree = ttk.Treeview(tree_fr, columns=columns, show="headings", selectmode="none")
        
        entity_name = "CUSTOMER" if self.is_receivable else "SUPPLIER"
        self.tree.heading("name", text=entity_name)
        self.tree.heading("col1", text="0-14")
        self.tree.heading("col2", text="15-30")
        self.tree.heading("col3", text="31-60")
        self.tree.heading("col4", text="61-90")
        self.tree.heading("col5", text="90+")
        self.tree.heading("total", text="TOTAL")
        
        self.tree.column("name", width=200, minwidth=200, anchor="w", stretch=False)
        self.tree.column("col1", width=80, minwidth=80, anchor="e", stretch=False)
        self.tree.column("col2", width=80, minwidth=80, anchor="e", stretch=False)
        self.tree.column("col3", width=80, minwidth=80, anchor="e", stretch=False)
        self.tree.column("col4", width=80, minwidth=80, anchor="e", stretch=False)
        self.tree.column("col5", width=80, minwidth=80, anchor="e", stretch=False)
        self.tree.column("total", width=100, minwidth=100, anchor="e", stretch=False)
        
        scrollbar = ttk.Scrollbar(tree_fr, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)
        self.tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        self.tree.tag_configure("even", background="#f9f9f9")
        self.tree.tag_configure("odd", background="#ffffff")
        self.tree.tag_configure("bold", font=("Segoe UI", 10, "bold"), background="#f0f0f0")
        
        self.on_mode_change()
        
    def load_combos(self):
        conn = db.get_conn()
        base_group = "Sundry Debtors" if self.is_receivable else "Sundry Creditors"
        
        # Groups can be the base group itself or sub-groups (if we had a hierarchy, but usually just 'ALL')
        self.cb_group['values'] = ["ALL", base_group]
        self.cb_group.current(0)
        
        names = conn.execute("SELECT aname FROM account_detail WHERE account_group=?", (base_group)).fetchall()
        self.cb_name['values'] = ["ALL"] + [n['aname'] for n in names]
        self.cb_name.current(0)
        conn.close()
        
    def on_mode_change(self):
        if self.filter_mode.get() == "group":
            self.cb_group.config(state="readonly")
            self.cb_name.config(state="disabled")
        else:
            self.cb_group.config(state="disabled")
            self.cb_name.config(state="readonly")
            
    def display_report(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
            
        mode = self.filter_mode.get()
        is_group = (mode == "group")
        name_or_group = self.cb_group.get() if is_group else self.cb_name.get()
        
        as_on_date = datetime.today().strftime('%Y-%m-%d')
        
        data = db.get_aging_data(self.is_receivable, name_or_group, is_group, as_on_date)
        
        total_1, total_2, total_3, total_4, total_5, total_all = 0, 0, 0, 0, 0, 0
        
        for i, row in enumerate(data):
            tag = "even" if i % 2 == 0 else "odd"
            name = row['name']
            
            c1, c2, c3, c4, c5, tot = row['0-14'], row['15-30'], row['31-60'], row['61-90'], row['90+'], row['total']
            total_1 += c1
            total_2 += c2
            total_3 += c3
            total_4 += c4
            total_5 += c5
            total_all += tot
            
            f_c1 = f"{c1:,.0f}" if c1 > 0 else "0"
            f_c2 = f"{c2:,.0f}" if c2 > 0 else "0"
            f_c3 = f"{c3:,.0f}" if c3 > 0 else "0"
            f_c4 = f"{c4:,.0f}" if c4 > 0 else "0"
            f_c5 = f"{c5:,.0f}" if c5 > 0 else "0"
            f_tot = f"{tot:,.0f}" if tot > 0 else "0"
            
            self.tree.insert("", "end", values=(name, f_c1, f_c2, f_c3, f_c4, f_c5, f_tot), tags=(tag))
            
        self.tree.insert("", "end", values=("TOTAL", f"RS{total_1:,.0f}", f"RS{total_2:,.0f}", f"RS{total_3:,.0f}", f"RS{total_4:,.0f}", f"RS{total_5:,.0f}", f"RS{total_all:,.0f}"), tags=("bold"))

    def not_implemented(self):
        messagebox.showinfo("Coming Soon", "This feature is currently under development.")
