with open('bookkeeper.py', 'r', encoding='utf-8') as f:
    lines = f.readlines()

new_lines = []
skip = False
for i, line in enumerate(lines):
    if "nar_lbl = tk.Label(bot_frame, text=\"Narration" in line:
        skip = True
    
    if skip and "ref_box.pack(side=\"right\")" in line:
        skip = False
        continue # skip this line too
    if skip and "btn_frame = tk.Frame(ref_box, bg=BG)" in line:
        skip = False
        continue
    
    if not skip:
        new_lines.append(line)

with open('bookkeeper.py', 'w', encoding='utf-8') as f:
    f.writelines(new_lines)
print("Removed conflicting grid code")
