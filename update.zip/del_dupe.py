with open('bookkeeper.py', 'r', encoding='utf-8') as f:
    lines = f.readlines()

del_start = -1
del_end = -1
for i, line in enumerate(lines):
    if "        #  Grand total vars " in line:
        del_start = i
    if del_start != -1 and "        #  Grand total calculator " in line:
        del_end = i
        break

if del_start != -1 and del_end != -1:
    new_lines = lines[:del_start] + lines[del_end:]
    with open('bookkeeper.py', 'w', encoding='utf-8') as f:
        f.writelines(new_lines)
    print(f"Deleted from {del_start} to {del_end}")
else:
    print("Not found")
