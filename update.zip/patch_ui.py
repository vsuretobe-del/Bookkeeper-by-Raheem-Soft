import re

with open('bookkeeper.py', 'r', encoding='utf-8') as f:
    content = f.read()

# Replace bottom action buttons
old_buttons = '''        # \ufffd\ufffd\ufffd Bottom action bar buttons \ufffd\ufffd\ufffd
        make_button(bottom, "  Ctrl+Q: Exit  ",
                    command=win.destroy,
                    bg="#cc4444", fg="white").pack(side="left", padx=6, pady=6)
        make_button(bottom, "  Ctrl+F12: Save & Receive  ",
                    command=lambda: save_voucher(print_receipt=True),
                    bg="#1155bb", fg="white"
                    ).pack(side="right", padx=6, pady=6)
        make_button(bottom, "  Alt+F12: Save & View  ",
                    command=lambda: save_voucher(view_after=True),
                    bg="#e07830", fg="white"
                    ).pack(side="right", padx=6, pady=6)
        make_button(bottom, "  F12: Save  ",
                    command=save_voucher,
                    bg="#229944", fg="white"
                    ).pack(side="right", padx=6, pady=6)'''

# Using regex to match regardless of unicode replacement chars
old_buttons_re = r'# [^\n]*Bottom action bar buttons [^\n]*\n\s*make_button\(bottom, "  Ctrl\+Q: Exit  ",\s*command=win\.destroy,\s*bg="#cc4444", fg="white"\)\.pack\(side="left", padx=6, pady=6\)\n\s*make_button\(bottom, "  Ctrl\+F12: Save & Receive  ",\s*command=lambda: save_voucher\(print_receipt=True\),\s*bg="#1155bb", fg="white"\s*\)\.pack\(side="right", padx=6, pady=6\)\n\s*make_button\(bottom, "  Alt\+F12: Save & View  ",\s*command=lambda: save_voucher\(view_after=True\),\s*bg="#e07830", fg="white"\s*\)\.pack\(side="right", padx=6, pady=6\)\n\s*make_button\(bottom, "  F12: Save  ",\s*command=save_voucher,\s*bg="#229944", fg="white"\s*\)\.pack\(side="right", padx=6, pady=6\)'

new_buttons = '''        # Bottom action bar buttons
        tk.Button(bottom, text="Ctrl+Q: Exit", font=("Segoe UI", 9), command=win.destroy, bg="#e0e0e0", fg="#000", relief="flat", bd=1).pack(side="left", padx=6, pady=6)
        tk.Button(bottom, text="F12:Save", font=("Segoe UI", 9), command=save_voucher, bg="#e0e0e0", fg="#000", relief="flat", bd=1).pack(side="right", padx=6, pady=6)
        tk.Button(bottom, text="Alt+F12: Save & View", font=("Segoe UI", 9), command=lambda: save_voucher(view_after=True), bg="#e0e0e0", fg="#000", relief="flat", bd=1).pack(side="right", padx=6, pady=6)
        tk.Button(bottom, text="Ctrl+F12: Save & Receipt", font=("Segoe UI", 9), command=lambda: save_voucher(print_receipt=True), bg="#e0e0e0", fg="#000", relief="flat", bd=1).pack(side="right", padx=6, pady=6)'''

content = re.sub(old_buttons_re, new_buttons, content)

# Replace Amount row
old_amount = r'# [^\n]*Amount row [^\n]*\n\s*sum_row = tk\.Frame\(win, bg=BG\)\n\s*sum_row\.pack\(fill="x", side="bottom", padx=8, pady=2\)\n\s*amount_disp_var = tk\.StringVar\(value=""\)\n\s*tk\.Entry\(sum_row, textvariable=amount_disp_var, font=FONT,\n\s*width=20, relief="sunken", bd=2, bg=WHITE,\n\s*state="readonly"\)\.pack\(side="right", padx=\(4, 0\)\)\n\s*tk\.Label\(sum_row, text="Amount", bg=BG, font=FONT_BOLD\)\.pack\(side="right"\)'

new_amount = '''        # Amount row
        sum_row = tk.Frame(win, bg=BG)
        sum_row.pack(fill="x", side="bottom", padx=8, pady=2)
        
        amount_disp_var = tk.StringVar(value="")
        tk.Entry(sum_row, textvariable=amount_disp_var, font=FONT, justify="right",
                 width=16, relief="solid", bd=1, bg=WHITE,
                 state="readonly").pack(side="right", padx=(4, 0))
        tk.Label(sum_row, text="Amount", bg=BG, font=FONT).pack(side="right", padx=10)
        
        counts_frame = tk.Frame(sum_row, bg=WHITE, relief="solid", bd=1)
        counts_frame.pack(side="right", padx=40)
        count_var = tk.StringVar(value="Total Count: 0")
        qty_sum_var = tk.StringVar(value="Total Qty: 0")
        tk.Label(counts_frame, textvariable=count_var, bg=WHITE, font=FONT).pack(side="left", padx=5, pady=2)
        tk.Label(counts_frame, textvariable=qty_sum_var, bg=WHITE, font=FONT).pack(side="left", padx=5, pady=2)'''

content = re.sub(old_amount, new_amount, content)

# Replace bot_frame
old_bot = r'# [^\n]*Narration \+ totals section [^\n]*\n\s*bot_frame = tk\.Frame\(win, bg=BG\)\n\s*bot_frame\.pack\(fill="x", side="bottom", padx=8, pady=4\)'

new_bot = '''        # Narration + totals section
        bot_frame = tk.Frame(win, bg=BG)
        bot_frame.pack(fill="x", side="bottom", padx=8, pady=4)
        
        nar_lbl = tk.Label(bot_frame, text="Narration\\nCtrl+Enter for next line",
                           bg=BG, fg="#000", font=("Tahoma", 8, "italic"), justify="left")
        nar_lbl.grid(row=0, column=0, sticky="nw", padx=4, pady=4)
        nar_text = tk.Text(bot_frame, font=FONT, height=3, width=50, relief="solid", bd=1)
        nar_text.grid(row=0, column=1, padx=4, pady=4, sticky="nsew")

        rt_frame = tk.Frame(bot_frame, bg=BG)
        rt_frame.grid(row=0, column=2, sticky="ne", padx=(40, 0))
        
        tk.Label(rt_frame, text="Round Off", bg=BG, font=FONT).grid(row=0, column=0, sticky="e", pady=2)
        round_var = tk.StringVar(value="0")
        tk.Entry(rt_frame, textvariable=round_var, font=FONT, width=12, justify="right",
                 relief="solid", bd=1).grid(row=0, column=1, padx=4, pady=2)
        
        tk.Label(rt_frame, text="Total Amount", bg=BG, font=FONT).grid(row=1, column=0, sticky="e", pady=2)
        total_var = tk.StringVar(value="")
        tk.Entry(rt_frame, textvariable=total_var, font=(FONT[0], 10, "bold"), width=12, justify="right",
                 relief="solid", bd=1, state="readonly").grid(row=1, column=1, padx=4, pady=2)
        
        ref_frame = tk.Frame(rt_frame, bg=BG)
        ref_frame.grid(row=2, column=0, columnspan=2, sticky="e", pady=10)
        
        ref_box = tk.LabelFrame(ref_frame, text="Reference Document", bg=BG, font=("Tahoma", 8))
        ref_box.pack(side="right")
        
        tk.Entry(ref_box, bg=WHITE, width=28, relief="solid", bd=1).pack(padx=4, pady=2)
        btn_frame = tk.Frame(ref_box, bg=BG)
        btn_frame.pack(fill="x", pady=(0, 4))
        tk.Button(btn_frame, text="Browse", bg="#e0e0e0", relief="flat", bd=1).pack(side="left", padx=4, fill="x", expand=True)
        tk.Button(btn_frame, text="View", bg="#e0e0e0", relief="flat", bd=1).pack(side="left", padx=4, fill="x", expand=True)
        tk.Button(btn_frame, text="Delete", bg="#e0e0e0", relief="flat", bd=1).pack(side="left", padx=4, fill="x", expand=True)'''

content = re.sub(old_bot, new_bot, content)

# Replace recalc_total
old_recalc = r'def recalc_total\(\):\n\s*tot = sum\(float\(r\["value_v"\]\.get\(\) or 0\) for r in line_data\)\n\s*try:\n\s*roff = float\(round_var\.get\(\) or 0\)\n\s*except:\n\s*roff = 0\n\s*grand = tot \+ roff\n\s*total_var\.set\(f"\{grand:,\.2f\}"\)\n\s*amount_disp_var\.set\(f"\{grand:,\.2f\}"\)'

new_recalc = '''def recalc_total():
            tot = sum(float(r["value_v"].get() or 0) for r in line_data)
            count = len([r for r in line_data if r["item_v"].get().strip()])
            qty = sum(float(r["qty_v"].get() or 0) for r in line_data if r["item_v"].get().strip())
            try:
                roff = float(round_var.get() or 0)
            except:
                roff = 0
            grand = tot + roff
            total_var.set(f"{grand:,.0f}" if grand.is_integer() else f"{grand:,.2f}")
            amount_disp_var.set(f"{tot:,.0f}" if tot.is_integer() else f"{tot:,.2f}")
            count_var.set(f"Total Count: {count}")
            qty_sum_var.set(f"Total Qty: {qty:g}")'''

content = re.sub(old_recalc, new_recalc, content)

with open('bookkeeper.py', 'w', encoding='utf-8') as f:
    f.write(content)
print("Updated UI styling!")
