with open('bookkeeper.py', 'r', encoding='utf-8') as f:
    content = f.read()

import re
from autocomplete import AutocompleteCombobox

new_form = '''    def _item_form(self, existing=None):
        win = tk.Toplevel(self)
        win.title("Create Inventory Item" if not existing else "Edit Inventory Item")
        win.geometry("900x700")
        win.resizable(False, False)
        win.configure(bg="#ffffff")
        win.grab_set()

        # Top Bar
        top_frame = tk.Frame(win, bg="#f0f0f0", height=30)
        top_frame.pack(fill="x", side="top")
        tk.Label(top_frame, text="Alt+M: Category/Subcategory    Alt+U: New Unit Of Measure", bg="#f0f0f0", fg="#333", font=(FONT[0], 9)).place(x=10, y=5)

        main_frame = tk.Frame(win, bg="#ffffff")
        main_frame.pack(fill="both", expand=True)

        tk.Label(main_frame, text="Press ENTER to move forward  SHIFT+ENTER to move back.", 
                 fg="darkred", bg="#ffffff", font=(FONT[0], 10, "italic", "bold")).place(x=10, y=5)

        fields = {}
        widgets = []
        image_path_var = tk.StringVar(value="")

        def register_widget(w):
            widgets.append(w)
            w.bind("<Return>", lambda e: focus_next(w))
            w.bind("<Shift-Return>", lambda e: focus_prev(w))
            return w

        def focus_next(current):
            try:
                idx = widgets.index(current)
                widgets[(idx + 1) % len(widgets)].focus_set()
            except: pass
            return "break"

        def focus_prev(current):
            try:
                idx = widgets.index(current)
                widgets[(idx - 1) % len(widgets)].focus_set()
            except: pass
            return "break"

        def create_lbl(x, y, text, align="right", width=25):
            lbl = tk.Label(main_frame, text=text, bg="#ffffff", fg="#000", font=FONT, anchor="e" if align=="right" else "w", width=width)
            lbl.place(x=x, y=y)
            return lbl

        def create_entry(x, y, w, bg="#ffffff"):
            e = tk.Entry(main_frame, font=FONT, width=w, relief="solid", bd=1, bg=bg)
            e.place(x=x, y=y)
            return register_widget(e)
            
        def create_combo(x, y, w, vals):
            c = AutocompleteCombobox(main_frame, font=FONT, width=w-2, values=vals)
            c.place(x=x, y=y)
            return register_widget(c)

        # Left Column
        lbl_x = 10
        ent_x = 180
        
        create_lbl(lbl_x, 35, "Item Name", width=20)
        fields['item'] = create_entry(ent_x, 35, 35, bg="#ffff00")
        
        create_lbl(lbl_x, 65, "Item Code/SKU/HSN", width=20)
        fields['sku'] = create_entry(ent_x, 65, 35)
        
        create_lbl(lbl_x, 95, "Barcode", width=20)
        fields['barcode'] = create_entry(ent_x, 95, 35)
        
        create_lbl(lbl_x, 125, "Units Of Measure", width=20)
        fields['units_name'] = create_combo(ent_x, 125, 35, ["Numbers", "Kgs", "Liters", "Boxes", "Pieces"])
        fields['units_name'].set("Numbers")
        tk.Label(main_frame, text="(i)", bg="#ffffff", fg="#333", font=(FONT[0], 9, "bold")).place(x=ent_x+260, y=125)
        
        create_lbl(lbl_x, 155, "Item Description", width=20)
        desc_box = tk.Text(main_frame, width=35, height=4, font=FONT, relief="solid", bd=1)
        desc_box.place(x=ent_x, y=155)
        fields['item_desc'] = desc_box
        tk.Label(main_frame, text="(i)", bg="#ffffff", fg="#333", font=(FONT[0], 9, "bold")).place(x=ent_x+260, y=155)
        tk.Label(main_frame, text="Ctrl+Enter for next line", bg="#ffffff", fg="#000", font=(FONT[0], 8)).place(x=ent_x+130, y=230)
        
        create_lbl(lbl_x, 255, "Initial Quantity On Hand", width=20)
        fields['stock'] = create_entry(ent_x, 255, 35)
        fields['stock'].insert(0, "0")
        
        create_lbl(lbl_x, 285, "As Of Date", width=20)
        if DateEntry:
            de = DateEntry(main_frame, width=32, background='darkblue', foreground='white', borderwidth=2, font=FONT)
            de.place(x=ent_x, y=285)
            fields['date_created'] = register_widget(de)
        else:
            fields['date_created'] = create_entry(ent_x, 285, 35)
            fields['date_created'].insert(0, datetime.datetime.now().strftime("%B %d, %Y"))
        tk.Label(main_frame, text="You can't pass journal/voucher entries before this date.", bg="#ffffff", fg="#000", font=(FONT[0], 8)).place(x=ent_x, y=310)
        
        create_lbl(lbl_x, 335, "Initial Cost/Unit", width=20)
        fields['rate1'] = create_entry(ent_x, 335, 35)
        fields['rate1'].insert(0, "0")
        
        create_lbl(lbl_x, 365, "Value", width=20)
        fields['rate2'] = create_entry(ent_x, 365, 35)
        fields['rate2'].insert(0, "0")
        
        create_lbl(lbl_x, 415, "Minimum Order Quantity", width=20)
        fields['reorder_qty'] = create_entry(ent_x, 415, 35)
        fields['reorder_qty'].insert(0, "50")
        tk.Label(main_frame, text="(i)", bg="#ffffff", fg="#333", font=(FONT[0], 9, "bold")).place(x=ent_x+260, y=415)
        
        create_lbl(lbl_x, 455, "Item Category", width=20)
        fields['category'] = create_combo(ent_x, 455, 35, ["default"])
        fields['category'].set("default")
        
        create_lbl(lbl_x, 485, "Item Subcategory", width=20)
        fields['subcategory'] = create_combo(ent_x, 485, 35, ["default"])
        fields['subcategory'].set("default")
        
        create_lbl(lbl_x, 525, "Remarks", width=20)
        fields['remarks'] = create_entry(ent_x, 525, 35)
        tk.Label(main_frame, text="Remarks are for internal use only, it won't\\nbe displayed anywhere.", bg="#ffffff", fg="#000", font=(FONT[0], 8), justify="left").place(x=ent_x, y=550)

        # Right Column
        rx = 500
        
        tk.Label(main_frame, text="Item Image", bg="#ffffff", fg="#000", font=FONT).place(x=rx+30, y=10)
        img_lbl = tk.Label(main_frame, bg="#ffffff", relief="solid", bd=1, width=15, height=7)
        img_lbl.place(x=rx+120, y=10)
        
        def choose_image():
            from tkinter import filedialog
            import shutil, os
            try:
                from PIL import Image, ImageTk
                file_path = filedialog.askopenfilename(title="Select Image", filetypes=[("Image Files", "*.png;*.jpg;*.jpeg")])
                if file_path:
                    if not os.path.exists('images'): os.makedirs('images')
                    filename = os.path.basename(file_path)
                    dest = os.path.join('images', filename)
                    shutil.copy(file_path, dest)
                    image_path_var.set(dest)
                    
                    img = Image.open(dest)
                    img.thumbnail((100, 100))
                    photo = ImageTk.PhotoImage(img)
                    img_lbl.config(image=photo, width=100, height=100)
                    img_lbl.image = photo
            except Exception as e:
                messagebox.showerror("Error", str(e), parent=win)

        tk.Button(main_frame, text="??", bg="#ffffff", relief="flat", command=choose_image, font=(FONT[0], 16)).place(x=rx+80, y=40)
        tk.Button(main_frame, text="???", bg="#ffffff", relief="flat", command=lambda: [image_path_var.set(""), img_lbl.config(image="")], font=(FONT[0], 16)).place(x=rx+80, y=80)
        
        tax_info = "For nil rated items, select 0% tax\\nFor exempted items, don't select tax account."
        tk.Label(main_frame, text=tax_info, bg="#ffffff", fg="#000", font=(FONT[0], 9), justify="right").place(x=rx, y=140)
        
        create_lbl(rx-60, 190, "Default Tax Account", width=20)
        fields['tax_regn'] = create_combo(rx+100, 190, 25, ["VAT 0%", "VAT 5%", "VAT 15%"])
        
        create_lbl(rx-60, 220, "Additional Cess", width=20)
        fields['additional_cess'] = create_entry(rx+100, 220, 25)
        fields['additional_cess'].insert(0, "0")
        
        tk.Label(main_frame, text="Exclusive Tax", bg="#ffffff", fg="#000", font=FONT).place(x=rx+70, y=260)
        tk.Label(main_frame, text="Inclusive Tax", bg="#ffffff", fg="#000", font=FONT).place(x=rx+190, y=260)
        
        create_lbl(rx-80, 290, "Default Purchase Price", width=20)
        fields['defaultpurchaseprice'] = create_entry(rx+70, 290, 12)
        fields['defaultpurchaseprice'].insert(0, "0")
        inc_pur = create_entry(rx+190, 290, 12)
        inc_pur.insert(0, "0")
        
        create_lbl(rx-80, 320, "Default Sale Price", width=20)
        fields['defaultsellingprice'] = create_entry(rx+70, 320, 12)
        fields['defaultsellingprice'].insert(0, "0")
        inc_sal = create_entry(rx+190, 320, 12)
        inc_sal.insert(0, "0")
        
        create_lbl(rx-80, 350, "Default Discount %", width=20)
        fields['defaultdiscountpercent'] = create_entry(rx+70, 350, 12)
        fields['defaultdiscountpercent'].insert(0, "0")
        inc_dis = create_entry(rx+190, 350, 12)
        inc_dis.insert(0, "0")
        
        if existing:
            for k, w in fields.items():
                if k in existing and existing[k] is not None:
                    val_str = str(existing[k])
                    if isinstance(w, tk.Entry):
                        w.delete(0, 'end')
                        w.insert(0, val_str)
                    elif isinstance(w, AutocompleteCombobox):
                        w.set(val_str)
                    elif isinstance(w, tk.Text):
                        w.delete("1.0", "end")
                        w.insert("1.0", val_str)
            if existing.get('detail1'):
                image_path_var.set(existing['detail1'])
                try:
                    from PIL import Image, ImageTk
                    img = Image.open(existing['detail1'])
                    img.thumbnail((100, 100))
                    photo = ImageTk.PhotoImage(img)
                    img_lbl.config(image=photo, width=100, height=100)
                    img_lbl.image = photo
                except: pass

        def save(event=None):
            data = {}
            for k, w in fields.items():
                if k in ['category', 'subcategory']: continue
                if isinstance(w, tk.Text):
                    val = w.get("1.0", "end").strip()
                else:
                    val = w.get() if hasattr(w, 'get') else ''
                if isinstance(val, str): val = val.strip()
                data[k] = val

            data['detail1'] = image_path_var.get()

            if not data.get('item'):
                messagebox.showerror("Error", "Item Name is required!", parent=win)
                fields['item'].focus_set()
                return

            try:
                for k in ['stock', 'defaultpurchaseprice', 'defaultsellingprice', 'reorder_qty', 'additional_cess', 'defaultdiscountpercent', 'rate1', 'rate2']:
                    if data.get(k): data[k] = float(data[k])
            except ValueError:
                pass 

            try:
                if existing:
                    db.update_item(existing["id"], data)
                else:
                    db.add_item(data)
                win.destroy()
                self._item_list("Products")
            except Exception as e:
                messagebox.showerror("Database Error", str(e), parent=win)

        win.bind('<Control-q>', lambda e: win.destroy())
        win.bind('<F12>', save)

        bot_frame = tk.Frame(win, bg="#f0f0f0", height=40)
        bot_frame.pack(fill="x", side="bottom")
        tk.Button(bot_frame, text="Ctrl+Q: Exit", bg="#e0e0e0", font=FONT, command=win.destroy, relief="solid", bd=1).place(x=10, y=5, width=100, height=30)
        tk.Label(bot_frame, text="Video: Inventory Management", fg="blue", bg="#f0f0f0", font=(FONT[0], 9, "underline")).place(x=350, y=10)
        tk.Button(bot_frame, text="F12:Save", bg="#e0e0e0", font=FONT, command=save, relief="solid", bd=1).place(x=780, y=5, width=100, height=30)
        
        fields['item'].focus_set()
'''

pattern = re.compile(r"    def _item_form\(self, existing=None\):.*?        make_button\(bf, \"  \?\? Cancel  \", command=win\.destroy, width=10\)\.pack\(side=\"left\", padx=6\)", re.DOTALL)
content = pattern.sub(new_form, content)

with open('bookkeeper.py', 'w', encoding='utf-8') as f:
    f.write(content)
print("Replaced properly!")
