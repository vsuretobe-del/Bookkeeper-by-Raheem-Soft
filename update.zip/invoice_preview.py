import tkinter as tk
from tkinter import ttk, messagebox
import datetime
import os
import re
import urllib.parse
import urllib.request
import webbrowser
import openpyxl
from PIL import Image, ImageDraw, ImageFont, ImageTk
import db

def create_paid_stamp_image():
    """Generates an ultra-crisp rotated red 'PAID' stamp with a bold border."""
    scale = 3
    w, h = 130 * scale, 55 * scale
    pad = 30 * scale
    img = Image.new("RGBA", (w + pad * 2, h + pad * 2), (255, 255, 255, 0))
    draw = ImageDraw.Draw(img)

    # Stamp border rectangle
    rect = [pad, pad, pad + w, pad + h]
    border_w = 4 * scale
    draw.rectangle(rect, outline="#e52b2b", width=border_w)

    # Text rendering
    try:
        font = ImageFont.truetype("arialbd.ttf", 34 * scale)
    except Exception:
        try:
            font = ImageFont.truetype("Arial Bold.ttf", 34 * scale)
        except Exception:
            font = ImageFont.load_default()

    text = "PAID"
    bbox = draw.textbbox((0, 0), text, font=font)
    tw = bbox[2] - bbox[0]
    th = bbox[3] - bbox[1]
    tx = rect[0] + (w - tw) / 2
    ty = rect[1] + (h - th) / 2 - (4 * scale)
    draw.text((tx, ty), text, fill="#e52b2b", font=font)

    # Rotate by 20 degrees counter-clockwise
    rotated = img.rotate(20, expand=True, resample=Image.BICUBIC)
    
    # Scale down for smooth anti-aliasing
    final_w = int(rotated.width / scale)
    final_h = int(rotated.height / scale)
    return rotated.resize((final_w, final_h), Image.LANCZOS)


def get_doc_config(doc_type_raw):
    dt = str(doc_type_raw or "sale").lower().strip()
    if dt in ("purchase_order", "po"):
        return {
            "key": "purchase_order",
            "title": "Purchase Order",
            "party_label": "Vendor / Supplier:",
            "doc_no_label": "Purchase Order No:",
            "show_paid_status": False,
            "declaration": "Please deliver the above goods/services as per agreed terms and conditions.",
            "signatory": "Authorized Signatory"
        }
    elif dt in ("estimate", "quotation", "quote"):
        return {
            "key": "estimate",
            "title": "Estimate / Quotation",
            "party_label": "Estimate To:",
            "doc_no_label": "Estimate No:",
            "show_paid_status": False,
            "declaration": "This is a quotation estimate, not a tax invoice. Rates are valid for 30 days.",
            "signatory": "Authorized Signatory"
        }
    elif dt in ("purchase", "pur"):
        return {
            "key": "purchase",
            "title": "Purchase Invoice",
            "party_label": "Vendor / Supplier:",
            "doc_no_label": "Purchase No:",
            "show_paid_status": True,
            "declaration": "We acknowledge receipt of goods/services as per the details stated above.",
            "signatory": "Authorized Signatory"
        }
    elif dt in ("delivery_note", "delivery", "challan"):
        return {
            "key": "delivery_note",
            "title": "Delivery Note",
            "party_label": "Delivered To:",
            "doc_no_label": "Delivery Note No:",
            "show_paid_status": False,
            "declaration": "Received the above mentioned goods in good order and condition.",
            "signatory": "Receiver's Signature & Stamp"
        }
    elif dt in ("credit_note", "credit"):
        return {
            "key": "credit_note",
            "title": "Credit Note",
            "party_label": "Customer:",
            "doc_no_label": "Credit Note No:",
            "show_paid_status": True,
            "declaration": "Credit note issued against returned goods or price adjustment.",
            "signatory": "Authorized Signatory"
        }
    elif dt in ("debit_note", "debit"):
        return {
            "key": "debit_note",
            "title": "Debit Note",
            "party_label": "Vendor / Supplier:",
            "doc_no_label": "Debit Note No:",
            "show_paid_status": True,
            "declaration": "Debit note issued against returned goods or price adjustment.",
            "signatory": "Authorized Signatory"
        }
    elif dt in ("expense", "payment"):
        return {
            "key": "expense",
            "title": "Expense",
            "party_label": "Paid To:",
            "doc_no_label": "Payment No.",
            "show_paid_status": False,
            "declaration": "",
            "signatory": "Authorized Signatory"
        }
    elif dt in ("income", "receipt"):
        return {
            "key": "income",
            "title": "Income",
            "party_label": "Received From:",
            "doc_no_label": "Receipt No.",
            "show_paid_status": False,
            "declaration": "",
            "signatory": "Authorized Signatory"
        }
    elif dt in ("journal",):
        return {
            "key": "journal",
            "title": "Journal",
            "party_label": "Account / Narration:",
            "doc_no_label": "Journal No.",
            "show_paid_status": False,
            "declaration": "",
            "signatory": "Authorized Signatory"
        }
    elif dt in ("contra", "banking"):
        return {
            "key": "contra",
            "title": "Contra",
            "party_label": "Account / Transfer Details:",
            "doc_no_label": "Contra No.",
            "show_paid_status": False,
            "declaration": "",
            "signatory": "Authorized Signatory"
        }
    else:
        return {
            "key": "sale",
            "title": "Sales Invoice",
            "party_label": "Bill To:",
            "doc_no_label": "Invoice No:",
            "show_paid_status": True,
            "declaration": "We declare that this invoice shows the actual price of the goods described and that all particulars are true and correct.",
            "signatory": "Authorized Signatory"
        }


def fmt_n(n):
    if n is None or n == "" or n == 0:
        return ""
    try:
        f = float(n)
        return f"{f:,.0f}" if f.is_integer() else f"{f:,.2f}"
    except Exception:
        return str(n)


def fmt_cur(n):
    if n is None or n == "":
        return "Rs0"
    try:
        f = float(n)
        s = f"{f:,.0f}" if f.is_integer() else f"{f:,.2f}"
        return f"Rs{s}"
    except Exception:
        return f"Rs{n}"


def show_invoice_preview(parent, inv_data, db_module=None, doc_type=None, auto_print=False):
    if db_module is None:
        db_module = db

    # Determine document type configuration
    raw_type = doc_type or inv_data.get('type') or 'sale'
    doc_cfg = get_doc_config(raw_type)
    doc_title = doc_cfg["title"]
    party_label = doc_cfg["party_label"]
    doc_no_label = doc_cfg["doc_no_label"]
    show_paid_status = doc_cfg["show_paid_status"]
    doc_declaration = doc_cfg["declaration"]
    doc_signatory = doc_cfg["signatory"]
    is_voucher = doc_cfg["key"] in ("expense", "income", "contra", "journal", "payment", "receipt")

    v_id = inv_data.get('id') or inv_data.get('v_id')
    inv_no = str(inv_data.get('invoice_no') or inv_data.get('vch_no') or '')
    inv_date = str(inv_data.get('date') or '')

    # Base64 helper for images
    def get_base64_image(path):
        import os, base64
        if not path or not os.path.exists(path): return ""
        try:
            with open(path, "rb") as img_file:
                ext = os.path.splitext(path)[1].lower()
                mime = "image/png" if ext == ".png" else "image/jpeg"
                return f"data:{mime};base64,{base64.b64encode(img_file.read()).decode('utf-8')}"
        except: return ""

    # Company info
    try:
        conn = db_module.get_conn()
        conn.row_factory = __import__('sqlite3').Row
        c_row = conn.execute("SELECT c_name FROM company LIMIT 1").fetchone()
        conn.close()
        company_name = c_row['c_name'] if c_row and c_row['c_name'] else "ALHUMDULILLAH"
    except Exception:
        company_name = db_module.get_setting("company_company_name") or "ALHUMDULILLAH"

    company_email = db_module.get_setting("company_email") or ""
    company_address = db_module.get_setting("company_address1") or ""
    if db_module.get_setting("company_address2"):
        company_address += " " + db_module.get_setting("company_address2")
    company_phone = db_module.get_setting("company_phone") or ""
    
    logo_b64 = get_base64_image(db_module.get_setting("company_logo_path"))
    sig_b64 = get_base64_image(db_module.get_setting("company_sig_path"))
    
    show_disc_col = db_module.get_setting("tmpl_tbl_show_disc", "1") == "1"
    show_tax_col = db_module.get_setting("tmpl_tbl_show_tax", "1") == "1"

    # ─────────────────────────────────────────────────────────────────────────
    # VOUCHER ACCOUNTING DATA PREPARATION (Income / Expense / Contra / Journal)
    # ─────────────────────────────────────────────────────────────────────────
    if is_voucher:
        va_rows = []
        narration_val = str(inv_data.get('notes') or inv_data.get('narration') or '')
        ref_doc_val = str(inv_data.get('ref_doc') or inv_data.get('detail2') or '')
        if v_id:
            try:
                conn = db_module.get_conn()
                conn.row_factory = __import__('sqlite3').Row
                v_row = conn.execute("SELECT * FROM vouchers WHERE v_id=?", (v_id,)).fetchone()
                if v_row:
                    if not inv_no: inv_no = str(v_row['vch_no'] or '')
                    if not inv_date: inv_date = str(v_row['date'] or '')
                    if not narration_val and v_row['narration']:
                        narration_val = str(v_row['narration'])
                    if not ref_doc_val and v_row['detail2']:
                        ref_doc_val = str(v_row['detail2'])
                va_rows = [dict(r) for r in conn.execute("SELECT debit, credit, amount FROM vouchers_all WHERE v_id=?", (v_id,)).fetchall()]
                conn.close()
            except Exception:
                va_rows = []

        if not va_rows:
            raw_items = inv_data.get('items') or inv_data.get('line_items') or []
            if doc_cfg['key'] in ('expense', 'payment'):
                p_from = inv_data.get('paid_from') or inv_data.get('credit') or 'Cash'
                if raw_items:
                    for it in raw_items:
                        name = it.get('name') or it.get('item_name') or 'Expense'
                        amt = float(it.get('total') or it.get('price') or it.get('amount') or 0)
                        va_rows.append({'debit': name, 'credit': p_from, 'amount': amt})
                else:
                    p_to = inv_data.get('paid_to') or inv_data.get('account_name') or 'Expense'
                    tot = float(inv_data.get('total') or inv_data.get('amount') or 0)
                    va_rows.append({'debit': p_to, 'credit': p_from, 'amount': tot})
            elif doc_cfg['key'] in ('income', 'receipt'):
                r_into = inv_data.get('received_into') or inv_data.get('paid_from') or inv_data.get('debit') or 'Cash'
                if raw_items:
                    for it in raw_items:
                        name = it.get('name') or it.get('item_name') or 'Income'
                        amt = float(it.get('total') or it.get('price') or it.get('amount') or 0)
                        va_rows.append({'debit': r_into, 'credit': name, 'amount': amt})
                else:
                    r_from = inv_data.get('received_from') or inv_data.get('account_name') or 'Sales'
                    tot = float(inv_data.get('total') or inv_data.get('amount') or 0)
                    va_rows.append({'debit': r_into, 'credit': r_from, 'amount': tot})
            else:
                p_from = inv_data.get('from_account') or inv_data.get('credit') or 'Cash'
                p_to = inv_data.get('to_account') or inv_data.get('debit') or 'Bank'
                tot = float(inv_data.get('total') or inv_data.get('amount') or 0)
                va_rows.append({'debit': p_to, 'credit': p_from, 'amount': tot})

        if doc_cfg['key'] in ('expense', 'payment'):
            group1_title = "Paid From"
            group1_col = "credit"
            group2_title = "Paid To"
            group2_col = "debit"

            cred_map = {}
            for r in va_rows:
                acc = r['credit'] or 'Cash'
                cred_map[acc] = cred_map.get(acc, 0.0) + float(r['amount'] or 0)
            group1_items = [(acc, amt) for acc, amt in cred_map.items()]
            group2_items = [(r['debit'] or 'Expense', float(r['amount'] or 0)) for r in va_rows]
            tot_debit = sum(amt for _, amt in group2_items)
            tot_credit = sum(amt for _, amt in group1_items)

        elif doc_cfg['key'] in ('income', 'receipt'):
            group1_title = "Received Into"
            group1_col = "debit"
            group2_title = "Received From"
            group2_col = "credit"

            deb_map = {}
            for r in va_rows:
                acc = r['debit'] or 'Cash'
                deb_map[acc] = deb_map.get(acc, 0.0) + float(r['amount'] or 0)
            group1_items = [(acc, amt) for acc, amt in deb_map.items()]
            group2_items = [(r['credit'] or 'Sales', float(r['amount'] or 0)) for r in va_rows]
            tot_debit = sum(amt for _, amt in group1_items)
            tot_credit = sum(amt for _, amt in group2_items)

        elif doc_cfg['key'] == 'contra':
            group1_title = "From"
            group1_col = "credit"
            group2_title = "To"
            group2_col = "debit"

            deb_map = {}
            cred_map = {}
            for r in va_rows:
                d_acc = r['debit'] or 'Cash'
                c_acc = r['credit'] or 'Bank'
                deb_map[d_acc] = deb_map.get(d_acc, 0.0) + float(r['amount'] or 0)
                cred_map[c_acc] = cred_map.get(c_acc, 0.0) + float(r['amount'] or 0)
            group1_items = [(acc, amt) for acc, amt in cred_map.items()]
            group2_items = [(acc, amt) for acc, amt in deb_map.items()]
            tot_debit = sum(amt for _, amt in group2_items)
            tot_credit = sum(amt for _, amt in group1_items)

        else: # journal
            group1_title = "Debit"
            group1_col = "debit"
            group2_title = "Credit"
            group2_col = "credit"
            group1_items = [(r['debit'], float(r['amount'] or 0)) for r in va_rows if r.get('debit')]
            group2_items = [(r['credit'], float(r['amount'] or 0)) for r in va_rows if r.get('credit')]
            tot_debit = sum(amt for _, amt in group1_items)
            tot_credit = sum(amt for _, amt in group2_items)

        total_val = max(tot_debit, tot_credit)
    else:
        # Standard invoice data preparation
        if not inv_data.get('items'):
            if v_id:
                try:
                    inv_data['items'] = db_module.get_invoice_items(v_id)
                except Exception:
                    inv_data['items'] = []

        if not inv_data.get('items'):
            tot = float(inv_data.get('total') or 0)
            desc_text = inv_data.get('desc') or inv_data.get('narration') or inv_data.get('notes') or 'Item'
            inv_data['items'] = [{
                'item_name': desc_text,
                'qty': 1,
                'unit': 'nos',
                'price': tot,
                'discount': 0,
                'tax_pct': '',
                'total': tot
            }]

        total_val = float(inv_data.get('total') or 0)
        paid_val = float(inv_data.get('paid') if inv_data.get('paid') is not None else total_val)
        due_val = float(inv_data.get('due') if inv_data.get('due') is not None else (total_val - paid_val))
        advance_val = 0.0
        inv_no = inv_data.get('invoice_no')
        if inv_no:
            try:
                # 'db' module is already imported or passed as db_module
                conn = db_module.get_conn()
                adv_row = conn.execute("SELECT amount FROM vouchers WHERE v_type='receipt' AND narration LIKE ?", (f"%Advance for invoice {inv_no}%",)).fetchone()
                if adv_row:
                    advance_val = float(adv_row[0] or 0)
                conn.close()
            except Exception:
                pass
        is_paid = show_paid_status and (due_val <= 0 and total_val > 0)

        party_name = inv_data.get('account_name') or inv_data.get('debit') or inv_data.get('credit') or 'Cash'
        if '\n' in party_name:
            p_lines = [l.strip() for l in party_name.split('\n') if l.strip()]
            if doc_cfg['key'] in ('purchase', 'purchase_order', 'debit_note'):
                party_name = p_lines[-1] if len(p_lines) > 1 else p_lines[0]
            else:
                party_name = p_lines[0]

        has_discount = any(float(it.get('discount') or 0) > 0 for it in inv_data['items'])
        has_tax = any(bool(it.get('tax_pct')) for it in inv_data['items'])
        show_disc_tax = has_discount or has_tax

        if show_disc_tax:
            col_specs = [
                ("#", 38, "center"),
                ("Description", 280, "w"),
                ("QTY", 85, "center"),
                ("Rate", 95, "e"),
                ("Discount", 65, "center"),
                ("Tax", 65, "center"),
                ("Amount", 120, "e")
            ]
        else:
            col_specs = [
                ("#", 38, "center"),
                ("Description", 380, "w"),
                ("QTY", 95, "center"),
                ("Rate", 110, "e"),
                ("Amount", 140, "e")
            ]

        total_qty = sum(float(it.get('qty') or 0) for it in inv_data['items'])
        subtotal_val = sum(float(it.get('qty') or 0) * float(it.get('price') or 0) for it in inv_data['items'])

    # Window creation
    win = tk.Toplevel(parent)
    win.title(doc_title)
    win.geometry("1120x800")
    win.minsize(980, 650)
    win.configure(bg="#f0f0f0")
    win.transient(parent)
    win.grab_set()

    def get_safe_filename(prefix, ext):
        raw_inv_no = str(inv_no or inv_data.get('invoice_no') or 'doc')
        safe_inv_no = re.sub(r'[\/:*?\"<>|\\ ]', '_', raw_inv_no)
        doc_prefix = doc_cfg["key"]
        return f"{doc_prefix}_{safe_inv_no}_{prefix}.{ext}" if prefix else f"{doc_prefix}_{safe_inv_no}.{ext}"

    # ─────────────────────────────────────────────────────────────────────────
    # EXPORT & GENERATION HELPERS
    # ─────────────────────────────────────────────────────────────────────────
    def generate_html():
        if is_voucher:
            body_rows_html = ""
            # Group 1 Header
            body_rows_html += f"""
            <tr>
                <td style="border-right: 1.5px solid #000; padding: 4px 12px; font-weight: bold; font-style: italic; text-align: left;">{group1_title}</td>
                <td style="border-right: 1.5px solid #000; padding: 4px 12px; text-align: right;"></td>
                <td style="padding: 4px 12px; text-align: right;"></td>
            </tr>
            """
            for acc, amt in group1_items:
                d_val = fmt_n(amt) if group1_col == 'debit' else ''
                c_val = fmt_n(amt) if group1_col == 'credit' else ''
                body_rows_html += f"""
            <tr>
                <td style="border-right: 1.5px solid #000; padding: 4px 12px 4px 32px; text-align: left;">{acc}</td>
                <td style="border-right: 1.5px solid #000; padding: 4px 12px; text-align: right;">{d_val}</td>
                <td style="padding: 4px 12px; text-align: right;">{c_val}</td>
            </tr>
            """
            # Group 2 Header
            body_rows_html += f"""
            <tr>
                <td style="border-right: 1.5px solid #000; padding: 4px 12px; font-weight: bold; font-style: italic; text-align: left;">{group2_title}</td>
                <td style="border-right: 1.5px solid #000; padding: 4px 12px; text-align: right;"></td>
                <td style="padding: 4px 12px; text-align: right;"></td>
            </tr>
            """
            for acc, amt in group2_items:
                d_val = fmt_n(amt) if group2_col == 'debit' else ''
                c_val = fmt_n(amt) if group2_col == 'credit' else ''
                body_rows_html += f"""
            <tr>
                <td style="border-right: 1.5px solid #000; padding: 4px 12px 4px 32px; text-align: left;">{acc}</td>
                <td style="border-right: 1.5px solid #000; padding: 4px 12px; text-align: right;">{d_val}</td>
                <td style="padding: 4px 12px; text-align: right;">{c_val}</td>
            </tr>
            """

            html = f"""<!DOCTYPE html>
            <html>
            <head>
                <meta charset="utf-8"/>
                <title>{doc_title} - {inv_no}</title>
                <style>
                    @page {{
                        size: A4 portrait;
                        margin: 15mm;
                    }}
                    body {{
                        font-family: 'Segoe UI', Arial, sans-serif;
                        margin: 0;
                        padding: 20px;
                        background-color: #f5f5f5;
                        color: #000;
                        font-size: 13px;
                    }}
                    .voucher-page {{
                        background: #fff;
                        max-width: 820px;
                        margin: 0 auto;
                        padding: 35px 40px 60px 40px;
                        border: 1px solid #ccc;
                        box-shadow: 0 0 10px rgba(0,0,0,0.1);
                    }}
                    .company-header {{
                        text-align: center;
                        margin-bottom: 20px;
                    }}
                    .company-name {{
                        font-size: 20px;
                        font-weight: bold;
                        text-transform: uppercase;
                        margin-bottom: 4px;
                    }}
                    .company-email {{
                        font-size: 12px;
                        color: #222;
                        margin-bottom: 12px;
                    }}
                    .doc-title {{
                        font-size: 20px;
                        font-weight: bold;
                        margin-top: 10px;
                        margin-bottom: 15px;
                        text-align: center;
                    }}
                    .voucher-box {{
                        border: 1.5px solid #000;
                        width: 100%;
                        border-collapse: collapse;
                    }}
                    .meta-header-row td {{
                        text-align: right;
                        padding: 8px 12px;
                        font-size: 13px;
                        border-bottom: 1.5px solid #000;
                        line-height: 1.4;
                    }}
                    .th-row th {{
                        border-bottom: 1.5px solid #000;
                        border-right: 1.5px solid #000;
                        padding: 6px 12px;
                        font-size: 13px;
                        font-weight: bold;
                    }}
                    .th-row th:last-child {{
                        border-right: none;
                    }}
                    .tot-row td {{
                        border-top: 1.5px solid #000;
                        font-weight: bold;
                        padding: 6px 12px;
                    }}
                    .signatory-container {{
                        margin-top: 60px;
                        text-align: right;
                        font-size: 13px;
                        font-weight: bold;
                        padding-right: 10px;
                    }}
                </style>
            </head>
            <body>
                <div class="voucher-page">
                    <div class="company-header">
                        <div class="company-name">{company_name}</div>
                        <div class="company-email">&#9993; {company_email}</div>
                        <div class="doc-title">{doc_title}</div>
                    </div>

                    <table class="voucher-box">
                        <tr class="meta-header-row">
                            <td colspan="3">
                                <strong>{doc_no_label} {inv_no}</strong><br/>
                                Dated: {inv_date}{f'<br/>Ref Doc: {ref_doc_val}' if ref_doc_val else ''}
                            </td>
                        </tr>
                        <tr class="th-row">
                            <th style="width: 66%; text-align: left;">Particulars</th>
                            <th style="width: 17%; text-align: right;">Debit</th>
                            <th style="width: 17%; text-align: right;">Credit</th>
                        </tr>
                        {body_rows_html}
                        <tr class="tot-row">
                            <td style="border-right: 1.5px solid #000; text-align: left;">Total</td>
                            <td style="border-right: 1.5px solid #000; text-align: right;">{fmt_cur(tot_debit)}</td>
                            <td style="text-align: right;">{fmt_cur(tot_credit)}</td>
                        </tr>
                        {f'<tr><td colspan="3" style="border-top: 1.5px solid #000; padding: 8px 12px; font-style: italic; font-size: 12px; text-align: left; background: #fafafa;"><strong>Narration / Remarks:</strong> {narration_val}</td></tr>' if narration_val else ''}
                    </table>

                    <div class="signatory-container">
                        Authorized Signatory
                    </div>
                </div>

                <script>
                    if (window.location.search.indexOf('print=1') > -1) {{
                        window.print();
                    }}
                </script>
            </body>
            </html>
            """
            return html
        else:
            # Commercial Invoices (Sales / Purchase / PO / Estimate, etc.)
            items_rows_html = ""
            for idx, it in enumerate(inv_data['items']):
                q = float(it.get('qty') or 0)
                p = float(it.get('price') or 0)
                amt = float(it.get('total') or (q * p))
                
                unit = it.get('unit') or 'pc'
                q_str = f"{q:,.0f} {unit}" if q.is_integer() else f"{q:,.2f} {unit}"
                p_str = f"{p:,.0f}" if p.is_integer() else f"{p:,.2f}"
                amt_str = f"{amt:,.0f}" if amt.is_integer() else f"{amt:,.2f}"
                
                disc_val = it.get('discount') or '0'
                tax_val = it.get('tax_pct') or ''

                desc_lines = []
                name = it.get('item_name') or it.get('name') or ''
                if name: desc_lines.append(name)
                desc_extra = it.get('desc') or ''
                if desc_extra and desc_extra != name:
                    desc_lines.append(desc_extra)
                remarks = it.get('remarks') or ''
                if remarks:
                    desc_lines.append(f"Remarks:<br/>{remarks}")
                full_desc_html = "<br/>".join(desc_lines) if desc_lines else name

                # Columns construction
                td_html = f'<td style="border: 1px solid #000; text-align: center; padding: 6px 4px;">{idx+1}</td>'
                td_html += f'<td style="border: 1px solid #000; text-align: left; padding: 6px 6px;">{full_desc_html}</td>'
                td_html += f'<td style="border: 1px solid #000; text-align: center; padding: 6px 4px;">{q_str}</td>'
                td_html += f'<td style="border: 1px solid #000; text-align: right; padding: 6px 6px;">{p_str}</td>'
                
                if show_disc_col:
                    td_html += f'<td style="border: 1px solid #000; text-align: center; padding: 6px 4px;">{disc_val}</td>'
                if show_tax_col:
                    td_html += f'<td style="border: 1px solid #000; text-align: center; padding: 6px 4px;">{tax_val}</td>'
                
                td_html += f'<td style="border: 1px solid #000; text-align: right; padding: 6px 6px;">{amt_str}</td>'
                
                items_rows_html += f"<tr>{td_html}</tr>"

            # Headers
            th_html = '<th style="border: 1px solid #000; width: 35px; text-align: center; padding: 6px 2px;">#</th>'
            th_html += '<th style="border: 1px solid #000; text-align: left; padding: 6px;">Description</th>'
            th_html += '<th style="border: 1px solid #000; width: 80px; text-align: center; padding: 6px 2px;">QTY</th>'
            th_html += '<th style="border: 1px solid #000; width: 85px; text-align: right; padding: 6px;">Rate</th>'
            
            cols_count = 5
            if show_disc_col:
                th_html += '<th style="border: 1px solid #000; width: 65px; text-align: center; padding: 6px 2px;">Discount</th>'
                cols_count += 1
            if show_tax_col:
                th_html += '<th style="border: 1px solid #000; width: 50px; text-align: center; padding: 6px 2px;">Tax</th>'
                cols_count += 1
                
            th_html += '<th style="border: 1px solid #000; width: 105px; text-align: right; padding: 6px;">Amount</th>'
            
            span_sub = cols_count - 2
            span_tot_left = span_sub - 1
            span_tot_mid = 2

            t_qty_str = f"{total_qty:,.0f}" if total_qty.is_integer() else f"{total_qty:,.2f}"
            sub_str = f"{subtotal_val:,.0f}" if subtotal_val.is_integer() else f"{subtotal_val:,.2f}"
            tot_str = f"Rs{total_val:,.0f}" if total_val.is_integer() else f"Rs{total_val:,.2f}"
            
            disc_tot = sum(float(it.get('discount_amt') or 0) for it in inv_data['items'])
            disc_tot_str = f"{disc_tot:,.0f}" if disc_tot.is_integer() else f"{disc_tot:,.2f}"

            bal_color = "#c00000" if due_val > 0 else "#008000" if due_val < 0 else "#000000"
            bal_str = f"Rs{due_val:,.0f}" if due_val.is_integer() else f"Rs{due_val:,.2f}"
            
            paid_stamp_html = ""
            if is_paid:
                paid_stamp_html = """
                <div class="paid-stamp-box">
                    <div class="paid-stamp">PAID</div>
                </div>
                """

            # Build Header HTML
            logo_html = f'<img src="{logo_b64}" style="max-height: 80px; max-width: 150px;"/>' if logo_b64 else ''
            header_html = f"""
                <table style="width: 100%; margin-bottom: 20px;">
                    <tr>
                        <td style="width: 25%; vertical-align: middle;">{logo_html}</td>
                        <td style="width: 50%; text-align: center; vertical-align: middle;">
                            <div style="font-size: 20px; font-weight: bold; margin-bottom: 4px;">{company_name}</div>
                            <div style="font-size: 13px;">{company_address}</div>
                            <div style="font-size: 13px;">&#9993; {company_email} , &#9742; {company_phone}</div>
                        </td>
                        <td style="width: 25%;"></td>
                    </tr>
                </table>
            """
            
            # Build Meta Box HTML
            meta_html = f"""
                <table style="width: 100%; border-collapse: collapse; border: 1.5px solid #000; margin-bottom: -1px;">
                    <tr>
                        <td style="width: 50%; border-right: 1px solid #000; padding: 6px 8px; vertical-align: top;">
                            <strong>{party_label}</strong><br/>
                            <span style="font-size: 14px; font-weight: bold;">{party_name}</span>
                        </td>
                        <td style="width: 50%; padding: 6px 8px; text-align: right; vertical-align: top;">
                            <strong>{doc_no_label} {inv_data.get('invoice_no', '')}</strong><br/>
                            <strong>Dated: {inv_data.get('date', '')}</strong>
                        </td>
                    </tr>
                </table>
            """
            
            sig_html = f'<img src="{sig_b64}" style="max-height: 50px; max-width: 120px; margin-bottom: 5px;"/>' if sig_b64 else '<div style="height: 50px;"></div>'
            footer_html = f"""
                <table style="width: 100%; margin-top: 30px; border-collapse: collapse;">
                    <tr>
                        <td style="width: 60%; vertical-align: bottom; font-size: 12px;">
                            {doc_declaration}<br/>
                            This is a computer generated document.
                        </td>
                        <td style="width: 40%; text-align: right; vertical-align: bottom;">
                            {sig_html}<br/>
                            {doc_signatory}
                        </td>
                    </tr>
                </table>
            """

            html = f"""<!DOCTYPE html>
            <html>
            <head>
                <meta charset="utf-8"/>
                <title>{doc_title} - {inv_data.get('invoice_no', '')}</title>
                <style>
                    @page {{
                        size: A4;
                        margin: 15mm;
                    }}
                    body {{
                        font-family: 'Segoe UI', Arial, sans-serif;
                        margin: 0;
                        padding: 20px;
                        background-color: #f5f5f5;
                        color: #000;
                        font-size: 13px;
                    }}
                    .invoice-page {{
                        background: #fff;
                        max-width: 800px;
                        margin: 0 auto;
                        padding: 30px;
                        border: 1px solid #ccc;
                        box-shadow: 0 0 10px rgba(0,0,0,0.1);
                        position: relative;
                    }}
                    .doc-title {{
                        font-size: 20px;
                        font-weight: bold;
                        color: #000;
                        text-align: center;
                        margin-bottom: 10px;
                    }}
                    .items-table {{
                        width: 100%;
                        border-collapse: collapse;
                        border: 1.5px solid #000;
                    }}
                    .paid-stamp-box {{
                        position: absolute;
                        top: 55%;
                        left: 12%;
                        transform: rotate(-18deg);
                        pointer-events: none;
                    }}
                    .paid-stamp {{
                        border: 4px solid #e52b2b;
                        color: #e52b2b;
                        font-size: 32px;
                        font-weight: bold;
                        padding: 6px 20px;
                        letter-spacing: 2px;
                        opacity: 0.9;
                        border-radius: 4px;
                    }}
                </style>
            </head>
            <body>
                <div class="invoice-page">
                    {paid_stamp_html}
                    {header_html}
                    <div class="doc-title">{doc_title}</div>
                    {meta_html}

                    <table class="items-table">
                        <thead>
                            <tr style="background: #ffffff;">
                                {th_html}
                            </tr>
                        </thead>
                        <tbody>
                            {items_rows_html}
                            <tr>
                                <td colspan="{span_sub}" style="border: 1px solid #000; border-top: 1.5px solid #000; text-align: right; font-weight: bold; padding: 4px 8px;">Sub Total</td>
                                <td style="border: 1px solid #000; border-top: 1.5px solid #000; text-align: right; font-weight: bold; padding: 4px 8px;">{sub_str}</td>
                            </tr>
                            <tr>
                                <td colspan="{span_sub}" style="border: 1px solid #000; text-align: right; font-weight: bold; padding: 4px 8px;">Discount</td>
                                <td style="border: 1px solid #000; text-align: right; font-weight: bold; padding: 4px 8px;">{disc_tot_str}</td>
                            </tr>
                            <tr>
                                <td colspan="{span_tot_left}" style="border: 1px solid #000; text-align: left; font-weight: bold; padding: 6px 8px;">Total</td>
                                <td style="border: 1px solid #000; text-align: center; font-weight: bold; padding: 6px 2px;">{t_qty_str}</td>
                                <td colspan="{span_tot_mid}" style="border: 1px solid #000; text-align: right; font-weight: bold; padding: 6px 8px;">{tot_str}</td>
                            </tr>
                        </tbody>
                    </table>
                    
                    {footer_html}
                </div>

                <script>
                    if (window.location.search.indexOf('print=1') > -1) {{
                        window.print();
                    }}
                </script>
            </body>
            </html>
            """
            return html

    def write_html_file(suffix=""):
        content = generate_html()
        filename = get_safe_filename(suffix, "html")
        path = os.path.abspath(os.path.join(os.getcwd(), filename))
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        return path

    def cmd_print():
        try:
            path = write_html_file("print")
            import subprocess
            # 1. Native Windows Print Dialog (direct print without browser window)
            try:
                subprocess.Popen(['rundll32.exe', 'mshtml.dll,PrintHTML', path])
                return
            except Exception:
                pass

            # 2. Try os.startfile print verb
            try:
                os.startfile(path, "print")
                return
            except Exception:
                pass

            # 3. Fallback: Browser print URL
            file_url = urllib.parse.urljoin('file:', urllib.request.pathname2url(path))
            webbrowser.open(f"{file_url}?print=1")
        except Exception as e:
            messagebox.showerror("Print Error", f"Unable to launch print dialog: {e}", parent=win)

    def cmd_browser():
        try:
            path = write_html_file("view")
            file_url = urllib.parse.urljoin('file:', urllib.request.pathname2url(path))
            webbrowser.open(file_url)
        except Exception as e:
            messagebox.showerror("Browser Error", f"Unable to open in browser: {e}", parent=win)

    def cmd_word():
        try:
            html_doc = generate_html()
            filename = get_safe_filename("", "doc")
            path = os.path.abspath(os.path.join(os.getcwd(), filename))
            with open(path, "w", encoding="utf-8") as f:
                f.write(html_doc)
            try:
                os.startfile(path)
            except Exception:
                webbrowser.open(path)
        except Exception as e:
            messagebox.showerror("MS Word Error", f"Unable to open in Word: {e}", parent=win)

    def cmd_pdf():
        try:
            path = write_html_file("pdf")
            file_url = urllib.parse.urljoin('file:', urllib.request.pathname2url(path))
            webbrowser.open(f"{file_url}?print=1")
        except Exception as e:
            messagebox.showerror("PDF Error", f"Unable to open PDF print preview: {e}", parent=win)

    def cmd_excel():
        try:
            filename = get_safe_filename("", "xlsx")
            path = os.path.abspath(os.path.join(os.getcwd(), filename))
            wb = openpyxl.Workbook()
            ws = wb.active
            ws.title = doc_title[:30]

            if is_voucher:
                ws.append([company_name])
                ws.append([f"✉ {company_email}"])
                ws.append([doc_title])
                ws.append([])
                ws.append(["", "", f"{doc_no_label} {inv_no}"])
                ws.append(["", "", f"Dated: {inv_date}"])
                ws.append([])
                ws.append(["Particulars", "Debit", "Credit"])
                ws.append([group1_title, "", ""])
                for acc, amt in group1_items:
                    d_val = amt if group1_col == 'debit' else ""
                    c_val = amt if group1_col == 'credit' else ""
                    ws.append([f"  {acc}", d_val, c_val])
                ws.append([group2_title, "", ""])
                for acc, amt in group2_items:
                    d_val = amt if group2_col == 'debit' else ""
                    c_val = amt if group2_col == 'credit' else ""
                    ws.append([f"  {acc}", d_val, c_val])
                ws.append(["Total", tot_debit, tot_credit])
                ws.append([])
                ws.append(["", "", doc_signatory])
            else:
                ws.append([company_name])
                ws.append([f"✉ {company_email}"])
                ws.append([doc_title])
                ws.append([])
                ws.append([party_label, party_name, "", doc_no_label, str(inv_data.get('invoice_no', '')), "Date:", str(inv_data.get('date', ''))])
                ws.append([])
                
                headers = [col[0] for col in col_specs]
                ws.append(headers)
                for idx, it in enumerate(inv_data['items']):
                    q = float(it.get('qty') or 0)
                    p = float(it.get('price') or 0)
                    amt = float(it.get('total') or (q * p))
                    unit = it.get('unit') or 'nos'
                    name = it.get('item_name') or it.get('name') or ''
                    if show_disc_tax:
                        ws.append([idx+1, name, q, unit, p, unit, it.get('discount', 0), it.get('tax_pct', ''), amt])
                    else:
                        ws.append([idx+1, name, q, unit, p, unit, amt])
                        
                ws.append([])
                ws.append(["Subtotal", "", "", "", "", "", subtotal_val])
                ws.append(["Total", total_qty, "", "", "", "", total_val])
                if show_paid_status:
                    ws.append(["Paid", "", "", "", "", "", paid_val])
                    ws.append(["Balance", "", "", "", "", "", due_val])

            wb.save(path)
            try:
                os.startfile(path)
            except Exception:
                messagebox.showinfo("Export", f"Saved to {path}", parent=win)
        except Exception as e:
            messagebox.showerror("MS Excel Error", f"Unable to export to Excel: {e}", parent=win)

    def cmd_email():
        try:
            subject = urllib.parse.quote(f"{doc_title} {inv_no or inv_data.get('invoice_no', '')} from {company_name}")
            body = urllib.parse.quote(f"Dear Sir/Madam,\n\nPlease find details for {doc_title} {inv_no or inv_data.get('invoice_no', '')}.\nTotal Amount: Rs{total_val:,.2f}\n\nThank you for your business!")
            webbrowser.open(f"mailto:?subject={subject}&body={body}")
        except Exception as e:
            messagebox.showerror("Email Error", f"Unable to launch email client: {e}", parent=win)

    # ─────────────────────────────────────────────────────────────────────────
    # TOP ACTION TOOLBAR
    # ─────────────────────────────────────────────────────────────────────────
    toolbar = tk.Frame(win, bg="#ffffff", bd=0)
    toolbar.pack(fill="x", side="top")

    t_row1 = tk.Frame(toolbar, bg="#ffffff")
    t_row1.pack(fill="x", padx=6, pady=(4, 2))

    def make_tb_btn(parent_f, text, cmd):
        btn = tk.Button(parent_f, text=text, font=("Segoe UI", 9), bg="#ffffff", fg="#000000",
                        relief="flat", bd=0, activebackground="#e8f0fe", cursor="hand2", command=cmd)
        btn.pack(side="left", padx=5, pady=2)
        return btn

    make_tb_btn(t_row1, "☒ Ctrl+Q: Exit", win.destroy)
    make_tb_btn(t_row1, "🖶 Alt+P: Print", cmd_print)
    make_tb_btn(t_row1, "📝 Ctrl+W: Open In MS Word", cmd_word)
    make_tb_btn(t_row1, "📊 Ctrl+E: Open In MS Excel", cmd_excel)
    make_tb_btn(t_row1, "📄 Ctrl+V: Open In PDF", cmd_pdf)
    make_tb_btn(t_row1, "🌐 Ctrl+H: Open In Browser", cmd_browser)

    t_row2 = tk.Frame(toolbar, bg="#ffffff")
    t_row2.pack(fill="x", padx=6, pady=(0, 4))

    tk.Label(t_row2, text="Number Of Copies:", font=("Segoe UI", 9), bg="#ffffff", fg="#000000").pack(side="left", padx=(5, 4))
    copies_cb = ttk.Combobox(t_row2, values=["None", "1", "2", "3", "4", "5"], font=("Segoe UI", 9), width=12, state="readonly")
    copies_cb.set("None")
    copies_cb.pack(side="left", padx=(0, 15))

    make_tb_btn(t_row2, "📧 Send Email", cmd_email)

    tk.Frame(win, bg="#d0d0d0", height=1).pack(fill="x")

    # ─────────────────────────────────────────────────────────────────────────
    # SCROLLABLE CANVAS & SHEET CONTAINER
    # ─────────────────────────────────────────────────────────────────────────
    canvas_wrap = tk.Frame(win, bg="#808080")
    canvas_wrap.pack(fill="both", expand=True)

    canvas = tk.Canvas(canvas_wrap, bg="#808080", highlightthickness=0, bd=0)
    vsb = ttk.Scrollbar(canvas_wrap, orient="vertical", command=canvas.yview)
    canvas.configure(yscrollcommand=vsb.set)
    vsb.pack(side="right", fill="y")
    canvas.pack(side="left", fill="both", expand=True)

    paper_w = 940
    paper = tk.Frame(canvas, bg="#ffffff", width=paper_w)
    paper_cw = canvas.create_window((0, 20), window=paper, anchor="n")

    def center_paper(event=None):
        cw = canvas.winfo_width()
        x = max(cw // 2, paper_w // 2 + 10)
        canvas.coords(paper_cw, x, 20)
        canvas.configure(scrollregion=canvas.bbox("all"))

    canvas.bind("<Configure>", center_paper)
    paper.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))

    def on_mousewheel(event):
        canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
    canvas.bind_all("<MouseWheel>", on_mousewheel)

    doc = tk.Frame(paper, bg="#ffffff", padx=40, pady=30)
    doc.pack(fill="both", expand=True)

    if is_voucher:
        # ─────────────────────────────────────────────────────────────────────
        # VOUCHER CANVAS RENDERING (Income, Expense, Contra, Journal)
        # ─────────────────────────────────────────────────────────────────────
        tk.Label(doc, text=company_name, font=("Segoe UI", 16, "bold"), bg="#ffffff", fg="#000000", anchor="center").pack(fill="x")
        tk.Label(doc, text=f"✉ {company_email}", font=("Segoe UI", 10), bg="#ffffff", fg="#222222", anchor="center").pack(fill="x", pady=(2, 12))
        tk.Label(doc, text=doc_title, font=("Segoe UI", 16, "bold"), bg="#ffffff", fg="#000000", anchor="center").pack(fill="x", pady=(0, 16))

        # Main Table Box
        tbl_border = tk.Frame(doc, bg="#000000", padx=1, pady=1)
        tbl_border.pack(fill="x", pady=(0, 15))

        tbl_inner = tk.Frame(tbl_border, bg="#ffffff")
        tbl_inner.pack(fill="both", expand=True)

        # Top Right Header inside box
        meta_f = tk.Frame(tbl_inner, bg="#ffffff")
        meta_f.pack(fill="x", padx=12, pady=6)
        tk.Label(meta_f, text=f"{doc_no_label} {inv_no}", font=("Segoe UI", 10, "bold"), bg="#ffffff", fg="#000000", anchor="e").pack(anchor="e")
        tk.Label(meta_f, text=f"Dated: {inv_date}", font=("Segoe UI", 10), bg="#ffffff", fg="#000000", anchor="e").pack(anchor="e")
        if ref_doc_val:
            tk.Label(meta_f, text=f"Ref Doc: {ref_doc_val}", font=("Segoe UI", 9), bg="#ffffff", fg="#555555", anchor="e").pack(anchor="e")

        # Divider line below top header
        tk.Frame(tbl_inner, bg="#000000", height=1).pack(fill="x")

        # Column Headers
        hdr_f = tk.Frame(tbl_inner, bg="#ffffff", height=28)
        hdr_f.pack(fill="x")
        hdr_f.columnconfigure(0, weight=1)
        hdr_f.columnconfigure(1, weight=0, minsize=1)
        hdr_f.columnconfigure(2, weight=0, minsize=140)
        hdr_f.columnconfigure(3, weight=0, minsize=1)
        hdr_f.columnconfigure(4, weight=0, minsize=140)

        tk.Label(hdr_f, text="Particulars", font=("Segoe UI", 10, "bold"), bg="#ffffff", fg="#000000", anchor="w", padx=10).grid(row=0, column=0, sticky="nsew")
        tk.Frame(hdr_f, bg="#000000", width=1).grid(row=0, column=1, sticky="ns")
        tk.Label(hdr_f, text="Debit", font=("Segoe UI", 10, "bold"), bg="#ffffff", fg="#000000", anchor="e", padx=10).grid(row=0, column=2, sticky="nsew")
        tk.Frame(hdr_f, bg="#000000", width=1).grid(row=0, column=3, sticky="ns")
        tk.Label(hdr_f, text="Credit", font=("Segoe UI", 10, "bold"), bg="#ffffff", fg="#000000", anchor="e", padx=10).grid(row=0, column=4, sticky="nsew")

        # Divider line below column headers
        tk.Frame(tbl_inner, bg="#000000", height=1).pack(fill="x")

        # Table Body
        body_f = tk.Frame(tbl_inner, bg="#ffffff")
        body_f.pack(fill="x")
        body_f.columnconfigure(0, weight=1)
        body_f.columnconfigure(1, weight=0, minsize=1)
        body_f.columnconfigure(2, weight=0, minsize=140)
        body_f.columnconfigure(3, weight=0, minsize=1)
        body_f.columnconfigure(4, weight=0, minsize=140)

        cur_row = 0

        def add_v_row(particulars_text, debit_text, credit_text, is_bold_italic=False, is_indent=False):
            nonlocal cur_row
            fnt = ("Segoe UI", 10, "bold italic") if is_bold_italic else ("Segoe UI", 10)
            pad_l = 30 if is_indent else 10

            lbl_p = tk.Label(body_f, text=particulars_text, font=fnt, bg="#ffffff", fg="#000000", anchor="w", padx=pad_l, pady=3)
            lbl_p.grid(row=cur_row, column=0, sticky="nsew")

            v1 = tk.Frame(body_f, bg="#000000", width=1)
            v1.grid(row=cur_row, column=1, sticky="ns")

            lbl_d = tk.Label(body_f, text=debit_text, font=fnt, bg="#ffffff", fg="#000000", anchor="e", padx=10, pady=3)
            lbl_d.grid(row=cur_row, column=2, sticky="nsew")

            v2 = tk.Frame(body_f, bg="#000000", width=1)
            v2.grid(row=cur_row, column=3, sticky="ns")

            lbl_c = tk.Label(body_f, text=credit_text, font=fnt, bg="#ffffff", fg="#000000", anchor="e", padx=10, pady=3)
            lbl_c.grid(row=cur_row, column=4, sticky="nsew")

            cur_row += 1

        # Group 1
        add_v_row(group1_title, "", "", is_bold_italic=True, is_indent=False)
        for acc, amt in group1_items:
            d_s = fmt_n(amt) if group1_col == 'debit' else ""
            c_s = fmt_n(amt) if group1_col == 'credit' else ""
            add_v_row(acc, d_s, c_s, is_bold_italic=False, is_indent=True)

        # Group 2
        add_v_row(group2_title, "", "", is_bold_italic=True, is_indent=False)
        for acc, amt in group2_items:
            d_s = fmt_n(amt) if group2_col == 'debit' else ""
            c_s = fmt_n(amt) if group2_col == 'credit' else ""
            add_v_row(acc, d_s, c_s, is_bold_italic=False, is_indent=True)

        # Divider line above Total
        tk.Frame(tbl_inner, bg="#000000", height=1).pack(fill="x")

        # Total Row
        tot_f = tk.Frame(tbl_inner, bg="#ffffff", height=28)
        tot_f.pack(fill="x")
        tot_f.columnconfigure(0, weight=1)
        tot_f.columnconfigure(1, weight=0, minsize=1)
        tot_f.columnconfigure(2, weight=0, minsize=140)
        tot_f.columnconfigure(3, weight=0, minsize=1)
        tot_f.columnconfigure(4, weight=0, minsize=140)

        tk.Label(tot_f, text="Total", font=("Segoe UI", 10, "bold"), bg="#ffffff", fg="#000000", anchor="w", padx=10, pady=4).grid(row=0, column=0, sticky="nsew")
        tk.Frame(tot_f, bg="#000000", width=1).grid(row=0, column=1, sticky="ns")
        tk.Label(tot_f, text=fmt_cur(tot_debit), font=("Segoe UI", 10, "bold"), bg="#ffffff", fg="#000000", anchor="e", padx=10, pady=4).grid(row=0, column=2, sticky="nsew")
        tk.Frame(tot_f, bg="#000000", width=1).grid(row=0, column=3, sticky="ns")
        tk.Label(tot_f, text=fmt_cur(tot_credit), font=("Segoe UI", 10, "bold"), bg="#ffffff", fg="#000000", anchor="e", padx=10, pady=4).grid(row=0, column=4, sticky="nsew")

        if narration_val:
            tk.Frame(tbl_inner, bg="#000000", height=1).pack(fill="x")
            nar_f = tk.Frame(tbl_inner, bg="#ffffff")
            nar_f.pack(fill="x", padx=10, pady=4)
            tk.Label(nar_f, text=f"Narration / Remarks: {narration_val}", font=("Segoe UI", 9, "italic"), bg="#ffffff", fg="#222222", anchor="w").pack(anchor="w")

        # Signatory (Only Authorized Signatory right-aligned, clean, exactly as in Image 1)
        sig_fr = tk.Frame(doc, bg="#ffffff")
        sig_fr.pack(fill="x", pady=(50, 20))
        tk.Label(sig_fr, text="Authorized Signatory", font=("Segoe UI", 10, "bold"), bg="#ffffff", fg="#000000", anchor="e").pack(side="right", padx=10)

    else:
        # ─────────────────────────────────────────────────────────────────────
        # COMMERCIAL INVOICE CANVAS RENDERING
        # ─────────────────────────────────────────────────────────────────────
        header_f = tk.Frame(doc, bg="#ffffff")
        header_f.pack(fill="x", pady=(0, 20))
        
        logo_f = tk.Frame(header_f, bg="#ffffff")
        logo_f.pack(side="left", padx=(0, 15))
        logo_path = db.get_setting("company_logo_path", "")
        if logo_path and os.path.exists(logo_path):
            try:
                from PIL import Image, ImageTk
                img = Image.open(logo_path)
                img.thumbnail((120, 80), Image.Resampling.LANCZOS)
                logo_tk = ImageTk.PhotoImage(img)
                lbl_logo = tk.Label(logo_f, image=logo_tk, bg="#ffffff")
                lbl_logo.image = logo_tk
                lbl_logo.pack()
            except Exception:
                pass
                
        info_f = tk.Frame(header_f, bg="#ffffff")
        info_f.pack(side="left", fill="both", expand=True)
        tk.Label(info_f, text=company_name, font=("Segoe UI", 16, "bold"), bg="#ffffff", fg="#000000", anchor="w").pack(fill="x")
        c_address = db.get_setting("company_address1", "")
        if c_address:
            tk.Label(info_f, text=c_address, font=("Segoe UI", 10), bg="#ffffff", fg="#222222", anchor="w").pack(fill="x")
        c_phone = db.get_setting("company_phone", "")
        tk.Label(info_f, text=f"✉ {company_email} , ☏ {c_phone}", font=("Segoe UI", 10), bg="#ffffff", fg="#333333", anchor="w").pack(fill="x", pady=(2, 12))
        
        tk.Label(doc, text=doc_title, font=("Segoe UI", 18, "bold"), bg="#ffffff", fg="#000000", anchor="center").pack(fill="x", pady=(0, 10))

        meta_frame = tk.Frame(doc, bg="#ffffff")
        meta_frame.pack(fill="x", pady=(0, 15))

        left_meta = tk.Frame(meta_frame, bg="#ffffff")
        left_meta.pack(side="left", fill="both", expand=True)
        tk.Label(left_meta, text=party_label, font=("Segoe UI", 9, "bold"), bg="#ffffff", fg="#000000", anchor="w").pack(fill="x")
        tk.Label(left_meta, text=party_name, font=("Segoe UI", 10, "bold"), bg="#ffffff", fg="#000000", anchor="w").pack(fill="x", pady=(2, 0))

        right_meta = tk.Frame(meta_frame, bg="#ffffff")
        right_meta.pack(side="right", anchor="ne")

        row_inv = tk.Frame(right_meta, bg="#ffffff")
        row_inv.pack(fill="x", pady=1)
        tk.Label(row_inv, text=doc_no_label, font=("Segoe UI", 9, "bold"), bg="#ffffff", fg="#000000", width=18, anchor="w").pack(side="left")
        tk.Label(row_inv, text=str(inv_data.get('invoice_no', '')), font=("Segoe UI", 9, "bold"), bg="#ffffff", fg="#000000", anchor="e").pack(side="right")

        row_dt = tk.Frame(right_meta, bg="#ffffff")
        row_dt.pack(fill="x", pady=1)
        tk.Label(row_dt, text="Date:", font=("Segoe UI", 9, "bold"), bg="#ffffff", fg="#000000", width=18, anchor="w").pack(side="left")
        tk.Label(row_dt, text=str(inv_data.get('date', '')), font=("Segoe UI", 9), bg="#ffffff", fg="#000000", anchor="e").pack(side="right")

        tbl_border = tk.Frame(doc, bg="#000000", padx=1, pady=1)
        tbl_border.pack(fill="x", pady=(5, 0))

        tbl_grid = tk.Frame(tbl_border, bg="#000000")
        tbl_grid.pack(fill="both", expand=True)

        num_cols = len(col_specs)
        for c_idx, (c_name, c_width, c_align) in enumerate(col_specs):
            tbl_grid.columnconfigure(c_idx, weight=1 if c_name == "Description" else 0)

        for c_idx, (c_name, c_width, c_align) in enumerate(col_specs):
            h_cell = tk.Frame(tbl_grid, bg="#ffffff", height=28, width=c_width)
            h_cell.grid(row=0, column=c_idx, sticky="nsew", padx=(0, 1 if c_idx < num_cols - 1 else 0), pady=(0, 1))
            h_cell.pack_propagate(False)
            lbl = tk.Label(h_cell, text=c_name, font=("Segoe UI", 9, "bold"), bg="#ffffff", fg="#000000",
                           anchor=c_align, padx=4)
            lbl.pack(fill="both", expand=True)

        current_grid_row = 1

        for it_idx, it in enumerate(inv_data['items']):
            q = float(it.get('qty') or 0)
            p = float(it.get('price') or 0)
            amt = float(it.get('total') or (q * p))
            q_str = f"{q:,.0f}" if q.is_integer() else f"{q:,.2f}"
            p_str = f"{p:,.0f}" if p.is_integer() else f"{p:,.2f}"
            amt_str = f"{amt:,.0f}" if amt.is_integer() else f"{amt:,.2f}"
            unit = it.get('unit') or 'nos'

            name = it.get('item_name') or it.get('name') or ''
            desc_extra = it.get('desc') or ''
            remarks = it.get('remarks') or ''

            row_h = 32
            if desc_extra and desc_extra != name: row_h += 16
            if remarks: row_h += 24

            if show_disc_tax:
                row_vals = [
                    (str(it_idx + 1), "center"),
                    (None, "w"),
                    (f"{q_str} {unit}", "center"),
                    (p_str, "e"),
                    (str(it.get('discount') or '0'), "center"),
                    (str(it.get('tax_pct') or ''), "center"),
                    (amt_str, "e")
                ]
            else:
                row_vals = [
                    (str(it_idx + 1), "center"),
                    (None, "w"),
                    (f"{q_str} {unit}", "center"),
                    (p_str, "e"),
                    (amt_str, "e")
                ]

            for c_idx, (val_text, align) in enumerate(row_vals):
                c_width = col_specs[c_idx][1]
                cell = tk.Frame(tbl_grid, bg="#ffffff", height=row_h, width=c_width)
                cell.grid(row=current_grid_row, column=c_idx, sticky="nsew",
                          padx=(0, 1 if c_idx < num_cols - 1 else 0), pady=(0, 1))
                cell.pack_propagate(False)

                if c_idx == 1:
                    d_fr = tk.Frame(cell, bg="#ffffff")
                    d_fr.pack(fill="both", expand=True, padx=6, pady=4)
                    tk.Label(d_fr, text=name, font=("Segoe UI", 9, "bold"), bg="#ffffff", fg="#000000", anchor="w").pack(fill="x")
                    if desc_extra and desc_extra != name:
                        tk.Label(d_fr, text=desc_extra, font=("Segoe UI", 9), bg="#ffffff", fg="#333333", anchor="w").pack(fill="x")
                    if remarks:
                        tk.Label(d_fr, text=f"Remarks: {remarks}", font=("Segoe UI", 8, "italic"), bg="#ffffff", fg="#555555", anchor="w").pack(fill="x")
                else:
                    tk.Label(cell, text=val_text, font=("Segoe UI", 9), bg="#ffffff", fg="#000000",
                             anchor=align, padx=6).pack(fill="both", expand=True)

            current_grid_row += 1

        t_qty_str = f"{total_qty:,.0f}" if total_qty.is_integer() else f"{total_qty:,.2f}"
        sub_str = f"{subtotal_val:,.0f}" if subtotal_val.is_integer() else f"{subtotal_val:,.2f}"
        tot_str = f"Rs{total_val:,.0f}" if total_val.is_integer() else f"Rs{total_val:,.2f}"
        paid_str = f"Rs{paid_val:,.0f}" if paid_val.is_integer() else f"Rs{paid_val:,.2f}"
        adv_str = f"Rs{advance_val:,.0f}" if advance_val.is_integer() else f"Rs{advance_val:,.2f}"

        bal_str = f"Rs{due_val:,.0f}" if due_val.is_integer() else f"Rs{due_val:,.2f}"
        bal_color = "#c00000" if due_val > 0 else "#008000" if due_val < 0 else "#000000"

        # Subtotal Row
        sub_lbl_cell = tk.Frame(tbl_grid, bg="#ffffff", height=28)
        sub_lbl_cell.grid(row=current_grid_row, column=0, columnspan=num_cols - 1, sticky="nsew", padx=(0, 1), pady=(0, 1))
        sub_lbl_cell.pack_propagate(False)
        tk.Label(sub_lbl_cell, text="Subtotal", font=("Segoe UI", 9, "bold"), bg="#ffffff", fg="#000000", anchor="e").pack(fill="both", expand=True, padx=8)

        sub_val_cell = tk.Frame(tbl_grid, bg="#ffffff", height=28)
        sub_val_cell.grid(row=current_grid_row, column=num_cols - 1, sticky="nsew", padx=(0, 0), pady=(0, 1))
        sub_val_cell.pack_propagate(False)
        tk.Label(sub_val_cell, text=sub_str, font=("Segoe UI", 9, "bold"), bg="#ffffff", fg="#000000", anchor="e").pack(fill="both", expand=True, padx=6)

        current_grid_row += 1

        # Total Row
        tot_lbl_cell = tk.Frame(tbl_grid, bg="#ffffff", height=28)
        tot_lbl_cell.grid(row=current_grid_row, column=0, columnspan=2, sticky="nsew", padx=(0, 1), pady=(0, 1))
        tot_lbl_cell.pack_propagate(False)
        tk.Label(tot_lbl_cell, text="Total", font=("Segoe UI", 9, "bold"), bg="#ffffff", fg="#000000", anchor="w").pack(fill="both", expand=True, padx=6)

        tot_qty_cell = tk.Frame(tbl_grid, bg="#ffffff", height=28)
        tot_qty_cell.grid(row=current_grid_row, column=2, sticky="nsew", padx=(0, 1), pady=(0, 1))
        tot_qty_cell.pack_propagate(False)
        tk.Label(tot_qty_cell, text=t_qty_str, font=("Segoe UI", 9, "bold"), bg="#ffffff", fg="#000000", anchor="center").pack(fill="both", expand=True)

        tot_mid_cell = tk.Frame(tbl_grid, bg="#ffffff", height=28)
        tot_mid_cell.grid(row=current_grid_row, column=3, columnspan=num_cols - 3, sticky="nsew", padx=(0, 0), pady=(0, 1))
        tot_mid_cell.pack_propagate(False)
        tk.Label(tot_mid_cell, text=tot_str, font=("Segoe UI", 9, "bold"), bg="#ffffff", fg="#000000", anchor="e").pack(fill="both", expand=True, padx=6)

        current_grid_row += 1

        if advance_val > 0:
            adv_lbl_cell = tk.Frame(tbl_grid, bg="#ffffff", height=28)
            adv_lbl_cell.grid(row=current_grid_row, column=0, columnspan=num_cols - 1, sticky="nsew", padx=(0, 1), pady=(0, 1))
            adv_lbl_cell.pack_propagate(False)
            tk.Label(adv_lbl_cell, text="Advance", font=("Segoe UI", 9, "bold"), bg="#ffffff", fg="#000000", anchor="e").pack(fill="both", expand=True, padx=8)

            adv_val_cell = tk.Frame(tbl_grid, bg="#ffffff", height=28)
            adv_val_cell.grid(row=current_grid_row, column=num_cols - 1, sticky="nsew", padx=(0, 0), pady=(0, 1))
            adv_val_cell.pack_propagate(False)
            tk.Label(adv_val_cell, text=adv_str, font=("Segoe UI", 9, "bold"), bg="#ffffff", fg="#000000", anchor="e").pack(fill="both", expand=True, padx=6)
            current_grid_row += 1

        if show_paid_status:
            paid_lbl_cell = tk.Frame(tbl_grid, bg="#ffffff", height=28)
            paid_lbl_cell.grid(row=current_grid_row, column=0, columnspan=num_cols - 1, sticky="nsew", padx=(0, 1), pady=(0, 1))
            paid_lbl_cell.pack_propagate(False)
            tk.Label(paid_lbl_cell, text="Paid", font=("Segoe UI", 9, "bold"), bg="#ffffff", fg="#000000", anchor="e").pack(fill="both", expand=True, padx=8)

            paid_val_cell = tk.Frame(tbl_grid, bg="#ffffff", height=28)
            paid_val_cell.grid(row=current_grid_row, column=num_cols - 1, sticky="nsew", padx=(0, 0), pady=(0, 1))
            paid_val_cell.pack_propagate(False)
            tk.Label(paid_val_cell, text=paid_str, font=("Segoe UI", 9, "bold"), bg="#ffffff", fg="#000000", anchor="e").pack(fill="both", expand=True, padx=6)

            current_grid_row += 1

            bal_lbl_cell = tk.Frame(tbl_grid, bg="#ffffff", height=28)
            bal_lbl_cell.grid(row=current_grid_row, column=0, columnspan=num_cols - 1, sticky="nsew", padx=(0, 1), pady=(0, 0))
            bal_lbl_cell.pack_propagate(False)
            tk.Label(bal_lbl_cell, text="Balance", font=("Segoe UI", 9, "bold"), bg="#ffffff", fg="#000000", anchor="e").pack(fill="both", expand=True, padx=8)

            bal_val_cell = tk.Frame(tbl_grid, bg="#ffffff", height=28)
            bal_val_cell.grid(row=current_grid_row, column=num_cols - 1, sticky="nsew", padx=(0, 0), pady=(0, 0))
            bal_val_cell.pack_propagate(False)
            tk.Label(bal_val_cell, text=bal_str, font=("Segoe UI", 9, "bold"), bg="#ffffff", fg=bal_color, anchor="e").pack(fill="both", expand=True, padx=6)

        if is_paid:
            try:
                stamp_pil = create_paid_stamp_image()
                stamp_tk = ImageTk.PhotoImage(stamp_pil)
                stamp_lbl = tk.Label(doc, image=stamp_tk, bg="#ffffff", bd=0)
                stamp_lbl.image = stamp_tk
                stamp_lbl.place(relx=0.08, rely=0.55, anchor="nw")
                stamp_lbl.lift()
            except Exception:
                stamp_lbl = tk.Label(doc, text="PAID", fg="#e52b2b", bg="#ffffff",
                                     font=("Arial", 28, "bold"), bd=3, relief="solid", padx=15, pady=4)
                stamp_lbl.place(relx=0.10, rely=0.55, anchor="nw")

        footer_f = tk.Frame(doc, bg="#ffffff")
        footer_f.pack(fill="x", pady=(15, 6))
        
        decl_f = tk.Frame(footer_f, bg="#ffffff")
        decl_f.pack(side="left", fill="y", expand=True)
        tk.Label(decl_f, text=doc_declaration, font=("Segoe UI", 9), bg="#ffffff", fg="#000000", justify="left", anchor="w", wraplength=400).pack(anchor="w", pady=(20, 0))
        tk.Label(decl_f, text="Invoice will be generated after acceptance of\nthis estimate." if doc_cfg['key'] == 'estimate' else "This is computer generated document", font=("Segoe UI", 9), bg="#ffffff", fg="#000000", justify="left", anchor="w").pack(anchor="w", pady=(4, 0))
        
        sig_f = tk.Frame(footer_f, bg="#ffffff")
        sig_f.pack(side="right", anchor="se", padx=12)
        
        sig_path = db.get_setting("company_sig_path", "")
        if sig_path and os.path.exists(sig_path):
            try:
                from PIL import Image, ImageTk
                img = Image.open(sig_path)
                img.thumbnail((150, 70), Image.Resampling.LANCZOS)
                sig_tk = ImageTk.PhotoImage(img)
                lbl_sig = tk.Label(sig_f, image=sig_tk, bg="#ffffff")
                lbl_sig.image = sig_tk
                lbl_sig.pack(anchor="s")
            except Exception:
                pass
                
        tk.Label(sig_f, text=doc_signatory, font=("Segoe UI", 9), bg="#ffffff", fg="#000000", anchor="s").pack(anchor="s", pady=(0, 6))

    # Keyboard Shortcuts
    win.bind("<Control-q>", lambda e: win.destroy())
    win.bind("<Control-Q>", lambda e: win.destroy())
    win.bind("<Escape>", lambda e: win.destroy())
    win.bind("<Alt-p>", lambda e: cmd_print())
    win.bind("<Alt-P>", lambda e: cmd_print())
    win.bind("<Control-p>", lambda e: cmd_print())
    win.bind("<Control-P>", lambda e: cmd_print())
    win.bind("<Control-w>", lambda e: cmd_word())
    win.bind("<Control-W>", lambda e: cmd_word())
    win.bind("<Control-e>", lambda e: cmd_excel())
    win.bind("<Control-E>", lambda e: cmd_excel())
    win.bind("<Control-v>", lambda e: cmd_pdf())
    win.bind("<Control-V>", lambda e: cmd_pdf())
    win.bind("<Control-h>", lambda e: cmd_browser())
    win.bind("<Control-H>", lambda e: cmd_browser())

    if auto_print:
        win.after(300, cmd_print)
