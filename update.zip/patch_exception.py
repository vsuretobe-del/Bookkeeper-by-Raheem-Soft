with open('bookkeeper.py', 'r', encoding='utf-8') as f:
    content = f.read()

old_except = '''            except Exception as e:
                messagebox.showerror("Database Error", str(e), parent=win)'''

new_except = '''            except Exception as e:
                if "UNIQUE constraint failed" in str(e):
                    messagebox.showerror("Error", f"A unit with the name '{name}' already exists!", parent=win)
                else:
                    messagebox.showerror("Database Error", str(e), parent=win)'''

content = content.replace(old_except, new_except)

with open('bookkeeper.py', 'w', encoding='utf-8') as f:
    f.write(content)
print("Updated exception handling")
