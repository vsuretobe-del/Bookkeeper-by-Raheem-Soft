import tkinter as tk
from tkinter import ttk
import calendar
from datetime import datetime

class DateEntry(tk.Frame):
    def __init__(self, master, date_pattern="yyyy-mm-dd", **kwargs):
        super().__init__(master, **kwargs)
        self.configure(bg="#ffffff")
        self.date_pattern = date_pattern
        
        self.entry_var = tk.StringVar()
        self.entry = tk.Entry(self, textvariable=self.entry_var, font=("Segoe UI", 10), relief="solid", bd=1)
        self.entry.pack(side="left", fill="x", expand=True)
        
        self.btn = tk.Button(self, text="📅", font=("Segoe UI", 8), relief="flat", bg="#f0f0f0", command=self.show_calendar)
        self.btn.pack(side="right")
        
        # Default to today
        self.set_date(datetime.today())
        
    def get(self):
        return self.entry_var.get()
        
    def set_date(self, dt):
        if self.date_pattern == "yyyy-mm-dd":
            self.entry_var.set(dt.strftime("%Y-%m-%d"))
        elif self.date_pattern == "Month DD, YYYY":
            self.entry_var.set(dt.strftime("%B %d, %Y"))
        else:
            self.entry_var.set(dt.strftime("%Y-%m-%d"))
            
    def get_date(self):
        # Try parsing back
        val = self.entry_var.get()
        try:
            if self.date_pattern == "yyyy-mm-dd":
                return datetime.strptime(val, "%Y-%m-%d")
            elif self.date_pattern == "Month DD, YYYY":
                return datetime.strptime(val, "%B %d, %Y")
        except ValueError:
            pass
        return datetime.today()

    def show_calendar(self):
        cal_win = tk.Toplevel(self)
        cal_win.title("Select Date")
        cal_win.grab_set()
        
        # Try to position below entry
        x = self.entry.winfo_rootx()
        y = self.entry.winfo_rooty() + self.entry.winfo_height()
        cal_win.geometry(f"+{x}+{y}")
        
        cal_win.configure(bg="#ffffff", relief="solid", bd=1)
        cal_win.overrideredirect(True) # Remove window decorations
        
        current_date = self.get_date()
        self.cal_year = current_date.year
        self.cal_month = current_date.month
        
        header_fr = tk.Frame(cal_win, bg="#2b579a")
        header_fr.pack(fill="x")
        
        btn_prev = tk.Button(header_fr, text="◀", bg="#2b579a", fg="white", relief="flat", 
                             command=lambda: self.change_month(-1, cal_win, days_frame, lbl_month))
        btn_prev.pack(side="left")
        
        lbl_month = tk.Label(header_fr, text="", bg="#2b579a", fg="white", font=("Segoe UI", 10, "bold"))
        lbl_month.pack(side="left", expand=True)
        
        btn_next = tk.Button(header_fr, text="▶", bg="#2b579a", fg="white", relief="flat", 
                             command=lambda: self.change_month(1, cal_win, days_frame, lbl_month))
        btn_next.pack(side="right")
        
        days_frame = tk.Frame(cal_win, bg="white")
        days_frame.pack(padx=5, pady=5)
        
        # Close button at bottom
        tk.Button(cal_win, text="Close", command=cal_win.destroy, relief="flat", bg="#f0f0f0").pack(fill="x")
        
        self.render_calendar(cal_win, days_frame, lbl_month)
        
    def change_month(self, delta, cal_win, days_frame, lbl_month):
        self.cal_month += delta
        if self.cal_month > 12:
            self.cal_month = 1
            self.cal_year += 1
        elif self.cal_month < 1:
            self.cal_month = 12
            self.cal_year -= 1
        self.render_calendar(cal_win, days_frame, lbl_month)
        
    def render_calendar(self, cal_win, days_frame, lbl_month):
        for widget in days_frame.winfo_children():
            widget.destroy()
            
        month_name = calendar.month_name[self.cal_month]
        lbl_month.config(text=f"{month_name} {self.cal_year}")
        
        days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
        for i, d in enumerate(days):
            tk.Label(days_frame, text=d, font=("Segoe UI", 8, "bold"), bg="white").grid(row=0, column=i)
            
        cal = calendar.monthcalendar(self.cal_year, self.cal_month)
        today = datetime.today()
        
        for row_idx, week in enumerate(cal):
            for col_idx, day in enumerate(week):
                if day != 0:
                    bg_color = "white"
                    fg_color = "black"
                    if self.cal_year == today.year and self.cal_month == today.month and day == today.day:
                        bg_color = "#e6f2ff" # Light blue for today
                        fg_color = "blue"
                        
                    btn = tk.Button(days_frame, text=str(day), width=3, bg=bg_color, fg=fg_color, relief="flat",
                                    command=lambda d=day: self.select_date(d, cal_win))
                    btn.grid(row=row_idx+1, column=col_idx, padx=1, pady=1)

    def select_date(self, day, cal_win):
        dt = datetime(self.cal_year, self.cal_month, day)
        self.set_date(dt)
        cal_win.destroy()
