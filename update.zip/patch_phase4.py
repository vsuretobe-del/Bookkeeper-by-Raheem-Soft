with open('bookkeeper.py', 'r', encoding='utf-8') as f:
    content = f.read()

t1 = '''create_dropdown_link("F9:", "Purchase", coming_soon, coming_soon)'''
r1 = '''create_dropdown_link("F9:", "Purchase", lambda: self._open_create_voucher("purchase"), lambda: self.show_invoices("purchase"))'''

content = content.replace(t1, r1)

# Ensure F8 uses "sale" explicitly (optional, but good practice since default is "sale")
t2 = '''create_dropdown_link("F8:", "Sale/Invoice/Bill", self._open_create_voucher, self.show_invoices)'''
r2 = '''create_dropdown_link("F8:", "Sale/Invoice/Bill", lambda: self._open_create_voucher("sale"), lambda: self.show_invoices("sale"))'''

content = content.replace(t2, r2)

with open('bookkeeper.py', 'w', encoding='utf-8') as f:
    f.write(content)

print("Phase 4 Patch Applied!")
