with open('bookkeeper.py', 'r', encoding='utf-8') as f:
    content = f.read()

t1 = '''        # 8. Render Rows
        invoices = db.get_all_invoices("sale")'''
r1 = '''        # 8. Render Rows
        invoices = db.get_all_invoices(v_type)'''
content = content.replace(t1, r1)

t2 = '''        # Right Click Context Menu
        ctx_menu = tk.Menu(win, tearoff=0, font=("Segoe UI", 9))
        ctx_menu.add_command(label="Edit")
        ctx_menu.add_command(label="Delete", accelerator="Alt+D")
        ctx_menu.add_command(label="Cancel", accelerator="Alt+X")
        ctx_menu.add_separator()
        
        if v_type == "purchase":
            ctx_menu.add_command(label="Payment to Supplier")
            ctx_menu.add_command(label="Create Debit Note")
            ctx_menu.add_command(label="Create Duplicate", accelerator="Alt+2")
            ctx_menu.add_command(label="Convert Purchase to Sale")
            
            rec_menu = tk.Menu(ctx_menu, tearoff=0, font=("Segoe UI", 9))
            rec_menu.add_command(label="Monthly")
            rec_menu.add_command(label="Yearly")
            ctx_menu.add_cascade(label="Make Recurring", menu=rec_menu)
            
            ctx_menu.add_separator()
            ctx_menu.add_command(label="Mark Paid")
            ctx_menu.add_command(label="View Purchase", command=lambda: invoice_preview.show_invoice_preview(self, v_type="purchase"))
        else:
            ctx_menu.add_command(label="Create Credit Note")
            ctx_menu.add_command(label="Create Duplicate", accelerator="Alt+2")
            
            rec_menu = tk.Menu(ctx_menu, tearoff=0, font=("Segoe UI", 9))
            rec_menu.add_command(label="Monthly")
            rec_menu.add_command(label="Yearly")
            ctx_menu.add_cascade(label="Make Recurring", menu=rec_menu)
            
            ctx_menu.add_separator()
            ctx_menu.add_command(label="e-Way Bill")
            ctx_menu.add_command(label="View Delivery Note")
            ctx_menu.add_command(label="View Invoice", command=lambda: invoice_preview.show_invoice_preview(self, v_type="sale"))'''
r2 = '''        # Right Click Context Menu
        ctx_menu = tk.Menu(win, tearoff=0, font=("Segoe UI", 9))
        
        # Store selected row data
        selected_po_data = {}
        
        def set_selected_data(po_data):
            selected_po_data.clear()
            selected_po_data.update(po_data)
            
        def cmd_make_purchase():
            if selected_po_data:
                win.destroy()
                self._open_create_voucher("purchase", linked_po=selected_po_data)
                
        def cmd_mark_closed():
            if selected_po_data and selected_po_data.get("id"):
                db.update_po_status(selected_po_data["id"], "CLOSED")
                win.destroy()
                self.show_invoices("purchase_order")
        
        ctx_menu.add_command(label="Edit")
        ctx_menu.add_command(label="Delete", accelerator="Alt+D")
        ctx_menu.add_command(label="Cancel", accelerator="Alt+X")
        ctx_menu.add_separator()
        
        if v_type == "purchase_order":
            ctx_menu.add_command(label="Create Duplicate", accelerator="Alt+2")
            ctx_menu.add_command(label="Mark Closed", command=cmd_mark_closed)
            ctx_menu.add_command(label="Make Purchase", command=cmd_make_purchase)
            ctx_menu.add_command(label="View Purchase Order", command=lambda: invoice_preview.show_invoice_preview(self, v_type="purchase_order"))
        elif v_type == "purchase":
            ctx_menu.add_command(label="Payment to Supplier")
            ctx_menu.add_command(label="Create Debit Note")
            ctx_menu.add_command(label="Create Duplicate", accelerator="Alt+2")
            ctx_menu.add_command(label="Convert Purchase to Sale")
            
            rec_menu = tk.Menu(ctx_menu, tearoff=0, font=("Segoe UI", 9))
            rec_menu.add_command(label="Monthly")
            rec_menu.add_command(label="Yearly")
            ctx_menu.add_cascade(label="Make Recurring", menu=rec_menu)
            
            ctx_menu.add_separator()
            ctx_menu.add_command(label="Mark Paid")
            ctx_menu.add_command(label="View Purchase", command=lambda: invoice_preview.show_invoice_preview(self, v_type="purchase"))
        else:
            ctx_menu.add_command(label="Create Credit Note")
            ctx_menu.add_command(label="Create Duplicate", accelerator="Alt+2")
            
            rec_menu = tk.Menu(ctx_menu, tearoff=0, font=("Segoe UI", 9))
            rec_menu.add_command(label="Monthly")
            rec_menu.add_command(label="Yearly")
            ctx_menu.add_cascade(label="Make Recurring", menu=rec_menu)
            
            ctx_menu.add_separator()
            ctx_menu.add_command(label="e-Way Bill")
            ctx_menu.add_command(label="View Delivery Note")
            ctx_menu.add_command(label="View Invoice", command=lambda: invoice_preview.show_invoice_preview(self, v_type="sale"))'''
content = content.replace(t2, r2)

t3 = '''        def show_ctx_menu(event, row_fr):
            on_row_click(event, row_fr)
            ctx_menu.tk_popup(event.x_root, event.y_root)'''
r3 = '''        def show_ctx_menu(event, row_fr, inv_data):
            on_row_click(event, row_fr)
            set_selected_data(inv_data)
            ctx_menu.tk_popup(event.x_root, event.y_root)'''
content = content.replace(t3, r3)

t4 = '''        def create_col(parent, text, w, anchor="w", fg="#000"):
            lbl = tk.Label(parent, text=str(text), bg=WHITE, fg=fg, font=("Segoe UI", 9), anchor=anchor, width=10)
            lbl.pack(side="left", fill="x", expand=True, padx=4)
            lbl.bind("<Button-1>", lambda e: on_row_click(e, parent))
            lbl.bind("<Button-3>", lambda e: show_ctx_menu(e, parent))
            return lbl

        for i, inv in enumerate(invoices):
            bg_color = WHITE if i % 2 == 0 else "#f8f9fa"
            row_fr = tk.Frame(list_inner, bg=bg_color, pady=4)
            row_fr.pack(fill="x")
            
            create_col(row_fr, inv["date"], 80)
            create_col(row_fr, inv.get("account_name", ""), 150)
            create_col(row_fr, inv["invoice_no"], 80)
            create_col(row_fr, f"{inv['total']:,.2f}", 80, "e")
            create_col(row_fr, f"{inv['paid']:,.2f}", 80, "e", fg="green")
            
            rows.append(row_fr)'''
r4 = '''        def create_col(parent, text, w, anchor="w", fg="#000", inv_data=None):
            lbl = tk.Label(parent, text=str(text), bg=WHITE, fg=fg, font=("Segoe UI", 9), anchor=anchor, width=10)
            lbl.pack(side="left", fill="x", expand=True, padx=4)
            lbl.bind("<Button-1>", lambda e: on_row_click(e, parent))
            lbl.bind("<Button-3>", lambda e: show_ctx_menu(e, parent, inv_data))
            return lbl

        for i, inv in enumerate(invoices):
            bg_color = WHITE if i % 2 == 0 else "#f8f9fa"
            row_fr = tk.Frame(list_inner, bg=bg_color, pady=4)
            row_fr.pack(fill="x")
            
            create_col(row_fr, inv["date"], 80, inv_data=inv)
            create_col(row_fr, inv.get("account_name", ""), 150, inv_data=inv)
            create_col(row_fr, inv["invoice_no"], 80, inv_data=inv)
            create_col(row_fr, f"{inv['total']:,.2f}", 80, "e", inv_data=inv)
            if v_type == "purchase_order":
                create_col(row_fr, inv.get("status", "OPEN") or "OPEN", 80, "e", fg="blue", inv_data=inv)
            else:
                create_col(row_fr, f"{inv['paid']:,.2f}", 80, "e", fg="green", inv_data=inv)
            
            rows.append(row_fr)'''
content = content.replace(t4, r4)

# Headers fix
t5 = '''        headers = [
            ("Date", 80), ("Accounts", 150), ("Invoice No", 80),
            ("Amount", 80), ("Balance", 80)
        ]
        if v_type == "purchase":
            headers[1] = ("Supplier", 150)
            headers[2] = ("Purchase No", 80)'''
r5 = '''        headers = [
            ("Date", 80), ("Accounts", 150), ("Invoice No", 80),
            ("Amount", 80), ("Balance", 80)
        ]
        if v_type == "purchase":
            headers[1] = ("Supplier", 150)
            headers[2] = ("Purchase No", 80)
        elif v_type == "purchase_order":
            headers[1] = ("Supplier", 150)
            headers[2] = ("Purchase Order No", 100)
            headers[4] = ("Status", 80)'''
content = content.replace(t5, r5)

# Sidebar link
t_sb = '''create_dropdown_link("Alt+F4:", "Credit Note/Sales Return", coming_soon, coming_soon)'''
r_sb = '''create_dropdown_link("Alt+F4:", "Purchase Order", lambda: self._open_create_voucher("purchase_order"), lambda: self.show_invoices("purchase_order"))
            create_dropdown_link("Alt+F5:", "Credit Note/Sales Return", coming_soon, coming_soon)'''
content = content.replace(t_sb, r_sb)

with open('bookkeeper.py', 'w', encoding='utf-8') as f:
    f.write(content)

print("Patch applied for show_invoices and sidebar!")
