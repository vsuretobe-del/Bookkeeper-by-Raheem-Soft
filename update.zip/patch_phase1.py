with open('bookkeeper.py', 'r', encoding='utf-8') as f:
from autocomplete import AutocompleteCombobox
    content = f.read()

# 1. Update signature
content = content.replace('def _open_create_voucher(self):', 'def _open_create_voucher(self, v_type="sale"):')

# 2. Update labels and dropdowns
t1 = '''        # Left column
        lbl(hdr, "Invoice No", 0, 0)
        inv_no_var, _ = entry_field(hdr, 0, 1, 14, db.get_next_invoice_no())'''

r1 = '''        # Left column
        lbl(hdr, "Purchase No" if v_type == "purchase" else "Invoice No", 0, 0)
        inv_no_var, _ = entry_field(hdr, 0, 1, 14, db.get_next_invoice_no())'''

content = content.replace(t1, r1)

t2 = '''        lbl(hdr, "Customer/Cash", 2, 0)
        cust_frame = tk.Frame(hdr, bg=WHITE)
        cust_frame.grid(row=2, column=1, sticky="w", padx=4, pady=3)
        cust_var = tk.StringVar(value="Cash")
        all_cust = ["Cash"] + [a["name"] for a in db.get_all_accounts("customer")]
        cust_cb = AutocompleteCombobox(cust_frame, textvariable=cust_var, values=all_cust,
                               font=FONT, width=19)'''

r2 = '''        lbl(hdr, "Supplier/Cash" if v_type == "purchase" else "Customer/Cash", 2, 0)
        cust_frame = tk.Frame(hdr, bg=WHITE)
        cust_frame.grid(row=2, column=1, sticky="w", padx=4, pady=3)
        cust_var = tk.StringVar(value="Cash")
        
        if v_type == "purchase":
            acc_list = ["Cash"] + [a["name"] for a in db.get_all_accounts("supplier")]
        else:
            acc_list = ["Cash"] + [a["name"] for a in db.get_all_accounts("customer")]
            
        cust_cb = AutocompleteCombobox(cust_frame, textvariable=cust_var, values=acc_list,
                               font=FONT, width=19)'''

content = content.replace(t2, r2)

t3 = '''        lbl(hdr, "Sales Account", 3, 0)
        tk.Label(hdr, text="Sales", bg=WHITE, fg="#000",
                 font=FONT).grid(row=3, column=1, sticky="w", padx=4, pady=3)'''

r3 = '''        lbl(hdr, "Purchase Account" if v_type == "purchase" else "Sales Account", 3, 0)
        tk.Label(hdr, text="Purchase" if v_type == "purchase" else "Sales", bg=WHITE, fg="#000",
                 font=FONT).grid(row=3, column=1, sticky="w", padx=4, pady=3)'''

content = content.replace(t3, r3)

# 3. Handle Other Charges Button & Popup
t4 = '''        other_var = tk.BooleanVar(value=False)
        tk.Checkbutton(bot_left, text="Other Charges", variable=other_var, bg=BG, font=FONT).pack(anchor="w", pady=(0, 4))'''

r4 = '''        other_charges_data = [] # List of dicts {name, amount}
        other_charges_tot = tk.DoubleVar(value=0.0)

        def open_other_charges():
            popup = tk.Toplevel(win)
            popup.title("Select Other Charge Account")
            popup.geometry("400x300")
            popup.transient(win)
            popup.grab_set()
            
            tk.Label(popup, text="Select Account", font=FONT).pack(pady=5)
            acc_var = tk.StringVar()
            cb = AutocompleteCombobox(popup, textvariable=acc_var, values=["Advertisement expenses", "Rent paid", "Cartage", "Discount"], width=30)
            cb.pack(pady=5)
            
            tk.Label(popup, text="Amount", font=FONT).pack(pady=5)
            amt_var = tk.StringVar(value="0")
            tk.Entry(popup, textvariable=amt_var, font=FONT).pack(pady=5)
            
            def add_chg():
                try:
                    val = float(amt_var.get())
                    other_charges_data.append({"name": acc_var.get(), "amount": val})
                    other_charges_tot.set(sum(c["amount"] for c in other_charges_data))
                    recalc_total()
                    popup.destroy()
                except:
                    pass
            tk.Button(popup, text="Add", command=add_chg).pack(pady=10)

        oc_fr = tk.Frame(bot_left, bg=BG)
        oc_fr.pack(anchor="w", pady=(0, 4))
        tk.Button(oc_fr, text="Select Other Charge", font=FONT, command=open_other_charges, bg="#e0e0e0", relief="flat").pack(side="left")
        tk.Label(oc_fr, textvariable=other_charges_tot, font=FONT, bg=BG).pack(side="left", padx=10)'''

content = content.replace(t4, r4)

with open('bookkeeper.py', 'w', encoding='utf-8') as f:
    f.write(content)

print("Phase 1 Patch Applied!")
