import sqlite3

with open('db.py', 'r', encoding='utf-8') as f:
    content = f.read()

# 1. get_next_invoice_no
t1 = '''def get_next_invoice_no(prefix='INV'):
    conn = get_conn()
    row = conn.execute("SELECT COUNT(*) as cnt FROM vouchers WHERE v_type='sale'").fetchone()'''
r1 = '''def get_next_invoice_no(prefix='INV', v_type='sale'):
    conn = get_conn()
    row = conn.execute("SELECT COUNT(*) as cnt FROM vouchers WHERE v_type=?", (v_type,)).fetchone()'''
content = content.replace(t1, r1)

# 2. create_invoice
t2 = '''def create_invoice(invoice_no, inv_type, account_id, date, line_items, notes=''):
    conn = get_conn()
    total = sum(item['total'] for item in line_items)
    
    account_name = account_id

    v_id = conn.execute(
        "INSERT INTO vouchers (vch_no, v_type, date, amount, narration, paid_amount) VALUES (?,?,?,?,?,?)",
        (invoice_no, inv_type, date, total, notes, 0.0)
    ).lastrowid'''
r2 = '''def create_invoice(invoice_no, inv_type, account_id, date, line_items, notes='', status=None, terms='', linked_po_id=None):
    conn = get_conn()
    total = sum(item['total'] for item in line_items)
    
    account_name = account_id

    v_id = conn.execute(
        "INSERT INTO vouchers (vch_no, v_type, date, amount, narration, paid_amount, status, terms, linked_po_id) VALUES (?,?,?,?,?,?,?,?,?)",
        (invoice_no, inv_type, date, total, notes, 0.0, status, terms, linked_po_id)
    ).lastrowid
    
    if linked_po_id:
        conn.execute("UPDATE vouchers SET status='CLOSED' WHERE id=?", (linked_po_id,))
'''
content = content.replace(t2, r2)

# 3. Handle line_items for purchase_order
t3 = '''        elif inv_type == 'purchase':
            conn.execute("""INSERT INTO purchases (v_id, date, item, cost_per_unit, units, discount, desc) 
                            VALUES (?,?,?,?,?,?,?)""",
                         (v_id, date, item['name'], item['price'], item['qty'], item.get('tax_pct', 0), ''))
            conn.execute("UPDATE stock SET cl_bal=cl_bal+? WHERE stock_name=?", (item['qty'], item['name']))'''
r3 = '''        elif inv_type == 'purchase':
            conn.execute("""INSERT INTO purchases (v_id, date, item, cost_per_unit, units, discount, desc) 
                            VALUES (?,?,?,?,?,?,?)""",
                         (v_id, date, item['name'], item['price'], item['qty'], item.get('tax_pct', 0), ''))
            conn.execute("UPDATE stock SET cl_bal=cl_bal+? WHERE stock_name=?", (item['qty'], item['name']))
        elif inv_type == 'purchase_order':
            # PO line items go to purchases table but don't affect stock
            conn.execute("""INSERT INTO purchases (v_id, date, item, cost_per_unit, units, discount, desc) 
                            VALUES (?,?,?,?,?,?,?)""",
                         (v_id, date, item['name'], item['price'], item['qty'], item.get('tax_pct', 0), ''))'''
content = content.replace(t3, r3)

# 4. update_po_status
content += '''
def update_po_status(po_id, status):
    conn = get_conn()
    conn.execute("UPDATE vouchers SET status=? WHERE id=?", (status, po_id))
    conn.commit()
    conn.close()
'''

with open('db.py', 'w', encoding='utf-8') as f:
    f.write(content)

print("db.py updated")
