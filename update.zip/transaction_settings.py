# transaction_settings.py
# Transaction Settings Window - 5 tabs: POS Settings, Date and Rate, Warnings, Misc., Voucher Series

import tkinter as tk
from tkinter import ttk, messagebox
import db
from autocomplete import AutocompleteCombobox

FONT = ("Segoe UI", 10)
FONT_BOLD = ("Segoe UI", 10, "bold")
BG = "#f0f0f0"
WHITE = "#ffffff"
GRAY_FRAME = "#e8e8e8"


class TransactionSettingsWindow(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.title("Transactions Settings")
        self.geometry("540x480")
        self.resizable(False, False)
        self.configure(bg=BG)
        self.grab_set()
        self.parent = parent

        # Load all settings
        self._vars = {}

        self._build_ui()
        self._load_settings()

        self.bind("<Control-q>", lambda e: self.destroy())
        self.bind("<Control-Q>", lambda e: self.destroy())
        self.bind("<F12>", lambda e: self._save())

    def _get(self, key, default="0"):
        return db.get_setting(key, default)

    def _save(self):
        # Save all settings
        for key, var in self._vars.items():
            db.set_setting(key, var.get())
        messagebox.showinfo("Saved", "Transaction Settings saved successfully.", parent=self)
        self.destroy()

    def _build_ui(self):
        # Notebook (tabs)
        nb = ttk.Notebook(self)
        nb.pack(fill="both", expand=True, padx=5, pady=5)

        # --- Tab 1: POS Settings ---
        tab_pos = tk.Frame(nb, bg=WHITE)
        nb.add(tab_pos, text="POS Settings")
        self._build_pos_tab(tab_pos)

        # --- Tab 2: Date and Rate ---
        tab_date = tk.Frame(nb, bg=WHITE)
        nb.add(tab_date, text="Date and Rate")
        self._build_date_tab(tab_date)

        # --- Tab 3: Warnings ---
        tab_warn = tk.Frame(nb, bg=WHITE)
        nb.add(tab_warn, text="Warnings")
        self._build_warnings_tab(tab_warn)

        # --- Tab 4: Misc. ---
        tab_misc = tk.Frame(nb, bg=WHITE)
        nb.add(tab_misc, text="Misc.")
        self._build_misc_tab(tab_misc)

        # --- Tab 5: Voucher Series ---
        tab_vs = tk.Frame(nb, bg=WHITE)
        nb.add(tab_vs, text="Voucher Series")
        self._build_voucher_series_tab(tab_vs)

        # Bottom bar
        bot = tk.Frame(self, bg=BG, height=45)
        bot.pack(fill="x", side="bottom")
        bot.pack_propagate(False)

        tk.Button(bot, text="Ctrl+Q: Exit", bg="#e0e0e0", font=FONT,
                  relief="solid", bd=1, command=self.destroy).place(x=10, y=7, width=110, height=30)
        lnk = tk.Label(bot, text="Video: How to Change Transaction Settings",
                        fg="blue", bg=BG, font=(FONT[0], 9, "underline"), cursor="hand2")
        lnk.place(relx=0.5, rely=0.5, anchor="center")
        tk.Button(bot, text="F12:Save", bg="#e0e0e0", font=FONT,
                  relief="solid", bd=1, command=self._save).place(x=415, y=7, width=110, height=30)

    # ---------------------------------------------------------------------------
    # Tab 1: POS Settings
    # ---------------------------------------------------------------------------
    def _build_pos_tab(self, parent):
        # POS frame
        fr = tk.LabelFrame(parent, text="POS", bg=WHITE, font=FONT, padx=10, pady=8)
        fr.pack(fill="x", padx=10, pady=10)

        # Default Account
        def make_combo_row(frame, label_text, key, default, row, account_type=None):
            tk.Label(frame, text=label_text, bg=WHITE, font=FONT, anchor="w").grid(
                row=row, column=0, sticky="w", pady=3, padx=5)
            var = tk.StringVar(value=self._get(key, default))
            self._vars[key] = var
            # Populate with accounts from DB
            try:
                accs = db.get_all_accounts(account_type)
                vals = [a["name"] for a in accs]
            except:
                vals = [default]
            if default not in vals:
                vals.insert(0, default)
            cb = AutocompleteCombobox(frame, textvariable=var, values=vals, font=FONT, width=25)
            cb.grid(row=row, column=1, sticky="w", padx=5, pady=3)
            return var

        make_combo_row(fr, "Default Account For Creating Invoice:", "pos_default_account", "Cash", 0, "cash")
        make_combo_row(fr, "Default Warehouse For Creating Invoice", "pos_default_warehouse", "Main Location", 1)
        make_combo_row(fr, "Default Sales A/c For Creating Invoice:", "pos_default_sales_ac", "Sales", 2, "sales")

        checkboxes = [
            ("Enable POS System",                        "pos_enable"),
            ("Enter Items First While Making Invoice",   "pos_enter_items_first"),
            ("Increase Quantity While Adding Same Item", "pos_increase_qty"),
            ("Display Cash Tender/Capture Bank details", "pos_cash_tender"),
            ("Print Invoice After Voucher Entry",        "pos_print_after_entry"),
            ("Enable Quick Receipt",                     "pos_quick_receipt"),
            ("View Invoice After Voucher Entry",         "pos_view_after_entry"),
        ]

        defaults = {
            "pos_enable": "0",
            "pos_enter_items_first": "1",
            "pos_increase_qty": "1",
            "pos_cash_tender": "0",
            "pos_print_after_entry": "0",
            "pos_quick_receipt": "1",
            "pos_view_after_entry": "0",
        }

        for i, (lbl, key) in enumerate(checkboxes):
            var = tk.StringVar(value=self._get(key, defaults.get(key, "0")))
            self._vars[key] = var
            cb = tk.Checkbutton(fr, text=lbl, variable=var, onvalue="1", offvalue="0",
                                bg=WHITE, font=FONT, anchor="w")
            cb.grid(row=i + 3, column=0, columnspan=2, sticky="w", pady=1, padx=5)

        video_lbl = tk.Label(parent, text="Video: POS in Book Keeper",
                             fg="blue", bg=WHITE, font=(FONT[0], 9, "underline"), cursor="hand2")
        video_lbl.pack(pady=10)

    # ---------------------------------------------------------------------------
    # Tab 2: Date and Rate
    # ---------------------------------------------------------------------------
    def _build_date_tab(self, parent):
        inner = tk.Frame(parent, bg=WHITE)
        inner.pack(fill="both", expand=True, padx=10, pady=10)

        # Nepali date
        v_nepali = tk.StringVar(value=self._get("date_nepali", "0"))
        self._vars["date_nepali"] = v_nepali
        tk.Checkbutton(inner, text="Enable Nepali Date", variable=v_nepali,
                       onvalue="1", offvalue="0", bg=WHITE, font=FONT).pack(anchor="w", pady=(0, 8))

        # Default Transaction Date
        date_fr = tk.LabelFrame(inner, text="Default Transaction Date", bg=WHITE, font=FONT, padx=10, pady=8)
        date_fr.pack(fill="x", pady=(0, 10))

        v_date_mode = tk.StringVar(value=self._get("date_mode", "current"))
        self._vars["date_mode"] = v_date_mode

        date_options = [
            ("Use Current Date As Default Transaction Date", "current"),
            ("Use Last Voucher Date",                       "last_voucher"),
            ("Use Custom Date",                             "custom"),
        ]

        for lbl, val in date_options:
            row_fr = tk.Frame(date_fr, bg=WHITE)
            row_fr.pack(fill="x", pady=1)
            rb = tk.Radiobutton(row_fr, text=lbl, variable=v_date_mode, value=val,
                                bg=WHITE, font=FONT)
            rb.pack(side="left")
            if val == "custom":
                try:
                    from tkcalendar import DateEntry
                    v_cust = tk.StringVar(value=self._get("date_custom_value", ""))
                    self._vars["date_custom_value"] = v_cust
                    de = DateEntry(row_fr, textvariable=v_cust, width=18,
                                   background='darkblue', foreground='white',
                                   borderwidth=2, font=FONT)
                    de.pack(side="left", padx=10)
                except ImportError:
                    v_cust = tk.StringVar(value=self._get("date_custom_value", ""))
                    self._vars["date_custom_value"] = v_cust
                    tk.Entry(row_fr, textvariable=v_cust, font=FONT, width=18,
                             relief="solid", bd=1).pack(side="left", padx=10)

        # Item Rate/Discount
        rate_fr = tk.LabelFrame(inner, text="Item Rate/Discount", bg=WHITE, font=FONT, padx=10, pady=8)
        rate_fr.pack(fill="x", pady=(0, 10))

        v_rate_mode = tk.StringVar(value=self._get("rate_mode", "customer_supplier"))
        self._vars["rate_mode"] = v_rate_mode

        rate_options = [
            ("Default Rate/Discount from Item Masters",                    "item_master"),
            ("Customer/Supplier Wise Rate/Discount from Last Voucher",     "customer_supplier"),
        ]
        for lbl, val in rate_options:
            tk.Radiobutton(rate_fr, text=lbl, variable=v_rate_mode, value=val,
                           bg=WHITE, font=FONT).pack(anchor="w", pady=1)

        rate_checks = [
            ("Fetch Purchase Rate While Converting Purchase To Sale",              "rate_fetch_purchase"),
            ("Compute Rate Per Unit Of Consumed Item In Manufacturing Journal",    "rate_compute_mfg"),
            ("Enable multiple pricing",                                            "rate_multi_pricing"),
        ]
        for lbl, key in rate_checks:
            var = tk.StringVar(value=self._get(key, "0"))
            self._vars[key] = var
            tk.Checkbutton(rate_fr, text=lbl, variable=var, onvalue="1", offvalue="0",
                           bg=WHITE, font=FONT).pack(anchor="w", pady=1)

    # ---------------------------------------------------------------------------
    # Tab 3: Warnings
    # ---------------------------------------------------------------------------
    def _build_warnings_tab(self, parent):
        inner = tk.Frame(parent, bg=WHITE)
        inner.pack(fill="both", expand=True, padx=10, pady=10)

        warn_fr = tk.LabelFrame(inner, text="Warnings", bg=WHITE, font=FONT, padx=10, pady=8)
        warn_fr.pack(fill="x")

        warnings = [
            ("Display Negative Inventory Warning",                                      "warn_neg_inventory"),
            ("Display Warning For Duplicate Purchase Order No/Supplier Invoice No",     "warn_dup_po"),
            ("Display Warning for Sales Price less than Purchase Price",                "warn_sale_lt_purchase"),
            ("Display Zero Rate Or Zero Quantity Warning In Invoice/Purchase/SR/PR",    "warn_zero_rate_qty"),
            ("Display Confirmation Message To Delete Item",                             "warn_confirm_delete"),
        ]
        for lbl, key in warnings:
            var = tk.StringVar(value=self._get(key, "0"))
            self._vars[key] = var
            tk.Checkbutton(warn_fr, text=lbl, variable=var, onvalue="1", offvalue="0",
                           bg=WHITE, font=FONT, wraplength=450, justify="left").pack(anchor="w", pady=2)

        # Password row
        pwd_fr = tk.Frame(warn_fr, bg=WHITE)
        pwd_fr.pack(anchor="w", fill="x", pady=3)
        v_pwd_chk = tk.StringVar(value=self._get("warn_del_password_enabled", "0"))
        self._vars["warn_del_password_enabled"] = v_pwd_chk
        tk.Checkbutton(pwd_fr, text="Password for deleting transaction",
                       variable=v_pwd_chk, onvalue="1", offvalue="0",
                       bg=WHITE, font=FONT).pack(side="left")
        v_pwd = tk.StringVar(value=self._get("warn_del_password", ""))
        self._vars["warn_del_password"] = v_pwd
        tk.Entry(pwd_fr, textvariable=v_pwd, font=FONT, width=20,
                 relief="solid", bd=1, show="*").pack(side="left", padx=10)

    # ---------------------------------------------------------------------------
    # Tab 4: Misc.
    # ---------------------------------------------------------------------------
    def _build_misc_tab(self, parent):
        inner = tk.Frame(parent, bg=WHITE)
        inner.pack(fill="both", expand=True, padx=10, pady=10)

        misc_items = [
            ("Display Column Of Rate Inclusive Of Tax",                                             "misc_col_rate_incl_tax",  "0"),
            ("Display Column Of Discount Amount",                                                   "misc_col_discount_amt",   "0"),
            ("Display Filter Options In Delivery Note",                                             "misc_filter_delivery",    "0"),
            ("Enable Auto Roundoff While Creating Invoice",                                         "misc_auto_roundoff",      "1"),
            ("Allow Modification Of Sub Total  While Creating Invoice/Purchase (For Admin Only)",   "misc_modify_subtotal",    "1"),
        ]
        for lbl, key, default in misc_items:
            var = tk.StringVar(value=self._get(key, default))
            self._vars[key] = var
            tk.Checkbutton(inner, text=lbl, variable=var, onvalue="1", offvalue="0",
                           bg=WHITE, font=FONT, wraplength=480, justify="left").pack(
                anchor="w", pady=3)

    # ---------------------------------------------------------------------------
    # Tab 5: Voucher Series
    # ---------------------------------------------------------------------------
    def _build_voucher_series_tab(self, parent):
        inner = tk.Frame(parent, bg=WHITE)
        inner.pack(fill="both", expand=True, padx=10, pady=10)

        v_single = tk.StringVar(value=self._get("vs_single_series", "0"))
        self._vars["vs_single_series"] = v_single
        tk.Checkbutton(inner, text="Enable Single Series For Invoicing",
                       variable=v_single, onvalue="1", offvalue="0",
                       bg=WHITE, font=FONT).pack(anchor="w", pady=5)

    # ---------------------------------------------------------------------------
    def _load_settings(self):
        # Settings are loaded lazily in each var's constructor; nothing extra needed.
        pass
