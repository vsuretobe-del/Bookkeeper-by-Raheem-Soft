with open('db.py', 'r', encoding='utf-8') as f:
    content = f.read()

new_methods = '''
def delete_unit(unit_id):
    conn = get_conn()
    conn.execute("DELETE FROM units_measure WHERE id=?", (unit_id,))
    conn.commit()
    conn.close()

def update_unit(unit_id, data):
    conn = get_conn()
    set_clause = ", ".join(f"{k}=?" for k in data.keys())
    query = f"UPDATE units_measure SET {set_clause} WHERE id=?"
    conn.execute(query, tuple(data.values()) + (unit_id,))
    conn.commit()
    conn.close()
'''
with open('db.py', 'w', encoding='utf-8') as f:
    f.write(content + "\n" + new_methods)

print("db updated")
