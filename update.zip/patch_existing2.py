import re

with open('bookkeeper.py', 'r', encoding='utf-8') as f:
    content = f.read()

# Find the end of if existing: block in _item_form
start_marker = "            if existing.get('detail1'):"

start_idx = content.find(start_marker)

if start_idx == -1:
    print("Markers not found")
    exit(1)

new_code = "            calc_inc()\n"

new_content = content[:start_idx] + new_code + content[start_idx:]

with open('bookkeeper.py', 'w', encoding='utf-8') as f:
    f.write(new_content)

print("Patch applied for calc_inc in existing")
