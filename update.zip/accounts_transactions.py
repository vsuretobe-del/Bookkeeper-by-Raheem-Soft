import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
import db
import urllib.parse
import webbrowser
import datetime
from autocomplete import AutocompleteCombobox

FONT = ("Segoe UI", 10)
FONT_BOLD = ("Segoe UI", 10, "bold")
FONT_TITLE = ("Segoe UI", 12, "bold")
FONT_ITALIC = ("Segoe UI", 10, "italic", "bold")
BG = "#f0f0f0"
BG_WHITE = "#ffffff"
HIGHLIGHT_YELLOW = "#3399FF" # Match screenshot selection color
HIGHLIGHT_BLUE = "#0056b3"
WHITE = "#ffffff"
BLUE_SEL = "#0056b3"

class GridTable(tk.Frame):
    def __init__(self, master, columns, widths, alignments, headers, is_acc=False, **kwargs):
        super().__init__(master, bg="#cccccc", **kwargs)
        self.columns = columns
        self.widths = widths
        self.alignments = alignments
        self.headers = headers
        self.is_acc = is_acc
        
        # Build headers
        self.header_fr = tk.Frame(self, bg="#ffffff")
        self.header_fr.pack(fill="x")
        h_height = 36 if any("\n" in str(h) for h in headers) else 28
        
        for idx, (col, w, align, head) in enumerate(zip(columns, widths, alignments, headers)):
            cell = tk.Frame(self.header_fr, bg="#ffffff", width=w, height=h_height)
            cell.pack(side="left", padx=(0, 1), pady=(0, 1))
            cell.pack_propagate(False)
            
            just = "center" if align == "center" else ("left" if align == "w" else "right")
            lbl = tk.Label(cell, text=head, font=FONT_BOLD, bg="#ffffff", fg="#000000", anchor=align, justify=just)
            lbl.pack(fill="both", expand=True, padx=4)

        # Scrollable area
        self.canvas = tk.Canvas(self, bg="#eaeaea", highlightthickness=0)
        self.vsb = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.scroll_fr = tk.Frame(self.canvas, bg="#cccccc")
        
        self.canvas.create_window((0, 0), window=self.scroll_fr, anchor="nw")
        self.canvas.configure(yscrollcommand=self.vsb.set)
        
        self.canvas.pack(side="left", fill="both", expand=True)
        self.vsb.pack(side="right", fill="y")
        
        self.scroll_fr.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        
        # Mousewheel scroll support
        self.canvas.bind_all("<MouseWheel>", self._on_mousewheel)

        self.rows = []
        self.selected_row_idx = None
        self.on_select_callback = None
        self.on_double_click_callback = None
        self.on_right_click_callback = None

    def _on_mousewheel(self, event):
        self.canvas.yview_scroll(int(-1*(event.delta/120)), "units")

    def clear(self):
        for r in self.rows:
            r["frame"].destroy()
        self.rows = []
        self.selected_row_idx = None

    def insert(self, values, tags=(), row_id=None):
        row_idx = len(self.rows)
        row_fr = tk.Frame(self.scroll_fr, bg="#ffffff")
        row_fr.pack(fill="x", pady=(0, 1))
        
        cells = []
        # Group row is shorter, normal rows are taller for multi-line
        r_height = 28 if str(row_id).startswith("__group__") else (36 if self.is_acc else 52)

        for idx, (val, w, align) in enumerate(zip(values, self.widths, self.alignments)):
            cell = tk.Frame(row_fr, bg="#ffffff", width=w, height=r_height)
            cell.pack(side="left", padx=(0, 1))
            cell.pack_propagate(False)
            
            # Special formatting for status tags
            bg = "#ffffff"
            fg = "#000000"
            font = FONT_BOLD if str(row_id).startswith("__group__") else FONT
            
            if idx == 4: # Status column
                if "paid" in tags:
                    bg = "#8cfa42" # Bright green
                    font = FONT_BOLD
                elif "overdue_yellow" in tags:
                    bg = "#ffff33" # Yellow
                elif "overdue_red" in tags:
                    bg = "#ff6666" # Red
                    fg = "#ffffff"
                    font = FONT_BOLD
            
            cell.config(bg=bg)
            
            just_val = "left" if align == "w" else ("right" if align == "e" else "center")
            lbl = tk.Label(cell, text=val, font=font, bg=bg, fg=fg, anchor=align, justify=just_val)
            lbl.pack(fill="both", expand=True, padx=5)
            cells.append((cell, lbl))
            
            # Bind events
            c_binds = [cell, lbl]
            for wgt in c_binds:
                wgt.bind("<Button-1>", lambda e, r=row_idx: self._select_row(r))
                wgt.bind("<Double-Button-1>", lambda e, r=row_idx: self._double_click_row(r))
                wgt.bind("<Button-3>", lambda e, r=row_idx: self._right_click_row(e, r))

        self.rows.append({
            "frame": row_fr,
            "cells": cells,
            "values": values,
            "tags": tags,
            "id": row_id or str(row_idx)
        })
        return row_id or str(row_idx)

    def _select_row(self, row_idx):
        self.selected_row_idx = row_idx
        # Redraw backgrounds
        for idx, r in enumerate(self.rows):
            is_sel = (idx == row_idx)
            for c_idx, (cell, lbl) in enumerate(r["cells"]):
                if is_sel:
                    # Highlight selected row
                    bg = HIGHLIGHT_YELLOW if self.is_acc else HIGHLIGHT_BLUE
                    fg = "#ffffff" if self.is_acc else "#ffffff"
                else:
                    # Reset to default
                    bg = "#ffffff"
                    fg = "#000000"
                    if c_idx == 4: # Status column
                        if "paid" in r["tags"]:
                            bg = "#8cfa42"
                        elif "overdue_yellow" in r["tags"]:
                            bg = "#ffff33"
                        elif "overdue_red" in r["tags"]:
                            bg = "#ff6666"
                            fg = "#ffffff"
                cell.config(bg=bg)
                lbl.config(bg=bg, fg=fg)
                
        if self.on_select_callback:
            self.on_select_callback(self.rows[row_idx]["id"])

    def _double_click_row(self, row_idx):
        self._select_row(row_idx)
        if self.on_double_click_callback:
            self.on_double_click_callback(self.rows[row_idx]["id"])

    def _right_click_row(self, event, row_idx):
        self._select_row(row_idx)
        if self.on_right_click_callback:
            self.on_right_click_callback(event, self.rows[row_idx]["id"])

    def get_selection(self):
        if self.selected_row_idx is not None and self.selected_row_idx < len(self.rows):
            return [self.rows[self.selected_row_idx]["id"]]
        return []

    def set_selection(self, row_id):
        for idx, r in enumerate(self.rows):
            if r["id"] == row_id:
                self._select_row(idx)
                break


class AccountsTransactionsWindow(tk.Toplevel):
    def __init__(self, master, acc_type=None):
        super().__init__(master)
        self.master = master
        self.acc_type = acc_type  # 'customer', 'supplier', or None
        self.title("Accounts/Transactions")
        self.geometry("1300x820")
        self.configure(bg=BG)
        self.state("zoomed")
        self.grab_set()

        self.page = 1
        self.page_size = 50

        self._build_ui()
        self._init_date_filters()
        self._load_accounts()

        # Keyboard Bindings
        self.bind("<Control-q>", lambda e: self.destroy())
        self.bind("<Control-Q>", lambda e: self.destroy())
        self.bind("<F5>", lambda e: self.master._open_payment_supplier())
        self.bind("<F6>", lambda e: self.master._open_receipt_customer())
        self.bind("<F7>", lambda e: self.master._open_journal_voucher())
        self.bind("<F8>", lambda e: self.master._open_create_voucher("sale"))
        self.bind("<F9>", lambda e: self.master._open_create_voucher("purchase"))
        self.bind("<Alt-e>", lambda e: self.master._open_expense_voucher())
        self.bind("<Alt-E>", lambda e: self.master._open_expense_voucher())
        self.bind("<Alt-i>", lambda e: self.master._open_income_voucher())
        self.bind("<Alt-I>", lambda e: self.master._open_income_voucher())
        self.bind("<F4>", lambda e: self.master._open_contra_voucher())
        
        self.bind("<Control-r>", lambda e: self._load_accounts())
        self.bind("<Control-R>", lambda e: self._load_accounts())
        self.bind("<Alt-t>", lambda e: self.master._account_form('tax', callback=self._load_accounts))
        self.bind("<Alt-T>", lambda e: self.master._account_form('tax', callback=self._load_accounts))
        self.bind("<Alt-g>", lambda e: self.master._account_form('tax_group', callback=self._load_accounts))
        self.bind("<Alt-G>", lambda e: self.master._account_form('tax_group', callback=self._load_accounts))
        self.bind("<Alt-a>", lambda e: self.master._account_form(None, callback=self._load_accounts))
        self.bind("<Alt-A>", lambda e: self.master._account_form(None, callback=self._load_accounts))
        self.bind("<Alt-c>", lambda e: self.master._account_form('customer', callback=self._load_accounts))
        self.bind("<Alt-C>", lambda e: self.master._account_form('customer', callback=self._load_accounts))
        self.bind("<Alt-s>", lambda e: self.master._account_form('supplier', callback=self._load_accounts))
        self.bind("<Alt-S>", lambda e: self.master._account_form('supplier', callback=self._load_accounts))

        self.bind("<Alt-p>", lambda e: self._prev_page())
        self.bind("<Alt-P>", lambda e: self._prev_page())
        self.bind("<Alt-n>", lambda e: self._next_page())
        self.bind("<Alt-N>", lambda e: self._next_page())

        self.bind("<F3>", lambda e: self.ent_search.focus_set())

    def _build_ui(self):
        # 1. Top Navigation Bar Frame
        nav_frame = tk.Frame(self, bg="#ffffff", height=32)
        nav_frame.pack(fill="x", side="top")
        
        def nav_btn(text, cmd):
            # Exit cross block matches image
            if "Exit" in text:
                btn_fr = tk.Frame(nav_frame, bg="#ffffff")
                btn_fr.pack(side="left", padx=5, pady=4)
                lbl_x = tk.Label(btn_fr, text="✕", font=("Segoe UI", 9, "bold"), fg="#ffffff", bg="#000000", width=2)
                lbl_x.pack(side="left")
                lbl_x.bind("<Button-1>", lambda e: cmd())
                btn = tk.Button(btn_fr, text="Ctrl+Q: Exit", font=("Segoe UI", 9), bg="#ffffff", activebackground="#dddddd", relief="flat", bd=0, command=cmd)
                btn.pack(side="left", padx=(3, 0))
            else:
                btn = tk.Button(nav_frame, text=text, font=("Segoe UI", 9), bg="#ffffff", activebackground="#dddddd", relief="flat", bd=0, command=cmd)
                btn.pack(side="left", padx=5, pady=4)
            # divider line
            tk.Frame(nav_frame, bg="#cccccc", width=1, height=18).pack(side="left", padx=2, pady=7)

        nav_btn("Exit", self.destroy)
        nav_btn("F5: Payment To Supplier", self.master._open_payment_supplier)
        nav_btn("F6: Receipt From Customer", self.master._open_receipt_customer)
        nav_btn("F7: Journal", self.master._open_journal_voucher)
        nav_btn("F8: Sale/Invoice/Bill", lambda: self.master._open_create_voucher("sale"))
        nav_btn("F9: Purchase", lambda: self.master._open_create_voucher("purchase"))
        nav_btn("Alt+E: Expense", self.master._open_expense_voucher)
        nav_btn("Alt+I: Income", self.master._open_income_voucher)
        nav_btn("F4: Contra", self.master._open_contra_voucher)

        # 2. Search Frame
        search_frame = tk.Frame(self, bg=BG, padx=15, pady=10)
        search_frame.pack(fill="x")
        
        tk.Label(search_frame, text="F3: Search:", font=FONT_BOLD, bg=BG).pack(side="left")
        self.v_search = tk.StringVar()
        self.ent_search = tk.Entry(search_frame, textvariable=self.v_search, font=FONT, width=70, relief="solid", bd=1)
        self.ent_search.pack(side="left", padx=10)
        self.ent_search.bind("<KeyRelease>", lambda e: self._on_search_changed())
        
        btn_search_all = tk.Button(search_frame, text="Search All Vouchers", font=FONT, bg="#e0e0e0", relief="solid", bd=1, padx=10, command=lambda: self.master.show_invoices("all"))
        btn_search_all.pack(side="right")

        # Notices Frame
        notice_frame = tk.Frame(self, bg=BG, padx=15)
        notice_frame.pack(fill="x")
        tk.Label(notice_frame, text="Press ENTER to edit and DELETE to delete", font=FONT_ITALIC, fg="#8b0000", bg=BG).pack(side="left")
        tk.Label(notice_frame, text="Press ENTER for more options. Use ARROW KEYS to move left/right.", font=FONT_ITALIC, fg="#8b0000", bg=BG).pack(side="right")

        # 3. Action Toolbar Frame
        toolbar = tk.Frame(self, bg="#eaeaea", padx=15, pady=5)
        toolbar.pack(fill="x")

        # Left side actions
        t_left = tk.Frame(toolbar, bg="#eaeaea")
        t_left.pack(side="left")
        
        def t_btn(text, cmd):
            return tk.Button(t_left, text=text, font=("Segoe UI", 9), bg="#f5f5f5", relief="groove", bd=1, padx=5, command=cmd).pack(side="left", padx=3)

        t_btn("🔄 Ctrl+R: Reload/Refresh", self._load_accounts)
        t_btn("Alt+T: New Tax Account", lambda: self.master._account_form('tax', callback=self._load_accounts))
        t_btn("Alt+G: Tax Group", lambda: self.master._account_form('tax_group', callback=self._load_accounts))
        t_btn("Alt+A: New Account", lambda: self.master._account_form(None, callback=self._load_accounts))
        t_btn("Alt+C: New Customer", lambda: self.master._account_form('customer', callback=self._load_accounts))
        t_btn("Alt+S: New Supplier", lambda: self.master._account_form('supplier', callback=self._load_accounts))

        # Right side pagination
        self.t_right = tk.Frame(toolbar, bg="#eaeaea")
        self.t_right.pack(side="right")
        
        self.btn_prev = tk.Button(self.t_right, text="◀ Alt+P: Previous Page\n(Newer Transactions)", font=("Segoe UI", 8), bg="#f5f5f5", relief="groove", bd=1, command=self._prev_page)
        self.btn_prev.pack(side="left", padx=5)

        self.lbl_page = tk.Label(self.t_right, text="Displaying page: 1", font=FONT_BOLD, bg="#eaeaea")
        self.lbl_page.pack(side="left", padx=10)

        self.btn_next = tk.Button(self.t_right, text="Alt+N: Next Page ▶\n(Older Transactions)", font=("Segoe UI", 8), bg="#f5f5f5", relief="groove", bd=1, command=self._next_page)
        self.btn_next.pack(side="left", padx=5)

        # 4. Main Body Frame (split panels)
        body = tk.Frame(self, bg=BG)
        body.pack(fill="both", expand=True, padx=15, pady=(5, 15))

        # Left panel: Accounts GridTable
        left_p = tk.Frame(body, bg=BG_WHITE, relief="solid", bd=1, width=615)
        left_p.pack(side="left", fill="both", expand=False)
        left_p.pack_propagate(False)

        # Columns: Account Type, Account Name, Account Balance, Total Balance
        self.acc_tree = GridTable(
            left_p,
            columns=("type", "name", "bal", "total"),
            widths=(150, 205, 120, 120),
            alignments=("w", "w", "e", "e"),
            headers=("Account\nType", "Account Name", "Account\nBalance", "Total\nBalance"),
            is_acc=True
        )
        self.acc_tree.pack(fill="both", expand=True)
        
        self.acc_tree.on_select_callback = self._on_account_selected
        self.acc_tree.on_double_click_callback = lambda row_id: self._on_edit_account()
        self.acc_tree.on_right_click_callback = self._show_context_menu

        # Context Menu for accounts
        self.ctx_menu = tk.Menu(self, tearoff=0, font=FONT)
        self.ctx_menu.add_command(label="Edit", command=self._on_edit_account)
        self.ctx_menu.add_command(label="Delete", command=self._on_delete_account)
        self.ctx_menu.add_separator()
        self.ctx_menu.add_command(label="Send Reminder on WhatsApp", command=self._send_whatsapp)
        self.ctx_menu.add_command(label="Send Reminder SMS", command=self._send_sms)
        self.ctx_menu.add_separator()
        self.ctx_menu.add_command(label="View Ledger", command=self._view_ledger)

        # Right panel: Date filters (PACK FIRST before expanding middle panel!)
        right_p = tk.Frame(body, bg=BG_WHITE, relief="solid", bd=1, width=125)
        right_p.pack(side="right", fill="y", expand=False, padx=(10, 0))
        right_p.pack_propagate(False)
        
        # Year combobox
        self.v_year = tk.StringVar()
        self.cb_year = AutocompleteCombobox(right_p, textvariable=self.v_year, font=("Segoe UI", 9), state="readonly", width=11)
        self.cb_year.pack(fill="x", padx=4, pady=4)
        self.cb_year.bind("<<ComboboxSelected>>", self._on_year_changed)

        # Month listbox
        self.lst_month = tk.Listbox(right_p, font=("Segoe UI", 9), bg=BG_WHITE, relief="solid", bd=1,
                                    selectbackground="#0078d7", selectforeground="#ffffff",
                                    activestyle="none", highlightthickness=0)
        self.lst_month.pack(fill="both", expand=True, padx=4, pady=(0, 4))
        self.lst_month.bind("<<ListboxSelect>>", self._on_month_selected)

        # Middle panel: Transactions GridTable (PACK LAST with expand=True)
        mid_p = tk.Frame(body, bg=BG_WHITE, relief="solid", bd=1)
        mid_p.pack(side="left", fill="both", expand=True, padx=(10, 0))

        # Columns: Date, Accounts, Description, Amount, Status
        self.tx_tree = GridTable(
            mid_p,
            columns=("date", "accs", "desc", "amt", "status"),
            widths=(80, 160, 200, 120, 110),
            alignments=("center", "w", "w", "e", "center"),
            headers=("Date", "Accounts", "Description", "Amount", "Status"),
            is_acc=False
        )
        self.tx_tree.pack(fill="both", expand=True)
        
        self.tx_tree.on_double_click_callback = lambda row_id: self._on_double_click_transaction(row_id)
        self.tx_tree.on_right_click_callback = self._show_context_menu_tx

    def _init_date_filters(self):
        # Fetch available years from vouchers
        conn = db.get_conn()
        rows = conn.execute("SELECT DISTINCT strftime('%Y', date) as yr FROM vouchers ORDER BY yr DESC").fetchall()
        years = [r["yr"] for r in rows if r["yr"]]
        conn.close()

        current_year = datetime.datetime.now().year
        fy_list = []
        for y_str in sorted(years, reverse=True):
            try:
                y = int(y_str)
                fy_list.append(f"{y}-{y+1}")
            except:
                pass
        
        if not fy_list:
            fy_list.append(f"{current_year}-{current_year+1}")

        self.cb_year["values"] = fy_list
        self.cb_year.set(fy_list[0])

        self._update_month_listbox()

    def _update_month_listbox(self):
        self.lst_month.delete(0, "end")
        self.lst_month.insert("end", "All")
        
        fy = self.v_year.get()
        try:
            start_yr = int(fy.split("-")[0])
        except:
            start_yr = datetime.datetime.now().year

        months_pattern = [
            ("Apr", start_yr), ("May", start_yr), ("Jun", start_yr),
            ("Jul", start_yr), ("Aug", start_yr), ("Sep", start_yr),
            ("Oct", start_yr), ("Nov", start_yr), ("Dec", start_yr),
            ("Jan", start_yr+1), ("Feb", start_yr+1), ("Mar", start_yr+1)
        ]
        
        for m, y in months_pattern:
            self.lst_month.insert("end", f"{m}-{y}")

        self.lst_month.selection_set(0)

    def _on_year_changed(self, event=None):
        self._update_month_listbox()
        self._load_transactions()

    def _on_month_selected(self, event=None):
        self.page = 1
        self._load_transactions()

    def _load_accounts(self):
        self.acc_tree.clear()

        accounts = db.get_all_accounts(self.acc_type)
        search_q = self.v_search.get().strip().lower()
        # Group accounts by type
        groups = {}
        for r in accounts:
            if search_q and search_q not in r["name"].lower():
                continue
            g_type = r.get("account_group") or "Other"
            if g_type not in groups:
                groups[g_type] = []
            groups[g_type].append(r)
            
        self.account_dict = {}
        first_row_id = None

        ORDER = [
            "Cash-in-hand", "Bank A/Cs", "Sundry Debtors", "Sundry Creditors",
            "Purchases A/C", "Purchases Return", "Sales A/C", "Sales Return",
            "Capital A/C", "Direct Expenses", "Indirect Expenses",
            "Direct Income", "Indirect Income", "Current Assets",
            "Current Liabilities", "Loans & Advances (Asset)", "Fixed Assets"
        ]
        
        def sort_key(g):
            try:
                return ORDER.index(g[0])
            except ValueError:
                return 999
                
        sorted_groups = sorted(groups.items(), key=sort_key)

        for g_type, acc_list in sorted_groups:
            total_bal = sum(x["balance"] for x in acc_list)
            total_bal_str = f"{total_bal:,.0f}" if total_bal.is_integer() else f"{total_bal:,.2f}"
            
            # Insert Group Header row
            group_id = f"__group__{g_type}"
            self.acc_tree.insert(
                values=(g_type, "", "", total_bal_str),
                row_id=group_id
            )
            if not first_row_id:
                first_row_id = group_id
                
            for r in acc_list:
                bal_str = f"{r['balance']:,.0f}" if r["balance"].is_integer() else f"{r['balance']:,.2f}"
                item_id = self.acc_tree.insert(
                    values=("", r["name"], bal_str, ""),
                    row_id=r["name"]
                )
                self.account_dict[item_id] = r
                
        # Set selection on first group row
        if first_row_id:
            self.acc_tree.set_selection(first_row_id)

    def _on_search_changed(self):
        self._load_accounts()

    def _on_account_selected(self, row_id):
        self.page = 1
        self._load_transactions()

    def _load_transactions(self):
        self.tx_tree.clear()

        sel = self.acc_tree.get_selection()
        if not sel:
            return
        
        acc_name = sel[0]
        start_date, end_date = self._get_date_filter_bounds()

        conn = db.get_conn()
        
        # Calculate pagination offset
        if acc_name.startswith("__group__"):
            group_name = acc_name.replace("__group__", "")
            # Query all accounts in the active category that match the group name
            # Or if it's just 'Other', we might need to handle it, but db.get_all_accounts returns all.
            accounts = db.get_all_accounts(self.acc_type)
            names = [r["name"] for r in accounts if (r.get("account_group") or "Other") == group_name]
            if not names:
                conn.close()
                return
            placeholders = ",".join("?" for _ in names)

            cnt_sql = f"SELECT COUNT(*) FROM vouchers WHERE (debit IN ({placeholders}) OR credit IN ({placeholders}))"
            params = list(names) + list(names)
        else:
            cnt_sql = "SELECT COUNT(*) FROM vouchers WHERE (debit=? OR credit=?)"
            params = [acc_name, acc_name]

        if start_date and end_date:
            cnt_sql += " AND date >= ? AND date <= ?"
            params.extend([start_date, end_date])
            
        total_count = conn.execute(cnt_sql, params).fetchone()[0]
        
        # Query page
        if acc_name.startswith("__group__"):
            group_name = acc_name.replace("__group__", "")
            accounts = db.get_all_accounts(self.acc_type)
            names = [r["name"] for r in accounts if (r.get("account_group") or "Other") == group_name]
            placeholders = ",".join("?" for _ in names)
            
            sql = f"""
                SELECT v_id, vch_no, v_type, date, debit, credit, amount, paid_amount, status
                FROM vouchers 
                WHERE (debit IN ({placeholders}) OR credit IN ({placeholders}))
            """
            q_params = list(names) + list(names)
        else:
            sql = """
                SELECT v_id, vch_no, v_type, date, debit, credit, amount, paid_amount, status
                FROM vouchers 
                WHERE (debit=? OR credit=?)
            """
            q_params = [acc_name, acc_name]

        if start_date and end_date:
            sql += " AND date >= ? AND date <= ?"
            q_params.extend([start_date, end_date])
            
        sql += " ORDER BY date DESC, v_id DESC LIMIT ? OFFSET ?"
        
        q_params = list(params)
        q_params.extend([self.page_size, (self.page - 1) * self.page_size])
        
        rows = conn.execute(sql, q_params).fetchall()
        conn.close()

        # Update display details
        self.lbl_page.config(text=f"Displaying page: {self.page}")
        self.btn_prev.config(state="normal" if self.page > 1 else "disabled")
        self.btn_next.config(state="normal" if self.page * self.page_size < total_count else "disabled")

        self.tx_dict = {}
        for idx, r in enumerate(rows):
            date_val = r["date"]
            accs_val = f"{r['debit']}\n{r['credit']}"
            
            type_lbl = r["v_type"].title() if r["v_type"] else "Voucher"
            type_map = {
                "sale": "Sales", "purchase": "Purchase", "receipt": "Receipt",
                "payment": "Payment", "journal": "Journal", "contra": "Contra",
                "expense": "Expense", "income": "Income", "credit_note": "Credit Note",
                "debit_note": "Debit Note", "purchase_order": "Purchase Order", "estimate": "Estimate"
            }
            type_lbl = type_map.get(r["v_type"], type_lbl)
            desc_val = f"{type_lbl}\nVoucher No:{r['vch_no']}"
            
            amt = r["amount"]
            amt_str = f"{amt:,.0f}" if amt.is_integer() else f"{amt:,.2f}"

            status_text = ""
            status_tag = ""
            v_type = r["v_type"]
            paid_amt = r["paid_amount"] or 0.0

            if v_type in ('purchase_order', 'estimate'):
                raw_st = str(r["status"] or "OPEN").strip().upper()
                status_text = raw_st if raw_st else "OPEN"
                status_tag = "paid" if status_text == "CLOSED" else "open"
            elif v_type in ('sale', 'credit_note', 'journal'):
                if paid_amt >= amt:
                    status_text = "Paid"
                    status_tag = "paid"
                else:
                    date_str = r["date"]
                    try:
                        due_dt = datetime.datetime.strptime(date_str, "%Y-%m-%d").date()
                        today = datetime.date.today()
                        if today > due_dt:
                            diff = (today - due_dt).days
                            status_text = f"Overdue by\n{diff} days"
                            status_tag = "overdue_yellow"
                    except Exception as e:
                        pass
            elif v_type in ('purchase', 'debit_note'):
                if paid_amt >= amt:
                    status_text = "Paid"
                    status_tag = "paid"
                else:
                    date_str = r["date"]
                    try:
                        due_dt = datetime.datetime.strptime(date_str, "%Y-%m-%d").date()
                        today = datetime.date.today()
                        if today > due_dt:
                            diff = (today - due_dt).days
                            status_text = f"Overdue by\n{diff} days"
                            status_tag = "overdue_red"
                    except Exception as e:
                        pass

            item_id = self.tx_tree.insert(
                values=(date_val, accs_val, desc_val, amt_str, status_text),
                tags=(status_tag),
                row_id=str(r["v_id"])
            )
            self.tx_dict[item_id] = r

        # Set default active row in transactions grid
        tx_children = [r["id"] for r in self.tx_tree.rows]
        if tx_children:
            self.tx_tree.set_selection(tx_children[0])

    def _get_date_filter_bounds(self):
        sel_idx = self.lst_month.curselection()
        if not sel_idx:
            return None, None
        
        sel_text = self.lst_month.get(sel_idx[0])
        if sel_text == "All":
            fy = self.v_year.get()
            try:
                start_yr = int(fy.split("-")[0])
                return f"{start_yr}-04-01", f"{start_yr+1}-03-31"
            except:
                return None, None

        try:
            m_str, y_str = sel_text.split("-")
            month_num = datetime.datetime.strptime(m_str, "%b").month
            year = int(y_str)
            start = f"{year}-{month_num:02d}-01"
            if month_num == 12:
                end = f"{year}-12-31"
            else:
                next_m = datetime.date(year, month_num + 1, 1)
                last_day = next_m - datetime.timedelta(days=1)
                end = last_day.strftime("%Y-%m-%d")
            return start, end
        except:
            return None, None

    def _prev_page(self):
        if self.page > 1:
            self.page -= 1
            self._load_transactions()

    def _next_page(self):
        self.page += 1
        self._load_transactions()

    def _show_context_menu(self, event, row_id):
        if str(row_id).startswith("__group__"):
            return
        self.ctx_menu.post(event.x_root, event.y_root)

    def _show_context_menu_tx(self, event, row_id):
        r = self.tx_dict.get(row_id)
        if not r: return
        
        menu = tk.Menu(self, tearoff=0)
        
        v_type = r["v_type"] or "voucher"
        view_text = "View " + v_type.replace("_", " ").title()
        
        menu.add_command(label="Edit", command=lambda: self._edit_transaction(row_id))
        
        def do_delete():
            if messagebox.askyesno("Delete", f"Are you sure you want to delete {v_type.title()} {r['vch_no']}?"):
                try:
                    db.delete_voucher(r['vch_no'])
                    self._load_transactions()
                except Exception as e:
                    messagebox.showerror("Error", str(e))
                    
        menu.add_command(label="Delete", command=do_delete)
        
        def do_cancel():
            if messagebox.askyesno("Cancel", f"Are you sure you want to cancel {v_type.title()} {r['vch_no']}?"):
                try:
                    db.cancel_voucher(r['vch_no'])
                    self._load_transactions()
                except Exception as e:
                    messagebox.showerror("Error", str(e))
                    
        menu.add_command(label="Cancel", command=do_cancel)
        menu.add_command(label="Create Duplicate", command=lambda: messagebox.showinfo("Info", "Duplicate feature coming soon!"))
        menu.add_command(label="Make Recurring", command=lambda: messagebox.showinfo("Info", "Recurring feature coming soon!"))
        menu.add_separator()
        menu.add_command(label=view_text, command=lambda: self._edit_transaction(row_id))
        
        menu.tk_popup(event.x_root, event.y_root)

    def _on_edit_account(self):
        sel = self.acc_tree.get_selection()
        if not sel or str(sel[0]).startswith("__group__"):
            return
        acc_name = sel[0]
        conn = db.get_conn()
        row = conn.execute("SELECT * FROM account_detail WHERE aname=?", (acc_name)).fetchone()
        conn.close()

        if row:
            acc_data = dict(row)
            acc_data["id"] = acc_data["aname"]
            acc_data["name"] = acc_data["aname"]
            acc_data["type"] = acc_data.get("account_group") or acc_data.get("type")
            acc_data["balance"] = acc_data["cl_bal"]
            
            grp = acc_data.get("account_group") or acc_data.get("type")
            if self.acc_type in ['customer', 'supplier']:
                form_type = self.acc_type
            elif grp == "Sundry Debtors":
                form_type = "customer"
            elif grp == "Sundry Creditors":
                form_type = "supplier"
            else:
                form_type = None
            
            self.master._account_form(form_type, existing=acc_data, callback=self._load_accounts)

    def _on_delete_account(self):
        sel = self.acc_tree.get_selection()
        if not sel or str(sel[0]).startswith("__group__"):
            return
        acc_name = sel[0]
        if messagebox.askyesno("Confirm Delete", f"Are you sure you want to delete the account '{acc_name}'?"):
            db.delete_account(acc_name)
            self._load_accounts()

    def _send_whatsapp(self):
        sel = self.acc_tree.get_selection()
        if not sel or str(sel[0]).startswith("__group__"):
            return
        acc_name = sel[0]
        conn = db.get_conn()
        row = conn.execute("SELECT phone, cl_bal FROM account_detail WHERE aname=?", (acc_name)).fetchone()
        conn.close()
        
        phone = ""
        bal = 0.0
        if row:
            phone = row["phone"] or ""
            bal = row["cl_bal"] or 0.0

        phone = simpledialog.askstring("WhatsApp Reminder", "Enter WhatsApp Phone Number (with country code):", initialvalue=phone, parent=self)
        if phone:
            message = f"Dear Customer, your outstanding balance with us is {bal:,.2f}. Please settle it at your earliest convenience. Thank you!"
            link = f"https://web.whatsapp.com/send?phone={phone}&text={urllib.parse.quote(message)}"
            webbrowser.open(link)

    def _send_sms(self):
        sel = self.acc_tree.get_selection()
        if not sel or str(sel[0]).startswith("__group__"):
            return
        acc_name = sel[0]
        conn = db.get_conn()
        row = conn.execute("SELECT phone, cl_bal FROM account_detail WHERE aname=?", (acc_name)).fetchone()
        conn.close()
        
        phone = ""
        bal = 0.0
        if row:
            phone = row["phone"] or ""
            bal = row["cl_bal"] or 0.0

        phone = simpledialog.askstring("SMS Reminder", "Enter Customer Mobile Number:", initialvalue=phone, parent=self)
        if phone:
            msg = f"Dear Customer, your outstanding balance is {bal:,.2f}. Please settle it at your earliest. Thank you!"
            messagebox.showinfo("SMS Sent", f"Reminder SMS text generated:\n\n\"{msg}\"\n\nSMS successfully routed to gateway!", parent=self)

    def _view_ledger(self):
        sel = self.acc_tree.get_selection()
        if not sel or str(sel[0]).startswith("__group__"):
            return
        acc_name = sel[0]
        LedgerWindow(self, acc_name)

    def _on_double_click_transaction(self, row_id):
        self._edit_transaction(row_id)

    def _edit_transaction(self, row_id):
        r = self.tx_dict.get(row_id)
        if not r:
            return
        
        v_type = r["v_type"]
        vch_no = r["vch_no"]

        if v_type == "expense":
            self.master._open_expense_voucher(existing_vch=vch_no)
        elif v_type == "income":
            self.master._open_income_voucher(existing_vch=vch_no)
        elif v_type == "contra":
            self.master._open_contra_voucher(existing_vch=vch_no)
        elif v_type == "payment":
            self.master._open_payment_supplier(existing_vch=vch_no)
        elif v_type == "receipt":
            self.master._open_receipt_customer(existing_vch=vch_no)
        elif v_type == "journal":
            self.master._open_journal_voucher(existing_vch=vch_no)
        elif v_type == "credit_note":
            self.master._open_credit_note_window(existing_vch=vch_no)
        elif v_type == "debit_note":
            self.master._open_debit_note_window(existing_vch=vch_no)
        elif v_type == "purchase":
            self.master._open_purchase_window(existing_vch=vch_no)
        elif v_type == "sale":
            self.master._open_sale_window(existing_vch=vch_no)
        elif v_type == "estimate":
            self.master._open_estimate_window(existing_vch=vch_no)
        elif v_type == "purchase_order":
            self.master._open_purchase_order_window(existing_vch=vch_no)
        else:
            self.master._open_create_voucher(v_type, existing_vch=vch_no)


class LedgerWindow(tk.Toplevel):
    def __init__(self, master, account_name):
        super().__init__(master)
        self.account_name = account_name
        self.title(f"Ledger Statement - {account_name}")
        self.geometry("950x600")
        self.configure(bg=BG)
        self.grab_set()
        self.transient(master)

        self._build_ui()
        self._load_ledger_data()

        # Keybinds
        self.bind("<Control-q>", lambda e: self.destroy())
        self.bind("<Control-Q>", lambda e: self.destroy())
        self.bind("<F12>", lambda e: self.destroy())

    def _build_ui(self):
        tk.Label(self, text=f"Account Statement/Ledger: {self.account_name}", font=FONT_TITLE, bg=BG).pack(pady=15)

        tbl_frame = tk.Frame(self, bg=BG_WHITE, relief="solid", bd=1)
        tbl_frame.pack(fill="both", expand=True, padx=25, pady=(5, 10))

        # Ledger spreadsheet style table
        self.tree = GridTable(
            tbl_frame,
            columns=("date", "vch", "type", "debit", "credit", "bal"),
            widths=(100, 110, 120, 130, 130, 150),
            alignments=("center", "center", "w", "e", "e", "e"),
            headers=("Date", "Voucher No", "Type", "Debit (Dr)", "Credit (Cr)", "Running Balance"),
            is_acc=True
        )
        self.tree.pack(fill="both", expand=True)

        bot = tk.Frame(self, bg=BG)
        bot.pack(fill="x", side="bottom")

        btn_exit = tk.Button(bot, text="Ctrl+Q: Exit", font=FONT, bg="#e0e0e0", relief="solid", bd=1, width=15, command=self.destroy)
        btn_exit.pack(side="left", padx=25, pady=10)

        self.lbl_final_bal = tk.Label(bot, text="Final Closing Balance: 0.00", font=FONT_TITLE, bg=BG, fg="#0056b3")
        self.lbl_final_bal.pack(side="right", padx=25, pady=10)

    def _load_ledger_data(self):
        conn = db.get_conn()
        rows = conn.execute("""
            SELECT v_id, vch_no, v_type, date, debit, credit, amount
            FROM vouchers 
            WHERE debit=? OR credit=? 
            ORDER BY date ASC, v_id ASC
        """, (self.account_name, self.account_name)).fetchall()
        conn.close()

        running_bal = 0.0
        self.tree.clear()

        for r in rows:
            amt = r["amount"]
            dr_amt = 0.0
            cr_amt = 0.0

            if r["debit"] == self.account_name:
                dr_amt = amt
                running_bal += amt
            else:
                cr_amt = amt
                running_bal -= amt

            dr_str = f"{dr_amt:,.2f}" if dr_amt > 0 else ""
            cr_str = f"{cr_amt:,.2f}" if cr_amt > 0 else ""
            bal_str = f"{running_bal:,.2f}"

            v_type = r["v_type"].title()
            type_map = {
                "sale": "Sales", "purchase": "Purchase", "receipt": "Receipt",
                "payment": "Payment", "journal": "Journal", "contra": "Contra",
                "expense": "Expense", "income": "Income", "credit_note": "Credit Note",
                "debit_note": "Debit Note"
            }
            v_type = type_map.get(r["v_type"], v_type)

            self.tree.insert(
                values=(
                    r["date"],
                    r["vch_no"],
                    v_type,
                    dr_str,
                    cr_str,
                    bal_str
                ),
                row_id=str(r["v_id"])
            )

        self.lbl_final_bal.config(text=f"Final Closing Balance: {running_bal:,.2f}")
